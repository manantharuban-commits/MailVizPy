---
name: boardroom-pptx
description: "Build modern, visually polished PowerPoint decks for senior executive audiences — CEO, CFO, CDAO, board and regulatory committees — with a designed colour palette, matched typography, semantic Bootstrap icons, native editable charts, KPI dashboards and an evidence-based information-loss check. Use this skill whenever the user asks for a PowerPoint, .pptx, deck, slides, presentation, board pack, executive review, KPI dashboard slide, results pack or steering-committee update, and also whenever they hand over raw text, a report, an email, a spreadsheet or query output and ask for it to be turned into slides or visualised. Use it for any request mentioning modern slide design, colour palettes or themes for presentations, chart libraries for decks, slide animation or transitions, or professional business English in slides. Prefer this skill over plain pptxgenjs or python-pptx for anything an executive will read."
license: Proprietary
---

# Boardroom PPTX

A design system, component library and working method for decks that a chief
executive will read in eight minutes and question for forty.

The library is JavaScript on top of `pptxgenjs`, so every chart is a **native
PowerPoint chart** the finance team can click into and edit. Nothing is
delivered as a flattened picture of a chart.

```
boardroom-pptx/
├── SKILL.md                      you are here — workflow and rules
├── lib/
│   ├── theme.js                  7 palettes, 6 font pairings, grid, status, contrast
│   ├── charts.js                 14 native chart presets
│   ├── components.js             KPI cards, bridge, heat grid, funnel, timeline, tables
│   ├── icons.js                  2,078 verified Bootstrap icons + concept matching
│   ├── animate.js                opt-in animation and transitions
│   └── deck.js                   deck factory, slide archetypes, footers, page numbers
├── references/                   read the one you need, when you need it
├── scripts/                      verification tools
├── assets/                       bundled icon manifest
└── demo/build-demo.js            a complete eight-slide worked example
```

---

## The ten rules

These are not preferences. A deck that breaks one of them goes back.

1. **Extract before you design.** Build the fact ledger first, then decide what
   becomes a KPI, a chart or a sentence. Never open the builder with an
   un-inventoried source.
2. **Zero information loss.** Every fact in the source lands somewhere — a
   slide, an appendix, or a documented, deliberate exclusion. Verified by
   `scripts/coverage_audit.py`, not by memory.
3. **Every data point is printed.** If a number is plotted, it is also written.
   An executive should never have to measure a bar against an axis.
4. **One theme, no strays.** One palette, one font pairing, for the whole deck.
   No colour and no typeface that is not in the chosen theme.
5. **Achievement is a signal, not a decoration.** The positive colour, the
   solid badge and the raised elevation mean "target met" and nothing else.
6. **One concept, one icon; one icon, one concept.** No glyph appears twice in
   a deck for two different things. Status glyphs are the sole exception.
7. **The title is the finding.** A full sentence stating what the evidence
   shows, not a label naming the subject.
8. **Provenance on every slide.** Source, as-at date, and classification.
9. **Animation is off unless asked for.** And it never carries meaning that the
   printed slide loses.
10. **Verify before delivering.** Schema validation, then render to images and
    look at every slide.

---

## Workflow

### Step 1 — Extract

Read the source and write a numbered ledger before designing anything. One line
per fact, verbatim, with its number and unit intact.

```
F01  NII H1 FY26 = ₹4,286 Cr
F02  NII H1 FY25 = ₹3,954 Cr
F03  NIM = 3.82%, plan 3.75%
F04  Cost-to-income = 41.2%, plan 40.0%, prior year 42.8%
F05  Caveat: management accounts, unaudited
...
```

Include the awkward material: caveats, exclusions, one-off items, footnotes,
dissenting views. Those are exactly the facts that get lost in translation to
slides, and exactly the ones a board member asks about.

Save the ledger as `ledger.txt` — `coverage_audit.py` reads it in Step 5.

### Step 2 — Plan the visuals

Classify each fact before choosing a chart. The question the fact answers
determines the visual; see `references/chart-library.md` for the full chooser.

| The fact is… | It becomes… |
|---|---|
| A headline measure against a target | KPI card, with status |
| A movement between two totals | Variance bridge |
| A measure over five or more periods | Line or column trend |
| A ranking across categories | Horizontal ranked bars |
| A composition of a whole | Stacked bar, or a donut for 3–5 parts |
| Two measures on different scales | Dual-axis combo |
| A status across a portfolio | Heat grid |
| A sequence of stages with attrition | Funnel |
| Dates with delivery status | Milestone timeline |
| A judgement, caveat or recommendation | Sentence — in a callout, not a chart |

Then draw the deck on one page before writing code: slide number, title
assertion, the visual, and the facts it carries. Aim for **one message per
slide** and no more than **six objects** on it.

### Step 3 — Choose the theme

Default to **Meridian Navy** with **Boardroom Classic** unless the user has a
brand palette or a stated preference. Both are safe for banking audiences and
render reliably in QA.

```js
const { createDeck } = require('./lib/deck');
const deck = createDeck({ palette: 'meridian-navy', fonts: 'boardroom-classic' });
const t = deck.theme;   // every colour, font and grid value comes from here
```

All seven palettes and six pairings, with every hex value and the guidance on
which to pick, are in `references/design-system.md`. **Read it before choosing.**

### Step 4 — Build

```js
const { createDeck } = require('./lib/deck');
const { IconLedger, png } = require('./lib/icons');
const C = require('./lib/components');
const charts = require('./lib/charts');

const deck = createDeck({
  palette: 'meridian-navy',
  fonts: 'boardroom-classic',
  meta: {
    title: 'Half-year performance review',
    company: 'Meridian Bank',
    classification: 'Confidential — Internal use only',
    asOf: '30 June 2026',
    source: 'Group Finance and the Data Office',
  },
});
const t = deck.theme;
const L = new IconLedger();          // one ledger per deck — this is what stops repeats

deck.titleSlide({ title: '…', subtitle: '…', audience: '…' });

const s = deck.kpiBandSlide({
  kicker: 'Executive summary',
  title: 'Net interest margin exceeded target while the cost ratio drifted wide',
  subtitle: 'Four of six board measures met plan at the half year.',
  cards: [{
    label: 'Net interest margin',
    value: '3.82%',
    delta: '+7 bps vs plan', deltaTone: 'positive',
    target: 'Plan 3.75%',
    status: 'achieved',
    iconPng: await png(L.pick('Net interest margin'), t.inkInverse, 96),
    badgeIconPng: await png(t.status.achieved.icon, t.inkInverse, 96),
  }],
});

charts.trendLine(deck.pptx, s, t, { x: 0.55, y: s.contentTop, w: 8, h: 3.6, … });

await deck.save('deck.pptx');        // stamps footers and page numbers
```

`slide.contentTop` is where content may begin on that slide — the title band
measures itself, so a two-line title pushes content down instead of colliding
with it. Always position from `slide.contentTop`, never from a hard-coded `y`.

Slide archetypes, exact geometry and worked layouts: `references/slide-patterns.md`.
Component and chart signatures: `references/chart-library.md`.
Icon selection rules: `references/icon-system.md`.
Writing the words: `references/language-standards.md`.

### Step 5 — Verify no information was lost

```bash
python3 scripts/coverage_audit.py ledger.txt deck.pptx
```

It extracts every number, percentage, currency figure and date from the source
ledger, extracts the same from the built deck, and reports what is missing. A
clean run prints `COVERAGE: 100%`. Anything less is either placed on a slide,
moved to an appendix, or recorded in the exclusions file with a reason.

It also flags **numbers that appear in the deck but not in the source** — an
invented figure is a worse failure than a dropped one.

### Step 6 — Validate and look at it

```bash
python3 /mnt/skills/public/pptx/scripts/office/validate.py deck.pptx
python3 /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf deck.pptx
rm -f slide-*.jpg && pdftoppm -jpeg -r 110 deck.pdf slide
```

Then open every image and check it. The full defect list is in
`references/qa-protocol.md`; the four that appear most often are text
overflowing its box, labels landing on a fill they cannot be read against,
elements closer than 0.3 inches, and a footer colliding with content above it.

### Step 7 — Animate, only if asked

Default is no animation. If the user asks:

```js
const { applyAnimations, revealSequence } = require('./lib/animate');
applyAnimations('deck.pptx', {
  2: { transition: 'fade', steps: revealSequence(['kpi-1','kpi-2','kpi-3','kpi-4']) },
  3: { transition: 'morph' },
});
```

Shapes must carry `objectName` at build time to be targetable. The effect
catalogue and the restraint rules are in `references/animation.md`.

---

## Quick reference

### Palettes

| Key | Name | Mode | Use it for |
|---|---|---|---|
| `meridian-navy` | Meridian Navy | light | **Default.** Board packs, results, any bank executive audience |
| `graphite-teal` | Graphite Teal | light | Data, technology, CDAO material |
| `oxford-indigo` | Oxford Indigo | light | Strategy, transformation, multi-year roadmaps |
| `burgundy-ledger` | Burgundy Ledger | light | Private banking, wealth, annual reviews |
| `porcelain-steel` | Porcelain Steel | light | Printed board packs, greyscale reproduction |
| `charcoal-copper` | Charcoal Copper | dark | Dark premium deck, or dark title and closing slides |
| `midnight-sapphire` | Midnight Sapphire | dark | Investor days, town halls, large-room projection |

No palette uses green as its dominant colour, so green always means one thing:
target met.

### Font pairings

| Key | Display / Body | QA-safe | Use it for |
|---|---|---|---|
| `boardroom-classic` | Cambria / Calibri | yes | **Default.** Serif authority, familiar body |
| `institutional-sans` | Arial / Arial | yes | Locked-down desktops, external distribution |
| `regulatory-serif` | Century Schoolbook / Calibri | yes | Audit, risk, regulatory documents |
| `ledger-book` | Bookman Old Style / Calibri | yes | Annual review, heritage material |
| `modern-grotesque` | Segoe UI Semibold / Segoe UI | no | Windows-only product and technology decks |
| `editorial-contrast` | Georgia / Segoe UI | no | Narrative decks for a known audience |

"QA-safe" means the LibreOffice preview matches the real widths, so overflow
checks are trustworthy. For the other two, leave about 10% slack and do not
trust the preview on text fit.

### Status vocabulary

| Key | Label | Colour | Glyph |
|---|---|---|---|
| `achieved` | Achieved | positive | `patch-check-fill` |
| `onTrack` | On track | primary | `circle-half` |
| `atRisk` | At risk | warning | `exclamation-triangle-fill` |
| `offTrack` | Off track | negative | `x-octagon-fill` |
| `notStarted` | Not started | neutral | `circle` |

Every status carries a glyph as well as a colour, so the deck still reads when
printed in black and white or viewed by a colour-blind reader.

### The achievement treatment

When `status: 'achieved'`, a KPI card changes in five ways at once:

- fill moves to the positive wash
- border thickens to 1.25pt in the positive colour
- the value itself is set in the positive colour
- elevation deepens to the `highlight` shadow
- the badge becomes solid, with the check glyph reversed out

Reserve it for genuine attainment against a stated target. Applied to anything
else, it stops meaning anything at all.

---

## Reference documents

Read these as you need them. Do not read all of them at the start.

| File | Read it when |
|---|---|
| `references/design-system.md` | Choosing or extending a palette, setting type, spacing anything |
| `references/slide-patterns.md` | Laying out a slide — twelve archetypes with exact geometry |
| `references/chart-library.md` | Choosing a visual, or calling any chart or component |
| `references/icon-system.md` | Picking icons, adding concepts, resolving a repeat |
| `references/language-standards.md` | Writing any word that appears on a slide |
| `references/animation.md` | The user has asked for animation or transitions |
| `references/qa-protocol.md` | Before delivery, every time |

## Scripts

| Script | What it does |
|---|---|
| `scripts/coverage_audit.py ledger.txt deck.pptx` | Information-loss audit in both directions |
| `scripts/verify-icons.js` | Checks every concept candidate against the manifest |
| `node demo/build-demo.js out.pptx` | Builds the worked example |

## Dependencies

`pptxgenjs` and `sharp` (both preinstalled — install only if a `require`
fails), Python 3 with `python-pptx` for the audit, and `unzip`/`zip` for
animation. Icons are fetched from `raw.githubusercontent.com` and cached in
`.icon-cache/`; the manifest in `assets/` is bundled, so name validation works
with no network at all.
