#!/usr/bin/env node
/**
 * verify-icons.js — guard against 404s and thin candidate lists.
 * Run after any edit to CONCEPTS in lib/icons.js.
 */
'use strict';
const I = require('../lib/icons');

const bad = I.auditConcepts();
const concepts = Object.entries(I.CONCEPTS);
const thin = concepts.filter(([, v]) => v.length < 4).map(([k, v]) => `${k} (${v.length})`);

const first = {};
concepts.forEach(([k, v]) => { (first[v[0]] = first[v[0]] || []).push(k); });
const shared = Object.entries(first).filter(([, ks]) => ks.length > 1);

console.log(`Manifest      : ${I.MANIFEST.count} icons (${I.MANIFEST.library})`);
console.log(`Concepts      : ${concepts.length}`);
console.log(`Invalid names : ${bad.length}`);
bad.forEach((b) => console.log(`  ${b.concept} -> "${b.icon}"  nearest: ${I.nearest(b.icon).join(', ') || '(none)'}`));
console.log(`Thin lists    : ${thin.length}${thin.length ? '  ' + thin.join(', ') : ''}`);
console.log(`Shared first choice: ${shared.length} (resolved by the ledger, not an error)`);
shared.forEach(([icon, ks]) => console.log(`  ${icon} <- ${ks.join(', ')}`));

process.exit(bad.length === 0 && thin.length === 0 ? 0 : 1);
