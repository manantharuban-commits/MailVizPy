#!/usr/bin/env python3
"""
coverage_audit.py — prove that nothing was lost on the way into the deck.

    python3 scripts/coverage_audit.py ledger.txt deck.pptx
    python3 scripts/coverage_audit.py ledger.txt deck.pptx --exclusions excluded.txt
    python3 scripts/coverage_audit.py ledger.txt deck.pptx --json report.json

The audit runs in both directions:

  FORWARD   every fact in the ledger must appear in the deck, on a slide or in
            the appendix, or be listed in the exclusions file with a reason.
            A fact that is silently dropped is the failure this exists to catch.

  REVERSE   every figure in the deck should trace back to the ledger. A number
            that appears on a slide and nowhere in the source is either derived
            (a percentage the deck computed) or invented. Invented numbers are
            worse than missing ones, so they are reported for review rather
            than ignored.

The deck is read from three places, because slide text alone is not the whole
deck: shape text, table cells, and the cached values inside native charts.

Exit status is 0 only when forward coverage is 100%.
"""

import argparse
import json
import os
import re
import sys
import zipfile
from xml.etree import ElementTree as ET

try:
    from pptx import Presentation
except ImportError:
    sys.exit("python-pptx is required:  pip install python-pptx --break-system-packages")

# A number with optional sign, thousands separators (western or Indian) and decimals.
NUM_RE = re.compile(r"[-+\u2212]?\d+(?:[,\u00A0]\d{2,3})*(?:\.\d+)?")
WORD_RE = re.compile(r"[A-Za-z][A-Za-z\-']+")

STOPWORDS = {
    "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "by", "at", "as",
    "is", "are", "was", "were", "be", "been", "with", "from", "that", "this", "it",
    "has", "have", "had", "will", "would", "there", "their", "its", "vs", "versus",
}

# Numbers that are structural rather than factual and must not raise a reverse flag.
STRUCTURAL = set(range(0, 13)) | {2020.0, 2021.0, 2022.0, 2023.0, 2024.0,
                                  2025.0, 2026.0, 2027.0, 2028.0, 2029.0, 2030.0}


def to_float(tok):
    t = tok.replace(",", "").replace("\u00A0", "").replace("\u2212", "-")
    try:
        return float(t)
    except ValueError:
        return None


def numbers_in(text):
    out = set()
    for m in NUM_RE.finditer(text or ""):
        v = to_float(m.group())
        if v is not None:
            out.add(round(v, 6))
    return out


def words_in(text):
    return {w.lower() for w in WORD_RE.findall(text or "") if w.lower() not in STOPWORDS}


# --------------------------------------------------------------------------- #
# Reading the deck                                                            #
# --------------------------------------------------------------------------- #

def deck_text(path):
    """All visible text: shapes, grouped shapes, tables, speaker notes."""
    prs = Presentation(path)
    chunks = []

    def walk(shapes):
        for sh in shapes:
            if sh.shape_type == 6 and hasattr(sh, "shapes"):      # group
                walk(sh.shapes)
                continue
            if sh.has_text_frame:
                chunks.append(sh.text_frame.text)
            if getattr(sh, "has_table", False):
                for row in sh.table.rows:
                    for cell in row.cells:
                        chunks.append(cell.text)

    for slide in prs.slides:
        walk(slide.shapes)
        if slide.has_notes_slide:
            chunks.append(slide.notes_slide.notes_text_frame.text)
    return "\n".join(chunks)


def chart_values(path):
    """Cached series values and category labels inside native charts."""
    vals, labels = set(), []
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not (name.startswith("ppt/charts/chart") and name.endswith(".xml")):
                continue
            root = ET.fromstring(z.read(name))
            for el in root.iter():
                if el.tag.endswith("}v") and el.text:
                    v = to_float(el.text.strip())
                    if v is not None:
                        vals.add(round(v, 6))
                    else:
                        labels.append(el.text.strip())
    return vals, "\n".join(labels)


# --------------------------------------------------------------------------- #
# Matching                                                                    #
# --------------------------------------------------------------------------- #

def covered(value, pool):
    """
    A ledger figure counts as present if the deck carries it exactly, or carries
    a legitimately rounded form of it (3.82 shown as 3.8), or carries it at a
    different scale (4286 shown as 4.3 in a chart labelled 'thousands').
    """
    if value in pool:
        return "exact"
    tol = max(abs(value) * 0.005, 0.01)
    if any(abs(value - p) <= tol for p in pool):
        return "exact"
    for dp in (0, 1, 2):
        if round(value, dp) in pool:
            return "rounded"
    if abs(value) >= 1000:
        for scale in (1000.0, 1000000.0):
            s = value / scale
            if s >= 1 and (round(s, 2) in pool or round(s, 1) in pool):
                return "scaled"
    return None


def parse_ledger(path):
    facts = []
    for raw in open(path, encoding="utf-8"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^([A-Za-z]{1,3}\d{1,3})[\s.:)\-]+(.*)$", line)
        fid, text = (m.group(1), m.group(2)) if m else (f"L{len(facts) + 1:02d}", line)
        facts.append({"id": fid, "text": text,
                      "numbers": sorted(numbers_in(text)), "words": words_in(text)})
    return facts


def audit(ledger_path, pptx_path, exclusions_path=None):
    facts = parse_ledger(ledger_path)
    text = deck_text(pptx_path)
    cvals, clabels = chart_values(pptx_path)
    pool = numbers_in(text) | cvals
    vocab = words_in(text) | words_in(clabels)

    excluded = set()
    if exclusions_path and os.path.exists(exclusions_path):
        for line in open(exclusions_path, encoding="utf-8"):
            m = re.match(r"^\s*([A-Za-z]{1,3}\d{1,3})\b", line)
            if m:
                excluded.add(m.group(1))

    placed, rounded, missing, skipped = [], [], [], []
    for f in facts:
        if f["id"] in excluded:
            skipped.append(f)
            continue
        # Years and single digits are structure, not evidence: "approved in April
        # 2026" is not covered by a footer that happens to say 2026.
        evidential = [n for n in f["numbers"] if n not in STRUCTURAL]
        if evidential:
            states = [covered(n, pool) for n in evidential]
            gaps = [n for n, s in zip(evidential, states) if s is None]
            if gaps:
                f["gaps"] = gaps
                missing.append(f)
            elif "rounded" in states or "scaled" in states:
                rounded.append(f)
            else:
                placed.append(f)
        else:
            # Prose fact: most of its content words, including at least two
            # distinctive ones, must appear somewhere in the deck.
            hits = f["words"] & vocab
            distinctive = [w for w in hits if len(w) >= 6]
            need = max(1, int(round(len(f["words"]) * 0.7)))
            ok = len(hits) >= need and (len(distinctive) >= 2 or len(hits) == len(f["words"]))
            (placed if ok else missing).append(f)

    source_numbers = set()
    for f in facts:
        source_numbers |= set(f["numbers"])
    unverified = sorted(
        v for v in pool
        if v not in STRUCTURAL and covered(v, source_numbers) is None
    )

    checked = len(facts) - len(skipped)
    pct = 100.0 if checked == 0 else round(100.0 * (len(placed) + len(rounded)) / checked, 1)
    return {
        "facts": len(facts), "checked": checked, "coverage": pct,
        "placed": [f["id"] for f in placed],
        "rounded": [{"id": f["id"], "text": f["text"]} for f in rounded],
        "missing": [{"id": f["id"], "text": f["text"], "gaps": f.get("gaps", [])} for f in missing],
        "excluded": [f["id"] for f in skipped],
        "unverified_in_deck": unverified,
    }


def main():
    ap = argparse.ArgumentParser(description="Information-loss audit for a built deck.")
    ap.add_argument("ledger")
    ap.add_argument("pptx")
    ap.add_argument("--exclusions", help="file listing deliberately excluded fact ids and reasons")
    ap.add_argument("--json", help="write the full report to this path")
    a = ap.parse_args()

    r = audit(a.ledger, a.pptx, a.exclusions)

    print(f"Facts in ledger      : {r['facts']}")
    print(f"Deliberately excluded: {len(r['excluded'])}"
          + (f"  ({', '.join(r['excluded'])})" if r["excluded"] else ""))
    print(f"Checked              : {r['checked']}")
    print(f"Placed exactly       : {len(r['placed'])}")
    print(f"Placed, rounded      : {len(r['rounded'])}")
    print(f"MISSING              : {len(r['missing'])}")
    print(f"COVERAGE: {r['coverage']}%")

    if r["rounded"]:
        print("\nRounded or rescaled — confirm the precision loss is intended:")
        for f in r["rounded"]:
            print(f"  {f['id']}  {f['text'][:88]}")
    if r["missing"]:
        print("\nMISSING FROM DECK — place it, appendix it, or exclude it with a reason:")
        for f in r["missing"]:
            gaps = f"   [not found: {', '.join(str(g) for g in f['gaps'])}]" if f["gaps"] else ""
            print(f"  {f['id']}  {f['text'][:88]}{gaps}")
    if r["unverified_in_deck"]:
        print("\nIn the deck but not in the source — derived, or invented:")
        print("  " + ", ".join(f"{v:g}" for v in r["unverified_in_deck"][:40]))

    if a.json:
        with open(a.json, "w", encoding="utf-8") as fh:
            json.dump(r, fh, indent=2)
        print(f"\nReport written to {a.json}")

    sys.exit(0 if r["coverage"] == 100.0 else 1)


if __name__ == "__main__":
    main()
