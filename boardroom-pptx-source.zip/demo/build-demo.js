/**
 * build-demo.js — Reference implementation.
 *
 * Run:  node demo/build-demo.js [outputPath]
 *
 * Every figure below is illustrative, but it is internally consistent: the
 * bridge ties to the closing balance and the funnel percentages follow from
 * the stage volumes. Keep that property in any real deck — an executive
 * audience checks the arithmetic.
 */

'use strict';

const path = require('path');
const { createDeck } = require('../lib/deck');
const { IconLedger, png } = require('../lib/icons');
const C = require('../lib/components');
const charts = require('../lib/charts');

const OUT = process.argv[2] || path.join(process.cwd(), 'boardroom-demo.pptx');

async function main() {
  const deck = createDeck({
    palette: 'meridian-navy',
    fonts: 'boardroom-classic',
    meta: {
      title: 'Data and Analytics Office — half-year performance review',
      company: 'Meridian Bank',
      author: 'Office of the Chief Data and Analytics Officer',
      classification: 'Confidential — Internal use only',
      asOf: '30 June 2026',
      source: 'Group Finance and the Data Office',
    },
  });
  const t = deck.theme;
  const pptx = deck.pptx;
  const L = new IconLedger();

  const ic = async (label, colour) => (await png(L.pick(label), colour || t.primary, 96));
  const stIcon = async (key) => png(t.status[key].icon, t.tone(t.status[key].tone), 96);
  const stIconInv = async (key) => png(t.status[key].icon, t.inkInverse, 96);

  /* ---------------------------------------------------------------- */
  /* 1. Title                                                          */
  /* ---------------------------------------------------------------- */
  deck.titleSlide({
    kicker: 'Meridian Bank  |  Board Risk and Performance Committee',
    title: 'Data and Analytics Office\nHalf-year performance review',
    subtitle: 'Margin expansion held, platform migration ahead of plan, two control gaps to close',
    audience: 'Prepared for the Chief Executive Officer and the Chief Data and Analytics Officer',
    date: 'Reporting period: 1 January to 30 June 2026',
  });

  /* ---------------------------------------------------------------- */
  /* 2. Executive summary — KPI band                                   */
  /* ---------------------------------------------------------------- */
  const s2 = deck.kpiBandSlide({
    kicker: 'Executive summary',
    title: 'Net interest margin exceeded target while the cost ratio drifted 120 bps wide',
    subtitle:
      'Four of the six board-level measures met or exceeded plan at the half year. '
      + 'The cost-to-income ratio and the data certification rate remain the two open items.',
    cards: [
      {
        objectName: 'kpi-1',
        label: 'Net interest margin',
        value: '3.82%',
        delta: '+7 bps vs plan',
        deltaTone: 'positive',
        target: 'Plan 3.75%',
        status: 'achieved',
        iconPng: await ic('Net interest margin', t.inkInverse),
        badgeIconPng: await stIconInv('achieved'),
        sparkValues: [3.61, 3.64, 3.71, 3.75, 3.79, 3.82],
        charts,
      },
      {
        objectName: 'kpi-2',
        label: 'Net interest income',
        value: '\u20B94,286 Cr',
        delta: '+8.4% year on year',
        deltaTone: 'positive',
        target: 'Plan \u20B94,210 Cr',
        status: 'achieved',
        iconPng: await ic('Net interest income', t.inkInverse),
        badgeIconPng: await stIconInv('achieved'),
        charts,
      },
      {
        objectName: 'kpi-3',
        label: 'Cost-to-income ratio',
        value: '41.2%',
        delta: '+120 bps vs plan',
        deltaTone: 'negative',
        target: 'Plan 40.0%',
        status: 'atRisk',
        iconPng: await ic('Cost-to-income ratio'),
        badgeIconPng: await stIcon('atRisk'),
        charts,
      },
      {
        objectName: 'kpi-4',
        label: 'Certified data products',
        value: '604',
        delta: '+186 in the half',
        deltaTone: 'positive',
        target: 'Plan 640',
        status: 'onTrack',
        iconPng: await ic('Certified data products'),
        badgeIconPng: await stIcon('onTrack'),
        charts,
      },
    ],
  });
  C.callout(pptx, s2, t, {
    x: t.grid.margin, y: s2.contentTop + 1.82, w: t.grid.contentW, h: 0.62,
    tone: 'positive',
    text: 'Recommendation: hold the current pricing stance to protect margin, and bring the '
      + 'cost programme forward one quarter to close the 120 basis point gap by 31 December 2026.',
  });
  C.dataTable(pptx, s2, t, {
    x: t.grid.margin, y: s2.contentTop + 2.68, w: t.grid.contentW,
    head: ['Board measure', 'H1 FY25', 'H1 FY26', 'Plan', 'Variance', 'Status'],
    colW: [4.4, 1.5, 1.5, 1.5, 1.6, 1.733],
    rows: [
      ['Net interest margin', '3.61%', '3.82%', '3.75%', '+7 bps', 'Achieved'],
      ['Cost-to-income ratio', '42.8%', '41.2%', '40.0%', '+120 bps', 'At risk'],
      ['Gross non-performing assets', '2.50%', '2.14%', '2.20%', '-6 bps', 'Achieved'],
      ['Data certification rate', '38.4%', '54.2%', '58.0%', '-380 bps', 'On track'],
    ],
    align: ['left', 'right', 'right', 'right', 'right', 'center'],
    toneCells: [
      { r: 0, c: 4, tone: 'positive', bold: true }, { r: 0, c: 5, tone: 'positive', bold: true },
      { r: 1, c: 4, tone: 'negative', bold: true }, { r: 1, c: 5, tone: 'warning', bold: true },
      { r: 2, c: 4, tone: 'positive', bold: true }, { r: 2, c: 5, tone: 'positive', bold: true },
      { r: 3, c: 4, tone: 'warning', bold: true }, { r: 3, c: 5, tone: 'primary', bold: true },
    ],
  });

  /* ---------------------------------------------------------------- */
  /* 3. Variance bridge                                                */
  /* ---------------------------------------------------------------- */
  const s3 = deck.contentSlide({
    kicker: 'Financial performance',
    title: 'Volume and repricing added \u20B9598 crore; funding cost returned \u20B9172 crore',
    subtitle: 'Movement in net interest income, H1 FY25 to H1 FY26 (\u20B9 crore)',
  });
  C.varianceBridge(pptx, s3, t, {
    x: t.grid.margin, y: s3.contentTop, w: t.grid.contentW * 0.66, h: 3.95,
    start: { label: 'H1 FY25', value: 3954 },
    steps: [
      { label: 'Advances\nvolume', value: 412 },
      { label: 'Asset\nrepricing', value: 186 },
      { label: 'Portfolio\nmix', value: -94 },
      { label: 'Funding\ncost', value: -172 },
    ],
    end: { label: 'H1 FY26' },
    higherIsBetter: true,
    format: { decimals: 0 },
  });
  C.panel(pptx, s3, t, {
    x: t.colX(9), y: s3.contentTop, w: t.colSpan(4), h: 3.95,
  });
  C.pointRows(pptx, s3, t, {
    x: t.colX(9) + 0.2, y: s3.contentTop + 0.24, w: t.colSpan(4) - 0.4, h: 3.47,
    items: [
      {
        title: 'Advances grew 11.2%',
        body: 'Secured retail led the growth; corporate drawdowns stayed flat.',
        tone: 'positive', iconPng: await ic('Advances growth'),
      },
      {
        title: 'Repricing benefit is now largely taken',
        body: 'Fewer than 8% of loans remain to reprice in the second half.',
        tone: 'primary', iconPng: await ic('Asset repricing'),
      },
      {
        title: 'Deposit competition continues',
        body: 'Term deposit rates rose 42 basis points across the peer set.',
        tone: 'warning',
        iconPng: await png(
          L.pick('Deposit competition', { candidates: ['piggy-bank', 'bank2', 'safe', 'cash-stack'] }),
          t.primary, 96
        ),
      },
    ],
  });
  C.sourceNote(s3, t, {
    x: t.grid.margin, y: s3.contentTop + 4.05, w: t.grid.contentW * 0.66,
    text: 'Figures may not sum precisely because of rounding. '
      + 'Basis of preparation: management accounts, unaudited.',
  });

  /* ---------------------------------------------------------------- */
  /* 4. Trend and dual measure                                         */
  /* ---------------------------------------------------------------- */
  const s4 = deck.contentSlide({
    kicker: 'Margin and volume',
    title: 'Margin held above plan for four consecutive quarters',
    subtitle: 'Quarterly net interest income (\u20B9 crore, left axis) and net interest margin '
      + '(per cent, right axis)',
  });
  charts.comboColumnLine(pptx, s4, t, {
    x: t.grid.margin, y: s4.contentTop, w: t.grid.contentW * 0.62, h: 4.05,
    categories: ['Q1 FY25', 'Q2 FY25', 'Q3 FY25', 'Q4 FY25', 'Q1 FY26', 'Q2 FY26'],
    columns: [{ name: 'Net interest income', values: [1948, 2006, 2072, 2118, 2124, 2162] }],
    line: { name: 'Net interest margin', values: [3.58, 3.64, 3.71, 3.75, 3.79, 3.82] },
    colColors: [t.primary],
    lineColor: t.accent,
    leftFormat: charts.FMT.int,
    rightFormat: charts.FMT.pctRaw1,
    lineFormat: charts.FMT.pctRaw2,
    showColumnValues: true,
  });
  charts.barRanked(pptx, s4, t, {
    x: t.colX(9), y: s4.contentTop + 0.4, w: t.colSpan(4), h: 3.1,
    categories: ['Secured retail', 'Unsecured retail', 'SME', 'Corporate', 'Agriculture'],
    values: [214, 96, 64, 28, 10],
    sort: 'desc',
    name: 'Contribution',
    format: charts.FMT.int,
    colors: [t.series[1]],
  });
  s4.addText('Contribution to advances growth (\u20B9 crore)', {
    x: t.colX(9), y: s4.contentTop + 0.06, w: t.colSpan(4), h: 0.3,
    isTextBox: true, margin: 0, fontFace: t.fonts.body, fontSize: t.type.caption,
    bold: true, color: t.inkMuted, align: 'left', valign: 'middle',
  });

  /* ---------------------------------------------------------------- */
  /* 5. Portfolio status                                               */
  /* ---------------------------------------------------------------- */
  const s5 = deck.contentSlide({
    kicker: 'Data domain health',
    title: 'Customer and payments domains are certified; risk data remains the constraint',
    subtitle: 'Assessment against the five control dimensions of the data governance standard',
  });
  C.heatGrid(pptx, s5, t, {
    x: t.grid.margin, y: s5.contentTop, w: t.grid.contentW * 0.62, h: 3.6,
    labelW: 1.85,
    cols: ['Ownership', 'Quality', 'Lineage', 'Retention', 'Access'],
    rows: ['Customer', 'Payments', 'Lending', 'Risk', 'Finance'],
    cells: [
      [{ text: 'A', tone: 'positive', solid: true }, { text: 'A', tone: 'positive', solid: true }, { text: 'A', tone: 'positive', solid: true }, { text: 'B', tone: 'primary' }, { text: 'A', tone: 'positive', solid: true }],
      [{ text: 'A', tone: 'positive', solid: true }, { text: 'A', tone: 'positive', solid: true }, { text: 'B', tone: 'primary' }, { text: 'B', tone: 'primary' }, { text: 'A', tone: 'positive', solid: true }],
      [{ text: 'B', tone: 'primary' }, { text: 'B', tone: 'primary' }, { text: 'C', tone: 'warning' }, { text: 'B', tone: 'primary' }, { text: 'B', tone: 'primary' }],
      [{ text: 'C', tone: 'warning' }, { text: 'D', tone: 'negative' }, { text: 'D', tone: 'negative' }, { text: 'C', tone: 'warning' }, { text: 'C', tone: 'warning' }],
      [{ text: 'B', tone: 'primary' }, { text: 'B', tone: 'primary' }, { text: 'B', tone: 'primary' }, { text: 'A', tone: 'positive', solid: true }, { text: 'B', tone: 'primary' }],
    ],
  });
  s5.addText('Adoption against half-year targets', {
    x: t.colX(9), y: s5.contentTop, w: t.colSpan(4), h: 0.28,
    isTextBox: true, margin: 0, fontFace: t.fonts.body, fontSize: t.type.caption,
    bold: true, color: t.inkMuted, align: 'left', valign: 'middle',
  });
  const bullets = [
    { label: 'Certified products', value: 604, target: 640, max: 800, valueText: '604', targetText: 'plan 640' },
    { label: 'Active self-service users', value: 3120, target: 2800, max: 3600, valueText: '3,120', targetText: 'plan 2,800' },
    { label: 'Automated quality checks', value: 78, target: 70, max: 100, valueText: '78%', targetText: 'plan 70%' },
    { label: 'Domains with named owner', value: 5, target: 5, max: 6, valueText: '5 of 6', targetText: 'plan 5' },
    { label: 'Reports retired', value: 142, target: 200, max: 240, valueText: '142', targetText: 'plan 200' },
  ];
  bullets.forEach((b, i) => {
    C.bulletRow(pptx, s5, t, {
      ...b, x: t.colX(9), y: s5.contentTop + 0.44 + i * 0.6, w: t.colSpan(4), h: 0.4,
      labelW: 1.65, valueW: 0.75,
    });
  });

  s5.addText(
    'A = fully compliant   B = minor gaps   C = material gaps   D = not evidenced',
    {
      x: t.grid.margin, y: s5.contentTop + 3.7, w: t.grid.contentW * 0.62, h: 0.26,
      isTextBox: true, margin: 0, fontFace: t.fonts.body, fontSize: t.type.footnote,
      color: t.inkMuted, align: 'left', valign: 'middle',
    }
  );

  /* ---------------------------------------------------------------- */
  /* 6. Platform funnel and maturity                                   */
  /* ---------------------------------------------------------------- */
  const s6 = deck.contentSlide({
    kicker: 'Platform',
    title: 'Two in every five ingested datasets reach a certified, consumable state',
    subtitle: 'Dataset attrition across the platform, and data maturity against the peer benchmark',
  });
  C.funnel(pptx, s6, t, {
    x: t.grid.margin, y: s6.contentTop + 0.3, w: t.grid.contentW * 0.45, h: 3.5,
    conversionLabel: 'Carried forward',
    stages: [
      { label: 'Registered', value: 1240 },
      { label: 'Ingested', value: 1086 },
      { label: 'Curated', value: 892 },
      { label: 'Certified', value: 604 },
      { label: 'Consumed', value: 431 },
    ],
    format: { decimals: 0 },
  });
  charts.radar(pptx, s6, t, {
    x: t.colX(8) - 0.1, y: s6.contentTop, w: t.colSpan(5) + 0.1, h: 4.0,
    categories: ['Governance', 'Quality', 'Platform', 'Literacy', 'Analytics', 'Delivery'],
    series: [
      { name: 'Meridian Bank', values: [3.6, 2.9, 4.1, 2.4, 3.2, 3.8] },
      { name: 'Peer median', values: [3.1, 3.3, 3.0, 3.0, 3.4, 3.1] },
    ],
    max: 5,
    colors: [t.primary, t.neutral],
  });

  /* ---------------------------------------------------------------- */
  /* 7. Milestones                                                     */
  /* ---------------------------------------------------------------- */
  const s7 = deck.contentSlide({
    kicker: 'Programme',
    title: 'Two milestones delivered early; the model risk framework has slipped',
    subtitle: 'Data platform programme, key milestones to March 2027',
  });
  C.milestoneTimeline(pptx, s7, t, {
    x: t.grid.margin + 0.7, y: s7.contentTop + 0.5, w: t.grid.contentW - 1.4, h: 2.4,
    milestones: [
      { label: 'Cloud landing zone', date: 'Delivered March 2026', status: 'achieved' },
      { label: 'Core platform go-live', date: 'Delivered May 2026', status: 'achieved' },
      { label: 'Customer 360 release', date: 'Due September 2026', status: 'onTrack' },
      { label: 'Model risk framework', date: 'Due November 2026', status: 'atRisk' },
      { label: 'Regulatory reporting move', date: 'Due March 2027', status: 'notStarted' },
    ],
  });
  const legend = ['achieved', 'onTrack', 'atRisk', 'notStarted'];
  for (let i = 0; i < legend.length; i += 1) {
    C.statusBadge(pptx, s7, t, {
      x: t.grid.margin + i * 1.35, y: s7.contentTop + 3.5, w: 1.25, h: 0.28,
      status: legend[i],
      iconPng: await stIcon(legend[i]),
      align: 'left',
    });
  }

  /* ---------------------------------------------------------------- */
  /* 8. Decisions                                                      */
  /* ---------------------------------------------------------------- */
  deck.decisionsSlide({
    subtitle: 'Three decisions are sought at this meeting. Each is costed and has a named owner.',
    items: [
      {
        title: 'Approve the reallocation of \u20B942 crore to the cost programme',
        body: 'Brings the cost-to-income remediation forward to the third quarter. '
          + 'Owner: Chief Financial Officer.',
        tone: 'primary', iconPng: await ic('Budget reallocation'),
      },
      {
        title: 'Approve a six-week extension for the model risk framework',
        body: 'Revised delivery date 15 January 2027, with an interim control in place from '
          + '1 December 2026. Owner: Chief Risk Officer.',
        tone: 'warning', iconPng: await ic('Model risk framework'),
      },
      {
        title: 'Note the certification trajectory and the revised year-end position',
        body: 'The year-end forecast moves from 780 to 742 certified products. '
          + 'Owner: Chief Data and Analytics Officer.',
        tone: 'neutral', iconPng: await ic('Certification trajectory'),
      },
    ],
  });

  await deck.save(OUT);
  console.log('Deck written:', OUT);
  console.log('Icons used:', JSON.stringify(L.report()));
}

main().catch((e) => { console.error('BUILD FAILED:', e); process.exit(1); });
