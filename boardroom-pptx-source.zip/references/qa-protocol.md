# QA protocol

A deck is not finished when it renders. It is finished when it has passed the
five gates below, in order, with evidence. The gates exist because the failure
modes are known: a fact silently dropped, a total that does not tie, a title
running out of its box, a label on a fill it cannot be read against, a figure
nobody can source.

## Contents

1. [Gate 1 — The extraction ledger](#gate-1--the-extraction-ledger)
2. [Gate 2 — The coverage audit](#gate-2--the-coverage-audit)
3. [Gate 3 — Arithmetic and consistency](#gate-3--arithmetic-and-consistency)
4. [Gate 4 — File validation](#gate-4--file-validation)
5. [Gate 5 — Visual inspection](#gate-5--visual-inspection)
6. [Sign-off record](#sign-off-record)
7. [Worked example](#worked-example)

---

## Gate 1 — The extraction ledger

Before any design decision, read the source in full and write one line per
fact. This is the single most effective step in the protocol and the one most
often skipped.

Format — an id, then the fact verbatim with its numbers and units intact:

```
# ledger.txt — H1 FY26 review — source: CFO note of 4 July 2026
F01  NII H1 FY26 ₹4,286 Cr, up 8.4% YoY
F02  NII H1 FY25 ₹3,954 Cr
F03  NIM 3.82%, plan 3.75%, H1 FY25 3.61%
F04  Cost-to-income 41.2%, plan 40.0%, H1 FY25 42.8%
F05  GNPA 2.14%, down 36 bps, plan 2.20%
F06  NII bridge: advances volume +412, asset repricing +186, portfolio mix -94, funding cost -172
F07  Fewer than 8% of loans remain to reprice in H2
F08  Term deposit rates rose 42 bps across the peer set
F09  Certified data products 604, +186 in the half, plan 640
F10  Caveat: management accounts, unaudited
F11  Recommendation: bring the cost programme forward one quarter
F12  Decision sought: reallocate ₹42 Cr to the cost programme (owner CFO)
```

What goes in:

- **Every number**, with its unit, sign, period and comparator.
- **Every caveat, exclusion, restatement and basis of preparation.** These are
  the facts most often lost and most often asked about.
- **Every recommendation and decision**, with its owner if named.
- **Every judgement** the source makes ("the team assesses X as at risk").
- **Every named entity**: systems, programmes, committees, dates.

What does not: the source's own headings, transitions and repetition. If a
figure appears three times in the source it appears once in the ledger.

Save it as `ledger.txt` beside the build script. It is the contract the deck
will be audited against, and it is what the presenter reads on the way to the
meeting.

---

## Gate 2 — The coverage audit

```bash
python3 scripts/coverage_audit.py ledger.txt deck.pptx
```

The script reads the deck from three places — shape text, table cells, and the
cached values inside native charts — and checks every ledger fact against it.

```
Facts in ledger      : 12
Deliberately excluded: 0
Checked              : 12
Placed exactly       : 11
Placed, rounded      : 1
MISSING              : 0
COVERAGE: 100%

Rounded or rescaled — confirm the precision loss is intended:
  F03  NIM 3.82%, plan 3.75%, H1 FY25 3.61%

In the deck but not in the source — derived, or invented:
  87.6, 82.1, 67.7, 71.4
```

Read each block:

- **MISSING** must be empty. Each missing fact is placed on a slide, moved to
  the appendix, or written into an exclusions file with a reason:

  ```
  # excluded.txt
  F08  Peer deposit rates — competitive information, not for committee circulation
  ```

  and re-run with `--exclusions excluded.txt`. An exclusion is a decision,
  recorded, that the presenter can defend. A missing fact is an accident.

- **Rounded** is a warning, not a failure: 3.82% printed as 3.8% on a chart
  label may be fine, or may be the difference between meeting plan and missing
  it. Confirm each one deliberately.

- **In the deck but not in the source** lists numbers the audit cannot trace.
  Derived values — carry-forward percentages, cumulative shares, computed
  totals — are expected here. Anything else is an invented figure and must be
  removed or sourced.

The script exits non-zero below 100%, so it can gate a build.

**Limits.** It matches numbers and, for prose facts, vocabulary. It cannot tell
that a fact is on the wrong slide, attributed to the wrong period, or given the
wrong sign. Those are Gate 3.

---

## Gate 3 — Arithmetic and consistency

Read the deck once for numbers only. An executive audience checks the
arithmetic, and a sum that does not tie discredits every other figure.

| Check | How |
|---|---|
| **Totals tie** | Every bridge closes to its stated end value; every stacked total equals its parts; every table total equals its rows |
| **Rounding disclosed** | Where parts are rounded, the note "Figures may not sum precisely because of rounding" is present, once |
| **Same figure, same value** | A measure quoted on two slides carries the same number, unit and precision on both |
| **Same figure, same name** | "Cost-to-income ratio" on one slide is not "CIR" on another without first-use expansion |
| **Variance direction** | Each signed variance has the colour its meaning deserves — a rising cost is adverse |
| **Basis stated** | Every comparison names its comparator: plan, prior year, prior quarter, peer median |
| **Period consistency** | The as-at date in the footer matches the period the numbers describe |
| **Percent vs points** | Differences between rates are in basis points, differences between shares in percentage points |
| **Derived values recomputed** | Every carry-forward, share and growth rate on a slide is recalculated by hand from the values shown |

The worked example at the end of this document shows a real inconsistency this
gate caught.

---

## Gate 4 — File validation

```bash
python3 /mnt/skills/public/pptx/scripts/office/validate.py deck.pptx
markitdown deck.pptx | grep -iE "lorem|ipsum|TODO|\[insert|xxx" ; true
```

`validate.py` checks the package against the schema and reports the faults
PowerPoint will refuse, naming the fix for each. Two are worth knowing by name
because the library guards against them and a hand-written chart might not: a
combo chart without both `valAxes` and `catAxes`, and `outEnd` labels on a
stacked chart.

The `grep` catches placeholder text left behind from a template or a draft.
Its output must be empty.

Fix failures in the generator and rebuild. Never hand-edit the packed XML to
pass validation.

---

## Gate 5 — Visual inspection

```bash
python3 /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf deck.pptx
rm -f slide-*.jpg && pdftoppm -jpeg -r 110 deck.pdf slide
ls -1 "$PWD"/slide-*.jpg
```

Open every image. Look at each one fresh — after writing the generator you see
what you expect rather than what rendered.

In order of how often they occur:

1. **Text overflowing or cut off** at a box or slide edge. Check every title,
   every KPI target line, every table cell. The title band measures itself and
   warns on the console; everything else is your responsibility.
2. **Text on a fill it cannot be read against** — a dark label inside a dark
   column, a muted caption on a mid-tone band. `t.onColour()` exists for this.
3. **Elements closer than 0.3 in**, or cards nearly touching.
4. **A footer or source note colliding** with content above it.
5. **Overlapping elements** — a line through words, a label on a marker.
6. **Uneven whitespace** — a large empty region beside a cramped one. Usually
   means a block should be taller, or the slide should be two slides.
7. **Chart labels colliding** with each other or with a second series.
8. **Inconsistent alignment** — columns of cards, rows of badges, axis
   baselines that do not line up across two charts on one slide.
9. **A repeated icon** for two different concepts. The ledger prevents it in
   code; confirm it by eye, and check `L.report()`.
10. **Anything that is not in the theme** — a stray colour, a second typeface,
    a default chart palette that escaped.
11. **Stray decoration** — an accent line under a title, a colour bar, an edge
    stripe. All prohibited.
12. **Placeholder or template residue.**

Fix, rebuild, re-render only the slides that changed, and look again. Two
passes is normal. Stop when a pass finds nothing.

For font pairings marked QA-unsafe in the design system, the preview's text
fit is approximate: trust the 10% slack you left, not what the image shows.

**Greyscale check** for anything that will be printed: convert one page to
black and white and confirm every status is still distinguishable by its glyph.

---

## Sign-off record

Keep this beside the deck. It is thirty seconds to fill in and it is what
answers "was this checked?".

```
Deck        : H1-FY26-DAO-review-v3.pptx
Source      : CFO note 4 July 2026; Data Office scorecard 30 June 2026
Ledger      : 41 facts, ledger.txt
Coverage    : 100% (2 excluded with reason, excluded.txt)
Arithmetic  : bridge ties to ₹4,286 Cr; table totals tie; 4 derived values recomputed
Validation  : validate.py passed; no placeholder text
Visual      : 9 slides rendered and inspected; 2 fixes (title length s7, label band s4)
Icons       : 10 distinct concepts, 10 distinct glyphs (ledger report attached)
Animation   : none  |  applied, verified in PowerPoint, PDF export complete
Palette     : meridian-navy / boardroom-classic
Reviewed by : —
Date        : 11 September 2026
```

---

## Worked example

During the build of the demo deck, the executive summary card read:

> Net interest margin **3.82%** — +18 bps vs plan — Plan 3.75%

and the table on the same slide read:

> Net interest margin | 3.61% | 3.82% | 3.75% | **+7 bps**

Both were "correct" in the sense that each figure existed somewhere in the
source. Both passed the coverage audit. But 3.82 minus 3.75 is 7 basis points,
not 18 — the card had picked up the year-on-year movement (+21 bps, itself
misquoted) and labelled it as the variance to plan.

Gate 3 caught it: *same figure, same value* — the variance to plan appeared
twice on one slide with two different numbers. The card was corrected to
"+7 bps vs plan".

The lesson is the reason the gates are ordered as they are. A coverage audit
proves nothing was dropped. Only a person reading for arithmetic proves nothing
was mislabelled.
