# Slide patterns

Twelve archetypes. Between them they cover an executive pack. Vary them — a
deck where every slide is the same shape reads as a form that was filled in.

All coordinates are inches on a 13.333 × 7.5 canvas. `TOP` means
`slide.contentTop`, the value the title band returns.

## Contents

1. [Deck structure](#deck-structure)
2. [The archetypes](#the-archetypes)
3. [Density budget](#density-budget)
4. [Writing the title](#writing-the-title)

---

## Deck structure

A board or executive pack runs in this order. Length is the number of slides
the audience actually reads before the discussion starts.

| # | Slide | Purpose |
|---|---|---|
| 1 | Title | Who, what, when, and the classification |
| 2 | Executive summary | The whole story on one page. If they read nothing else |
| 3 | Decisions requested | Moved to the front when a decision is the point of the meeting |
| 4–n | Evidence | One message per slide, in the order the summary made its claims |
| n+1 | Risks and mitigations | What could go wrong and who owns it |
| n+2 | Decisions requested | If not placed at the front |
| A1+ | Appendix | Method, definitions, lineage, the full tables |

Twelve slides before the appendix is a comfortable ceiling for a
sixty-minute committee. Twenty is a reading pack, not a presentation.

**Section dividers** are worth their page only when the deck runs past twelve
slides and covers genuinely separate subjects.

**The appendix is not a dumping ground — it is the answer to rule two.** Any
fact from the source that does not earn a place in the main flow goes here, so
the coverage audit passes and the presenter can answer the question that gets
asked.

---

## The archetypes

### 1. Title

`deck.titleSlide({ kicker, title, subtitle, audience, date })`

Dark `primaryDeep` canvas. No chart, no logo wall, no photograph. The subtitle
is the one-sentence thesis of the pack, not a restatement of the title.

| Element | x | y | w |
|---|---|---|---|
| Kicker | 0.55 | 1.75 | content |
| Title (40pt) | 0.55 | 2.15 | 82% |
| Subtitle (16pt) | 0.55 | 3.75 | 70% |
| Audience, date, classification | 0.55 | 6.50 | content |

### 2. Executive summary — KPI band with supporting table

`deck.kpiBandSlide({ kicker, title, subtitle, cards })`

The most important slide in the pack. Four KPI cards, a one-sentence callout
carrying the recommendation, and a table giving the full set of measures.

| Element | x | y | h |
|---|---|---|---|
| Cards ×4 | `cardRow(4)` | `TOP` | 1.62 |
| Callout | 0.55 | `TOP + 1.82` | 0.62 |
| Table | 0.55 | `TOP + 2.68` | auto |

Mark at most two cards `achieved`. If everything is achieved, the targets were
not stretching and the audience will say so.

### 3. Single chart with interpretation

Two-thirds chart, one-third panel of point rows. The default evidence slide.

| Element | x | y | w | h |
|---|---|---|---|---|
| Chart | 0.55 | `TOP` | `contentW × 0.66` | 3.95 |
| Panel | `colX(9)` | `TOP` | `colSpan(4)` | 3.95 |
| Point rows | `colX(9)+0.2` | `TOP+0.24` | `colSpan(4)−0.4` | 3.47 |
| Source note | 0.55 | `TOP+4.05` | `contentW × 0.66` | 0.24 |

The panel carries three points at most, each a bold assertion and one
supporting line. Not bullets — assertions.

### 4. Two charts side by side

Only when the two answer the *same* question from different angles. Equal
halves, `colSpan(6)` and `colX(7)`, both at `TOP`, both the same height. Give
each a caption line above it in `caption` size, muted.

### 5. Variance bridge

The bridge across two-thirds, drivers down the right. Geometry as archetype 3.
Always add the rounding note: *"Figures may not sum precisely because of
rounding."*

### 6. Portfolio status — heat grid with adoption measures

Heat grid left at `contentW × 0.62`, bullet rows right at `colSpan(4)` on a
0.6 pitch, grade legend beneath the grid at `TOP + 3.7`.

### 7. Process and profile — funnel with radar

Funnel left at `contentW × 0.45`, radar right at `colSpan(5)`. Carry-forward
percentages down the right of the funnel.

### 8. Milestone timeline

Timeline inset 0.7 from each margin so the first and last labels have room:
`x: margin + 0.7`, `w: contentW − 1.4`, `h: 2.4`, at `TOP + 0.5`. Status legend
at `TOP + 3.5` on a 1.35 pitch.

### 9. Table slide

One table, full content width, at `TOP`. Eight rows maximum. Emphasise the
total row. Tone the variance column. If the table needs more than eight rows,
it belongs in the appendix with a summary on the slide.

### 10. Risks and mitigations

A four-column table — risk, impact, mitigation, owner — with the status badge
in the impact column. Or point rows with `tone` set by severity where there are
three or fewer.

### 11. Decisions requested

`deck.decisionsSlide({ subtitle, items })`

Each item: what is being approved, the consequence, and a named owner. Three
decisions is the practical maximum for one meeting. A decision without an owner
and a date is not a decision.

### 12. Appendix

Same chrome, `kicker: 'Appendix'`, numbered A1, A2. Method, definitions, data
lineage, full tables, the workings behind any figure on a main slide.

---

## Density budget

Per slide, at most:

| Item | Limit |
|---|---|
| Messages | 1 |
| Objects (charts, tables, panels, card groups) | 6 |
| KPI cards | 6, comfortably 4 |
| Chart series | 6, comfortably 4 |
| Table rows | 8 |
| Table columns | 6 |
| Point rows | 3 |
| Callouts | 1 |
| Words in the title | 12 |
| Words on the slide, excluding tables | 90 |

Over budget means either the slide splits in two, or the detail moves to the
appendix. It does not mean smaller type.

---

## Writing the title

The title is the finding. The subtitle is the setting.

| Instead of | Write |
|---|---|
| Net interest margin | Net interest margin exceeded target for the fourth consecutive quarter |
| Data quality update | Risk data remains the only domain below the certification threshold |
| Programme status | Two milestones delivered early; the model risk framework has slipped |
| Q2 results | Volume and repricing added ₹598 crore; funding cost returned ₹172 crore |

Rules:

- One assertion, twelve words or fewer, sentence case, no full stop.
- It must be falsifiable by the evidence on the same slide. If the chart cannot
  confirm or refute it, one of the two is wrong.
- No colons introducing a reveal, no rhetorical questions, no verbs like
  "unlock", "leverage" or "supercharge".
- The subtitle carries units, period, basis and scope — everything needed to
  read the chart, and nothing that belongs in the assertion.

The title band measures itself and will step the font down once rather than
overflow, but a title that needs two lines is usually a title that needs
editing. A console warning appears if it would run to three.

Full guidance on the words themselves: `references/language-standards.md`.
