# Animation and transitions

**Default: off.** A deck is delivered with no animation unless the user has
asked for it. This document applies only once they have.

## Contents

1. [The policy](#the-policy)
2. [How it works](#how-it-works)
3. [Making shapes targetable](#making-shapes-targetable)
4. [Effect catalogue](#effect-catalogue)
5. [Transitions](#transitions)
6. [Recipes](#recipes)
7. [The XML](#the-xml)
8. [Verification](#verification)

---

## The policy

Animation in an executive deck has exactly one legitimate job: **controlling
when information arrives**, so the presenter can make one point before the
audience reads the next. Everything else is decoration, and decoration in a
board pack costs credibility.

Four rules.

1. **The static slide must be complete.** Every animated deck is also printed,
   exported to PDF and read in a browser preview that ignores timing. Nothing
   may exist only in the animated state.
2. **Entrance only, with one exception.** Entrances control arrival. Exits
   remove information the audience may still need. The exception is a single
   emphasis `pulse` on an achievement badge, once, when its card arrives.
3. **One effect per deck.** Choose `fade` or `rise` and use it everywhere. A
   deck in which each slide animates differently looks assembled by committee.
4. **Nothing moves for longer than half a second.** 450 ms is the default.
   Anything slower is felt as lag by an audience waiting for the number.

Never use: fly-in from an edge, bounce, spin, swivel, boomerang, typewriter
text, animated chart series, motion paths, or sound.

---

## How it works

Neither `pptxgenjs` nor `python-pptx` exposes animation, because animation is
not part of the shape tree. It lives in `<p:transition>` and `<p:timing>`,
which sit inside `<p:sld>` after `<p:cSld>`. `lib/animate.js` unpacks the
finished file, injects that XML and repacks it.

Animation is therefore always a **post-processing step**, run after the deck is
built, validated and visually checked.

```js
const { applyAnimations, revealSequence } = require('./lib/animate');

const result = applyAnimations('deck.pptx', {
  2: {
    transition: 'fade',
    steps: revealSequence(['kpi-1', 'kpi-2', 'kpi-3', 'kpi-4'], { effect: 'rise' })
      .concat([{ shape: 'kpi-1-badge', effect: 'pulse', trigger: 'afterPrev', delay: 250 }]),
  },
  3: { transition: 'morph' },
  4: { transition: 'fade', steps: [{ shape: 'bridge-callout', effect: 'fade' }] },
}, { out: 'deck-animated.pptx' });

console.log(result.applied);   // ['slide 2: 5 step(s)', 'slide 3: transition only', …]
```

Omit `out` to modify in place. Re-running on an already-animated deck throws
rather than layering a second timing tree on the first — rebuild instead.

---

## Making shapes targetable

Give any shape an `objectName` when you create it. Names are resolved to OOXML
shape ids at injection time, and an unknown name is a hard error naming every
available shape, not a silent no-op.

```js
slide.addShape(pptx.ShapeType.roundRect, { …, objectName: 'kpi-1' });
slide.addText('3.82%', { …, isTextBox: true, objectName: 'kpi-1-value' });
```

`kpiCard` and `statusBadge` accept `objectName` and pass it to their background
shape; a card named `kpi-1` names its own badge `kpi-1-badge`. Other components
do not set names, because a name is a decision about what the presenter will
reveal. Name what you intend to animate and nothing else. A convention that
works: `kpi-1`, `kpi-1-badge`, `bridge`, `conclusion-callout`.

An unnamed shape appears immediately, with the slide. That is the correct
default for titles, footers and chrome — those should never animate.

---

## Effect catalogue

| Key | Class | What it does | Use it for |
|---|---|---|---|
| `fade` | entrance | Opacity 0 to 1 | **The default.** Anything |
| `rise` | entrance | Fade plus 0.04 in upward travel | Cards and panels arriving as a group |
| `wipeLeft` | entrance | Fills from the left | Bars, bullet tracks, progress rows |
| `wipeUp` | entrance | Grows from the bottom | Columns, funnel stages |
| `zoomIn` | entrance | Scales in | Rings and circular marks |
| `pulse` | emphasis | Grows to 106% and returns | **The achievement badge, once** |
| `grow` | emphasis | Grows to 112% and returns | A single hero number |
| `fadeOut` | exit | Fades away | Before-and-after overlays only |

Triggers:

| Trigger | Behaviour |
|---|---|
| `click` | Waits for the presenter. Starts a new click group |
| `afterPrev` | Follows the previous step automatically, after `delay` |
| `withPrev` | Runs simultaneously with the previous step |

Steps are grouped automatically: each `click` opens a group, and everything
after it runs on that one click. Four cards revealed with a 150 ms stagger cost
the presenter one click, not four.

`delay` is milliseconds before the step begins; `duration` is milliseconds the
effect runs. Defaults: 450 ms duration, 150 ms stagger.

---

## Transitions

| Key | Effect |
|---|---|
| `none` | No transition. The default |
| `fade` | Cross-fade. Safe everywhere |
| `wipeLeft` | Directional wipe. Use for a section change |
| `pushUp` | Push upward. Use for a section change |
| `morph` | Morph: shared shapes travel between slides |

**Morph** is the one worth knowing. Where two consecutive slides share shapes —
the same KPI card, the same chart, repositioned or resized — morph animates the
change without any per-shape timing at all. It is the cleanest way to build up
an argument: show four cards, then on the next slide show the same four with
one enlarged and a chart beneath it.

Morph needs PowerPoint 2019 or Microsoft 365. The library writes an
`mc:AlternateContent` block so older clients fall back to a fade automatically.

---

## Recipes

**Progressive KPI reveal.** Four cards arrive on one click, then the achieved
badge pulses.

```js
2: {
  transition: 'fade',
  steps: [
    ...revealSequence(['kpi-1','kpi-2','kpi-3','kpi-4'], { effect: 'rise', stagger: 140 }),
    { shape: 'kpi-1-badge', effect: 'pulse', trigger: 'afterPrev', delay: 300, duration: 350 },
  ],
}
```

**Evidence then conclusion.** The chart is on the slide from the start; the
callout arrives when the presenter is ready to state the conclusion.

```js
4: { steps: [{ shape: 'conclusion-callout', effect: 'fade', trigger: 'click' }] }
```

**Bridge built step by step.** One click per driver, so each can be discussed.
Requires naming each bar at build time.

```js
5: { steps: ['step-1','step-2','step-3','step-4','bar-closing']
       .map((s) => ({ shape: s, effect: 'wipeUp', trigger: 'click', duration: 400 })) }
```

**Milestone walk.** Each milestone on its own click, along the timeline.

```js
7: { steps: ['ms-1','ms-2','ms-3','ms-4','ms-5']
       .map((s) => ({ shape: s, effect: 'zoomIn', trigger: 'click', duration: 350 })) }
```

---

## The XML

Useful when debugging, or when a specific effect is needed that the catalogue
does not carry.

A slide's timing is a tree of time nodes. The root is `tmRoot`; beneath it sits
`mainSeq`, the sequence that advances on click; beneath that, one `<p:par>` per
click group; and inside each group, one `<p:par>` per effect.

```xml
<p:timing><p:tnLst><p:par>
  <p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst>
    <p:seq concurrent="1" nextAc="seek">
      <p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>
        <!-- one click group -->
        <p:par><p:cTn id="3" fill="hold">
          <p:stCondLst><p:cond delay="indefinite"/></p:stCondLst>
          <p:childTnLst><p:par><p:cTn id="4" fill="hold">
            <p:stCondLst><p:cond delay="0"/></p:stCondLst>
            <p:childTnLst>
              <!-- one effect -->
              <p:par><p:cTn id="5" presetID="10" presetClass="entr" presetSubtype="0"
                            fill="hold" grpId="0" nodeType="clickEffect">
                <p:stCondLst><p:cond delay="0"/></p:stCondLst>
                <p:childTnLst>
                  <p:set>…style.visibility → visible…</p:set>
                  <p:animEffect transition="in" filter="fade">
                    <p:cBhvr><p:cTn id="6" dur="450"/>
                      <p:tgtEl><p:spTgt spid="7"/></p:tgtEl></p:cBhvr>
                  </p:animEffect>
                </p:childTnLst>
              </p:cTn></p:par>
            </p:childTnLst>
          </p:cTn></p:par></p:childTnLst>
        </p:cTn></p:par>
      </p:childTnLst></p:cTn>
      <p:prevCondLst>…</p:prevCondLst><p:nextCondLst>…</p:nextCondLst>
    </p:seq>
  </p:childTnLst></p:cTn>
</p:par></p:tnLst></p:timing>
```

Three things that break a file, all handled by the library:

- **Element order.** Inside `<p:sld>`: `cSld`, `clrMapOvr`, `transition`,
  `timing`. A transition written after the timing block makes the deck
  unopenable.
- **Unique node ids.** Every `<p:cTn id>` in a slide must differ. The library
  runs one counter across the whole tree.
- **`spid` must be a real shape id** on that slide, resolved from the
  `<p:cNvPr id name>` pairs, not invented.

Motion is expressed as behaviours rather than preset ids, so what plays is
exactly what is written: `rise` is a fade plus a `<p:anim>` on `ppt_y` from
`#ppt_y+0.04` to `#ppt_y`; `pulse` is `<p:animScale>` with `autoRev="1"`.

---

## Verification

Animation is invisible to every automated check. `validate.py` sees valid XML,
LibreOffice renders a static frame, and the PDF export ignores timing entirely.

So:

1. Run `validate.py` on the animated file — it catches structural damage from
   the repack, which is the failure mode that matters most.
2. Confirm the static render is unchanged from the pre-animation version. If
   any slide differs, something was injected into the shape tree by mistake.
3. **Open it in PowerPoint and press F5.** This is the only real test. Check
   the click count matches what the presenter expects, that nothing arrives
   after the point it is discussed, and that morph slides do not swap elements
   unexpectedly.
4. Export to PDF and confirm every slide is complete — this is rule one, and it
   is the one that fails in practice.

Deliver both files where the user will present from one and circulate the
other: `deck.pptx` and `deck-animated.pptx`.
