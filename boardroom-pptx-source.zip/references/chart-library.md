# Chart and component library

Two modules. `charts.js` produces **native PowerPoint charts** — clickable,
editable, re-linkable to data. `components.js` composes shapes for the visuals
PowerPoint has no native form for.

That split is deliberate. A bank's finance team edits decks. A picture of a
chart cannot be edited, cannot be re-cut for a different period, and betrays
itself the moment someone zooms in.

## Contents

1. [Choosing the visual](#choosing-the-visual)
2. [Rules that apply to every chart](#rules-that-apply-to-every-chart)
3. [Number formats](#number-formats)
4. [Native charts](#native-charts)
5. [Composed components](#composed-components)
6. [Slide furniture](#slide-furniture)
7. [Known constraints](#known-constraints)

---

## Choosing the visual

Start from the question the audience is asking, not from the shape of the data.

| The question | The visual | Function |
|---|---|---|
| How does this measure stand against its target? | KPI card | `kpiCard` |
| How do six measures stand against their targets? | Bullet rows | `bulletRow` |
| What moved the result between two dates? | Variance bridge | `varianceBridge` |
| How has this measure moved over time? | Line trend | `trendLine` |
| How has this volume accumulated? | Area trend | `trendArea` |
| How do a handful of periods compare? | Column trend | `columnTrend` |
| Which categories are largest? | Ranked horizontal bars | `barRanked` |
| Actual against target, by category? | Grouped columns | `groupedColumn` |
| What is this total made of, over time? | Stacked columns | `stackedColumn` |
| What share does each part hold? | 100% stacked, or donut for 3–5 parts | `stackedColumn` / `donutMix` |
| Which few drivers explain most of the total? | Pareto | `pareto` |
| How do a volume and a rate move together? | Dual-axis combo | `comboColumnLine` |
| How far through are we? | Progress ring | `progressDonut` |
| Where does each item sit on two dimensions? | Scatter with quadrants | `scatter` + `quadrantOverlay` |
| How do we score across several capabilities? | Radar | `radar` |
| What is the status across a portfolio? | Heat grid | `heatGrid` |
| Where do items drop out of a process? | Funnel | `funnel` |
| What is delivered and what is late? | Milestone timeline | `milestoneTimeline` |
| What are the precise figures? | Table | `dataTable` |
| What should the reader conclude? | Callout — words, not a chart | `callout` |

**When not to chart at all.** A single number is a KPI card, not a bar of one.
Two numbers are a sentence. A judgement, a recommendation or a caveat is prose.
A chart that carries fewer than four data points is usually a decorated number.

---

## Rules that apply to every chart

- **Values are printed.** `showValue` defaults to true. Turn it off only when
  labels would overlap, and then move the figures into a table or a callout —
  never simply drop them.
- **No chart title inside the chart.** The slide title states the finding; the
  subtitle states the units and period. `showTitle` is false everywhere.
- **No legend for one series.** For two or more, the legend sits at the bottom.
  Better still, name the series in the subtitle and drop the legend.
- **Horizontal grid lines only**, in `hairline`. No vertical grid, no axis lines.
- **Bars start at zero.** Always. A truncated bar axis misstates the comparison.
  Line charts may use a non-zero axis when the movement is the subject.
- **Category order carries meaning.** Time runs left to right. Rankings run
  largest first. Never leave categories in whatever order the query returned.
- **Six series is the ceiling**, four is comfortable, and beyond six you need
  small multiples or a table.
- **Units in the subtitle**, not repeated in every label.

---

## Number formats

`charts.FMT` holds Excel format codes that PowerPoint applies to data labels
and axes. Use these rather than pre-formatting values into strings — a native
chart should keep real numbers behind it.

| Code | Renders | Notes |
|---|---|---|
| `FMT.int` | 1,234 | |
| `FMT.dec1` `FMT.dec2` | 1,234.5 / 1,234.56 | |
| `FMT.pctRaw` | 62% | **Pass 62.** No multiplication. Prefer this. |
| `FMT.pctRaw1` `FMT.pctRaw2` | 62.4% / 62.40% | Pass 62.4 |
| `FMT.pctFrac` | 62% | Pass 0.62. Excel multiplies by 100. |
| `FMT.bps` | 120 bps | |
| `FMT.inr` `FMT.inrCr` `FMT.inrLakh` | ₹1,234 / ₹1,234.5 Cr / ₹12.3 L | |
| `FMT.inrIndian` | ₹1,23,45,678 | Indian digit grouping |
| `FMT.usd` `FMT.usdMn` `FMT.mn` | $1,234 / $1.2 mn / 1.2 mn | |
| `FMT.days` `FMT.x` | 45 days / 2.4x | |

The percentage trap is worth stating plainly: `pctFrac` multiplies by 100,
`pctRaw` does not. Mixing them produces a chart reading 3,800% and an
embarrassing meeting. When in doubt use `pctRaw` and pass the number the way a
human would say it.

For label text you write yourself, `components.fmt` does the same job in
JavaScript:

```js
C.fmt(4286, { prefix: '₹', suffix: ' Cr' })            // ₹4,286 Cr
C.fmt(12345678, { prefix: '₹', grouping: 'indian' })   // ₹1,23,45,678
C.fmt(-36, { signed: true, suffix: ' bps' })           // -36 bps
C.fmt(7,  { signed: true, suffix: ' bps' })            // +7 bps
C.fmt(null)                                            // —
```

---

## Native charts

Every signature is `fn(pptx, slide, theme, spec)`. Every spec takes `x, y, w, h`
in inches. Shared optional keys: `format` (data label code), `colors` (override
the series array), `showValue`, `labelSize`, `axisSize`.

### trendLine

A continuous measure over five or more periods.

```js
charts.trendLine(pptx, slide, t, {
  x: 0.55, y: slide.contentTop, w: 8.0, h: 3.6,
  categories: ['Q1 FY25','Q2 FY25','Q3 FY25','Q4 FY25','Q1 FY26','Q2 FY26'],
  series: [{ name: 'Net interest margin', values: [3.58,3.64,3.71,3.75,3.79,3.82] }],
  format: charts.FMT.pctRaw2,
  min: 3.4, max: 3.9,          // optional axis bounds
  symbols: true,               // false for a bare line
  valFormat: charts.FMT.pctRaw1,
});
```

With one series, values are labelled. With more than one, labels are suppressed
by default and a legend appears — override with `showValue: true` only if the
lines are well separated.

### trendArea

One cumulative or volume measure. `opacity` defaults to 35.

### columnTrend

Up to eight periods or categories. `gap` sets the bar gap percentage (default 55).

### barRanked

The default for "which is biggest". Long category names stay readable.

```js
charts.barRanked(pptx, slide, t, {
  x: 0.55, y: 1.9, w: 5.2, h: 3.1,
  categories: ['Secured retail','Unsecured retail','SME','Corporate','Agriculture'],
  values: [214, 96, 64, 28, 10],
  sort: 'desc',                // sorts and reverses so the largest sits at the top
  name: 'Contribution',
  format: charts.FMT.int,
  colors: [t.series[1]],       // one colour: these are one series, not five
});
```

Use a single colour. Five colours for five bars of the same measure implies a
distinction that does not exist.

### groupedColumn

Actual against target, side by side. Pass `horizontal: true` for bars.
Defaults to `[primary, neutral]` — the comparison series should always be the
quiet one.

### stackedColumn

`mode: 'stacked' | 'percentStacked'`. Labels are forced to a safe position:
`outEnd` on a stacked chart corrupts the file, so the library coerces it to
`ctr` and carries on.

### comboColumnLine

Two measures on different scales. The hard one, and the one PowerPoint most
often refuses, so the library does the axis bookkeeping for you.

```js
charts.comboColumnLine(pptx, slide, t, {
  x: 0.55, y: slide.contentTop, w: 7.6, h: 4.05,
  categories: ['Q1','Q2','Q3','Q4','Q1','Q2'],
  columns: [{ name: 'Net interest income', values: [1948,2006,2072,2118,2124,2162] }],
  line: { name: 'Net interest margin', values: [3.58,3.64,3.71,3.75,3.79,3.82] },
  leftTitle: '₹ crore', rightTitle: 'Per cent',
  leftFormat: charts.FMT.int,
  rightFormat: charts.FMT.pctRaw1,
  lineFormat: charts.FMT.pctRaw2,
});
```

Because both series carry printed values, they must occupy separate bands of
the plot or the labels collide. The library sets the two axis ranges so that
columns fill the lower 62% and the line floats between 72% and 94%, where its
labels land on clear canvas. Pass `liftLine: false` to return to automatic
scaling, and expect to hide one set of labels if you do.

A combo needs **both** `valAxes` and `catAxes` with two entries each. Supplying
only `valAxes` makes PowerPoint discard the chart and report the file as
corrupt. The library always writes both.

### pareto

Ranked columns plus a cumulative share line. Sorts the data for you and
computes the cumulative percentages.

```js
charts.pareto(pptx, slide, t, {
  x: 0.55, y: 1.9, w: 7.6, h: 3.8,
  categories: ['Duplicate records','Missing values','Stale feeds','Schema drift','Other'],
  values: [412, 268, 141, 88, 34],
  name: 'Defects',
});
```

### progressDonut

One measure against 100%. The only circular chart permitted for a single
number. Turns the positive colour automatically at 100%.

```js
charts.progressDonut(pptx, slide, t, { x: 9.2, y: 2.0, w: 2.2, h: 2.2, percent: 78 });
```

### donutMix

Composition across three to five parts, with a legend on the right.

### scatter

Two dimensions. Pair with `quadrantOverlay`, drawn **before** the chart so the
guides sit behind the marks.

```js
C.quadrantOverlay(pptx, slide, t, {
  x: 0.55, y: 1.9, w: 7.0, h: 3.8,
  labels: [
    { text: 'High value, low effort', x: 0.52, y: 0.05 },
    { text: 'Low value, high effort', x: 0.04, y: 0.90 },
  ],
});
charts.scatter(pptx, slide, t, {
  x: 0.55, y: 1.9, w: 7.0, h: 3.8,
  x: [2,4,5,7,8], series: [{ name: 'Initiatives', y: [3,6,4,8,7] }],
  xTitle: 'Effort (person-months)', yTitle: 'Annual benefit (₹ crore)',
});
```

### radar

Capability or maturity profiles across five to eight dimensions, usually
against a benchmark. `max` defaults to 5.

### sparkline

A bare trend for a KPI card: no axes, no labels, no symbols. Called for you
when a card carries `sparkValues`.

---

## Composed components

### kpiCard

```js
C.kpiCard(pptx, slide, t, {
  x, y, w, h: 1.62,
  label: 'Net interest margin',      // upper-cased by the component
  value: '3.82%',                    // pre-formatted string
  delta: '+7 bps vs plan',
  deltaTone: 'positive',             // positive | negative | neutral | warning
  target: 'Plan 3.75%',              // one short line — it shares the row with the badge
  status: 'achieved',                // drives the achievement treatment
  iconPng: '<data string>',
  badgeIconPng: '<data string>',
  sparkValues: [3.61,3.64,3.71,3.75,3.79,3.82],
  charts,                            // required only when sparkValues is present
});
```

Four cards across the content width is the readable maximum; five and six work
for dense operational packs. Keep `target` to a single short line — it sits
beside the badge, and two lines will crowd it.

### bulletRow

Actual against target on one line. Denser and more honest than a gauge, and it
prints. Turns positive and gains the highlight shadow when value ≥ target.

```js
C.bulletRow(pptx, slide, t, {
  x: 8.0, y: 2.2, w: 4.6, h: 0.4,
  label: 'Certified products', value: 604, target: 640, max: 800,
  valueText: '604',
  labelW: 1.65, valueW: 0.75,
});
```

### varianceBridge

The most useful chart in a results pack, and PowerPoint has no native form for
it.

```js
C.varianceBridge(pptx, slide, t, {
  x: 0.55, y: slide.contentTop, w: 8.0, h: 3.95,
  start: { label: 'H1 FY25', value: 3954 },
  steps: [
    { label: 'Advances\nvolume', value: 412 },
    { label: 'Asset\nrepricing', value: 186 },
    { label: 'Portfolio\nmix',   value: -94 },
    { label: 'Funding\ncost',    value: -172 },
  ],
  end: { label: 'H1 FY26' },
  higherIsBetter: true,       // false for a cost bridge
  format: { decimals: 0 },
  zeroBase: false,            // true to anchor the scale at zero
});
```

The closing total is computed, never passed — so the bridge cannot disagree
with its own arithmetic. Steps take the favourable or adverse colour from
`higherIsBetter`, and an individual step can override with `tone`.

The scale is taken from the extent of the steps, not from zero, because a
bridge anchored at zero compresses every step into a sliver. Totals rise from
the plot floor and every bar prints its value, so nothing can be misread. Set
`zeroBase: true` where a policy requires a full axis.

### heatGrid

```js
C.heatGrid(pptx, slide, t, {
  x: 0.55, y: 1.9, w: 7.6, h: 3.6,
  labelW: 1.85,
  cols: ['Ownership','Quality','Lineage','Retention','Access'],
  rows: ['Customer','Payments','Lending','Risk','Finance'],
  cells: [ [ { text: 'A', tone: 'positive', solid: true }, … ], … ],
});
```

`solid: true` fills with the tone; otherwise the cell is washed with a tone
border. Always include a legend defining the grades — the reader will not guess
what B means.

### funnel

Stage attrition with carry-forward percentages down the right.

```js
C.funnel(pptx, slide, t, {
  x: 0.55, y: 2.0, w: 5.5, h: 3.5,
  stages: [
    { label: 'Registered', value: 1240 },
    { label: 'Ingested',   value: 1086 },
    { label: 'Certified',  value: 604 },
  ],
  conversionLabel: 'Carried forward',
});
```

Label colour is chosen by measured contrast against each band, so the text
stays legible as the ramp darkens.

### milestoneTimeline

Markers alternate above and below the spine so labels never collide. Achieved
milestones render filled, enlarged and shadowed.

```js
C.milestoneTimeline(pptx, slide, t, {
  x: 1.25, y: 2.2, w: 10.8, h: 2.4,
  milestones: [
    { label: 'Cloud landing zone', date: 'Delivered March 2026', status: 'achieved' },
    { label: 'Model risk framework', date: 'Due November 2026', status: 'atRisk' },
  ],
});
```

Five milestones is comfortable, seven is the ceiling. Add a status legend
below using `statusBadge`.

### dataTable

Financial reading conventions built in: header in the primary colour, labels
left, figures right, zebra banding, horizontal rules only.

```js
C.dataTable(pptx, slide, t, {
  x: 0.55, y: 4.3, w: 12.23,
  head: ['Board measure','H1 FY25','H1 FY26','Plan','Variance','Status'],
  colW: [4.4, 1.5, 1.5, 1.5, 1.6, 1.733],       // must sum to w
  rows: [['Net interest margin','3.61%','3.82%','3.75%','+7 bps','Achieved'], …],
  align: ['left','right','right','right','right','center'],
  emphasiseRows: [3],                             // totals
  toneCells: [{ r: 0, c: 4, tone: 'positive', bold: true }],
});
```

Eight rows and six columns is the practical ceiling on one slide. Beyond that,
summarise on the slide and put the full table in an appendix.

### pointRows, callout, panel, statusBadge, sourceNote

`pointRows` replaces bullets with numbered or icon-led rows carrying a bold
assertion and a supporting line. `callout` is a tinted box for the one sentence
you want the reader to take away — one per slide at most. `panel` groups
content. `statusBadge` is the standalone pill. `sourceNote` is the italic
method line under a chart.

---

## Slide furniture

`slideTitle` measures itself: it counts the lines the title needs, sizes its box
accordingly, steps the font down once if the title would run to three lines,
warns on the console if it still does, positions the subtitle below, and
**returns the y at which content may start**. `deck.contentSlide()` stores that
on `slide.contentTop`.

Position everything from `slide.contentTop`. Hard-coded y values are the reason
decks break when a title grows by one word.

`slideFooter` is stamped by `deck.finalise()` — called automatically by
`deck.save()` — so page numbers are correct regardless of the order slides were
built in. Title and section slides are excluded from the count.

---

## Known constraints

These are properties of the file format and the library, not bugs to work
around by hand.

- **Per-point colour is not available on a native bar chart.** To highlight one
  bar, add a `callout` pointing at it, or compose the bars from shapes.
- **Waterfall, bullet, heat grid, funnel and timeline have no native chart
  type.** They are shapes, which is why they live in `components.js`.
- **`outEnd` data labels corrupt stacked charts.** The library coerces to `ctr`.
- **Gradient fills are unsupported.** Use solid fills.
- **`rectRadius` works only on `ROUNDED_RECTANGLE`.**
- **Shadow offsets must be zero or positive.**
- **Option objects are mutated in place** by pptxgenjs on first use. Every
  function here builds its options fresh; if you write your own, do the same
  and never share one object across two calls.
- **One `new PptxGenJS()` per output file.**
