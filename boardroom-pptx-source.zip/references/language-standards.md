# Language standards

The audience is a chief executive, a chief data and analytics officer, a board
committee or a regulator. They read quickly, they read critically, and they
have read a great many decks. The register is formal, plain and confident,
without ornament.

## Contents

1. [Register](#register)
2. [Sentence construction](#sentence-construction)
3. [Words that do not appear](#words-that-do-not-appear)
4. [Tense and certainty](#tense-and-certainty)
5. [Numbers](#numbers)
6. [Banking terminology](#banking-terminology)
7. [Capitalisation](#capitalisation)
8. [Punctuation](#punctuation)
9. [Lists and parallel structure](#lists-and-parallel-structure)
10. [British and American spelling](#british-and-american-spelling)
11. [Attribution and provenance](#attribution-and-provenance)
12. [Correction table](#correction-table)
13. [Proof-reading checklist](#proof-reading-checklist)

---

## Register

Three qualities, in tension, all required.

**Plain.** Say the thing. "The cost-to-income ratio is 120 basis points above
plan" beats "cost efficiency metrics are currently tracking outside of the
envisaged corridor".

**Formal.** No contractions, no slang, no exclamation marks, no emoji, no
rhetorical questions. Write *cannot*, not *can't*; *has not*, not *hasn't*.

**Confident.** State findings as findings. "Margin exceeded target" — not "we
believe margin may have exceeded target" where the number is known. Hedge only
genuine uncertainty, and then hedge precisely.

The test: would this sentence survive being quoted in the minutes?

---

## Sentence construction

- **Active voice by default.** "The Data Office certified 186 products" rather
  than "186 products were certified". Passive is acceptable where the actor is
  irrelevant or deliberately unnamed.
- **One idea per sentence.** Twenty-five words is long for a slide.
- **Subject early.** Do not open with a subordinate clause on a slide; the
  reader may only get halfway.
- **Concrete subjects.** Prefer a named function or team to abstractions like
  "the business" or "the organisation".
- **No nominalisation.** "We decided" rather than "a decision was taken";
  "costs rose" rather than "there was an increase in costs".
- **No stacked modifiers.** "Enterprise-wide strategic data quality remediation
  initiative" is four adjectives looking for a noun. Write "the data quality
  programme".

---

## Words that do not appear

These are the tells of a deck written to impress rather than inform.

| Never | Write instead |
|---|---|
| leverage (as a verb) | use, apply, draw on |
| unlock, supercharge, turbocharge | enable, increase, accelerate |
| game-changing, transformational, best-in-class | describe the actual effect |
| journey (for a programme) | programme, migration, roll-out |
| space (for a market) | market, segment |
| deep dive | detailed review, analysis |
| reach out | contact, ask, write to |
| circle back, touch base | return to, follow up |
| learnings | lessons, findings |
| ideate, operationalise, incentivise | design, put into operation, reward |
| going forward | from [date], in future, or delete |
| at this point in time | now, currently, or delete |
| very, significantly, substantially, dramatically | the number |
| robust, holistic, synergistic, seamless | delete, or state the property |
| align on | agree |
| double-click on | examine |
| north star, moonshot, low-hanging fruit | the objective, the quick wins |

Two further prohibitions. **Never write "significant" about a number without
saying how much** — if it is significant, the figure proves it. And **never use
"drive" as an all-purpose verb**: costs are reduced, adoption is increased,
change is led.

---

## Tense and certainty

| Subject | Tense | Example |
|---|---|---|
| A result in the period | Past | "Net interest income rose 8.4%." |
| A current state | Present | "Four domains hold a certification." |
| A committed plan | Present or future | "Delivery is scheduled for November 2026." |
| A projection | Conditional, with basis | "On current pricing, margin would hold above 3.75%." |

Calibrate certainty to evidence, and use one word from this ladder rather than
vague hedging:

| Word | Means |
|---|---|
| is, was | Measured, reconciled |
| estimated at | Calculated on a stated basis |
| expected to | More likely than not, on current assumptions |
| may | Possible, not forecast |
| is at risk of | An identified threat with an owner |

"We think it should probably be fine" says nothing a committee can act on.

---

## Numbers

**Consistency is the rule that matters most.** One unit, one scale, one number
of decimal places per measure, across the entire deck.

- **Scale.** Choose crore, lakh, million or billion once, state it in the
  subtitle, and never mix. If the audience is domestic, ₹ crore. If it is
  international or the pack goes to a parent entity, convert everything and say
  so.
- **Currency symbol on first use in a block**, then rely on the stated unit:
  "₹4,286 Cr" in the KPI value, "4,286" in the chart whose subtitle reads
  "(₹ crore)".
- **Percentages against percentages are basis points.** A move from 3.61% to
  3.82% is 21 basis points, not 0.21% and not 5.8%. Write "bps" after a number,
  spelled out on first use: "21 basis points (bps)".
- **Percentage points** for differences between percentages that are not rates:
  "share rose 4 percentage points".
- **Decimals.** Two for rates and ratios (3.82%), one for large currency in
  crore (₹4,286.0 Cr only if the precision is real), none for counts. Never
  present more precision than the data supports.
- **Signed variances.** Always show the sign: +7 bps, −36 bps. Use a true minus
  sign, not a hyphen.
- **Direction words, not just signs.** "The ratio rose 120 bps" tells the reader
  whether that is good; "+120 bps" alone does not.
- **Rounding.** Where components are rounded, totals may not sum. Say so, once,
  in the source note: *"Figures may not sum precisely because of rounding."*
  Never adjust a component to force a total.
- **Indian digit grouping** (12,34,56,789) where the audience is domestic:
  `C.fmt(n, { grouping: 'indian' })` or `FMT.inrIndian`. International grouping
  otherwise. Not both in one deck.
- **Dates in full**: 30 June 2026. Not 30/06/26, which means two different days
  depending on the reader.
- **Periods named consistently**: H1 FY26, Q2 FY26. Define the financial year
  in the appendix if the audience spans jurisdictions.
- **Spell out numbers below ten** in prose — "three decisions are sought" — but
  never in a table, a label or a measurement.

---

## Banking terminology

Expand on first use, then abbreviate. Expansion goes in the subtitle or a
footnote, never inside the title.

| Abbreviation | First use |
|---|---|
| NII | net interest income (NII) |
| NIM | net interest margin (NIM) |
| CASA | current account and savings account (CASA) |
| CIR | cost-to-income ratio (CIR) |
| GNPA / NNPA | gross / net non-performing assets |
| PCR | provision coverage ratio (PCR) |
| CRAR | capital to risk-weighted assets ratio (CRAR) |
| LCR / NSFR | liquidity coverage ratio / net stable funding ratio |
| RoA / RoE | return on assets / return on equity |
| CoF | cost of funds (CoF) |
| SMA | special mention account (SMA) |
| AML / CFT | anti-money laundering / countering the financing of terrorism |
| KYC | know your customer (KYC) |
| ECL | expected credit loss (ECL) |
| RWA | risk-weighted assets (RWA) |

Data and analytics terms deserve the same discipline, because they are less
familiar to a board than their users assume: **data product**, **data domain**,
**certification**, **lineage**, **golden source**, **model risk** and
**straight-through processing** should each be defined in the appendix if the
deck depends on them.

Use the institution's own terms. If the bank says "customer" rather than
"client", or "advances" rather than "loans", follow it throughout.

---

## Capitalisation

- **Sentence case for titles, headings and table headers.** Not Title Case.
- **Upper case only for kickers and KPI labels**, with letter spacing. Nothing
  else.
- **Job titles**: capitalised when naming the office ("the Chief Risk Officer
  will own the control"), lower case when generic ("a chief risk officer").
- **Committees and bodies**: capitalised when naming a specific one ("the Board
  Risk Committee"), lower case generically ("the committee agreed").
- **Products, systems and programmes**: capitalised as the institution writes
  them. Check, do not guess.
- **Departments**: "Group Finance", "the Data Office" — capitalised as proper
  names; "the finance team" — not.
- Never capitalise a common noun for emphasis. The Bank's Strategic Priorities
  is not more important than the bank's strategic priorities; it is only harder
  to read.

---

## Punctuation

- **No full stop** at the end of a slide title, a KPI label, a table cell or a
  fragment in a list. Full stops on complete sentences in prose blocks.
- **Serial comma** when it removes ambiguity; consistently, either way.
- **En dash** for ranges (2024–2026) and a spaced en dash for parenthetical
  asides. Avoid em dashes on slides; they read as informal.
- **Colons** introduce a list or a definition, never a dramatic pause.
- **Semicolons** join two independent clauses in a title: "Two milestones
  delivered early; the model risk framework has slipped."
- **No ampersand** in prose; acceptable in a column header where width is tight.
- **No "etc."** — either the list is complete or it is illustrative, and
  "including" says so.
- **Quotation marks** only for genuine quotation. Never for irony or to flag a
  term you are uncomfortable with.

---

## Lists and parallel structure

Every item in a list starts with the same part of speech and takes the same
grammatical form.

Wrong:
- Reduce costs by 4%
- Certification of the risk domain
- We should hire two engineers

Right:
- Reduce costs by 4%
- Certify the risk domain
- Recruit two data engineers

Point rows carry a bold assertion and one supporting sentence. The assertion is
a claim, not a category label: "Advances grew 11.2%", not "Advances".

---

## British and American spelling

Pick one and hold it across every slide, footnote and chart label. The default
for an Indian or UK institution is British; for a US parent or listing, American.

| British | American |
|---|---|
| organisation, prioritise, recognise | organization, prioritize, recognize |
| analyse, utilise, normalise | analyze, utilize, normalize |
| programme (initiative) | program |
| centre, metre | center, meter |
| licence (noun) / license (verb) | license (both) |
| practice (noun) / practise (verb) | practice (both) |
| behaviour, favourable, labour | behavior, favorable, labor |
| catalogue, dialogue | catalog, dialog |
| judgement (general) | judgment |
| towards, amongst | toward, among |

Note the one exception British English itself makes: a **computer program** is
a program even in British spelling; a **change programme** is a programme.

---

## Attribution and provenance

Every slide states where its numbers came from and what date they are true as
at. `deck` does this automatically from `meta`, but the wording is yours.

- **Source**: the system or team, not the file. "Group Finance" or "Core
  banking system, via the Group data warehouse". Not "final_v7.xlsx".
- **As at**: the date the data represents, not the date the slide was made.
- **Basis**: state it when it is not obvious — "management accounts,
  unaudited", "excludes the acquired portfolio", "constant currency".
- **Definition changes**: when a measure has been restated, say so on the slide
  carrying it, not only in the appendix.
- **Forward-looking figures** need the basis in the same sentence: "on current
  pricing and no further rate movement, margin would hold above 3.75%".
- **Attribute judgements.** "The Data Office assesses the risk domain as below
  threshold" is different from "the risk domain is below threshold", and a
  committee will want to know which one it is being told.

---

## Correction table

Real sentences, corrected. The pattern on the left is what a first draft
produces.

| First draft | Corrected |
|---|---|
| Significant improvement in margins was seen | Net interest margin rose 21 bps to 3.82% |
| We are on a journey to leverage our data assets | The data platform is in its second year of a three-year migration |
| Costs were slightly higher than expected | The cost-to-income ratio was 120 bps above plan, at 41.2% |
| KPIs are mostly green | Four of six board measures met plan; two are at risk |
| The team did a great job on the migration | The migration completed six weeks ahead of schedule |
| There has been an increase in the number of certified data products | Certified data products rose by 186 in the half, to 604 |
| Going forward we will be looking to drive adoption | From October, the Data Office will publish adoption by division each month |
| Deep dive on NPAs | Gross non-performing assets fell 36 bps to 2.14% |
| It is expected that the framework may possibly be delayed | The model risk framework is at risk of a six-week delay |
| Best-in-class data quality capabilities | Automated quality checks cover 78% of certified products, against a peer median of 64% |

---

## Proof-reading checklist

Read the deck once for each of these, separately. Reading for everything at
once catches nothing.

1. **Titles.** Is each one an assertion the slide proves? Twelve words or fewer?
   Sentence case, no full stop?
2. **Numbers.** Same unit, same scale, same decimals for the same measure
   everywhere? Does every total tie? Does every figure on a slide match the
   source ledger?
3. **Signs and direction.** Is every variance signed, and does its colour match
   whether it is good news?
4. **Terminology.** Every abbreviation expanded on first use? The institution's
   own vocabulary used throughout?
5. **Spelling convention.** British or American, consistently, including in
   chart labels and axis titles?
6. **Parallel structure.** Does every list item take the same grammatical form?
7. **Banned words.** Search for *leverage*, *journey*, *robust*, *significant*,
   *going forward*, *deep dive*.
8. **Provenance.** Source, as-at date and classification on every content slide?
9. **Ownership.** Does every action and every decision name a person and a date?
10. **The read-aloud test.** Read each title aloud. If it sounds like a label
    rather than a statement, rewrite it.
