# Icon system

Bootstrap Icons, MIT licensed, 2,078 glyphs, fetched as SVG, recoloured to a
theme token and rasterised to PNG.

Three properties the module guarantees, none of which survive doing this by
hand:

1. **No missing icons.** Every name is checked against the bundled manifest,
   taken from the published `font/bootstrap-icons.json`, before any request is
   made. A wrong name fails immediately with the nearest real alternatives,
   rather than producing a blank square in the finished deck.
2. **No wrong icons.** A concept resolves through a ranked candidate list, so a
   net interest margin card gets a percent sign and not a generic document.
3. **No repeats.** A ledger records what has been used. Two different concepts
   never receive the same glyph in one deck.

## Contents

1. [Using it](#using-it)
2. [How resolution works](#how-resolution-works)
3. [The uniqueness rule](#the-uniqueness-rule)
4. [Sizing and colour](#sizing-and-colour)
5. [Where icons belong](#where-icons-belong)
6. [The concept catalogue](#the-concept-catalogue)
7. [Adding concepts](#adding-concepts)
8. [Troubleshooting](#troubleshooting)

---

## Using it

One ledger per deck. Create it once, pass it everywhere.

```js
const { IconLedger, png, iconFor } = require('./lib/icons');
const L = new IconLedger();

// Resolve and render in one step
const { name, data } = await iconFor(L, 'Net interest margin', t.inkInverse, 96);
// name === 'percent'

// Or in two, when you want to log the choice
const glyph = L.pick('Cloud migration');          // 'cloud-arrow-up'
const img   = await png(glyph, t.primary, 96);

// Status glyphs bypass the ledger — a legend must repeat
const badge = await png(t.status.achieved.icon, t.inkInverse, 96);

console.log(L.report());   // [{ icon, concept }, …] — paste into QA notes
```

Render size is 96px for card and row icons, 128px where an icon is displayed
above about 0.4 in. Files are cached in `.icon-cache/`, so a rebuild costs
nothing.

---

## How resolution works

`L.pick(label)` runs four steps.

**1. Exact concept.** If the label matches a key in `CONCEPTS`, its candidate
list is used directly.

**2. Word scoring.** Otherwise the label is reduced to content words —
stopwords like *net*, *total*, *gross*, *average*, *rate*, *value*, *key* are
dropped — and each concept key is scored against them:

| Match | Score |
|---|---|
| Exact word | +3 |
| One word is a prefix of the other | +2 |
| Shared five-letter stem (*achieve* / *achieved* / *achievement*) | +2 |
| One word contains the other | +1 |
| The label's **final** word matches the concept | +4 |

That last rule matters more than it looks. English puts the head noun last: in
*service availability* the subject is availability, not service; in *model risk*
it is risk, not the model. Weighting the final word is what makes the matcher
behave the way a reader would.

**3. Merge.** Candidates from the four best-scoring concepts are concatenated,
best first, with generic shapes appended as a last resort.

**4. Ledger filter.** The first candidate not already used in this deck is
returned and recorded.

Worked examples, all produced by the module:

| Label | Resolves to |
|---|---|
| Net interest margin | `percent` |
| Net interest income | `cash-coin` |
| Cost-to-income ratio | `pie-chart` |
| Certified data products | `database` |
| Customer attrition | `person-dash` |
| Regulatory compliance | `clipboard-check` |
| Service availability | `reception-4` |
| Cloud migration | `cloud-arrow-up` |
| Model risk framework | `shield-exclamation` |
| Data governance | `diagram-3` |

---

## The uniqueness rule

**One concept, one icon. One icon, one concept.**

Asking for the same concept twice returns the same glyph — that is consistency,
and it is desirable. Asking for a *different* concept gets a different glyph,
always.

When every candidate for a label is already taken, the ledger throws rather
than silently duplicating:

```
Every candidate for "Deposit growth" is already used in this deck
(graph-up-arrow, arrow-up-right-circle, rocket-takeoff, bar-chart-line).
Add a candidate to CONCEPTS or pass opts.candidates.
```

Two fixes, in order of preference:

```js
// 1. Say what you actually mean for this item
L.pick('Deposit growth', { candidates: ['piggy-bank', 'bank2', 'safe', 'cash-stack'] });

// 2. Add the concept permanently to CONCEPTS in lib/icons.js
```

**The one exception** is the status vocabulary. `achieved`, `onTrack`,
`atRisk`, `offTrack` and `notStarted` repeat by design, on every card, badge and
milestone that carries that state. A legend that changed its symbols would be
useless. Those glyphs come from `theme.status`, never from the ledger.

---

## Sizing and colour

| Context | Disc | Glyph | Colour |
|---|---|---|---|
| KPI card, standard | 0.34 in `primarySoft` | 0.17 in | `primary` |
| KPI card, achieved | 0.34 in solid `positive` | 0.17 in | `inkInverse` |
| Point row | 0.36 in tone wash | 0.18 in | the tone |
| Status badge, outlined | none | 0.13 in | the tone |
| Status badge, solid | none | 0.13 in | `inkInverse` |
| Milestone marker | 0.18–0.24 in | none | the tone |

Never place a glyph directly on the canvas without its disc — the disc is the
deck's visual motif, and a floating icon reads as clip art. Never place a dark
glyph on a dark fill: use `t.onColour(fill)` if you are unsure.

Bootstrap icons carry `fill="currentColor"`, which no rasteriser can resolve.
The module substitutes the hex before rendering; that is why you pass a colour
rather than recolouring afterwards.

---

## Where icons belong

Use them on KPI card labels, point rows, status badges, milestone markers and
section numbers.

Do not use them as slide decoration, as a substitute for a chart, inside chart
plot areas, or at more than about eight per slide. An icon should identify
something, not fill space.

---

## The concept catalogue

124 concepts, every candidate verified against the manifest. Run
`node scripts/verify-icons.js` to confirm after any edit.

**Financial performance** — revenue, income, profit, cost, expense, margin,
ratio, growth, decline, budget, forecast, variance, target, achievement,
pricing, repricing, fee, interest, capex, opex

**Balance sheet and products** — bank, deposits, casa, loans, advances,
mortgage, cards, payments, treasury, capital, liquidity, npa, collections,
branch, atm

**Customer** — customer, acquisition, retention, attrition, satisfaction,
segment, onboarding, channel, digital

**Risk and control** — risk, fraud, aml, kyc, compliance, regulation, audit,
control, security, privacy, resilience

**Data and technology** — data, dataQuality, dataGovernance, lineage, pipeline,
ingestion, warehouse, cloud, migration, platform, analytics, reporting,
dashboard, selfService, ai, model, automation, api, integration, latency,
uptime, storage, catalogue, certification

**Programme and people** — strategy, roadmap, milestone, programme, delivery,
timeline, people, talent, training, adoption, governance, partnership, vendor,
investment, efficiency, productivity, innovation, sustainability, headcount

**Operations** — processing, transaction, volume, quality, speed, accuracy,
coverage, availability, incident, backlog, escalation

**Narrative furniture** — summary, decision, recommendation, issue, mitigation,
dependency, question, appendix, method, benchmark, market, competition,
timeframe, region, trajectory

---

## Adding concepts

Four candidates per concept, best first, each a real Bootstrap icon name.
Four is the working minimum: fewer and the ledger runs out on a dense deck.

```js
// in lib/icons.js
securitisation: ['layers-half', 'stack', 'file-earmark-binary', 'boxes'],
```

Then verify:

```bash
node scripts/verify-icons.js
```

It reports any candidate that is not a real icon, with the nearest real names,
and lists concepts sharing a first choice. Shared first choices are fine — the
ledger resolves them — but a concept whose whole list overlaps another's is a
future failure.

---

## Troubleshooting

**A fallback shape appeared** (`circle-fill`, `square-fill`, `diamond-fill`).
Nothing scored above zero. Add the concept, or pass explicit candidates.

**The wrong icon, semantically.** The head-noun rule chose the last word and
you meant the first. Pass explicit candidates for that item; do not reorder the
sentence to fool the matcher.

**`"x" is not a Bootstrap icon`.** The name does not exist in the manifest. The
error lists the nearest real names. Do not guess — `chess-knight`,
`filter`, `server-rack` and `scale` all look plausible and none exist.

**A network failure.** Name validation works offline from the bundled manifest,
but rasterising needs the SVG. Warm the cache on a connected machine, or supply
your own PNGs: every component checks `if (spec.iconPng)` and lays out cleanly
without one.

**A different icon set.** Anything that resolves to an SVG with a substitutable
colour attribute works. Replace `SVG_URL` and the manifest, keep the ledger.
Note that stroke-based sets such as Lucide need `stroke` substituted rather
than `fill`.
