# Design system

Every value here exists in `lib/theme.js`. Read the hex from the token, never
type a colour into a slide by hand.

## Contents

1. [How a theme is built](#how-a-theme-is-built)
2. [The seven palettes](#the-seven-palettes)
3. [Choosing a palette](#choosing-a-palette)
4. [Semantic colour](#semantic-colour)
5. [The achievement treatment](#the-achievement-treatment)
6. [Typography](#typography)
7. [Grid and spacing](#grid-and-spacing)
8. [Elevation](#elevation)
9. [Visual motif](#visual-motif)
10. [Accessibility and print](#accessibility-and-print)
11. [Extending with a brand palette](#extending-with-a-brand-palette)

---

## How a theme is built

```js
const { createTheme } = require('./lib/theme');
const t = createTheme('meridian-navy', 'boardroom-classic');

t.ink            // primary text
t.canvas         // slide background
t.surface        // card background
t.primary        // dominant brand colour
t.accent         // the single sharp colour, used sparingly
t.series[0..5]   // categorical chart colours, in order
t.ramp[0..5]     // sequential ramp, light to dark
t.tone('positive')   // semantic lookup
t.wash('positive')   // the tinted surface for that tone
t.onColour('123E6B') // returns whichever of ink / inkInverse is legible on it
```

Token vocabulary, consistent across all seven palettes:

| Token | Meaning |
|---|---|
| `ink` | Primary text on the canvas |
| `inkMuted` | Secondary text: labels, captions, axis text, footers |
| `inkInverse` | Text reversed out of a solid dark or solid brand fill |
| `canvas` | The slide background |
| `surface` | Card and panel background, one step from the canvas |
| `surfaceAlt` | Second-level fill: table banding, empty track, header cells |
| `hairline` | Borders and grid lines. Never used for text |
| `primary` | Dominant colour. 60–70% of the coloured area of a deck |
| `primaryDeep` | Title and section-slide backgrounds |
| `primarySoft` | Icon discs, quiet fills, on-track wash |
| `accent` | One sharp colour. Section numbers, the secondary line on a combo |
| `positive` `warning` `negative` `neutral` | Semantic states |
| `*Wash` | The tinted card fill for each state |
| `series` | Six categorical chart colours, in intended order |
| `ramp` | Six sequential shades for funnels, heat grids, choropleths |

---

## The seven palettes

### Meridian Navy — light — default

| Token | Hex | Token | Hex |
|---|---|---|---|
| ink | `0B1F3A` | positive | `0E7C61` |
| inkMuted | `5A6B82` | positiveWash | `E4F2EE` |
| inkInverse | `FFFFFF` | warning | `B26B0F` |
| canvas | `FFFFFF` | warningWash | `FBEFE0` |
| surface | `F4F6FA` | negative | `A8231D` |
| surfaceAlt | `E8EDF5` | negativeWash | `F8E7E5` |
| hairline | `D4DCE8` | neutral | `7A8AA0` |
| primary | `123E6B` | neutralWash | `EEF1F6` |
| primaryDeep | `0B1F3A` | accent | `A8801C` |
| primarySoft | `CBD8E8` | | |

Series `123E6B` · `3E86B5` · `0E7C61` · `A8801C` · `6B5B95` · `8A94A6`
Ramp `E8EDF5` · `C3D2E4` · `8FAAC9` · `5A7FAC` · `2A5687` · `123E6B`

### Graphite Teal — light

| Token | Hex | Token | Hex |
|---|---|---|---|
| ink | `12181F` | positive | `1C7C43` |
| inkMuted | `5C6773` | positiveWash | `E5F1E9` |
| canvas | `FFFFFF` | warning | `B26B0F` |
| surface | `F3F5F7` | warningWash | `FAEEE0` |
| surfaceAlt | `E5EAEE` | negative | `9E2B24` |
| hairline | `D2D9DF` | negativeWash | `F6E6E5` |
| primary | `12556B` | neutral | `76828F` |
| primaryDeep | `072F3D` | neutralWash | `EDEFF2` |
| primarySoft | `C9DEE6` | accent | `C2610C` |

Series `12556B` · `4795AE` · `1C7C43` · `C2610C` · `5C5F8C` · `8A939C`
Ramp `E5EAEE` · `C2D8E0` · `8EBAC8` · `5795AB` · `23708B` · `12556B`

### Oxford Indigo — light

| Token | Hex | Token | Hex |
|---|---|---|---|
| ink | `171A2E` | positive | `1B7A4D` |
| inkMuted | `5B6080` | positiveWash | `E5F1EA` |
| canvas | `FFFFFF` | warning | `A87308` |
| surface | `F5F5FA` | warningWash | `F9F0DC` |
| surfaceAlt | `E8E9F3` | negative | `9C2A2A` |
| hairline | `D7D8E6` | negativeWash | `F6E6E6` |
| primary | `2E3A8C` | neutral | `7B819C` |
| primaryDeep | `171F52` | neutralWash | `EFEFF5` |
| primarySoft | `D2D7F0` | accent | `BE6A10` |

Series `2E3A8C` · `6A79D1` · `1B7A4D` · `BE6A10` · `8C5AA8` · `868BA6`
Ramp `E8E9F3` · `CBCFEA` · `9CA4DA` · `6C76C4` · `44509F` · `2E3A8C`

### Burgundy Ledger — light

| Token | Hex | Token | Hex |
|---|---|---|---|
| ink | `241419` | positive | `1C7047` |
| inkMuted | `6B5A60` | positiveWash | `E6F0EA` |
| canvas | `FFFFFF` | warning | `A8701A` |
| surface | `F8F5F5` | warningWash | `F8EEDE` |
| surfaceAlt | `EDE5E6` | negative | `A03028` |
| hairline | `DCD1D3` | negativeWash | `F7E7E5` |
| primary | `6E1F32` | neutral | `8A7A7E` |
| primaryDeep | `3F0F1D` | neutralWash | `F1EDED` |
| primarySoft | `E4CDD3` | accent | `A8801C` |

Series `6E1F32` · `A85A6B` · `1C7047` · `A8801C` · `4E5A8C` · `8A7A7E`
Ramp `EDE5E6` · `DCC0C6` · `C293A0` · `A16278` · `85405A` · `6E1F32`

### Porcelain Steel — light — print and greyscale

| Token | Hex | Token | Hex |
|---|---|---|---|
| ink | `1B1F24` | positive | `19653F` |
| inkMuted | `5A626C` | positiveWash | `E6EEE9` |
| canvas | `FFFFFF` | warning | `8A5A00` |
| surface | `F5F6F7` | warningWash | `F5EDDC` |
| surfaceAlt | `E8EAEC` | negative | `8C2F28` |
| hairline | `D4D8DC` | negativeWash | `F3E6E5` |
| primary | `33414F` | neutral | `767E88` |
| primaryDeep | `1B242E` | neutralWash | `EFF1F2` |
| primarySoft | `D6DBE0` | accent | `0F6E8C` |

Series `33414F` · `6E7B89` · `19653F` · `0F6E8C` · `8A5A00` · `A6AEB6`
Ramp `E8EAEC` · `C8CDD3` · `9BA3AC` · `6E7884` · `4A5562` · `33414F`

Every state colour in this palette is dark enough to remain distinguishable
when the page is photocopied. Use it whenever the pack will be printed.

### Charcoal Copper — dark

| Token | Hex | Token | Hex |
|---|---|---|---|
| ink | `F2F4F7` | positive | `3BA776` |
| inkMuted | `A6B0BD` | positiveWash | `16342A` |
| inkInverse | `14181D` | warning | `E0A030` |
| canvas | `14181D` | warningWash | `3A2E14` |
| surface | `1C2229` | negative | `E0685C` |
| surfaceAlt | `262E37` | negativeWash | `3A1F1C` |
| hairline | `36404B` | neutral | `8A94A0` |
| primary | `C97B3F` | neutralWash | `232A32` |
| primaryDeep | `8A4F22` | accent | `5FA8D3` |
| primarySoft | `3A2A1E` | | |

Series `C97B3F` · `5FA8D3` · `3BA776` · `D9C06A` · `9B8AC4` · `8A94A0`

### Midnight Sapphire — dark

| Token | Hex | Token | Hex |
|---|---|---|---|
| ink | `EAF0F8` | positive | `35B37E` |
| inkMuted | `9AAAC2` | positiveWash | `113329` |
| inkInverse | `0C1424` | warning | `E0A93B` |
| canvas | `0C1424` | warningWash | `33290F` |
| surface | `141E33` | negative | `E2685C` |
| surfaceAlt | `1D2A45` | negativeWash | `361C1A` |
| hairline | `2C3C59` | neutral | `8493AB` |
| primary | `3E7BD6` | neutralWash | `1A2438` |
| primaryDeep | `1E4A8F` | accent | `E2B857` |
| primarySoft | `1B2C4C` | | |

Series `3E7BD6` · `6FB3E0` · `35B37E` · `E2B857` · `9B8AD6` · `8493AB`

---

## Choosing a palette

Ask three questions in order.

1. **Does the organisation have a brand palette?** If so, map it into a theme
   (see the last section) rather than inventing one.
2. **Where will the deck be consumed?** Printed board pack → Porcelain Steel.
   Projected in a large dark room → Midnight Sapphire or Charcoal Copper.
   Read on a laptop → any of the light palettes.
3. **What is the subject?** Financial results and governance → Meridian Navy.
   Data and platform → Graphite Teal. Strategy and change → Oxford Indigo.
   Wealth and heritage → Burgundy Ledger.

Then commit. Changing palette halfway through a deck is the single most
visible sign that a pack was assembled rather than designed.

**Mixing modes.** A light deck may use its own `primaryDeep` as the background
of the title, section and closing slides. That is the sandwich structure, and
`deck.titleSlide()` and `deck.sectionSlide()` already do it. Do not mix modes
on a content slide.

---

## Semantic colour

Colour carries meaning in exactly four places. Nowhere else.

| Meaning | Token | Applied to |
|---|---|---|
| Target met, favourable variance | `positive` | Achieved cards, favourable bridge steps, met bullet bars |
| Watch, approaching tolerance | `warning` | At-risk badges, amber heat cells |
| Breach, adverse variance | `negative` | Off-track badges, adverse bridge steps |
| No judgement | `neutral` | Not started, comparison and prior-year series |

Direction is not the same as good news. A rising cost line is an adverse
movement. Use `t.varianceTone(delta, higherIsBetter)` and pass
`higherIsBetter: false` for costs, attrition, latency, non-performing assets,
incident counts and anything else where less is better.

```js
t.varianceTone(+120, false)   // 'negative' — costs rose
t.varianceTone(-36,  false)   // 'positive' — non-performing assets fell
```

---

## The achievement treatment

The user-visible effect of `status: 'achieved'` on a KPI card:

| Property | Standard card | Achieved card |
|---|---|---|
| Fill | `surface` | `positiveWash` |
| Border | 0.75pt `hairline` | 1.25pt `positive` |
| Value colour | `ink` | `positive` |
| Icon disc | `primarySoft`, dark glyph | solid `positive`, reversed glyph |
| Elevation | `card` — 8pt blur, 10% | `highlight` — 18pt blur, 30% |
| Badge | outlined, tinted | **solid**, reversed text and glyph |

The same signal appears elsewhere in the library, always meaning the same
thing: a bullet row whose value reaches its target switches to `positive` and
gains the highlight shadow; a milestone marked `achieved` renders as a filled,
enlarged, shadowed disc rather than an outline.

If the user asks for animation, the achievement badge is the one element that
earns an emphasis effect — a single `pulse`, once, when its card arrives.

**Do not** apply the treatment to a measure that improved but missed target, to
the best of a bad set, or to a figure with no stated target. "Improved" is a
`positive` delta line on a standard card. Achievement means the target was met.

---

## Typography

Two typefaces, never three: one display face for titles and large numbers, one
text face for everything else. A monospace face is permitted in reconciliation
tables only.

### Pairings

| Key | Display | Body | Mono | QA-safe |
|---|---|---|---|---|
| `boardroom-classic` | Cambria | Calibri | Courier New | yes |
| `institutional-sans` | Arial | Arial | Courier New | yes |
| `regulatory-serif` | Century Schoolbook | Calibri | Courier New | yes |
| `ledger-book` | Bookman Old Style | Calibri | Courier New | yes |
| `modern-grotesque` | Segoe UI Semibold | Segoe UI | Consolas | no |
| `editorial-contrast` | Georgia | Segoe UI | Consolas | no |

The fonts written into the file are rendered by the reader's PowerPoint, not by
this environment. The QA preview substitutes anything it does not have, and for
the two pairings marked "no" the substitute has different widths — so an
apparent overflow in the preview may not be real, and an apparent fit may not
be either. With those two, leave roughly 10% slack and check on a real machine.

Never specify Aptos. It has no metric-compatible substitute here and is absent
from older Office installations, so it is unreliable at both ends.

### Scale

| Element | Token | Size |
|---|---|---|
| Deck title | `deckTitle` | 40 |
| Section title | `sectionTitle` | 32 |
| Slide title | `slideTitle` | 24, stepping to 21 if it would run to three lines |
| KPI value, hero number | `kpiValue` / `kpiValueLarge` | 30 / 40 |
| Lead paragraph | `lead` | 16 |
| Body | `body` | 13 |
| Dense body, table cells, bullet rows | `dense` | 11.5 |
| Kicker, KPI label | `kicker` / `kpiLabel` | 11 / 10.5 |
| Caption | `caption` | 10 |
| Footnote, source, footer | `footnote` | 8.5 |

Four sizes on a slide is the maximum. Contrast between them must be obvious: a
24pt title against 13pt body is clear; 16pt against 14pt looks like a mistake.

### Rules

- **Kickers and KPI labels** are upper case with `charSpacing: 0.8` to `1.6`.
  Nothing else is upper case — not titles, not headings, not table headers.
- **Numbers are right-aligned** in every table column that contains them.
  Labels left, figures right. Always.
- **Never centre body text.** Titles may be left-aligned or, on a title slide,
  left-aligned. Paragraphs and lists are always left-aligned.
- **Set `margin: 0`** on any text box that must align with a shape, rule or
  icon. Text boxes carry internal padding that will otherwise offset them.
- **Bold carries meaning**: labels, totals, the achieved value, the assertion
  in a point row. Bolding for emphasis inside a sentence is not done.
- Italic is for source notes and method statements only.

---

## Grid and spacing

Canvas 13.333 × 7.5 inches. Set the layout before adding a single slide.

| Property | Value |
|---|---|
| Margin | 0.55 in on all four sides |
| Columns | 12 |
| Gutter | 0.22 in |
| Content width | 12.233 in |
| Column width | 0.8178 in |
| Footer baseline | y = 6.92 |

```js
t.colX(9)        // x of column 9
t.colSpan(4)     // width of a four-column span
t.cardRow(4)     // [{x,w} …] for four equal cards across the content width
```

Common spans: a KPI band of four cards is `cardRow(4)`, each 2.893 in wide. A
two-thirds / one-third split is `colSpan(8)` and `colX(9) + colSpan(4)`. A half
split is `colSpan(6)` and `colX(7)`.

### Vertical rhythm

| Band | y |
|---|---|
| Kicker | 0.42 |
| Title | 0.64, height measured from the text |
| Subtitle | directly below the title |
| Content | `slide.contentTop` — never a hard-coded number |
| Footer | 6.92 |

Gaps between content blocks: choose 0.22 in (the gutter) or 0.44 in and use the
same one throughout. Nothing sits closer than 0.3 in to anything else, and
nothing comes within 0.5 in of a slide edge.

---

## Elevation

Three levels, all with a positive offset because a negative offset corrupts the
file. To cast a shadow upward, use `angle: 270` with a positive offset.

| Level | Blur | Offset | Opacity | Applied to |
|---|---|---|---|---|
| `card` | 8 | 2 | 0.10 | Standard cards, panels, bridge totals |
| `raised` | 14 | 3 | 0.16 | A card being singled out for discussion |
| `highlight` | 18 | 3 | 0.30 | The achievement treatment only |

Callouts, badges and heat cells take no shadow. Shadow everything and nothing
reads as raised.

---

## Visual motif

Pick one and repeat it on every slide. This library's motif is **the icon disc**:
a filled circle carrying a single reversed or tinted glyph, at 0.34 in on cards
and 0.36 in in point rows. It appears on KPI cards, point rows, status badges
and milestone markers, and nowhere else.

### Never

- **No accent line under a title.** Whitespace separates the title from the body.
- **No colour bars or stripes** — not a header band across the slide, not a
  vertical strip down an edge, not a thin rule along one side of a card. A card
  is set apart by its fill, its border and its shadow.
- **No gradient fills.** `pptxgenjs` does not support them; a gradient image
  background is the only route and is rarely worth it.
- **No 3-D charts, no chart shadows, no rounded bar caps** on data marks.
- **No pie chart with more than five slices**, and no pie at all where a bar
  would answer the question.
- **No decorative stock photography** in a results pack.

---

## Accessibility and print

- **Contrast.** Body text needs 4.5:1 against its fill, large text 3:1. Use
  `t.onColour(fill)` to pick the text colour rather than guessing;
  `t.contrastRatio(a, b)` returns the measured ratio.
- **Never colour alone.** Every status carries a glyph, every chart series is
  labelled, every heat cell carries a letter grade. Test by converting a slide
  to greyscale: if a reader cannot tell achieved from at-risk, fix it.
- **Series order matters.** The first three series in every palette are
  distinguishable under the common forms of colour blindness. Charts with more
  than four series should be split or turned into small multiples.
- **Minimum size.** Nothing below 8.5pt, and 8.5pt is reserved for footers and
  source notes. Table cells do not go below 11.5pt.
- **Alt text.** Set `altText` on every image and chart so screen readers and
  accessibility checkers report a clean deck.
- **Greyscale check** before a pack goes to print: convert to PDF, print one
  page in black and white, and confirm the states are still distinct. Porcelain
  Steel is built for this.

---

## Extending with a brand palette

When the organisation has its own colours, map rather than replace:

1. The brand's primary becomes `primary`; a darkened form becomes `primaryDeep`
   and a tint at roughly 18% becomes `primarySoft`.
2. Keep the semantic four — `positive`, `warning`, `negative`, `neutral` — from
   the nearest built-in palette unless the brand defines its own. Brand palettes
   rarely define a credible adverse colour.
3. If the brand primary is green, move it to the accent slot and choose a
   neutral dominant colour instead. Green must stay free to mean "achieved".
4. Rebuild the series array so no two adjacent entries are close in lightness.
5. Run `t.contrastRatio()` over every text-on-fill pairing before using it.

```js
const { createTheme } = require('./lib/theme');
const t = createTheme('meridian-navy', 'boardroom-classic', {
  seriesOverride: ['0C4A6E', '0E7490', '15803D', 'B45309', '6D28D9', '64748B'],
});
```

For a full custom palette, copy an existing entry in `lib/theme.js`, rename the
key, and change the hex values. Every token must be present — the components
read all of them.
