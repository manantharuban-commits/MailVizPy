#!/usr/bin/env python3
"""
qlik_tools.py — an MCP-equivalent tool surface for Qlik Sense, without an MCP server.

WHY THIS EXISTS
---------------
An MCP server gives you three things: a discoverable catalog of tools with schemas, a
uniform way to invoke them, and a session that stays alive between calls. None of those
require the MCP protocol — they only require an agreed interface. This module provides
all three over a CLI and over stdio JSON-RPC, so an agent gets the same ergonomics with
no daemon, no listening port, and nothing for a security review to object to.

THREE WAYS TO USE IT
--------------------
1. One-shot CLI — good for scripts and ad-hoc work:
       python qlik_tools.py list
       python qlik_tools.py describe qlik.query
       python qlik_tools.py call qlik.query --params '{"app":"Sales","dimensions":["Region"],"measures":["Sum(Sales)"]}'

2. Batch — many calls over ONE WebSocket, which is dramatically faster because opening
   an app is the expensive part:
       python qlik_tools.py batch calls.jsonl

3. Stdio JSON-RPC server — the MCP transport itself. An agent writes JSON-RPC lines to
   stdin and reads results from stdout, holding one live Engine session throughout:
       python qlik_tools.py serve
   Supports methods: initialize, tools/list, tools/call, resources/list, resources/read.
   If your organisation ever unblocks MCP, wrapping this in an MCP server is a thin
   adapter rather than a rewrite.

SAFETY
------
Tools are tagged read / write / destructive. Destructive tools refuse to run unless
--allow-destructive is passed (or "confirm": true is in the params), because there is no
undo in the Engine API beyond restoring a .qvf export.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from typing import Any, Callable, Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qlik_client import (  # noqa: E402
    EngineAPI, QrsAPI, QpsAPI, QlikError, load_config, resolve_app_id,
)

# =======================================================================================
# Registry
# =======================================================================================

TOOLS: Dict[str, Dict[str, Any]] = {}


def tool(name: str, group: str, access: str, summary: str,
         params: Optional[Dict[str, Any]] = None,
         returns: str = "", when: str = "", api: str = "") -> Callable:
    """
    Register a tool.

    `when` and `api` are the fields an agent actually reasons over: when to reach for
    this tool, and which underlying Qlik API it lands on. Keeping them in the registry
    means the routing knowledge travels with the tool instead of living in prose the
    agent may not have loaded.
    """
    def deco(fn: Callable) -> Callable:
        TOOLS[name] = {
            "name": name, "group": group, "access": access, "summary": summary,
            "when": when, "api": api, "returns": returns,
            "params": params or {}, "fn": fn,
        }
        return fn
    return deco


class Ctx:
    """Holds config and lazily-opened, reused connections."""

    def __init__(self, config_path: Optional[str] = None, allow_destructive: bool = False):
        self.cfg = load_config(config_path)
        self.allow_destructive = allow_destructive
        self._qrs: Optional[QrsAPI] = None
        self._qps: Optional[QpsAPI] = None
        self._eng: Optional[EngineAPI] = None
        self._open_app: Optional[str] = None
        self._doc: Optional[int] = None

    @property
    def qrs(self) -> QrsAPI:
        if self._qrs is None:
            self._qrs = QrsAPI(self.cfg)
        return self._qrs

    @property
    def qps(self) -> QpsAPI:
        if self._qps is None:
            self._qps = QpsAPI(self.cfg)
        return self._qps

    def doc(self, app: str, no_data: bool = False):
        """
        Open an app, reusing the session if the same app is already open.

        Reusing matters more than it looks: OpenDoc on a large app can take tens of
        seconds and pins server memory, so an agent making twenty calls against one app
        should pay that once, not twenty times.
        """
        app_id = resolve_app_id(self.cfg, app)
        if self._eng is not None and self._open_app == app_id and self._doc is not None:
            return self._eng, self._doc
        if self._eng is not None:
            self._eng.close()
        self._eng = EngineAPI(self.cfg, app_id).connect()
        self._doc = self._eng.open_doc(app_id, no_data=no_data)
        self._open_app = app_id
        return self._eng, self._doc

    def close(self) -> None:
        if self._eng is not None:
            try:
                self._eng.close()
            except Exception:
                pass
            self._eng, self._doc, self._open_app = None, None, None


# =======================================================================================
# Group 1 — Platform discovery  (QRS)
# =======================================================================================

@tool("qlik.about", "platform", "read",
      "Version and reachability check for the Qlik site.",
      when="First call when anything is failing. Isolates 'can I reach and authenticate' "
           "from 'am I allowed to do this'.",
      api="QRS GET /qrs/about")
def _about(ctx: Ctx, **_) -> Any:
    return ctx.qrs.about()


@tool("qlik.health", "platform", "read",
      "Per-node service status across the site.",
      when="A reload failed or the hub is slow, before assuming your code is at fault. "
           "A node outage looks identical to a script error from the client side.",
      api="QRS GET /qrs/servicestatus/full")
def _health(ctx: Ctx, **_) -> Any:
    return ctx.qrs.service_status()


@tool("qlik.apps.list", "platform", "read",
      "List apps visible to the authenticated user.",
      params={"filter": "optional QRS filter, e.g. \"stream.name eq 'Finance'\""},
      when="Discovery, or checking whether a user can see an app at all. An empty list "
           "with a successful auth means a permissions problem, not a connection problem.",
      api="QRS GET /qrs/app/full")
def _apps(ctx: Ctx, filter: str = "", **_) -> Any:
    return [{"id": a["id"], "name": a["name"],
             "stream": (a.get("stream") or {}).get("name"),
             "published": a.get("published"),
             "lastReload": a.get("lastReloadTime"),
             "owner": (a.get("owner") or {}).get("userId")}
            for a in ctx.qrs.apps(filter)]


@tool("qlik.app.find", "platform", "read",
      "Resolve an app name to its GUID.",
      params={"name": "app name or GUID (required)"},
      when="Before any Engine call, since Engine methods take GUIDs. Fails loudly if two "
           "apps share a name, which is the right outcome — silently picking one is worse.",
      api="QRS GET /qrs/app/full?filter=name eq '...'")
def _find_app(ctx: Ctx, name: str, **_) -> Any:
    return ctx.qrs.find_app(name)


@tool("qlik.streams.list", "platform", "read",
      "List streams and their IDs.",
      when="Before publishing — you need the stream GUID, not its name.",
      api="QRS GET /qrs/stream/full")
def _streams(ctx: Ctx, **_) -> Any:
    return [{"id": s["id"], "name": s["name"]} for s in ctx.qrs.streams()]


@tool("qlik.connections.list", "platform", "read",
      "List data connections with their connection strings.",
      params={"filter": "optional QRS filter"},
      when="A load script fails with 'connection not found'. The name must match exactly "
           "including case and spaces, and a connection owned by someone else and not "
           "shared is invisible to your script even though an admin can see it in the QMC.",
      api="QRS GET /qrs/dataconnection/full")
def _connections(ctx: Ctx, filter: str = "", **_) -> Any:
    rows = ctx.qrs.request("GET", "/qrs/dataconnection/full",
                           params={"filter": filter} if filter else None)
    return [{"id": c["id"], "name": c["name"], "type": c.get("type"),
             "connectionString": c.get("connectionstring"),
             "owner": (c.get("owner") or {}).get("userId")} for c in rows]


@tool("qlik.users.find", "platform", "read",
      "Find users by id or directory.",
      params={"userId": "optional", "userDirectory": "optional"},
      when="A user reports they cannot see an app. Check they exist and hold a licence "
           "before debugging security rules.",
      api="QRS GET /qrs/user/full")
def _users(ctx: Ctx, userId: str = "", userDirectory: str = "", **_) -> Any:
    parts = []
    if userId:
        parts.append(f"userId eq '{userId}'")
    if userDirectory:
        parts.append(f"userDirectory eq '{userDirectory}'")
    flt = " and ".join(parts)
    rows = ctx.qrs.request("GET", "/qrs/user/full", params={"filter": flt} if flt else None)
    return [{"id": u["id"], "userId": u.get("userId"),
             "userDirectory": u.get("userDirectory"), "name": u.get("name"),
             "removedExternally": u.get("removedExternally")} for u in rows]


# =======================================================================================
# Group 2 — App lifecycle  (QRS)
# =======================================================================================

@tool("qlik.app.create", "lifecycle", "write",
      "Create a new empty app.",
      params={"name": "required", "locale": "optional, default en-US"},
      when="Starting a dashboard from nothing. For a variant of an existing app use "
           "qlik.app.copy instead, so you inherit the script and data model.",
      api="Engine Global CreateApp")
def _app_create(ctx: Ctx, name: str, locale: str = "en-US", **_) -> Any:
    eng = EngineAPI(ctx.cfg).connect()
    try:
        return {"appId": eng.create_app(name, locale), "name": name}
    finally:
        eng.close()


@tool("qlik.app.copy", "lifecycle", "write",
      "Duplicate an app.",
      params={"app": "source app name or id", "name": "new app name"},
      when="Before any risky change to a live app. This is the cheapest rollback you have.",
      api="QRS POST /qrs/app/{id}/copy")
def _app_copy(ctx: Ctx, app: str, name: str, **_) -> Any:
    return ctx.qrs.copy_app(resolve_app_id(ctx.cfg, app), name)


@tool("qlik.app.export", "lifecycle", "read",
      "Export an app to a .qvf file.",
      params={"app": "app name or id", "path": "local output path", "skipData": "bool, default false"},
      when="Take one before ANY bulk modification. The Engine API has no undo; this "
           "export is the only rollback that exists.",
      api="QRS POST /qrs/app/{id}/export/{token} then GET downloadPath")
def _app_export(ctx: Ctx, app: str, path: str, skipData: bool = False, **_) -> Any:
    return ctx.qrs.export_app(resolve_app_id(ctx.cfg, app), path, skip_data=skipData)


@tool("qlik.app.publish", "lifecycle", "destructive",
      "Publish an app to a stream.",
      params={"app": "app name or id", "stream": "stream name or id", "name": "optional published name"},
      when="Releasing to users. Note that publishing makes the app READ-ONLY for objects — "
           "further edits must go to an unpublished copy and then through qlik.app.replace.",
      api="QRS PUT /qrs/app/{id}/publish")
def _app_publish(ctx: Ctx, app: str, stream: str, name: str = "", **_) -> Any:
    stream_id = stream
    if "-" not in stream:
        matches = [s for s in ctx.qrs.streams() if s["name"] == stream]
        if not matches:
            raise QlikError(f"No stream named '{stream}'")
        stream_id = matches[0]["id"]
    return ctx.qrs.publish_app(resolve_app_id(ctx.cfg, app), stream_id, name)


@tool("qlik.app.replace", "lifecycle", "destructive",
      "Replace a published app's contents from a development copy, keeping its ID.",
      params={"source": "development app", "target": "published app to overwrite"},
      when="The correct production update pattern. Publishing a fresh copy instead breaks "
           "every saved bookmark and every embedded link pointing at the old GUID — which "
           "surfaces on Monday morning, not at deploy time.",
      api="QRS PUT /qrs/app/{id}/replace?app={targetId}")
def _app_replace(ctx: Ctx, source: str, target: str, **_) -> Any:
    src, tgt = resolve_app_id(ctx.cfg, source), resolve_app_id(ctx.cfg, target)
    return ctx.qrs.request("PUT", f"/qrs/app/{src}/replace", params={"app": tgt})


@tool("qlik.app.delete", "lifecycle", "destructive",
      "Delete an app permanently.",
      params={"app": "app name or id", "confirm": "must be true"},
      when="Rarely. Export first.",
      api="QRS DELETE /qrs/app/{id}")
def _app_delete(ctx: Ctx, app: str, **_) -> Any:
    app_id = resolve_app_id(ctx.cfg, app)
    ctx.qrs.delete_app(app_id)
    return {"deleted": app_id}


@tool("qlik.app.reload", "lifecycle", "write",
      "Reload an app's data by running its load script.",
      params={"app": "app name or id", "mode": "0 default, 1 error-tolerant, 2 abort-on-error"},
      when="Development only. On anything published, prefer qlik.task.start so the QMC "
           "audit trail, service account, and downstream task chain all stay intact — a "
           "direct reload bypasses every one of them.",
      api="Engine Doc DoReloadEx, then DoSave")
def _app_reload(ctx: Ctx, app: str, mode: int = 0, **_) -> Any:
    eng, doc = ctx.doc(app)
    result = eng.call(doc, "DoReloadEx", {"qMode": mode})
    eng.do_save(doc)
    return result


@tool("qlik.tasks.list", "lifecycle", "read",
      "List reload tasks.",
      params={"app": "optional app name filter"},
      when="Finding the governed way to reload, and checking when a task last ran.",
      api="QRS GET /qrs/reloadtask/full")
def _tasks(ctx: Ctx, app: str = "", **_) -> Any:
    flt = f"app.name eq '{app}'" if app else ""
    rows = ctx.qrs.request("GET", "/qrs/reloadtask/full",
                           params={"filter": flt} if flt else None)
    return [{"id": t["id"], "name": t["name"],
             "app": (t.get("app") or {}).get("name"),
             "enabled": t.get("enabled"),
             "lastExecution": (t.get("operational") or {}).get("lastExecutionResult", {}).get("status")}
            for t in rows]


@tool("qlik.task.start", "lifecycle", "write",
      "Trigger a reload task.",
      params={"task": "task name or id", "wait": "bool, poll for completion"},
      when="The preferred way to reload a published app.",
      api="QRS POST /qrs/task/{id}/start[/synchronous]")
def _task_start(ctx: Ctx, task: str, wait: bool = False, **_) -> Any:
    return ctx.qrs.start_task(task, wait=wait)


@tool("qlik.task.status", "lifecycle", "read",
      "Execution results for a task.",
      params={"task": "task name or id"},
      when="After triggering a reload. Status 7 is success, 8 is failure; the result "
           "carries the log path where the actual error text lives.",
      api="QRS GET /qrs/executionresult/full")
def _task_status(ctx: Ctx, task: str, **_) -> Any:
    rows = ctx.qrs.request("GET", "/qrs/executionresult/full",
                           params={"filter": f"reloadTask.name eq '{task}'"})
    return rows[:5]


# =======================================================================================
# Group 3 — App inspection  (Engine, read-only)
# =======================================================================================

@tool("qlik.app.info", "inspect", "read",
      "App metadata: title, last reload time, sheet count.",
      params={"app": "app name or id"},
      when="Before trusting any number. If the app reloaded at 02:00 and you are "
           "comparing against a source queried now, the two legitimately differ.",
      api="Engine Doc GetAppLayout")
def _app_info(ctx: Ctx, app: str, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    layout = eng.get_app_layout(doc)
    infos = eng.get_all_infos(doc)
    counts: Dict[str, int] = {}
    for i in infos:
        counts[i.get("qType", "?")] = counts.get(i.get("qType", "?"), 0) + 1
    return {"title": layout.get("qTitle"), "lastReloadTime": layout.get("qLastReloadTime"),
            "hasData": layout.get("qHasData"), "objectCounts": counts}


@tool("qlik.app.datamodel", "inspect", "read",
      "Tables, fields, row counts, keys, and synthetic-key detection.",
      params={"app": "app name or id"},
      when="ALWAYS before writing an expression, and first when numbers look wrong. A "
           "$Syn table or a circular reference distorts every aggregation in the app, and "
           "no amount of expression fixing helps until it is resolved.",
      api="Engine Doc GetTablesAndKeys")
def _datamodel(ctx: Ctx, app: str, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    tk = eng.get_tables_and_keys(doc)
    tables = []
    synthetic = []
    for t in tk.get("qtr", []):
        name = t.get("qName", "")
        entry = {"table": name, "rows": t.get("qNoOfRows"),
                 "fields": [f.get("qName") for f in t.get("qFields", [])]}
        tables.append(entry)
        if name.startswith("$Syn"):
            synthetic.append(name)
    result = {"tables": tables, "keys": tk.get("qk", [])}
    if synthetic:
        result["WARNING"] = (f"Synthetic keys present: {synthetic}. These distort "
                             "aggregations across the join — fix before trusting any figure.")
    return result


@tool("qlik.app.lineage", "inspect", "read",
      "Where each table came from: connections and source statements.",
      params={"app": "app name or id"},
      when="Building validation SQL, or answering 'which database does this number come "
           "from'. Also reveals load-script WHERE clauses that explain why the app holds "
           "fewer rows than the source table.",
      api="Engine Doc GetLineage")
def _lineage(ctx: Ctx, app: str, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    return eng.get_lineage(doc)


@tool("qlik.app.fields", "inspect", "read",
      "All fields with cardinality and tags.",
      params={"app": "app name or id"},
      when="Before writing any expression. A misspelled field name produces a chart that "
           "builds successfully and shows nothing, so checking is cheaper than debugging.",
      api="Engine Doc CreateSessionObject with qFieldListDef")
def _fields(ctx: Ctx, app: str, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    h = eng.create_session_object(doc, {
        "qInfo": {"qType": "FieldList"},
        "qFieldListDef": {"qShowSystem": False, "qShowHidden": False, "qShowSrcTables": True}})
    items = eng.get_layout(h).get("qFieldList", {}).get("qItems", [])
    return [{"name": f.get("qName"), "tables": f.get("qSrcTables"),
             "cardinal": f.get("qCardinal"), "tags": f.get("qTags")} for f in items]


@tool("qlik.field.values", "inspect", "read",
      "Distinct values of one field.",
      params={"app": "app name or id", "field": "field name", "limit": "default 100"},
      when="Writing set analysis. Set modifiers match on exact text including case, so "
           "{<Region={'north'}>} silently returns nothing if the data says 'North'.",
      api="Engine Doc CreateSessionObject with qListObjectDef")
def _field_values(ctx: Ctx, app: str, field: str, limit: int = 100, **_) -> Any:
    eng, doc = ctx.doc(app)
    h = eng.create_session_object(doc, {
        "qInfo": {"qType": "ListObject"},
        "qListObjectDef": {"qDef": {"qFieldDefs": [field]},
                           "qInitialDataFetch": [{"qTop": 0, "qLeft": 0,
                                                  "qHeight": min(limit, 1000), "qWidth": 1}]}})
    lo = eng.get_layout(h).get("qListObject", {})
    pages = lo.get("qDataPages", [])
    rows = pages[0].get("qMatrix", []) if pages else []
    return {"field": field, "totalDistinct": lo.get("qSize", {}).get("qcy"),
            "values": [r[0].get("qText") for r in rows]}


@tool("qlik.app.script.get", "inspect", "read",
      "The full load script.",
      params={"app": "app name or id"},
      when="Before editing it (SetScript replaces everything, so read-modify-write is "
           "mandatory), and when explaining why the app's data differs from the source.",
      api="Engine Doc GetScript")
def _script_get(ctx: Ctx, app: str, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    return {"script": eng.get_script(doc)}


@tool("qlik.app.objects.list", "inspect", "read",
      "Every object in the app with id and type.",
      params={"app": "app name or id", "type": "optional filter, e.g. sheet, barchart"},
      when="Finding the object id for any other tool. Object ids are opaque and only "
           "discoverable this way.",
      api="Engine Doc GetAllInfos")
def _objects(ctx: Ctx, app: str, type: str = "", **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    infos = eng.get_all_infos(doc)
    return [i for i in infos if not type or i.get("qType") == type]


@tool("qlik.app.sheets", "inspect", "read",
      "Sheets with their titles and the objects on each.",
      params={"app": "app name or id"},
      when="Orienting yourself in an unfamiliar app, or locating the chart a user is "
           "asking about by its visible title.",
      api="Engine Doc GetAllInfos + GetObject + GetLayout per sheet")
def _sheets(ctx: Ctx, app: str, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    out = []
    for info in eng.get_all_infos(doc):
        if info.get("qType") != "sheet":
            continue
        h = eng.get_object(doc, info["qId"])
        props = eng.get_properties(h)
        out.append({
            "id": info["qId"],
            "title": (props.get("qMetaDef") or {}).get("title"),
            "objects": [{"id": c.get("name"), "type": c.get("type"),
                         "col": c.get("col"), "row": c.get("row")}
                        for c in props.get("cells", [])]})
    return out


@tool("qlik.object.properties", "inspect", "read",
      "An object's DEFINITION — the JSON you would edit.",
      params={"app": "app name or id", "object": "object id"},
      when="Modifying a chart, or copying a working object's shape when you are unsure of "
           "the schema for your Qlik version. Copying a real object beats reproducing "
           "documentation, because these schemas drift between releases.",
      api="Engine GenericObject GetProperties")
def _obj_props(ctx: Ctx, app: str, object: str, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    return eng.get_properties(eng.get_object(doc, object))


@tool("qlik.object.layout", "inspect", "read",
      "An object's EVALUATED state — what the user actually sees, including errors.",
      params={"app": "app name or id", "object": "object id"},
      when="Checking whether a chart works. qHyperCube.qSize.qcy is the real signal; "
           "'created successfully' means very little because the Engine stores unknown "
           "properties without complaint.",
      api="Engine GenericObject GetLayout")
def _obj_layout(ctx: Ctx, app: str, object: str, **_) -> Any:
    eng, doc = ctx.doc(app)
    layout = eng.get_layout(eng.get_object(doc, object))
    hc = layout.get("qHyperCube", {})
    return {"title": layout.get("title"), "type": (layout.get("qInfo") or {}).get("qType"),
            "rows": hc.get("qSize", {}).get("qcy"), "error": hc.get("qError"),
            "dimensions": [d.get("qFallbackTitle") for d in hc.get("qDimensionInfo", [])],
            "measures": [m.get("qFallbackTitle") for m in hc.get("qMeasureInfo", [])]}


# =======================================================================================
# Group 4 — Data and analysis  (Engine)
# =======================================================================================

@tool("qlik.query", "data", "read",
      "Ad-hoc aggregation against the app — dimensions plus measures, no object created.",
      params={"app": "app name or id", "dimensions": "list of field names or =expressions",
              "measures": "list of Qlik expressions", "limit": "default 500",
              "selections": "optional {field: [values]} applied first"},
      returns="{columns, rows, totalRows}",
      when="THE workhorse. Any 'what does Qlik say for X' question. Uses a session object, "
           "so nothing is saved and the app is untouched — far better than creating a "
           "throwaway chart and forgetting to delete it.",
      api="Engine Doc CreateSessionObject + GetHyperCubeData")
def _query(ctx: Ctx, app: str, dimensions: Optional[List[str]] = None,
           measures: Optional[List[str]] = None, limit: int = 500,
           selections: Optional[Dict[str, List[Any]]] = None, **_) -> Any:
    dimensions, measures = dimensions or [], measures or []
    if not dimensions and not measures:
        raise QlikError("qlik.query needs at least one dimension or measure")
    eng, doc = ctx.doc(app)

    eng.clear_all(doc)
    if selections:
        for field, values in selections.items():
            fh = eng.call(doc, "GetField", {"qFieldName": field})["qReturn"]["qHandle"]
            eng.call(fh, "SelectValues", {"qFieldValues": [
                {"qText": str(v), "qIsNumeric": False} for v in values]})

    width = len(dimensions) + len(measures)
    props = {
        "qInfo": {"qType": "adhoc-query"},
        "qHyperCubeDef": {
            "qDimensions": [{"qDef": {"qFieldDefs": [d]}, "qNullSuppression": False}
                            for d in dimensions],
            "qMeasures": [{"qDef": {"qDef": m, "qLabel": m}} for m in measures],
            "qInitialDataFetch": [{"qTop": 0, "qLeft": 0,
                                   "qHeight": min(limit, max(1, 10000 // max(width, 1))),
                                   "qWidth": width}]}}
    h = eng.create_session_object(doc, props)
    layout = eng.get_layout(h)
    hc = layout.get("qHyperCube", {})
    if hc.get("qError"):
        raise QlikError(f"Hypercube error: {hc['qError']}", hc)

    cols = ([d.get("qFallbackTitle") for d in hc.get("qDimensionInfo", [])] +
            [m.get("qFallbackTitle") for m in hc.get("qMeasureInfo", [])])
    n_dims = len(hc.get("qDimensionInfo", []))
    rows = []
    for i, row in enumerate(eng.iter_hypercube_rows(h)):
        if i >= limit:
            break
        rows.append([c.get("qText") if j < n_dims else c.get("qNum", c.get("qText"))
                     for j, c in enumerate(row)])
    return {"columns": cols, "rows": rows, "totalRows": hc.get("qSize", {}).get("qcy")}


@tool("qlik.expression.evaluate", "data", "read",
      "Evaluate a single Qlik expression and return its value.",
      params={"app": "app name or id", "expression": "e.g. Sum(Sales)"},
      when="Getting one scalar. Also the workaround for $-expansion when building "
           "validation SQL: evaluate $(=Max(Year)) here to get the literal Qlik would "
           "substitute, then paste that into the SQL.",
      api="Engine Doc EvaluateEx")
def _evaluate(ctx: Ctx, app: str, expression: str, **_) -> Any:
    eng, doc = ctx.doc(app)
    return eng.call(doc, "EvaluateEx", {"qExpression": expression})


@tool("qlik.expression.check", "data", "read",
      "Validate expression syntax and report bad field names.",
      params={"app": "app name or id", "expression": "expression to check"},
      when="Before creating any chart. Catches misspelled fields in milliseconds, versus "
           "debugging a blank chart later.",
      api="Engine Doc CheckExpression")
def _check_expr(ctx: Ctx, app: str, expression: str, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    return eng.check_expression(doc, expression)


@tool("qlik.object.data", "data", "read",
      "Read all rows from an existing chart.",
      params={"app": "app name or id", "object": "object id", "limit": "default 1000",
              "clearSelections": "bool, default true"},
      when="Answering 'what does this chart show'. Clear selections unless you are "
           "deliberately reproducing a filtered view — a stale selection in the session "
           "silently filters results and looks like a data bug.",
      api="Engine GenericObject GetHyperCubeData")
def _obj_data(ctx: Ctx, app: str, object: str, limit: int = 1000,
              clearSelections: bool = True, **_) -> Any:
    eng, doc = ctx.doc(app)
    if clearSelections:
        eng.clear_all(doc)
    h = eng.get_object(doc, object)
    layout = eng.get_layout(h)
    hc = layout.get("qHyperCube", {})
    n_dims = len(hc.get("qDimensionInfo", []))
    cols = ([d.get("qFallbackTitle") for d in hc.get("qDimensionInfo", [])] +
            [m.get("qFallbackTitle") for m in hc.get("qMeasureInfo", [])])
    rows = []
    for i, row in enumerate(eng.iter_hypercube_rows(h)):
        if i >= limit:
            break
        rows.append([c.get("qText") if j < n_dims else c.get("qNum", c.get("qText"))
                     for j, c in enumerate(row)])
    return {"columns": cols, "rows": rows, "totalRows": hc.get("qSize", {}).get("qcy")}


@tool("qlik.selections.apply", "data", "write",
      "Apply selections to the current session.",
      params={"app": "app name or id", "selections": "{field: [values]}"},
      when="Reproducing what a user sees when they report a number. Session-scoped only — "
           "this does not change the app for anyone else.",
      api="Engine Field SelectValues")
def _select(ctx: Ctx, app: str, selections: Dict[str, List[Any]], **_) -> Any:
    eng, doc = ctx.doc(app)
    for field, values in selections.items():
        fh = eng.call(doc, "GetField", {"qFieldName": field})["qReturn"]["qHandle"]
        eng.call(fh, "SelectValues", {"qFieldValues": [
            {"qText": str(v), "qIsNumeric": False} for v in values]})
    return {"applied": selections}


@tool("qlik.selections.clear", "data", "write",
      "Clear all selections in the session.",
      params={"app": "app name or id"},
      when="Before reading any data for validation. This is step one of every discrepancy "
           "investigation, because a leftover selection is the most common cause.",
      api="Engine Doc ClearAll")
def _clear(ctx: Ctx, app: str, **_) -> Any:
    eng, doc = ctx.doc(app)
    eng.clear_all(doc)
    return {"cleared": True}


# =======================================================================================
# Group 5 — Authoring  (Engine, write)
# =======================================================================================

@tool("qlik.app.script.set", "author", "destructive",
      "Replace the app's load script.",
      params={"app": "app name or id", "script": "full script text", "checkOnly": "bool"},
      when="SetScript replaces EVERYTHING — always read the current script first and keep "
           "a copy, since that is the only rollback. Preserve ///$tab markers or the "
           "user's script collapses into one unreadable tab.",
      api="Engine Doc SetScript + CheckScriptSyntax + DoSave")
def _script_set(ctx: Ctx, app: str, script: str, checkOnly: bool = False, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    original = eng.get_script(doc)
    eng.set_script(doc, script)
    errors = eng.call(doc, "CheckScriptSyntax").get("qErrors", [])
    if errors or checkOnly:
        eng.set_script(doc, original)
        return {"applied": False, "errors": errors,
                "note": "Script restored." if errors else "checkOnly — no change made."}
    eng.do_save(doc)
    return {"applied": True, "errors": []}


@tool("qlik.measure.create", "author", "write",
      "Create a master measure.",
      params={"app": "app name or id", "title": "", "expression": "", "format": "optional",
              "description": "optional", "tags": "optional list"},
      when="Any measure used in more than one chart. Defining it once means a later "
           "correction lands in one place instead of eleven charts with two missed.",
      api="Engine Doc CreateMeasure")
def _measure_create(ctx: Ctx, app: str, title: str, expression: str,
                    format: str = "", description: str = "",
                    tags: Optional[List[str]] = None, **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    check = eng.check_expression(doc, expression)
    if check.get("qErrorMsg"):
        return {"created": False, "error": check.get("qErrorMsg"),
                "badFields": check.get("qBadFieldNames")}
    props = {"qInfo": {"qType": "measure"},
             "qMeasure": {"qLabel": title, "qDef": expression, "qGrouping": "N",
                          "qNumFormat": {"qType": "F", "qFmt": format} if format else {"qType": "U"}},
             "qMetaDef": {"title": title, "description": description, "tags": tags or []}}
    mid = eng.create_measure(doc, props)
    eng.do_save(doc)
    return {"created": True, "id": mid, "title": title}


@tool("qlik.dimension.create", "author", "write",
      "Create a master dimension.",
      params={"app": "app name or id", "title": "", "fields": "list; >1 makes a drill-down",
              "description": "optional"},
      when="Same reasoning as master measures. Several fields creates a drill-down group.",
      api="Engine Doc CreateDimension")
def _dimension_create(ctx: Ctx, app: str, title: str, fields: List[str],
                      description: str = "", **_) -> Any:
    eng, doc = ctx.doc(app, no_data=True)
    props = {"qInfo": {"qType": "dimension"},
             "qDim": {"qGrouping": "H" if len(fields) > 1 else "N",
                      "qFieldDefs": fields, "qFieldLabels": fields, "title": title},
             "qMetaDef": {"title": title, "description": description, "tags": []}}
    did = eng.create_dimension(doc, props)
    eng.do_save(doc)
    return {"created": True, "id": did, "title": title}


@tool("qlik.object.create", "author", "write",
      "Create an object from raw property JSON.",
      params={"app": "app name or id", "properties": "full qProp object"},
      when="An object type the dashboard builder does not cover, or an extension. Get the "
           "shape by reading a hand-built object with qlik.object.properties first — "
           "inventing property names produces a chart that builds and renders blank.",
      api="Engine Doc CreateObject")
def _obj_create(ctx: Ctx, app: str, properties: Dict[str, Any], **_) -> Any:
    eng, doc = ctx.doc(app)
    created = eng.create_object(doc, properties)
    eng.do_save(doc)
    return {"id": created["id"]}


@tool("qlik.object.update", "author", "destructive",
      "Overwrite an object's properties.",
      params={"app": "app name or id", "object": "object id", "properties": "full qProp"},
      when="SetProperties replaces the WHOLE definition — read with "
           "qlik.object.properties, modify that dict, write it back. A partial object "
           "silently drops everything you omitted.",
      api="Engine GenericObject SetProperties")
def _obj_update(ctx: Ctx, app: str, object: str, properties: Dict[str, Any], **_) -> Any:
    eng, doc = ctx.doc(app)
    eng.set_properties(eng.get_object(doc, object), properties)
    eng.do_save(doc)
    return {"updated": object}


@tool("qlik.object.delete", "author", "destructive",
      "Delete an object.",
      params={"app": "app name or id", "object": "object id"},
      when="Removing a chart. Also remove its entry from the parent sheet's cells array, "
           "or the sheet shows a broken tile.",
      api="Engine Doc DestroyObject")
def _obj_delete(ctx: Ctx, app: str, object: str, **_) -> Any:
    eng, doc = ctx.doc(app)
    ok = eng.destroy_object(doc, object)
    eng.do_save(doc)
    return {"deleted": ok}


@tool("qlik.dashboard.build", "author", "destructive",
      "Build entire sheets from a YAML/JSON spec.",
      params={"app": "app name or id", "spec": "path to spec file", "dryRun": "bool, default true"},
      when="Any multi-object build. Dry run first and show the plan — the spec is readable "
           "by someone who does not know the QIX API, which is what makes review possible.",
      api="Engine Doc CreateObject (many) — see scripts/build_dashboard.py")
def _dashboard(ctx: Ctx, app: str, spec: str, dryRun: bool = True, **_) -> Any:
    import subprocess
    here = os.path.dirname(os.path.abspath(__file__))
    cmd = [sys.executable, os.path.join(here, "build_dashboard.py"), "--spec", spec]
    if dryRun:
        cmd.append("--dry-run")
    p = subprocess.run(cmd, capture_output=True, text=True)
    return {"exitCode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}


# =======================================================================================
# Group 6 — QA
# =======================================================================================

@tool("qlik.object.to_sql", "qa", "read",
      "Translate a chart into equivalent SQL for independent verification.",
      params={"app": "app name or id", "object": "object id",
              "dialect": "bigquery|mssql|oracle|postgres|ansi"},
      when="Proving a number against the source database. ALWAYS relay the -- REVIEW: "
           "lines to the user: a query that silently drops a set modifier invents a "
           "discrepancy and sends someone chasing a bug that does not exist.",
      api="Engine GetProperties + GetLineage — see scripts/object_to_sql.py")
def _to_sql(ctx: Ctx, app: str, object: str, dialect: str = "ansi", **_) -> Any:
    from object_to_sql import hypercube_to_sql, DIALECTS
    eng, doc = ctx.doc(app, no_data=True)
    h = eng.get_object(doc, object)
    props = eng.get_properties(h)
    lineage = eng.get_lineage(doc)
    title = (props.get("qMetaDef") or {}).get("title") or object
    sql = hypercube_to_sql(props, lineage, DIALECTS.get(dialect, DIALECTS["ansi"]), title)
    return {"sql": sql, "reviewCount": sql.count("REVIEW:")}


# =======================================================================================
# Resources (MCP-style read-only URIs)
# =======================================================================================

RESOURCE_HELP = {
    "qlik://apps": "All visible apps",
    "qlik://app/{name}/datamodel": "Tables, fields, keys",
    "qlik://app/{name}/script": "Load script",
    "qlik://app/{name}/sheets": "Sheets and their objects",
    "qlik://app/{name}/fields": "Field list with cardinality",
    "qlik://app/{name}/lineage": "Source connections and statements",
}


def read_resource(ctx: Ctx, uri: str) -> Any:
    if uri == "qlik://apps":
        return _apps(ctx)
    parts = uri.replace("qlik://app/", "").split("/")
    if len(parts) != 2:
        raise QlikError(f"Unrecognised resource URI: {uri}")
    app, kind = parts
    return {"datamodel": _datamodel, "script": _script_get, "sheets": _sheets,
            "fields": _fields, "lineage": _lineage}[kind](ctx, app=app)


# =======================================================================================
# Dispatch
# =======================================================================================

def call_tool(ctx: Ctx, name: str, params: Dict[str, Any]) -> Any:
    spec = TOOLS.get(name)
    if spec is None:
        near = [t for t in TOOLS if name.split(".")[-1] in t]
        raise QlikError(f"Unknown tool '{name}'." + (f" Did you mean: {near}?" if near else
                                                     " Run 'list' to see all tools."))
    if spec["access"] == "destructive" and not ctx.allow_destructive and not params.get("confirm"):
        raise QlikError(
            f"'{name}' is destructive and there is no undo in the Engine API. "
            f"Re-run with --allow-destructive, or pass \"confirm\": true. "
            f"Consider qlik.app.export first.")
    return spec["fn"](ctx, **params)


def manifest() -> List[Dict[str, Any]]:
    return [{k: v for k, v in t.items() if k != "fn"} for t in TOOLS.values()]


def _serve(ctx: Ctx) -> int:
    """Stdio JSON-RPC loop — the MCP transport, holding one Engine session throughout."""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError as exc:
            print(json.dumps({"jsonrpc": "2.0", "id": None,
                              "error": {"code": -32700, "message": str(exc)}}), flush=True)
            continue
        rid, method, params = req.get("id"), req.get("method"), req.get("params") or {}
        try:
            if method == "initialize":
                result = {"protocolVersion": "2024-11-05",
                          "capabilities": {"tools": {}, "resources": {}},
                          "serverInfo": {"name": "qlik-sense-onprem", "version": "1.0"}}
            elif method == "tools/list":
                result = {"tools": manifest()}
            elif method == "tools/call":
                result = {"content": [{"type": "text", "text": json.dumps(
                    call_tool(ctx, params.get("name", ""), params.get("arguments") or {}),
                    default=str)}]}
            elif method == "resources/list":
                result = {"resources": [{"uri": u, "description": d}
                                        for u, d in RESOURCE_HELP.items()]}
            elif method == "resources/read":
                result = {"contents": [{"uri": params.get("uri"), "mimeType": "application/json",
                                        "text": json.dumps(read_resource(ctx, params["uri"]),
                                                           default=str)}]}
            else:
                raise QlikError(f"Unknown method '{method}'")
            print(json.dumps({"jsonrpc": "2.0", "id": rid, "result": result},
                             default=str), flush=True)
        except Exception as exc:
            print(json.dumps({"jsonrpc": "2.0", "id": rid,
                              "error": {"code": -32000, "message": str(exc)}}), flush=True)
    ctx.close()
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["list", "describe", "call", "batch", "serve", "resources"])
    ap.add_argument("target", nargs="?", default="")
    ap.add_argument("--params", default="{}", help="JSON object of arguments")
    ap.add_argument("--config")
    ap.add_argument("--allow-destructive", action="store_true")
    ap.add_argument("--group", help="filter 'list' by group")
    args = ap.parse_args()

    if args.command == "list":
        rows = [t for t in manifest() if not args.group or t["group"] == args.group]
        by_group: Dict[str, List[Dict[str, Any]]] = {}
        for t in rows:
            by_group.setdefault(t["group"], []).append(t)
        for group, items in by_group.items():
            print(f"\n{group.upper()}")
            for t in items:
                flag = {"read": " ", "write": "*", "destructive": "!"}[t["access"]]
                print(f"  {flag} {t['name']:<30} {t['summary']}")
        print("\n  * writes    ! destructive (needs --allow-destructive)\n")
        return 0

    if args.command == "resources":
        for u, d in RESOURCE_HELP.items():
            print(f"  {u:<40} {d}")
        return 0

    if args.command == "describe":
        spec = TOOLS.get(args.target)
        if not spec:
            print(f"Unknown tool '{args.target}'", file=sys.stderr)
            return 2
        print(json.dumps({k: v for k, v in spec.items() if k != "fn"}, indent=2))
        return 0

    ctx = Ctx(args.config, args.allow_destructive)
    try:
        if args.command == "serve":
            return _serve(ctx)

        if args.command == "batch":
            with open(args.target, encoding="utf-8") as fh:
                for line in fh:
                    if not line.strip():
                        continue
                    req = json.loads(line)
                    try:
                        out = call_tool(ctx, req["tool"], req.get("params", {}))
                        print(json.dumps({"tool": req["tool"], "ok": True, "result": out},
                                         default=str))
                    except Exception as exc:
                        print(json.dumps({"tool": req["tool"], "ok": False, "error": str(exc)}))
            return 0

        result = call_tool(ctx, args.target, json.loads(args.params))
        print(json.dumps(result, indent=2, default=str))
        return 0
    except QlikError as exc:
        print(json.dumps({"error": str(exc)}, indent=2), file=sys.stderr)
        return 1
    except Exception:
        traceback.print_exc()
        return 1
    finally:
        ctx.close()


if __name__ == "__main__":
    sys.exit(main())
