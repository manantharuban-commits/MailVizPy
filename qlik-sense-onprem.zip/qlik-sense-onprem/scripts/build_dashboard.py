#!/usr/bin/env python3
"""
build_dashboard.py — create master items, sheets and visualizations in a Qlik Sense app
from a declarative YAML/JSON spec.

The spec is a deliberate intermediate artifact: it is human-reviewable, diffable, and
re-runnable. Generate it from a prompt, let the user correct field names, then apply it.

Usage:
    python build_dashboard.py --spec dashboard.yaml --dry-run    # validate, change nothing
    python build_dashboard.py --spec dashboard.yaml              # apply
    python build_dashboard.py --spec dashboard.yaml --replace-sheets

See assets/dashboard_spec.example.yaml for a complete annotated example, and
references/object-schemas.md for the property shape of each visualization type.

Safety: --dry-run validates every field and expression against the live app WITHOUT
writing anything. Always run it first on an app anyone else uses.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, List, Optional, Tuple

try:
    import yaml
except ImportError:
    yaml = None

from qlik_client import EngineAPI, QlikError, load_config, resolve_app_id

# --------------------------------------------------------------------------------------
# Number formats
# --------------------------------------------------------------------------------------

NUM_FORMATS = {
    "auto":     {"qType": "U", "qnDec": 10, "qUseThou": 0},
    "integer":  {"qType": "F", "qnDec": 0, "qUseThou": 1, "qFmt": "#,##0", "qDec": ".", "qThou": ","},
    "decimal":  {"qType": "F", "qnDec": 2, "qUseThou": 1, "qFmt": "#,##0.00", "qDec": ".", "qThou": ","},
    "money":    {"qType": "M", "qnDec": 2, "qUseThou": 1, "qFmt": "$#,##0.00", "qDec": ".", "qThou": ","},
    "percent":  {"qType": "F", "qnDec": 1, "qUseThou": 0, "qFmt": "#,##0.0%", "qDec": "."},
    "date":     {"qType": "D", "qnDec": 0, "qUseThou": 0, "qFmt": "YYYY-MM-DD"},
}

DEFAULT_SORT_CRITERIA = [{
    "qSortByLoadOrder": 1, "qSortByNumeric": 1, "qSortByAscii": 1,
    "qSortByState": 0, "qSortByFrequency": 0, "qSortByGreyness": 0, "qSortByExpression": 0,
    "qExpression": {"qv": ""},
}]


# --------------------------------------------------------------------------------------
# Hypercube assembly
# --------------------------------------------------------------------------------------

def _num_format(spec: Any) -> Dict[str, Any]:
    if isinstance(spec, dict):
        return spec
    return dict(NUM_FORMATS.get(str(spec or "auto"), NUM_FORMATS["auto"]))


def make_dimension(spec: Any, master_lookup: Dict[str, str]) -> Dict[str, Any]:
    """
    Accepts:
        "Region"                                     -> field
        "=If(Sales>100,'High','Low')"                -> calculated dimension
        {field: Region, label: "Sales Region"}
        {master: "Region"}                           -> reference a master dimension
    """
    if isinstance(spec, str):
        spec = {"field": spec}

    if spec.get("master"):
        lib_id = master_lookup.get(spec["master"])
        if not lib_id:
            raise QlikError(f"Master dimension '{spec['master']}' was not found or not created.")
        return {
            "qLibraryId": lib_id, "qDef": {}, "qNullSuppression": spec.get("suppress_null", True),
            "qOtherTotalSpec": {}, "qAttributeExpressions": [], "qAttributeDimensions": [],
        }

    field = spec["field"]
    label = spec.get("label") or field.lstrip("=")
    return {
        "qLibraryId": "",
        "qDef": {
            "qGrouping": "N",
            "qFieldDefs": [field],
            "qFieldLabels": [label],
            "qSortCriterias": DEFAULT_SORT_CRITERIA,
            "autoSort": True,
            "cId": "",
        },
        "qNullSuppression": spec.get("suppress_null", True),
        "qOtherTotalSpec": {
            "qOtherMode": "OTHER_OFF" if not spec.get("limit") else "OTHER_COUNTED",
            "qOtherCounted": {"qv": str(spec.get("limit", 10))},
            "qOtherSortMode": "OTHER_SORT_DESCENDING",
            "qSuppressOther": True,
            "qOtherLabel": {"qv": "Others"},
        },
        "qAttributeExpressions": [],
        "qAttributeDimensions": [],
        "qCalcCond": {"qv": ""},
    }


def make_measure(spec: Any, master_lookup: Dict[str, str]) -> Dict[str, Any]:
    """
    Accepts:
        "Sum(Sales)"
        {expression: "Sum(Sales)", label: "Revenue", format: money}
        {master: "Total Sales"}
    """
    if isinstance(spec, str):
        spec = {"expression": spec}

    if spec.get("master"):
        lib_id = master_lookup.get(spec["master"])
        if not lib_id:
            raise QlikError(f"Master measure '{spec['master']}' was not found or not created.")
        return {
            "qLibraryId": lib_id, "qDef": {},
            "qSortBy": {"qSortByNumeric": -1, "qSortByLoadOrder": 0, "qSortByAscii": 0},
            "qAttributeExpressions": [], "qAttributeDimensions": [],
        }

    expr = spec["expression"]
    return {
        "qLibraryId": "",
        "qDef": {
            "qDef": expr,
            "qLabel": spec.get("label", ""),
            "qLabelExpression": spec.get("label_expression", ""),
            "qNumFormat": _num_format(spec.get("format")),
            "autoSort": True,
            "cId": "",
            "numFormatFromTemplate": True,
        },
        "qSortBy": {
            "qSortByLoadOrder": 0, "qSortByAscii": 0,
            "qSortByNumeric": -1 if spec.get("sort", "desc") == "desc" else 1,
        },
        "qAttributeExpressions": [],
        "qAttributeDimensions": [],
        "qCalcCond": {"qv": ""},
        "qTrellisDef": {"qEnabled": False},
    }


def make_hypercube(dims: List[Any], measures: List[Any], master_lookup: Dict[str, str],
                   mode: str = "S", sort_by_measure: bool = True,
                   fetch_rows: int = 50) -> Dict[str, Any]:
    qdims = [make_dimension(d, master_lookup) for d in (dims or [])]
    qmeas = [make_measure(m, master_lookup) for m in (measures or [])]
    n_dims, n_meas = len(qdims), len(qmeas)

    # Sort order is a priority list of column indices. Putting the first measure first
    # gives the "biggest bar on top" behaviour people expect from a generated chart.
    order = list(range(n_dims + n_meas))
    if sort_by_measure and n_meas and n_dims:
        order = [n_dims] + [i for i in order if i != n_dims]

    width = max(1, n_dims + n_meas)
    return {
        "qDimensions": qdims,
        "qMeasures": qmeas,
        "qInterColumnSortOrder": order,
        "qSuppressZero": False,
        "qSuppressMissing": True,
        "qMode": mode,
        "qInitialDataFetch": [{
            "qTop": 0, "qLeft": 0,
            "qHeight": max(1, min(fetch_rows, 10000 // width)),
            "qWidth": width,
        }],
        "qStateName": "$",
    }


# --------------------------------------------------------------------------------------
# Visualization property builders
# --------------------------------------------------------------------------------------

def _base(vis_type: str, spec: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "qInfo": {"qType": vis_type},
        "visualization": vis_type,
        "type": vis_type,
        "title": spec.get("title", ""),
        "subtitle": spec.get("subtitle", ""),
        "footnote": spec.get("footnote", ""),
        "showTitles": spec.get("show_titles", True),
        "showDetails": False,
        "disableNavMenu": False,
        "showDisclaimer": True,
    }


def build_kpi(spec, ml):
    p = _base("kpi", spec)
    p["qHyperCubeDef"] = make_hypercube([], spec.get("measures", []), ml, sort_by_measure=False)
    p.update({
        "showMeasureTitle": spec.get("show_measure_title", True),
        "sharing": {"enabled": False},
        "layoutBehavior": "responsive",
        "textAlign": spec.get("align", "center"),
        "useLink": False,
        "openUrlInNewTab": True,
    })
    return p


def build_barchart(spec, ml):
    p = _base("barchart", spec)
    p["qHyperCubeDef"] = make_hypercube(spec.get("dimensions", []), spec.get("measures", []), ml,
                                        fetch_rows=spec.get("fetch_rows", 100))
    p.update({
        "orientation": spec.get("orientation", "vertical"),
        "barGrouping": {"grouping": spec.get("grouping", "grouped"), "stackedType": "stacked"},
        "dataPoint": {"showLabels": spec.get("show_labels", False), "showSegmentLabels": False},
        "legend": {"show": spec.get("show_legend", True), "dock": "auto", "showTitle": True},
        "gridline": {"auto": True, "spacing": 2},
        "color": {"auto": True},
    })
    return p


def build_linechart(spec, ml):
    p = _base("linechart", spec)
    p["qHyperCubeDef"] = make_hypercube(spec.get("dimensions", []), spec.get("measures", []), ml,
                                        sort_by_measure=False, fetch_rows=spec.get("fetch_rows", 500))
    p.update({
        "lineType": spec.get("line_type", "line"),   # line | area
        "dataPoint": {"show": spec.get("show_points", True), "showLabels": False},
        "legend": {"show": spec.get("show_legend", True), "dock": "auto"},
        "gridline": {"auto": True},
        "scrollStartPos": 0,
        "color": {"auto": True},
    })
    return p


def build_combochart(spec, ml):
    p = _base("combochart", spec)
    measures = spec.get("measures", [])
    p["qHyperCubeDef"] = make_hypercube(spec.get("dimensions", []), measures, ml,
                                        sort_by_measure=False)
    # series[i].type controls whether measure i draws as a bar or a line.
    types = spec.get("series_types", [])
    p["series"] = [
        {"type": (types[i] if i < len(types) else ("bar" if i == 0 else "line")),
         "axis": 0 if i == 0 else 1}
        for i in range(len(measures))
    ]
    p["legend"] = {"show": True, "dock": "auto"}
    return p


def build_piechart(spec, ml):
    p = _base("piechart", spec)
    p["qHyperCubeDef"] = make_hypercube(spec.get("dimensions", [])[:1], spec.get("measures", [])[:1], ml)
    p.update({
        "donut": spec.get("donut", False),
        "dataPoint": {"showLabels": True, "labelMode": "share"},
        "legend": {"show": True, "dock": "auto"},
    })
    return p


def build_scatterplot(spec, ml):
    p = _base("scatterplot", spec)
    p["qHyperCubeDef"] = make_hypercube(spec.get("dimensions", [])[:1], spec.get("measures", [])[:3], ml,
                                        sort_by_measure=False, fetch_rows=1000)
    p.update({"dataPoint": {"showLabels": False}, "legend": {"show": True}, "compressionResolution": 0})
    return p


def build_table(spec, ml):
    p = _base("table", spec)
    p["qHyperCubeDef"] = make_hypercube(spec.get("dimensions", []), spec.get("measures", []), ml,
                                        sort_by_measure=False, fetch_rows=spec.get("fetch_rows", 100))
    p.update({
        "totals": {"show": spec.get("show_totals", True), "position": "noTotals", "label": "Totals"},
        "scrolling": {"horizontal": False, "keepFirstColumnInView": False},
        "multiline": {"wrapTextInHeaders": True, "wrapTextInCells": False},
    })
    return p


def build_pivot(spec, ml):
    p = _base("pivot-table", spec)
    dims = spec.get("dimensions", [])
    n_left = int(spec.get("left_dimensions", max(1, len(dims) - 1)))
    p["qHyperCubeDef"] = make_hypercube(dims, spec.get("measures", []), ml,
                                        mode="P", sort_by_measure=False)
    p["qHyperCubeDef"]["qNoOfLeftDims"] = n_left
    p["qHyperCubeDef"]["qAlwaysFullyExpanded"] = spec.get("fully_expanded", True)
    p["qHyperCubeDef"]["qIndentMode"] = True
    p.update({"nullMode": "hidden", "totals": {"show": True}})
    return p


def build_gauge(spec, ml):
    p = _base("gauge", spec)
    p["qHyperCubeDef"] = make_hypercube([], spec.get("measures", [])[:1], ml, sort_by_measure=False)
    p.update({
        "gauge": {
            "mode": spec.get("gauge_mode", "radial"),   # radial | bar
            "min": {"value": spec.get("min", 0), "auto": "min" not in spec},
            "max": {"value": spec.get("max", 100), "auto": "max" not in spec},
            "segments": {"limits": spec.get("segments", []), "colorScheme": "d"},
        },
        "showTitles": True,
    })
    return p


def build_treemap(spec, ml):
    p = _base("treemap", spec)
    p["qHyperCubeDef"] = make_hypercube(spec.get("dimensions", [])[:3], spec.get("measures", [])[:2], ml)
    p.update({"dataPoint": {"showLabels": True}, "legend": {"show": True}})
    return p


def build_text(spec, _ml):
    p = _base("text-image", spec)
    p.update({
        "qHyperCubeDef": make_hypercube([], [], {}, sort_by_measure=False),
        "measures": [],
        "text": spec.get("html") or f"<p>{spec.get('text', '')}</p>",
        "textAlign": spec.get("align", "left"),
        "style": {"fontSize": spec.get("font_size", 13)},
    })
    return p


def build_filterpane(spec, _ml):
    p = _base("filterpane", spec)
    p["qChildListDef"] = {"qData": {"title": "/title"}}
    return p


VIZ_BUILDERS = {
    "kpi": build_kpi,
    "barchart": build_barchart,
    "linechart": build_linechart,
    "combochart": build_combochart,
    "piechart": build_piechart,
    "scatterplot": build_scatterplot,
    "table": build_table,
    "pivot-table": build_pivot,
    "gauge": build_gauge,
    "treemap": build_treemap,
    "text-image": build_text,
    "filterpane": build_filterpane,
}

# Friendly aliases so a generated spec doesn't fail on a reasonable synonym.
ALIASES = {
    "bar": "barchart", "column": "barchart", "line": "linechart", "area": "linechart",
    "pie": "piechart", "donut": "piechart", "scatter": "scatterplot",
    "straight-table": "table", "straighttable": "table", "pivot": "pivot-table",
    "text": "text-image", "filter": "filterpane", "map": "map",
}


def listbox_props(field: str, title: str = "") -> Dict[str, Any]:
    return {
        "qInfo": {"qType": "listbox"},
        "qListObjectDef": {
            "qStateName": "$",
            "qDef": {
                "qFieldDefs": [field],
                "qFieldLabels": [title or field],
                "qSortCriterias": DEFAULT_SORT_CRITERIA,
            },
            "qAutoSortByState": {"qDisplayNumberOfRows": 1},
            "qFrequencyMode": "V",
            "qInitialDataFetch": [{"qTop": 0, "qLeft": 0, "qHeight": 100, "qWidth": 1}],
        },
        "title": title or field,
        "showTitles": True,
    }


# --------------------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------------------

def collect_expressions(obj: Dict[str, Any]) -> List[Tuple[str, str]]:
    """Return [(kind, expression)] for everything in an object spec that Qlik must parse."""
    out = []
    for d in obj.get("dimensions", []) or []:
        d = {"field": d} if isinstance(d, str) else d
        if d.get("field"):
            out.append(("dimension", d["field"]))
    for m in obj.get("measures", []) or []:
        m = {"expression": m} if isinstance(m, str) else m
        if m.get("expression"):
            out.append(("measure", m["expression"]))
    return out


def validate_spec(eng: EngineAPI, doc: int, spec: Dict[str, Any]) -> List[str]:
    """Check every field and expression against the live app. Returns a list of problems."""
    problems: List[str] = []

    model = eng.get_tables_and_keys(doc)
    known_fields = {
        f.get("qName") for t in model.get("qtr", []) for f in t.get("qFields", [])
    }

    def check_expr(where: str, kind: str, expr: str) -> None:
        if kind == "dimension" and not expr.startswith("="):
            if expr not in known_fields:
                near = [f for f in known_fields if f.lower() == expr.lower()]
                hint = f" Did you mean '{near[0]}'?" if near else ""
                problems.append(f"{where}: field '{expr}' does not exist in the data model.{hint}")
            return
        probe = expr if expr.startswith("=") else f"={expr}"
        result = eng.check_expression(doc, probe.lstrip("="))
        err = result.get("qErrorMsg", "")
        if err:
            problems.append(f"{where}: invalid {kind} expression '{expr}' -> {err}")

    for mi in spec.get("master_measures", []) or []:
        check_expr(f"master measure '{mi.get('title')}'", "measure", mi.get("expression", ""))
    for mi in spec.get("master_dimensions", []) or []:
        for f in mi.get("fields", []):
            check_expr(f"master dimension '{mi.get('title')}'", "dimension", f)

    for si, sheet in enumerate(spec.get("sheets", []) or []):
        for oi, obj in enumerate(sheet.get("objects", []) or []):
            vt = ALIASES.get(obj.get("type", ""), obj.get("type", ""))
            where = f"sheet[{si}] '{sheet.get('title')}' object[{oi}] ({vt})"
            if vt not in VIZ_BUILDERS and vt != "filterpane":
                problems.append(
                    f"{where}: unsupported type '{obj.get('type')}'. "
                    f"Supported: {', '.join(sorted(VIZ_BUILDERS))}"
                )
                continue
            if vt == "filterpane":
                for f in obj.get("fields", []):
                    if f not in known_fields:
                        problems.append(f"{where}: filter field '{f}' does not exist.")
                continue
            for kind, expr in collect_expressions(obj):
                check_expr(where, kind, expr)

    return problems


# --------------------------------------------------------------------------------------
# Application
# --------------------------------------------------------------------------------------

def create_master_items(eng: EngineAPI, doc: int, spec: Dict[str, Any]) -> Dict[str, str]:
    """Create master dimensions/measures and return {title: libraryId}."""
    lookup: Dict[str, str] = {}

    for d in spec.get("master_dimensions", []) or []:
        props = {
            "qInfo": {"qType": "dimension"},
            "qDim": {
                "qGrouping": "N",
                "qFieldDefs": d["fields"],
                "qFieldLabels": d.get("labels", d["fields"]),
                "title": d["title"],
                "qLabelExpression": "",
            },
            "qMetaDef": {"title": d["title"], "description": d.get("description", ""),
                         "tags": d.get("tags", [])},
        }
        lookup[d["title"]] = eng.create_dimension(doc, props)

    for m in spec.get("master_measures", []) or []:
        props = {
            "qInfo": {"qType": "measure"},
            "qMeasure": {
                "qLabel": m["title"],
                "qDef": m["expression"],
                "qLabelExpression": "",
                "qNumFormat": _num_format(m.get("format")),
                "qGrouping": "N",
                "qExpressions": [],
                "qActiveExpression": 0,
            },
            "qMetaDef": {"title": m["title"], "description": m.get("description", ""),
                         "tags": m.get("tags", [])},
        }
        lookup[m["title"]] = eng.create_measure(doc, props)

    return lookup


def apply_spec(eng: EngineAPI, doc: int, spec: Dict[str, Any],
               replace_sheets: bool = False) -> Dict[str, Any]:
    report: Dict[str, Any] = {"master_items": {}, "sheets": [], "warnings": []}

    if replace_sheets:
        titles = {s.get("title") for s in spec.get("sheets", [])}
        for info in eng.get_all_infos(doc):
            if info.get("qType") != "sheet":
                continue
            handle = eng.get_object(doc, info["qId"])
            meta = eng.get_layout(handle).get("qMeta", {})
            if meta.get("title") in titles:
                eng.destroy_object(doc, info["qId"])
                report["warnings"].append(f"Replaced existing sheet '{meta.get('title')}'.")

    master_lookup = create_master_items(eng, doc, spec)
    report["master_items"] = master_lookup

    for rank, sheet in enumerate(spec.get("sheets", []) or []):
        cols = int(sheet.get("columns", 24))
        rows = int(sheet.get("rows", 12))
        sheet_props = {
            "qInfo": {"qType": "sheet"},
            "qMetaDef": {"title": sheet.get("title", f"Sheet {rank + 1}"),
                         "description": sheet.get("description", "")},
            "rank": rank,
            "thumbnail": {"qStaticContentUrlDef": {"qUrl": ""}},
            "columns": cols,
            "rows": rows,
            "cells": [],
            "gridResolution": "small",
            "layoutOptions": {"mobileLayout": "LIST", "extendable": False},
            "customRowBase": rows,
        }
        created = eng.create_object(doc, sheet_props)
        sheet_handle, sheet_id = created["handle"], created["id"]
        cells, obj_report = [], []

        for obj in sheet.get("objects", []) or []:
            vt = ALIASES.get(obj.get("type", ""), obj.get("type", ""))
            builder = VIZ_BUILDERS.get(vt)
            if builder is None:
                report["warnings"].append(f"Skipped unsupported type '{obj.get('type')}'.")
                continue

            props = builder(obj, master_lookup)
            child = eng.create_object(doc, props)

            # A filterpane holds listboxes as child objects, not as hypercube columns.
            if vt == "filterpane":
                for field in obj.get("fields", []):
                    eng.call(child["handle"], "CreateChild",
                             {"qProp": listbox_props(field, field)})

            pos = obj.get("position", {})
            cells.append({
                "name": child["id"],
                "type": vt,
                "col": int(pos.get("col", 0)),
                "row": int(pos.get("row", 0)),
                "colspan": int(pos.get("colspan", 12)),
                "rowspan": int(pos.get("rowspan", 6)),
                "bounds": {
                    "y": round(100 * int(pos.get("row", 0)) / rows, 4),
                    "x": round(100 * int(pos.get("col", 0)) / cols, 4),
                    "width": round(100 * int(pos.get("colspan", 12)) / cols, 4),
                    "height": round(100 * int(pos.get("rowspan", 6)) / rows, 4),
                },
            })

            # Confirm the object actually produced data. The Engine accepts unknown or
            # nonsensical properties silently, so "created successfully" means very little
            # on its own — an empty hypercube is the real signal that something is wrong.
            status = "ok"
            try:
                layout = eng.get_layout(child["handle"])
                hc = layout.get("qHyperCube", {})
                if hc.get("qError"):
                    status = f"error: {hc['qError']}"
                elif vt not in ("text-image", "filterpane") and hc.get("qSize", {}).get("qcy", 0) == 0:
                    status = "EMPTY — returned zero rows"
            except QlikError as exc:
                status = f"error: {exc}"

            if status != "ok":
                report["warnings"].append(f"{sheet.get('title')} / {obj.get('title', vt)}: {status}")
            obj_report.append({"id": child["id"], "type": vt,
                               "title": obj.get("title", ""), "status": status})

        sheet_props["cells"] = cells
        eng.set_properties(sheet_handle, sheet_props)
        report["sheets"].append({"id": sheet_id, "title": sheet.get("title"), "objects": obj_report})

    eng.do_save(doc)
    return report


# --------------------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------------------

def load_spec(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()
    if path.lower().endswith((".yaml", ".yml")):
        if yaml is None:
            raise QlikError("PyYAML is not installed. Run: pip install pyyaml")
        return yaml.safe_load(text)
    return json.loads(text)


def preview(spec: Dict[str, Any]) -> None:
    print(f"App target : {spec.get('app')}")
    md = spec.get("master_dimensions", []) or []
    mm = spec.get("master_measures", []) or []
    if md or mm:
        print(f"Master items: {len(md)} dimension(s), {len(mm)} measure(s)")
        for m in mm:
            print(f"    measure  {m['title']:<28} = {m['expression']}")
        for d in md:
            print(f"    dimension {d['title']:<28} = {', '.join(d['fields'])}")
    for s in spec.get("sheets", []) or []:
        print(f"\nSheet: {s.get('title')}  ({s.get('columns', 24)}x{s.get('rows', 12)} grid)")
        for o in s.get("objects", []) or []:
            pos = o.get("position", {})
            loc = f"c{pos.get('col', 0)},r{pos.get('row', 0)} {pos.get('colspan', 12)}x{pos.get('rowspan', 6)}"
            print(f"    [{o.get('type'):<12}] {o.get('title', ''):<30} {loc}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Build Qlik Sense sheets and charts from a spec")
    ap.add_argument("--config")
    ap.add_argument("--spec", required=True)
    ap.add_argument("--app", help="Override the app named in the spec")
    ap.add_argument("--dry-run", action="store_true", help="Validate only; write nothing")
    ap.add_argument("--replace-sheets", action="store_true",
                    help="Delete existing sheets with the same titles before creating")
    ap.add_argument("--out", help="Write the apply report to this JSON path")
    args = ap.parse_args()

    cfg = load_config(args.config)
    spec = load_spec(args.spec)
    app_ref = args.app or spec.get("app")
    if not app_ref:
        raise QlikError("No app specified — set 'app:' in the spec or pass --app.")

    app_id = resolve_app_id(cfg, app_ref)
    preview(spec)
    print()

    with EngineAPI(cfg, app_id) as eng:
        doc = eng.open_doc(app_id)

        print("Validating against the live app...")
        problems = validate_spec(eng, doc, spec)
        if problems:
            print(f"\n{len(problems)} problem(s) found:")
            for p in problems:
                print(f"  - {p}")
            if not args.dry_run:
                print("\nRefusing to apply a spec with validation errors. "
                      "Fix them, or re-run with --dry-run to iterate safely.")
                return 1
        else:
            print("  All fields and expressions resolve correctly.")

        if args.dry_run:
            print("\nDry run — nothing was written.")
            return 0 if not problems else 1

        print("\nApplying...")
        report = apply_spec(eng, doc, spec, replace_sheets=args.replace_sheets)

    for s in report["sheets"]:
        print(f"  Sheet '{s['title']}' -> {s['id']}  ({len(s['objects'])} objects)")
    if report["warnings"]:
        print("\nWarnings — these need a human look:")
        for w in report["warnings"]:
            print(f"  ! {w}")

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(report, fh, indent=2)
        print(f"\nReport written to {args.out}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except QlikError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(2)
