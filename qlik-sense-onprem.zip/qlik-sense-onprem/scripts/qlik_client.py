#!/usr/bin/env python3
"""
qlik_client.py — shared connection layer for Qlik Sense Enterprise on Windows
(client-managed / on-premises).

Provides two classes used by every other script in this skill:

    EngineAPI  — WebSocket JSON-RPC to the QIX Engine (default port 4747)
    QrsAPI     — REST to the Qlik Repository Service      (default port 4242)

Dependencies:
    pip install websocket-client requests pyyaml
    # optional, only for auth_mode = "ntlm":
    pip install requests-ntlm

CLI usage:
    python qlik_client.py --selftest
    python qlik_client.py --list-apps
    python qlik_client.py --app <id> --eval "Sum(Sales)"
    python qlik_client.py --app <id> --set-script script.qvs --reload
    python qlik_client.py --start-task "Reload Sales App"
"""

from __future__ import annotations

import argparse
import json
import os
import random
import ssl
import string
import sys
from typing import Any, Dict, List, Optional

import requests

try:
    from websocket import create_connection  # websocket-client
except ImportError:  # pragma: no cover
    create_connection = None

# On-prem Qlik uses self-signed certs signed by the site's own root CA.
requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]

GLOBAL_HANDLE = -1
DEFAULT_CONFIG_NAMES = ("qlik_config.json", "config.json")


# --------------------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------------------

class QlikError(RuntimeError):
    """Raised for any Engine or QRS level failure, with the Qlik payload attached."""

    def __init__(self, message: str, payload: Any = None):
        super().__init__(message)
        self.payload = payload


class QlikConfig:
    """
    Connection settings. Loaded from JSON, then overridden by QLIK_* environment
    variables so that CI can inject secrets without a file on disk.
    """

    def __init__(self, **kw: Any):
        self.server: str = kw.get("server", "localhost")
        self.auth_mode: str = kw.get("auth_mode", "certificate")  # certificate|ntlm|ticket|jwt|header
        self.engine_port: int = int(kw.get("engine_port", 4747))
        self.qrs_port: int = int(kw.get("qrs_port", 4242))
        self.cert_dir: str = kw.get("cert_dir", "")
        self.user_directory: str = kw.get("user_directory", "INTERNAL")
        self.user_id: str = kw.get("user_id", "sa_repository")
        self.virtual_proxy: str = kw.get("virtual_proxy", "")   # e.g. "hdr" for header auth
        self.verify_ssl: bool = bool(kw.get("verify_ssl", False))
        self.ntlm_user: str = kw.get("ntlm_user", "")
        self.ntlm_password: str = kw.get("ntlm_password", "")
        self.jwt: str = kw.get("jwt", "")
        self.header_name: str = kw.get("header_name", "X-Qlik-HeaderAuth")
        self.timeout: int = int(kw.get("timeout", 60))

    # -- factory ------------------------------------------------------------------

    @classmethod
    def load(cls, path: Optional[str] = None) -> "QlikConfig":
        data: Dict[str, Any] = {}
        candidates = [path] if path else list(DEFAULT_CONFIG_NAMES)
        for c in candidates:
            if c and os.path.exists(c):
                with open(c, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                break
        else:
            if path:
                raise FileNotFoundError(f"Config not found: {path}")

        # Environment always wins, so secrets never have to live in the file.
        env_map = {
            "server": "QLIK_SERVER",
            "cert_dir": "QLIK_CERT_DIR",
            "user_directory": "QLIK_USER_DIRECTORY",
            "user_id": "QLIK_USER_ID",
            "auth_mode": "QLIK_AUTH_MODE",
            "virtual_proxy": "QLIK_VIRTUAL_PROXY",
            "ntlm_user": "QLIK_NTLM_USER",
            "ntlm_password": "QLIK_NTLM_PASSWORD",
            "jwt": "QLIK_JWT",
        }
        for key, env in env_map.items():
            if os.environ.get(env):
                data[key] = os.environ[env]
        return cls(**data)

    # -- derived ------------------------------------------------------------------

    @property
    def qlik_user_header(self) -> str:
        return f"UserDirectory={self.user_directory}; UserId={self.user_id}"

    def cert_paths(self) -> Dict[str, str]:
        if not self.cert_dir:
            raise QlikError("cert_dir is not set but auth_mode is 'certificate'.")
        paths = {
            "certfile": os.path.join(self.cert_dir, "client.pem"),
            "keyfile": os.path.join(self.cert_dir, "client_key.pem"),
            "ca_certs": os.path.join(self.cert_dir, "root.pem"),
        }
        missing = [p for p in paths.values() if not os.path.exists(p)]
        if missing:
            raise QlikError(
                "Missing certificate file(s): "
                + ", ".join(missing)
                + "\nExport them from QMC -> Certificates as 'Platform independent PEM'."
            )
        return paths


# --------------------------------------------------------------------------------------
# Engine JSON API (QIX) over WebSocket
# --------------------------------------------------------------------------------------

class EngineAPI:
    """
    Thin, synchronous JSON-RPC client for the Qlik Engine.

    The Engine is handle-oriented: every object you open returns a numeric handle, and
    subsequent calls target that handle. Handle -1 is the Global object.

    Typical flow:
        with EngineAPI(cfg) as eng:
            doc = eng.open_doc(app_id)          # -> handle
            obj = eng.get_object(doc, obj_id)   # -> handle
            layout = eng.call(obj, "GetLayout")
    """

    def __init__(self, config: QlikConfig, app_id: str = ""):
        if create_connection is None:
            raise QlikError("websocket-client is not installed. Run: pip install websocket-client")
        self.cfg = config
        self.app_id = app_id
        self.ws = None
        self._req_id = 0
        self._doc_handles: Dict[str, int] = {}

    # -- lifecycle ----------------------------------------------------------------

    def connect(self) -> "EngineAPI":
        url, headers, sslopt = self._connection_params()
        self.ws = create_connection(
            url,
            header=headers,
            sslopt=sslopt,
            timeout=self.cfg.timeout,
            suppress_origin=True,
        )
        # The Engine emits an unsolicited OnConnected notification first. Consume it so
        # it doesn't get mistaken for a response to the first real call.
        self._drain_notifications()
        return self

    def close(self) -> None:
        if self.ws:
            try:
                self.ws.close()
            finally:
                self.ws = None

    def __enter__(self) -> "EngineAPI":
        return self.connect()

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def _connection_params(self):
        cfg = self.cfg
        suffix = f"/app/{self.app_id}" if self.app_id else "/app/engineData"

        if cfg.auth_mode == "certificate":
            url = f"wss://{cfg.server}:{cfg.engine_port}{suffix}"
            headers = [f"X-Qlik-User: {cfg.qlik_user_header}"]
            certs = cfg.cert_paths()
            sslopt = {
                "certfile": certs["certfile"],
                "keyfile": certs["keyfile"],
                "ca_certs": certs["ca_certs"],
                # Qlik's node certificates are issued to the machine name, which rarely
                # matches the hostname you dial. Hostname checking is therefore normally
                # disabled here; the root CA check below is what actually establishes trust.
                "cert_reqs": ssl.CERT_REQUIRED if cfg.verify_ssl else ssl.CERT_NONE,
                "check_hostname": False,
            }
            return url, headers, sslopt

        # Everything else routes through the Qlik Proxy Service on 443.
        vp = f"/{cfg.virtual_proxy}" if cfg.virtual_proxy else ""
        url = f"wss://{cfg.server}{vp}{suffix}"
        headers = []
        if cfg.auth_mode == "jwt":
            headers.append(f"Authorization: Bearer {cfg.jwt}")
        elif cfg.auth_mode == "header":
            headers.append(f"{cfg.header_name}: {cfg.user_id}")
        elif cfg.auth_mode == "ticket":
            headers.append(f"Cookie: X-Qlik-Session={self._get_session_cookie()}")
        sslopt = {"cert_reqs": ssl.CERT_REQUIRED if cfg.verify_ssl else ssl.CERT_NONE}
        return url, headers, sslopt

    def _get_session_cookie(self) -> str:
        """Exchange a QPS ticket for a session cookie (auth_mode='ticket')."""
        qps = QpsAPI(self.cfg)
        return qps.request_session_cookie()

    # -- RPC ----------------------------------------------------------------------

    def _drain_notifications(self, budget: int = 5) -> None:
        """Read and discard any pending push notifications without blocking forever."""
        assert self.ws is not None
        self.ws.settimeout(2)
        try:
            for _ in range(budget):
                raw = self.ws.recv()
                msg = json.loads(raw)
                if msg.get("method") == "OnConnected":
                    break
        except Exception:
            pass
        finally:
            self.ws.settimeout(self.cfg.timeout)

    def call(self, handle: int, method: str, params: Any = None) -> Dict[str, Any]:
        """
        Invoke an Engine method. `params` may be a dict (named) or list (positional);
        named is preferred because Qlik's positional order changes between versions.
        """
        if self.ws is None:
            raise QlikError("Engine websocket is not connected. Call connect() first.")
        self._req_id += 1
        req_id = self._req_id
        payload = {
            "jsonrpc": "2.0",
            "id": req_id,
            "handle": handle,
            "method": method,
            "params": params if params is not None else {},
        }
        self.ws.send(json.dumps(payload))

        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") != req_id:
                continue  # push notification (OnConnected, change lists, progress) — skip
            if "error" in msg:
                err = msg["error"]
                raise QlikError(
                    f"Engine {method} failed [{err.get('code')}]: {err.get('message')} "
                    f"{err.get('parameter', '')}".strip(),
                    payload=err,
                )
            return msg.get("result", {})

    # -- Global -------------------------------------------------------------------

    def engine_version(self) -> str:
        return self.call(GLOBAL_HANDLE, "EngineVersion").get("qVersion", {}).get("qComponentVersion", "?")

    def get_doc_list(self) -> List[Dict[str, Any]]:
        return self.call(GLOBAL_HANDLE, "GetDocList").get("qDocList", [])

    def open_doc(self, app_id: str, no_data: bool = False) -> int:
        """Open an app and return its handle. Cached per app_id within this connection."""
        if app_id in self._doc_handles:
            return self._doc_handles[app_id]
        res = self.call(
            GLOBAL_HANDLE,
            "OpenDoc",
            {"qDocName": app_id, "qNoData": no_data},
        )
        handle = res["qReturn"]["qHandle"]
        self._doc_handles[app_id] = handle
        return handle

    def create_app(self, name: str, locale: str = "en-US") -> str:
        res = self.call(GLOBAL_HANDLE, "CreateApp", {"qAppName": name, "qLocalizedScriptMainSection": locale})
        return res.get("qAppId", "")

    # -- Doc ----------------------------------------------------------------------

    def get_script(self, doc: int) -> str:
        return self.call(doc, "GetScript").get("qScript", "")

    def set_script(self, doc: int, script: str) -> None:
        self.call(doc, "SetScript", {"qScript": script})

    def do_reload(self, doc: int, partial: bool = False) -> bool:
        res = self.call(doc, "DoReload", {"qMode": 0, "qPartial": partial, "qDebug": False})
        return bool(res.get("qReturn", False))

    def do_save(self, doc: int) -> None:
        self.call(doc, "DoSave", {"qFileName": ""})

    def get_app_layout(self, doc: int) -> Dict[str, Any]:
        return self.call(doc, "GetAppLayout").get("qLayout", {})

    def get_all_infos(self, doc: int) -> List[Dict[str, Any]]:
        """Every object in the app as {qId, qType}."""
        return self.call(doc, "GetAllInfos").get("qInfos", [])

    def get_object(self, doc: int, object_id: str) -> int:
        res = self.call(doc, "GetObject", {"qId": object_id})
        handle = res["qReturn"]["qHandle"]
        if handle < 0:
            raise QlikError(f"Object '{object_id}' not found in this app.")
        return handle

    def create_object(self, doc: int, props: Dict[str, Any]) -> Dict[str, Any]:
        """Create a persistent generic object. Returns {'handle': int, 'id': str}."""
        res = self.call(doc, "CreateObject", {"qProp": props})
        return {"handle": res["qReturn"]["qHandle"], "id": res["qReturn"]["qGenericId"]}

    def create_session_object(self, doc: int, props: Dict[str, Any]) -> int:
        """Create a throwaway object that is never saved — ideal for ad-hoc data pulls."""
        return self.call(doc, "CreateSessionObject", {"qProp": props})["qReturn"]["qHandle"]

    def destroy_object(self, doc: int, object_id: str) -> bool:
        return bool(self.call(doc, "DestroyObject", {"qId": object_id}).get("qSuccess", False))

    def create_dimension(self, doc: int, props: Dict[str, Any]) -> str:
        return self.call(doc, "CreateDimension", {"qProp": props})["qReturn"]["qGenericId"]

    def create_measure(self, doc: int, props: Dict[str, Any]) -> str:
        return self.call(doc, "CreateMeasure", {"qProp": props})["qReturn"]["qGenericId"]

    def evaluate(self, doc: int, expression: str) -> str:
        """Evaluate a Qlik expression in the app's current selection state."""
        return self.call(doc, "EvaluateEx", {"qExpression": expression}).get("qValue", {}).get("qText", "")

    def check_expression(self, doc: int, expression: str) -> Dict[str, Any]:
        """Validate an expression without executing it. Empty qErrorMsg means valid."""
        return self.call(doc, "CheckExpression", {"qExpr": expression})

    def get_tables_and_keys(self, doc: int) -> Dict[str, Any]:
        """The physical data model: tables, their fields, row counts, and key links."""
        return self.call(
            doc,
            "GetTablesAndKeys",
            {
                "qWindowSize": {"qcx": 0, "qcy": 0},
                "qNullSize": {"qcx": 0, "qcy": 0},
                "qCellHeight": 0,
                "qSyntheticMode": True,
                "qIncludeSysVars": False,
            },
        )

    def get_lineage(self, doc: int) -> List[Dict[str, Any]]:
        """Source connections and the statement that loaded each table. Key for SQL tracing."""
        return self.call(doc, "GetLineage").get("qLineage", [])

    def clear_all(self, doc: int) -> None:
        self.call(doc, "ClearAll", {"qLockedAlso": False})

    def publish_object(self, obj_handle: int) -> None:
        self.call(obj_handle, "Publish")

    # -- Generic object -----------------------------------------------------------

    def get_layout(self, handle: int) -> Dict[str, Any]:
        return self.call(handle, "GetLayout").get("qLayout", {})

    def get_properties(self, handle: int) -> Dict[str, Any]:
        return self.call(handle, "GetProperties").get("qProp", {})

    def set_properties(self, handle: int, props: Dict[str, Any]) -> None:
        self.call(handle, "SetProperties", {"qProp": props})

    def get_hypercube_data(
        self, handle: int, path: str = "/qHyperCubeDef",
        top: int = 0, left: int = 0, height: int = 500, width: int = 20,
    ) -> List[Dict[str, Any]]:
        """
        Fetch straight-table pages from an object's hypercube.

        Qlik caps a single page at 10,000 cells (height * width), so pull in chunks and
        let the caller concatenate. Returns the raw qDataPages list.
        """
        height = max(1, min(height, max(1, 10000 // max(width, 1))))
        return self.call(
            handle,
            "GetHyperCubeData",
            {"qPath": path, "qPages": [{"qTop": top, "qLeft": left, "qHeight": height, "qWidth": width}]},
        ).get("qDataPages", [])

    def iter_hypercube_rows(self, handle: int, path: str = "/qHyperCubeDef", page_rows: int = 500):
        """Generator over every row of a hypercube, paging automatically."""
        layout = self.get_layout(handle)
        hc = layout.get("qHyperCube", {})
        size = hc.get("qSize", {})
        total_rows, total_cols = size.get("qcy", 0), size.get("qcx", 0)
        if not total_rows or not total_cols:
            return
        step = max(1, min(page_rows, 10000 // total_cols))
        top = 0
        while top < total_rows:
            pages = self.get_hypercube_data(handle, path, top=top, height=step, width=total_cols)
            if not pages:
                break
            matrix = pages[0].get("qMatrix", [])
            if not matrix:
                break
            for row in matrix:
                yield row
            top += len(matrix)


# --------------------------------------------------------------------------------------
# Repository Service (QRS) REST API
# --------------------------------------------------------------------------------------

def _xrfkey() -> str:
    """QRS requires a 16-char alphanumeric anti-CSRF key in BOTH the query string and a header."""
    return "".join(random.choices(string.ascii_letters + string.digits, k=16))


class QrsAPI:
    """REST client for the Qlik Repository Service."""

    def __init__(self, config: QlikConfig):
        self.cfg = config
        self.session = requests.Session()
        self.session.verify = config.verify_ssl

        if config.auth_mode == "certificate":
            certs = config.cert_paths()
            self.session.cert = (certs["certfile"], certs["keyfile"])
            self.base = f"https://{config.server}:{config.qrs_port}/qrs"
            self.extra_headers = {"X-Qlik-User": config.qlik_user_header}
        elif config.auth_mode == "ntlm":
            try:
                from requests_ntlm import HttpNtlmAuth
            except ImportError:
                raise QlikError("auth_mode 'ntlm' needs: pip install requests-ntlm")
            self.session.auth = HttpNtlmAuth(config.ntlm_user, config.ntlm_password)
            vp = f"/{config.virtual_proxy}" if config.virtual_proxy else ""
            self.base = f"https://{config.server}{vp}/qrs"
            self.extra_headers = {}
        else:
            vp = f"/{config.virtual_proxy}" if config.virtual_proxy else ""
            self.base = f"https://{config.server}{vp}/qrs"
            self.extra_headers = (
                {"Authorization": f"Bearer {config.jwt}"} if config.auth_mode == "jwt" else {}
            )

    def request(self, method: str, path: str, params: Optional[Dict[str, Any]] = None,
                body: Any = None) -> Any:
        key = _xrfkey()
        params = dict(params or {})
        params["xrfkey"] = key
        headers = {
            "X-Qlik-Xrfkey": key,
            "Content-Type": "application/json",
            "User-Agent": "Windows",  # required when using NTLM through the proxy
        }
        headers.update(self.extra_headers)

        url = f"{self.base}/{path.lstrip('/')}"
        resp = self.session.request(
            method, url, params=params, headers=headers,
            json=body, timeout=self.cfg.timeout,
        )
        if resp.status_code >= 400:
            raise QlikError(f"QRS {method} {path} -> HTTP {resp.status_code}: {resp.text[:500]}")
        if not resp.content:
            return None
        try:
            return resp.json()
        except ValueError:
            return resp.text

    # -- convenience --------------------------------------------------------------

    def about(self) -> Dict[str, Any]:
        return self.request("GET", "about")

    def apps(self, filter_expr: str = "") -> List[Dict[str, Any]]:
        params = {"filter": filter_expr} if filter_expr else None
        return self.request("GET", "app/full", params=params)

    def find_app(self, name_or_id: str) -> Dict[str, Any]:
        """Resolve either an app GUID or an app name to the full app record."""
        if len(name_or_id) == 36 and name_or_id.count("-") == 4:
            hits = self.request("GET", "app/full", params={"filter": f"id eq {name_or_id}"})
            if hits:
                return hits[0]
        safe = name_or_id.replace("'", "''")
        hits = self.request("GET", "app/full", params={"filter": f"name eq '{safe}'"})
        if not hits:
            raise QlikError(f"No app found matching '{name_or_id}'.")
        if len(hits) > 1:
            names = ", ".join(f"{a['name']} ({a['id']})" for a in hits[:5])
            raise QlikError(f"Ambiguous app name '{name_or_id}'. Candidates: {names}")
        return hits[0]

    def streams(self) -> List[Dict[str, Any]]:
        return self.request("GET", "stream/full")

    def app_objects(self, app_id: str = "", object_type: str = "") -> List[Dict[str, Any]]:
        clauses = []
        if app_id:
            clauses.append(f"app.id eq {app_id}")
        if object_type:
            clauses.append(f"objectType eq '{object_type}'")
        params = {"filter": " and ".join(clauses)} if clauses else None
        return self.request("GET", "app/object/full", params=params)

    def tasks(self) -> List[Dict[str, Any]]:
        return self.request("GET", "reloadtask/full")

    def start_task(self, task_name_or_id: str, wait: bool = False) -> Any:
        task_id = task_name_or_id
        if not (len(task_name_or_id) == 36 and task_name_or_id.count("-") == 4):
            safe = task_name_or_id.replace("'", "''")
            hits = self.request("GET", "reloadtask/full", params={"filter": f"name eq '{safe}'"})
            if not hits:
                raise QlikError(f"No reload task named '{task_name_or_id}'.")
            task_id = hits[0]["id"]
        endpoint = f"task/{task_id}/start/synchronous" if wait else f"task/{task_id}/start"
        return self.request("POST", endpoint)

    def copy_app(self, app_id: str, new_name: str) -> Dict[str, Any]:
        return self.request("POST", f"app/{app_id}/copy", params={"name": new_name})

    def publish_app(self, app_id: str, stream_id: str, name: str = "") -> Dict[str, Any]:
        params = {"stream": stream_id}
        if name:
            params["name"] = name
        return self.request("PUT", f"app/{app_id}/publish", params=params)

    def delete_app(self, app_id: str) -> None:
        self.request("DELETE", f"app/{app_id}")

    def service_status(self) -> List[Dict[str, Any]]:
        return self.request("GET", "ServiceStatus/full")


class QpsAPI:
    """Qlik Proxy Service — ticket issuance and session management (port 4243)."""

    def __init__(self, config: QlikConfig):
        self.cfg = config
        self.session = requests.Session()
        self.session.verify = config.verify_ssl
        certs = config.cert_paths()
        self.session.cert = (certs["certfile"], certs["keyfile"])
        vp = config.virtual_proxy or ""
        self.base = f"https://{config.server}:4243/qps" + (f"/{vp}" if vp else "")

    def request_ticket(self) -> str:
        key = _xrfkey()
        resp = self.session.post(
            f"{self.base}/ticket",
            params={"xrfkey": key},
            headers={"X-Qlik-Xrfkey": key, "Content-Type": "application/json"},
            json={
                "UserDirectory": self.cfg.user_directory,
                "UserId": self.cfg.user_id,
                "Attributes": [],
            },
            timeout=self.cfg.timeout,
        )
        if resp.status_code >= 400:
            raise QlikError(f"Ticket request failed: HTTP {resp.status_code} {resp.text[:300]}")
        return resp.json()["Ticket"]

    def request_session_cookie(self) -> str:
        """Redeem a ticket through the proxy and return the X-Qlik-Session cookie value."""
        ticket = self.request_ticket()
        vp = f"/{self.cfg.virtual_proxy}" if self.cfg.virtual_proxy else ""
        resp = requests.get(
            f"https://{self.cfg.server}{vp}/hub",
            params={"qlikTicket": ticket},
            verify=self.cfg.verify_ssl,
            allow_redirects=True,
            timeout=self.cfg.timeout,
        )
        cookie = resp.cookies.get("X-Qlik-Session") or resp.cookies.get(
            f"X-Qlik-Session-{self.cfg.virtual_proxy}"
        )
        if not cookie:
            raise QlikError("Ticket redeemed but no X-Qlik-Session cookie was returned.")
        return cookie


# --------------------------------------------------------------------------------------
# Helpers shared by other scripts
# --------------------------------------------------------------------------------------

def resolve_app_id(cfg: QlikConfig, name_or_id: str) -> str:
    """Accept an app name or GUID and always return a GUID."""
    if len(name_or_id) == 36 and name_or_id.count("-") == 4:
        return name_or_id
    return QrsAPI(cfg).find_app(name_or_id)["id"]


def load_config(path: Optional[str]) -> QlikConfig:
    return QlikConfig.load(path)


# --------------------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------------------

def _selftest(cfg: QlikConfig) -> int:
    print(f"Server        : {cfg.server}")
    print(f"Auth mode     : {cfg.auth_mode}  ({cfg.user_directory}\\{cfg.user_id})")
    ok = True

    try:
        qrs = QrsAPI(cfg)
        about = qrs.about()
        print(f"QRS           : OK  (build {about.get('buildVersion')})")
        apps = qrs.apps()
        print(f"Apps visible  : {len(apps)}")
    except Exception as exc:
        ok = False
        print(f"QRS           : FAILED -> {exc}")

    try:
        with EngineAPI(cfg) as eng:
            print(f"Engine        : OK  (version {eng.engine_version()})")
    except Exception as exc:
        ok = False
        print(f"Engine        : FAILED -> {exc}")

    if not ok:
        print("\nSee references/auth-and-connection.md for error-by-error triage.")
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description="Qlik Sense on-prem connection utility")
    ap.add_argument("--config", help="Path to qlik_config.json")
    ap.add_argument("--selftest", action="store_true", help="Verify Engine + QRS connectivity")
    ap.add_argument("--list-apps", action="store_true")
    ap.add_argument("--list-tasks", action="store_true")
    ap.add_argument("--app", help="App name or GUID")
    ap.add_argument("--eval", dest="expression", help="Evaluate a Qlik expression in --app")
    ap.add_argument("--check", help="Validate a Qlik expression without running it")
    ap.add_argument("--set-script", help="Path to a .qvs file to upload as the app's load script")
    ap.add_argument("--reload", action="store_true", help="Reload after --set-script")
    ap.add_argument("--start-task", help="Trigger a QMC reload task by name or id")
    ap.add_argument("--wait", action="store_true", help="Block until --start-task finishes")
    args = ap.parse_args()

    cfg = load_config(args.config)

    if args.selftest:
        return _selftest(cfg)

    if args.list_apps:
        for a in QrsAPI(cfg).apps():
            stream = (a.get("stream") or {}).get("name", "(unpublished)")
            print(f"{a['id']}  {a['name']}  [{stream}]")
        return 0

    if args.list_tasks:
        for t in QrsAPI(cfg).tasks():
            print(f"{t['id']}  {t['name']}  enabled={t.get('enabled')}")
        return 0

    if args.start_task:
        print(json.dumps(QrsAPI(cfg).start_task(args.start_task, wait=args.wait), indent=2, default=str))
        return 0

    if not args.app:
        ap.print_help()
        return 1

    app_id = resolve_app_id(cfg, args.app)
    with EngineAPI(cfg, app_id) as eng:
        doc = eng.open_doc(app_id)

        if args.expression:
            print(eng.evaluate(doc, args.expression))

        if args.check:
            result = eng.check_expression(doc, args.check)
            err = result.get("qErrorMsg", "")
            print("VALID" if not err else f"INVALID: {err}")

        if args.set_script:
            with open(args.set_script, "r", encoding="utf-8") as fh:
                eng.set_script(doc, fh.read())
            print(f"Script uploaded from {args.set_script}")
            if args.reload:
                print("Reloading...")
                success = eng.do_reload(doc)
                print("Reload succeeded" if success else "Reload FAILED — check the script log")
            eng.do_save(doc)
            print("App saved.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except QlikError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(2)
