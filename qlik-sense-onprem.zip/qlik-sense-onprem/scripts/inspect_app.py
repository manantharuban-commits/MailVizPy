#!/usr/bin/env python3
"""
inspect_app.py — dump everything you need to know about a Qlik Sense app before
writing a single expression against it.

Why this exists: the most common failure in prompt-driven Qlik work is inventing a
field name that doesn't exist. The Engine accepts the bad expression, the chart builds,
and it renders empty. Reading the real model first eliminates that entire class of bug.

Usage:
    python inspect_app.py --app "Sales Dashboard" --out app_model.json
    python inspect_app.py --app <guid> --sheet-detail --out app_model.json
    python inspect_app.py --app <guid> --script-only > current_script.qvs
    python inspect_app.py --app <guid> --summary          # human-readable, no file
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, List

from qlik_client import EngineAPI, QlikError, QrsAPI, load_config, resolve_app_id

# Object types that are charts/containers we care about, versus infrastructure.
INFRA_TYPES = {"appprops", "LoadModel", "SearchHistory", "sheet-title", "hiddenbookmark"}


def collect_data_model(eng: EngineAPI, doc: int) -> Dict[str, Any]:
    raw = eng.get_tables_and_keys(doc)
    tables = []
    for t in raw.get("qtr", []):
        tables.append({
            "name": t.get("qName"),
            "rows": t.get("qNoOfRows"),
            "is_synthetic": t.get("qIsSynthetic", False),
            "is_loose": t.get("qIsLoose", False),
            "fields": [
                {
                    "name": f.get("qName"),
                    "cardinality": f.get("qnTotalDistinctValues"),
                    "rows_present": f.get("qnPresentDistinctValues"),
                    "is_key": f.get("qKeyType", "NOT_KEY") != "NOT_KEY",
                    "tags": f.get("qTags", []),
                }
                for f in t.get("qFields", [])
            ],
        })
    keys = [
        {"key_fields": [f.get("qName") for f in k.get("qKeyFields", [])],
         "tables": k.get("qTables", [])}
        for k in raw.get("qk", [])
    ]
    return {"tables": tables, "key_links": keys}


def collect_master_items(eng: EngineAPI, doc: int, infos: List[Dict[str, Any]]) -> Dict[str, Any]:
    dimensions, measures = [], []
    for info in infos:
        qtype = info.get("qType")
        if qtype not in ("dimension", "measure"):
            continue
        try:
            handle = eng.get_object(doc, info["qId"])
            props = eng.get_properties(handle)
        except QlikError:
            continue
        meta = props.get("qMetaDef", {})
        if qtype == "dimension":
            qdim = props.get("qDim", {})
            dimensions.append({
                "id": info["qId"],
                "title": meta.get("title") or qdim.get("title"),
                "fields": qdim.get("qFieldDefs", []),
                "labels": qdim.get("qFieldLabels", []),
                "grouping": qdim.get("qGrouping", "N"),
                "tags": meta.get("tags", []),
            })
        else:
            qm = props.get("qMeasure", {})
            measures.append({
                "id": info["qId"],
                "title": meta.get("title") or qm.get("qLabel"),
                "expression": qm.get("qDef"),
                "label_expression": qm.get("qLabelExpression", ""),
                "tags": meta.get("tags", []),
            })
    return {"dimensions": dimensions, "measures": measures}


def collect_variables(eng: EngineAPI, doc: int) -> List[Dict[str, Any]]:
    props = {
        "qInfo": {"qType": "VariableList"},
        "qVariableListDef": {"qType": "variable", "qShowReserved": False,
                             "qShowConfig": False, "qData": {"tags": "/tags"}},
    }
    try:
        handle = eng.create_session_object(doc, props)
        layout = eng.get_layout(handle)
        return [
            {"name": v.get("qName"), "definition": v.get("qDefinition"),
             "is_script_created": v.get("qIsScriptCreated", False)}
            for v in layout.get("qVariableList", {}).get("qItems", [])
            if not v.get("qIsReserved")
        ]
    except QlikError:
        return []


def _summarise_hypercube(hc_def: Dict[str, Any]) -> Dict[str, Any]:
    dims = []
    for d in hc_def.get("qDimensions", []):
        qdef = d.get("qDef", {})
        dims.append({
            "library_id": d.get("qLibraryId", "") or None,
            "fields": qdef.get("qFieldDefs", []),
            "labels": qdef.get("qFieldLabels", []),
            "null_suppression": d.get("qNullSuppression", False),
        })
    measures = []
    for m in hc_def.get("qMeasures", []):
        qdef = m.get("qDef", {})
        measures.append({
            "library_id": m.get("qLibraryId", "") or None,
            "expression": qdef.get("qDef", ""),
            "label": qdef.get("qLabel", ""),
        })
    return {
        "dimensions": dims,
        "measures": measures,
        "suppress_zero": hc_def.get("qSuppressZero", False),
        "suppress_missing": hc_def.get("qSuppressMissing", False),
    }


def collect_sheets(eng: EngineAPI, doc: int, infos: List[Dict[str, Any]],
                   detail: bool = False) -> List[Dict[str, Any]]:
    sheets = []
    for info in infos:
        if info.get("qType") != "sheet":
            continue
        handle = eng.get_object(doc, info["qId"])
        props = eng.get_properties(handle)
        layout = eng.get_layout(handle)
        cells = props.get("cells", [])

        objects = []
        for cell in cells:
            entry = {
                "id": cell.get("name"),
                "type": cell.get("type"),
                "col": cell.get("col"), "row": cell.get("row"),
                "colspan": cell.get("colspan"), "rowspan": cell.get("rowspan"),
            }
            if detail:
                try:
                    oh = eng.get_object(doc, cell["name"])
                    oprops = eng.get_properties(oh)
                    olayout = eng.get_layout(oh)
                    entry["title"] = oprops.get("title") if isinstance(oprops.get("title"), str) else ""
                    if "qHyperCubeDef" in oprops:
                        entry["hypercube"] = _summarise_hypercube(oprops["qHyperCubeDef"])
                    size = olayout.get("qHyperCube", {}).get("qSize", {})
                    entry["rendered_size"] = {"rows": size.get("qcy"), "cols": size.get("qcx")}
                    if olayout.get("qHyperCube", {}).get("qError"):
                        entry["error"] = olayout["qHyperCube"]["qError"]
                except QlikError as exc:
                    entry["error"] = str(exc)
            objects.append(entry)

        sheets.append({
            "id": info["qId"],
            "title": (layout.get("qMeta") or {}).get("title", ""),
            "description": (layout.get("qMeta") or {}).get("description", ""),
            "published": (layout.get("qMeta") or {}).get("published", False),
            "grid": {"columns": props.get("columns", 24), "rows": props.get("rows", 12)},
            "objects": objects,
        })
    return sheets


def collect_lineage(eng: EngineAPI, doc: int) -> List[Dict[str, Any]]:
    out = []
    for item in eng.get_lineage(doc):
        out.append({
            "connection": item.get("qDiscriminator", ""),
            "statement": (item.get("qStatement", "") or "").strip(),
        })
    return out


def build_report(cfg, app_ref: str, detail: bool) -> Dict[str, Any]:
    app_id = resolve_app_id(cfg, app_ref)
    try:
        app_meta = QrsAPI(cfg).find_app(app_id)
    except QlikError:
        app_meta = {}

    with EngineAPI(cfg, app_id) as eng:
        doc = eng.open_doc(app_id)
        infos = eng.get_all_infos(doc)

        report: Dict[str, Any] = {
            "app": {
                "id": app_id,
                "name": app_meta.get("name", ""),
                "stream": (app_meta.get("stream") or {}).get("name", "(unpublished)"),
                "published": app_meta.get("published", False),
                "last_reload": app_meta.get("lastReloadTime", ""),
                "file_size_bytes": app_meta.get("fileSize"),
            },
            "object_counts": {},
            "data_model": collect_data_model(eng, doc),
            "master_items": collect_master_items(eng, doc, infos),
            "variables": collect_variables(eng, doc),
            "sheets": collect_sheets(eng, doc, infos, detail=detail),
            "lineage": collect_lineage(eng, doc),
            "script": eng.get_script(doc),
        }

        counts: Dict[str, int] = {}
        for i in infos:
            t = i.get("qType", "?")
            if t in INFRA_TYPES:
                continue
            counts[t] = counts.get(t, 0) + 1
        report["object_counts"] = dict(sorted(counts.items(), key=lambda kv: -kv[1]))

    return report


def print_summary(report: Dict[str, Any]) -> None:
    app = report["app"]
    print(f"App        : {app['name']}  ({app['id']})")
    print(f"Stream     : {app['stream']}   published={app['published']}")
    print(f"Last reload: {app['last_reload']}")
    print()

    print("Data model")
    for t in report["data_model"]["tables"]:
        flag = " [SYNTHETIC KEY]" if t["is_synthetic"] else (" [LOOSE]" if t["is_loose"] else "")
        print(f"  {t['name']}  ({t['rows']:,} rows){flag}")
        for f in t["fields"]:
            key = " *key*" if f["is_key"] else ""
            print(f"      - {f['name']}  ({f['cardinality']} distinct){key}")
    print()

    mi = report["master_items"]
    print(f"Master dimensions ({len(mi['dimensions'])})")
    for d in mi["dimensions"]:
        print(f"  {d['title']}  ->  {', '.join(d['fields'])}")
    print(f"Master measures ({len(mi['measures'])})")
    for m in mi["measures"]:
        print(f"  {m['title']}  ->  {m['expression']}")
    print()

    print(f"Sheets ({len(report['sheets'])})")
    for s in report["sheets"]:
        print(f"  {s['title']}  ({len(s['objects'])} objects)")
        for o in s["objects"]:
            extra = ""
            if o.get("rendered_size"):
                extra = f"  rows={o['rendered_size']['rows']}"
                if o["rendered_size"]["rows"] == 0:
                    extra += "  <-- EMPTY"
            print(f"      [{o['type']}] {o.get('title') or o['id']}{extra}")
    print()

    if report["lineage"]:
        print("Lineage (source of each table)")
        seen = set()
        for l in report["lineage"]:
            key = (l["connection"], l["statement"][:80])
            if key in seen:
                continue
            seen.add(key)
            stmt = l["statement"].replace("\n", " ")[:110]
            print(f"  {l['connection'] or '(inline)'}")
            if stmt:
                print(f"      {stmt}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Inspect a Qlik Sense app")
    ap.add_argument("--config")
    ap.add_argument("--app", required=True, help="App name or GUID")
    ap.add_argument("--out", help="Write full JSON report to this path")
    ap.add_argument("--sheet-detail", action="store_true",
                    help="Include each chart's hypercube definition (slower)")
    ap.add_argument("--script-only", action="store_true", help="Print only the load script")
    ap.add_argument("--summary", action="store_true", help="Print a readable summary")
    args = ap.parse_args()

    cfg = load_config(args.config)

    if args.script_only:
        app_id = resolve_app_id(cfg, args.app)
        with EngineAPI(cfg, app_id) as eng:
            print(eng.get_script(eng.open_doc(app_id)))
        return 0

    report = build_report(cfg, args.app, detail=args.sheet_detail)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(report, fh, indent=2, ensure_ascii=False)
        print(f"Wrote {args.out}", file=sys.stderr)

    if args.summary or not args.out:
        print_summary(report)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except QlikError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(2)
