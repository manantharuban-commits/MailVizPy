#!/usr/bin/env python3
"""
object_to_sql.py — reverse-engineer a Qlik Sense chart into equivalent SQL.

The use case is QA: you have a chart showing a number, and you want to prove that
number independently against the source database.

WHAT THIS IS NOT
----------------
This is a *translation aid*, not a compiler. Qlik's associative model has no exact SQL
equivalent, and several common constructs (AGGR, TOTAL, alternate states, $-sign
expansion evaluated at runtime) genuinely cannot be expressed as a single flat query.
Rather than guessing, the translator emits `-- REVIEW:` comments wherever it is unsure
and refuses to silently drop anything.

Always show the REVIEW lines to the user. A validation query that quietly ignores a set
analysis modifier is worse than no query at all, because it manufactures a discrepancy
that sends someone hunting for a bug that does not exist.

Usage
-----
    python scripts/object_to_sql.py --app "<app-id>" --object "<object-id>" \
        --dialect bigquery --out validate.sql

    # discover object ids first
    python scripts/inspect_app.py --app "<app-id>" --sheet-detail --out model.json
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qlik_client import EngineAPI, QlikError, load_config, resolve_app_id  # noqa: E402


# =======================================================================================
# Dialect definitions
# =======================================================================================

class Dialect:
    name = "ansi"
    quote_open = '"'
    quote_close = '"'
    supports_limit = True

    @classmethod
    def quote(cls, ident: str) -> str:
        # Only quote when needed — unquoted output is far easier for a human to read
        # and edit, which matters because this SQL is meant to be reviewed.
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", ident):
            return ident
        return f"{cls.quote_open}{ident}{cls.quote_close}"

    @classmethod
    def limit_clause(cls, n: int) -> str:
        return f"LIMIT {n}"

    @classmethod
    def string_literal(cls, s: str) -> str:
        return "'" + s.replace("'", "''") + "'"


class BigQuery(Dialect):
    name = "bigquery"
    quote_open = "`"
    quote_close = "`"


class MSSQL(Dialect):
    name = "mssql"
    quote_open = "["
    quote_close = "]"
    supports_limit = False

    @classmethod
    def limit_clause(cls, n: int) -> str:
        return ""  # handled as TOP in the SELECT


class Oracle(Dialect):
    name = "oracle"

    @classmethod
    def limit_clause(cls, n: int) -> str:
        return f"FETCH FIRST {n} ROWS ONLY"


class Postgres(Dialect):
    name = "postgres"


DIALECTS = {
    "ansi": Dialect,
    "bigquery": BigQuery,
    "mssql": MSSQL,
    "oracle": Oracle,
    "postgres": Postgres,
}


# =======================================================================================
# Expression translation
# =======================================================================================

# Qlik aggregation -> SQL aggregation. Deliberately conservative: anything not here
# gets flagged rather than guessed.
AGG_MAP = {
    "sum": "SUM",
    "count": "COUNT",
    "avg": "AVG",
    "min": "MIN",
    "max": "MAX",
    "median": "MEDIAN",
    "stdev": "STDDEV",
    "only": "MAX",          # Only() returns the value iff unique; MAX is the closest
    "firstsortedvalue": None,
    "aggr": None,
    "rangesum": None,
}

# Constructs with no faithful flat-SQL equivalent.
UNTRANSLATABLE = {
    "aggr": "AGGR() builds a virtual table — needs a subquery/CTE, write it by hand",
    "total": "TOTAL ignores chart dimensions — express as a window function or scalar subquery",
    "above": "inter-record function — use LAG()/LEAD()",
    "below": "inter-record function — use LEAD()/LAG()",
    "before": "inter-record function — use LAG() over the pivot axis",
    "after": "inter-record function — use LEAD() over the pivot axis",
    "rank": "Qlik RANK() ranks within the chart's dimension, not the table — use RANK() OVER()",
    "rowno": "row context is chart-specific — use ROW_NUMBER() OVER()",
    "recno": "load-time row counter — has no query-time equivalent",
    "peek": "load-script only",
    "previous": "load-script only",
    "alt": "ALT() is a coalesce chain — use COALESCE()",
    "firstsortedvalue": "use a correlated subquery or ARRAY_AGG(... ORDER BY ...)[OFFSET(0)]",
}

# Cosmetic wrappers that do not change the value and can be safely unwrapped.
COSMETIC = {"num", "money", "date", "timestamp", "interval", "dual"}


def _split_top_level(text: str, sep: str = ",") -> List[str]:
    """Split on `sep` ignoring separators inside brackets or quotes."""
    parts, depth, buf, quote = [], 0, [], ""
    for ch in text:
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = ""
            continue
        if ch in "'\"":
            quote = ch
            buf.append(ch)
        elif ch in "([{":
            depth += 1
            buf.append(ch)
        elif ch in ")]}":
            depth -= 1
            buf.append(ch)
        elif ch == sep and depth == 0:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    parts.append("".join(buf))
    return [p.strip() for p in parts if p.strip()]


def extract_set_analysis(expr: str) -> Tuple[str, Optional[str]]:
    """
    Pull a leading set expression `{<Field={a,b}>}` out of an aggregation body.

    Returns (body_without_set, set_text_or_None).
    """
    m = re.search(r"\{\s*(<.*?>)\s*\}", expr, flags=re.DOTALL)
    if not m:
        return expr, None
    return (expr[: m.start()] + expr[m.end():]).strip(), m.group(1)


def set_analysis_to_predicate(set_text: str, dialect) -> Tuple[List[str], List[str]]:
    """
    Translate `<Year={2024}, Region={'North','South'}>` into SQL predicates.

    Returns (predicates, review_notes). Anything using set operators (+ - * /),
    element functions like P()/E(), or a $-expansion goes to review_notes untouched,
    because a wrong guess here silently changes the number.
    """
    predicates: List[str] = []
    notes: List[str] = []

    inner = set_text.strip().lstrip("<").rstrip(">")

    for clause in _split_top_level(inner):
        if any(tok in clause for tok in ("P(", "E(", "p(", "e(")):
            notes.append(f"set modifier uses an element function, translate by hand: {clause}")
            continue
        if "$(" in clause:
            notes.append(f"set modifier uses $-expansion resolved at runtime: {clause}")
            continue

        m = re.match(r"\s*([\[\]\w. ]+?)\s*(\*=|\+=|-=|=)\s*\{(.*)\}\s*$", clause, re.DOTALL)
        if not m:
            notes.append(f"could not parse set modifier: {clause}")
            continue

        field, op, values = m.group(1).strip().strip("[]"), m.group(2), m.group(3).strip()

        if op != "=":
            notes.append(f"set operator '{op}' modifies the current selection: {clause}")
            continue

        if values.startswith('"') and values.endswith('"'):
            # {"=Sum(X)>100"} — a search expression, effectively a HAVING clause
            notes.append(f"search-expression set modifier maps to HAVING: {clause}")
            continue

        items = [v.strip().strip("'\"") for v in _split_top_level(values)]
        if not items:
            continue

        col = dialect.quote(field)
        if len(items) == 1:
            v = items[0]
            lit = v if re.fullmatch(r"-?\d+(\.\d+)?", v) else dialect.string_literal(v)
            predicates.append(f"{col} = {lit}")
        else:
            lits = ", ".join(
                v if re.fullmatch(r"-?\d+(\.\d+)?", v) else dialect.string_literal(v)
                for v in items
            )
            predicates.append(f"{col} IN ({lits})")

    return predicates, notes


def translate_measure(expr: str, label: str, dialect) -> Dict[str, Any]:
    """
    Translate one Qlik measure expression into a SQL select-list item.

    Returns {'sql': str, 'where': [str], 'reviews': [str]}.
    """
    reviews: List[str] = []
    where: List[str] = []
    raw = expr.strip().lstrip("=").strip()

    # Hard stops first — flag and pass the original through as a comment.
    lowered = raw.lower()
    for token, reason in UNTRANSLATABLE.items():
        if re.search(rf"\b{token}\s*\(", lowered) or (token == "total" and re.search(r"\btotal\b", lowered)):
            reviews.append(f"[{label}] {token.upper()}: {reason}")
            return {"sql": f"NULL /* {raw} */", "where": [], "reviews": reviews}

    # Unwrap cosmetic formatting: Num(Sum(X), '#,##0') -> Sum(X)
    for fn in COSMETIC:
        m = re.match(rf"^{fn}\s*\((.*)\)$", raw, re.IGNORECASE | re.DOTALL)
        if m:
            inner_args = _split_top_level(m.group(1))
            if inner_args:
                raw = inner_args[0]
                break

    # Match  Agg( [DISTINCT] <body> )
    m = re.match(r"^(\w+)\s*\((.*)\)$", raw, re.DOTALL)
    if not m:
        # A bare field or arithmetic between aggregations, e.g. Sum(a)/Sum(b).
        if re.search(r"\b(sum|count|avg|min|max)\s*\(", lowered):
            translated = raw
            for qfn, sfn in AGG_MAP.items():
                if sfn:
                    translated = re.sub(rf"\b{qfn}\s*\(", f"{sfn}(", translated, flags=re.IGNORECASE)
            reviews.append(f"[{label}] compound expression translated term-by-term — verify operator precedence and division-by-zero handling")
            return {"sql": translated, "where": [], "reviews": reviews}
        reviews.append(f"[{label}] not an aggregation; may be a chart-level expression")
        return {"sql": f"NULL /* {raw} */", "where": [], "reviews": reviews}

    fn, body = m.group(1).lower(), m.group(2).strip()
    sql_fn = AGG_MAP.get(fn)
    if sql_fn is None:
        reviews.append(f"[{label}] unsupported aggregation '{fn}()' — translate by hand")
        return {"sql": f"NULL /* {raw} */", "where": [], "reviews": reviews}

    body, set_text = extract_set_analysis(body)

    distinct = ""
    if re.match(r"^distinct\s+", body, re.IGNORECASE):
        distinct = "DISTINCT "
        body = re.sub(r"^distinct\s+", "", body, flags=re.IGNORECASE).strip()

    body = body.strip().strip("[]") or "*"
    col = dialect.quote(body) if re.fullmatch(r"[\w. ]+", body) else body

    if set_text:
        preds, notes = set_analysis_to_predicate(set_text, dialect)
        reviews.extend(f"[{label}] {n}" for n in notes)
        if preds:
            # Scoped to this measure only, so a CASE expression is correct here —
            # a WHERE clause would wrongly restrict every other measure too.
            cond = " AND ".join(preds)
            return {
                "sql": f"{sql_fn}({distinct}CASE WHEN {cond} THEN {col} END)",
                "where": [],
                "reviews": reviews,
            }

    return {"sql": f"{sql_fn}({distinct}{col})", "where": where, "reviews": reviews}


# =======================================================================================
# Lineage → FROM clause
# =======================================================================================

def guess_source(lineage: List[Dict[str, Any]]) -> Tuple[str, List[str]]:
    """
    Derive a FROM target from the app's lineage entries.

    Lineage records look like {'qDiscriminator': 'LIB://Conn', 'qStatement': 'SELECT ...'}.
    Multiple distinct sources mean the chart spans a Qlik association, which SQL must
    express as an explicit JOIN — a decision only a human can make correctly.
    """
    statements = [l.get("qStatement", "") for l in lineage if l.get("qStatement")]
    tables: List[str] = []
    for st in statements:
        m = re.search(r"\bFROM\s+([\w.\[\]`\"]+)", st, re.IGNORECASE)
        if m:
            tables.append(m.group(1).strip("[]`\""))

    tables = list(dict.fromkeys(tables))
    if not tables:
        return "<SOURCE_TABLE>", ["could not derive source table from lineage — fill in FROM manually"]
    if len(tables) == 1:
        return tables[0], []
    return tables[0], [
        "chart spans multiple source tables: " + ", ".join(tables)
        + " — Qlik joins these associatively on shared field names; add explicit JOINs"
    ]


# =======================================================================================
# Main translation
# =======================================================================================

def hypercube_to_sql(props: Dict[str, Any], lineage: List[Dict[str, Any]],
                     dialect, title: str = "") -> str:
    hc = props.get("qHyperCubeDef", {}) or {}
    dims = hc.get("qDimensions", []) or []
    measures = hc.get("qMeasures", []) or []

    reviews: List[str] = []
    select_dims: List[str] = []
    group_by: List[str] = []

    for d in dims:
        qdef = d.get("qDef", {}) or {}
        fields = qdef.get("qFieldDefs", []) or []
        if not fields:
            reviews.append("dimension has no field definition (likely a master item — resolve it first)")
            continue
        if len(fields) > 1:
            reviews.append(f"drill-down dimension {fields} — SQL uses the first level only")
        f = fields[0].strip()
        if f.startswith("="):
            reviews.append(f"calculated dimension translated as-is: {f}")
            expr = f.lstrip("=")
        else:
            expr = dialect.quote(f.strip("[]"))
        labels = qdef.get("qFieldLabels", []) or []
        alias = (labels[0] if labels and labels[0] else f.strip("[]"))
        select_dims.append(f"{expr} AS {dialect.quote(alias)}")
        group_by.append(expr)

    select_measures: List[str] = []
    where: List[str] = []
    for m in measures:
        qdef = m.get("qDef", {}) or {}
        expr = qdef.get("qDef", "")
        label = qdef.get("qLabel") or expr
        out = translate_measure(expr, label, dialect)
        reviews.extend(out["reviews"])
        where.extend(out["where"])
        select_measures.append(f"{out['sql']} AS {dialect.quote(label)}")

    table, src_reviews = guess_source(lineage)
    reviews.extend(src_reviews)

    # Assemble
    lines: List[str] = []
    lines.append("-- =============================================================")
    lines.append(f"-- Validation SQL for Qlik object: {title or '(untitled)'}")
    lines.append(f"-- Dialect: {dialect.name}")
    lines.append("-- Generated by object_to_sql.py. This is an APPROXIMATION.")
    lines.append("-- =============================================================")
    if reviews:
        lines.append("--")
        lines.append("-- REVIEW BEFORE USE:")
        for r in reviews:
            lines.append(f"--   REVIEW: {r}")
        lines.append("--")
    lines.append("")

    top = ""
    limit = ""
    max_rows = 0
    for d in dims:
        spec = (d.get("qDef", {}) or {}).get("qOtherTotalSpec", {}) or {}
        if spec.get("qOtherMode") in ("OTHER_COUNTED", "OTHER_ABS_LIMITED"):
            try:
                max_rows = int(str(spec.get("qOtherCounted", "0")).strip("'\""))
            except (TypeError, ValueError):
                max_rows = 0
    if max_rows:
        if dialect.name == "mssql":
            top = f"TOP {max_rows} "
        else:
            limit = dialect.limit_clause(max_rows)

    cols = select_dims + select_measures
    lines.append(f"SELECT {top}" + ("\n       " + ",\n       ".join(cols) if cols else "*"))
    lines.append(f"  FROM {table}")
    if where:
        lines.append("  WHERE " + "\n    AND ".join(where))
    if group_by:
        lines.append("  GROUP BY " + ", ".join(group_by))
    if select_measures and group_by:
        lines.append(f"  ORDER BY {len(select_dims) + 1} DESC")
    if limit:
        lines.append(f"  {limit}")
    return "\n".join(lines) + ";\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--app", required=True, help="app GUID or name")
    ap.add_argument("--object", required=True, help="object id (from inspect_app.py)")
    ap.add_argument("--dialect", default="ansi", choices=sorted(DIALECTS))
    ap.add_argument("--out", help="write SQL here instead of stdout")
    ap.add_argument("--props-json", help="offline mode: read object properties from a JSON file")
    args = ap.parse_args()

    dialect = DIALECTS[args.dialect]

    if args.props_json:
        with open(args.props_json, encoding="utf-8") as fh:
            payload = json.load(fh)
        props = payload.get("properties", payload)
        lineage = payload.get("lineage", [])
        title = props.get("title") or args.object
    else:
        cfg = load_config(args.config)
        app_id = resolve_app_id(cfg, args.app)
        with EngineAPI(cfg, app_id) as eng:
            doc = eng.open_doc(app_id)
            try:
                handle = eng.get_object(doc, args.object)
            except QlikError as exc:
                print(f"Could not open object '{args.object}': {exc}", file=sys.stderr)
                print("Run inspect_app.py --sheet-detail to list valid object ids.", file=sys.stderr)
                return 2
            props = eng.get_properties(handle)
            lineage = eng.get_lineage(doc)
            title = (props.get("qMetaDef", {}) or {}).get("title") or props.get("title") or args.object

    sql = hypercube_to_sql(props, lineage, dialect, title)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(sql)
        print(f"Wrote {args.out}")
        n = sql.count("REVIEW:")
        if n:
            print(f"{n} item(s) need review — read the header comments before running this SQL.")
    else:
        print(sql)
    return 0


if __name__ == "__main__":
    sys.exit(main())
