#!/usr/bin/env python3
"""
validate_object.py — compare the numbers a Qlik chart shows against numbers from the
source database.

This is the payoff of the QA workflow: object_to_sql.py generates a query, you run it
in your database, and this script diffs the two result sets row by row.

    # 1. generate the query
    python scripts/object_to_sql.py --app "Sales" --object AbCdEf --dialect bigquery --out q.sql
    # 2. run q.sql in BigQuery, export as CSV -> results.csv
    # 3. diff
    python scripts/validate_object.py --app "Sales" --object AbCdEf \
        --sql-results results.csv --tolerance 0.01

Matching is by dimension values, not by row order, because Qlik and SQL sort
differently and an order-sensitive diff produces noise that hides real breaks.

Exit codes: 0 = match, 1 = discrepancies found, 2 = could not run.
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qlik_client import EngineAPI, QlikError, load_config, resolve_app_id  # noqa: E402


def _to_number(value: Any) -> Optional[float]:
    """Best-effort numeric parse; returns None for genuinely non-numeric text."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip()
    if not s or s in {"-", "NULL", "null", "NaN"}:
        return None
    # Strip the presentation layer: currency, thousands separators, percent, ( ) negatives
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    pct = s.endswith("%")
    s = s.rstrip("%")
    s = "".join(ch for ch in s if ch.isdigit() or ch in ".-")
    if not s or s in {"-", "."}:
        return None
    try:
        n = float(s)
    except ValueError:
        return None
    if pct:
        n /= 100.0
    return -n if neg else n


def fetch_qlik_rows(eng: EngineAPI, handle: int) -> Tuple[List[str], List[List[Any]]]:
    """Pull every row of the chart's hypercube, with column headers."""
    layout = eng.get_layout(handle)
    hc = layout.get("qHyperCube", {}) or {}

    headers = [c.get("qFallbackTitle", f"col{i}")
               for i, c in enumerate((hc.get("qDimensionInfo") or []) + (hc.get("qMeasureInfo") or []))]

    n_dims = len(hc.get("qDimensionInfo") or [])
    rows: List[List[Any]] = []
    for row in eng.iter_hypercube_rows(handle):
        out: List[Any] = []
        for i, cell in enumerate(row):
            if i < n_dims:
                out.append(cell.get("qText", ""))
            else:
                out.append(cell.get("qNum") if cell.get("qNum") not in (None, "NaN") else cell.get("qText"))
        rows.append(out)
    return headers, rows


def read_sql_csv(path: str) -> Tuple[List[str], List[List[Any]]]:
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.reader(fh)
        rows = [r for r in reader if any(c.strip() for c in r)]
    if not rows:
        raise SystemExit(f"{path} is empty")
    return rows[0], rows[1:]


def key_of(row: List[Any], n_dims: int) -> Tuple[str, ...]:
    return tuple(str(v).strip() for v in row[:n_dims])


def compare(q_headers, q_rows, s_headers, s_rows, n_dims: int,
            tolerance: float) -> Dict[str, Any]:
    q_index = {key_of(r, n_dims): r for r in q_rows}
    s_index = {key_of(r, n_dims): r for r in s_rows}

    only_qlik = sorted(set(q_index) - set(s_index))
    only_sql = sorted(set(s_index) - set(q_index))
    shared = sorted(set(q_index) & set(s_index))

    mismatches: List[Dict[str, Any]] = []
    checked = 0

    for k in shared:
        qr, sr = q_index[k], s_index[k]
        for i in range(n_dims, min(len(qr), len(sr))):
            qv, sv = _to_number(qr[i]), _to_number(sr[i])
            if qv is None and sv is None:
                continue
            checked += 1
            if qv is None or sv is None:
                mismatches.append({"key": k, "column": q_headers[i] if i < len(q_headers) else f"col{i}",
                                   "qlik": qr[i], "sql": sr[i], "delta": None})
                continue
            denom = max(abs(qv), abs(sv), 1e-12)
            if abs(qv - sv) / denom > tolerance:
                mismatches.append({"key": k, "column": q_headers[i] if i < len(q_headers) else f"col{i}",
                                   "qlik": qv, "sql": sv, "delta": qv - sv,
                                   "pct": (qv - sv) / denom})
    return {
        "rows_qlik": len(q_rows), "rows_sql": len(s_rows),
        "rows_matched": len(shared), "values_checked": checked,
        "only_in_qlik": only_qlik, "only_in_sql": only_sql,
        "mismatches": mismatches,
    }


def report(result: Dict[str, Any], tolerance: float) -> int:
    print("=" * 72)
    print("QLIK vs SQL VALIDATION")
    print("=" * 72)
    print(f"  Qlik rows        : {result['rows_qlik']}")
    print(f"  SQL rows         : {result['rows_sql']}")
    print(f"  Matched keys     : {result['rows_matched']}")
    print(f"  Values compared  : {result['values_checked']}  (tolerance {tolerance:.4%})")
    print()

    ok = True

    if result["only_in_qlik"]:
        ok = False
        print(f"  Rows only in Qlik ({len(result['only_in_qlik'])}):")
        for k in result["only_in_qlik"][:15]:
            print(f"    {' | '.join(k)}")
        if len(result["only_in_qlik"]) > 15:
            print(f"    ... and {len(result['only_in_qlik']) - 15} more")
        print("    -> usually a WHERE clause the SQL applies but the chart does not,")
        print("       or Qlik rows generated by a synthetic/orphan key.")
        print()

    if result["only_in_sql"]:
        ok = False
        print(f"  Rows only in SQL ({len(result['only_in_sql'])}):")
        for k in result["only_in_sql"][:15]:
            print(f"    {' | '.join(k)}")
        if len(result["only_in_sql"]) > 15:
            print(f"    ... and {len(result['only_in_sql']) - 15} more")
        print("    -> usually the chart suppressing nulls/zeros, a dimension limit (top N),")
        print("       or the app's load script filtering rows out.")
        print()

    if result["mismatches"]:
        ok = False
        print(f"  Value mismatches ({len(result['mismatches'])}):")
        print(f"    {'KEY':<34}{'COLUMN':<18}{'QLIK':>14}{'SQL':>14}{'DIFF':>14}")
        for m in result["mismatches"][:25]:
            key = " | ".join(m["key"])[:32]
            q = f"{m['qlik']:,.2f}" if isinstance(m["qlik"], float) else str(m["qlik"])[:12]
            s = f"{m['sql']:,.2f}" if isinstance(m["sql"], float) else str(m["sql"])[:12]
            d = f"{m['delta']:,.2f}" if isinstance(m.get("delta"), float) else "n/a"
            print(f"    {key:<34}{m['column'][:16]:<18}{q:>14}{s:>14}{d:>14}")
        if len(result["mismatches"]) > 25:
            print(f"    ... and {len(result['mismatches']) - 25} more")
        print()
        print("    Before assuming the app is wrong, check in this order:")
        print("      1. Is a selection active in the Qlik session? (Clear all, re-read.)")
        print("      2. Does the measure use set analysis the SQL did not reproduce?")
        print("      3. Did the app reload from the same data as the query? Compare reload time.")
        print("      4. Rounding: Qlik aggregates in double precision, some DBs in decimal.")
        print()

    if ok:
        print("  RESULT: MATCH — every compared value is within tolerance.")
    else:
        print("  RESULT: DISCREPANCIES FOUND (see above).")
    print("=" * 72)
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--app", required=True)
    ap.add_argument("--object", required=True)
    ap.add_argument("--sql-results", required=True, help="CSV exported from your database")
    ap.add_argument("--tolerance", type=float, default=0.001,
                    help="relative tolerance, default 0.001 (0.1%%)")
    ap.add_argument("--dimensions", type=int, default=None,
                    help="number of leading dimension columns; inferred from the chart if omitted")
    ap.add_argument("--clear-selections", action="store_true",
                    help="clear all selections first so the chart reflects the full dataset")
    args = ap.parse_args()

    cfg = load_config(args.config)
    app_id = resolve_app_id(cfg, args.app)

    with EngineAPI(cfg, app_id) as eng:
        doc = eng.open_doc(app_id)
        if args.clear_selections:
            eng.clear_all(doc)
        try:
            handle = eng.get_object(doc, args.object)
        except QlikError as exc:
            print(f"Could not open object '{args.object}': {exc}", file=sys.stderr)
            return 2
        layout = eng.get_layout(handle)
        n_dims = args.dimensions
        if n_dims is None:
            n_dims = len((layout.get("qHyperCube", {}) or {}).get("qDimensionInfo") or [])
        q_headers, q_rows = fetch_qlik_rows(eng, handle)

    s_headers, s_rows = read_sql_csv(args.sql_results)

    if len(s_headers) < n_dims + 1:
        print(f"CSV has {len(s_headers)} columns but the chart has {n_dims} dimension(s) "
              f"plus measures. Column order must match the chart: dimensions first.",
              file=sys.stderr)
        return 2

    result = compare(q_headers, q_rows, s_headers, s_rows, n_dims, args.tolerance)
    return report(result, args.tolerance)


if __name__ == "__main__":
    sys.exit(main())
