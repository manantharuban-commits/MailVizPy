---
name: qlik-sense-onprem
description: Drive Qlik Sense Enterprise on Windows (client-managed / on-premises) from prompts — connect via the Engine JSON API and Repository (QRS) REST API to inspect apps, read and write load scripts, create master dimensions and measures, build entire sheets and charts, extract hypercube data, reverse-engineer a chart into validation SQL, and trigger reloads. Use this skill whenever the user mentions Qlik, Qlik Sense, QRS, QMC, QVF, QVD, hypercube, set analysis, Qlik load script, enigma.js, a Qlik dashboard or sheet, comparing Qlik numbers against a database, or wants to automate/QA anything in Qlik — even if they don't name a specific API. Also use it when a Qlik beginner asks how something in Qlik works.
---

# Qlik Sense Enterprise (on-premises) automation

This skill replaces an MCP server with plain Python scripts. Everything runs locally
against your own Qlik Sense server using its two documented APIs:

| API | Transport | Use it for |
|---|---|---|
| **Engine JSON API (QIX)** | WebSocket JSON-RPC, port `4747` | Anything *inside* an app: script, data model, sheets, charts, master items, hypercube data, expression evaluation, reload |
| **Repository API (QRS)** | REST, port `4242` | Anything *around* an app: app list, streams, tasks, users, import/export, publish, custom properties |

Both scripts live in `scripts/`. Read the reference file for whichever API you need —
don't guess method names or property shapes, because Qlik's schemas are strict and a
wrong key is silently ignored rather than rejected, which produces charts that look
built but render empty.

---

## Before doing anything: establish the connection

Automation against on-prem Qlik almost always uses **certificate authentication** with the
`INTERNAL\sa_repository` service account. Certificates are exported from the QMC
(**QMC → Certificates → export for a machine name, format: Platform Independent PEM**),
which produces `client.pem`, `client_key.pem`, `root.pem`.

Create `qlik_config.json` next to the scripts (copy `assets/config.example.json`):

```json
{
  "server": "qliksense.mycompany.local",
  "auth_mode": "certificate",
  "cert_dir": "C:/qlik-certs",
  "user_directory": "INTERNAL",
  "user_id": "sa_repository",
  "verify_ssl": false
}
```

Then confirm reachability before anything else — this saves a lot of wasted debugging:

```bash
python scripts/qlik_client.py --config qlik_config.json --selftest
```

It prints the engine version, the QRS version, and the number of visible apps. If it fails,
read `references/auth-and-connection.md` — it covers all four on-prem auth modes
(certificate, Windows/NTLM via proxy, ticket, JWT via virtual proxy) and the specific
errors each one produces.

**Never write credentials, certificate paths, or server hostnames into chat output or into
committed files.** Keep them in `qlik_config.json` and add it to `.gitignore`.

---

## The tool interface (MCP-equivalent)

`scripts/qlik_tools.py` gives you what an MCP server would: a discoverable catalog of
operations with schemas, a uniform way to call them, and a session that persists across
calls. 41 tools across the Engine and Repository APIs.

```bash
python scripts/qlik_tools.py list                  # catalog, with write/destructive flags
python scripts/qlik_tools.py describe qlik.query   # params, when to use it, which API
python scripts/qlik_tools.py call qlik.query --params '{"app":"Sales","dimensions":["Region"],"measures":["Sum(Sales)"]}'
python scripts/qlik_tools.py batch calls.jsonl     # many calls, ONE WebSocket
python scripts/qlik_tools.py serve                 # stdio JSON-RPC, persistent session
```

Every tool carries a `when` field naming the situation it is for and an `api` field naming
the underlying Qlik method, so `describe` answers "which call do I need here?" without
loading a reference file. Run it before guessing.

Prefer `batch` or `serve` for anything multi-step. `OpenDoc` on a large app costs tens of
seconds and pins server memory; paying that once rather than per call is the difference
between a usable agent and an unusable one.

`serve` speaks `initialize` / `tools/list` / `tools/call` / `resources/list` /
`resources/read` over stdio — MCP's own transport and method set. If MCP is ever unblocked
in your organisation, wrapping this is a thin adapter rather than a rewrite.

**`qlik.query` is the tool to reach for most often.** It answers "what does Qlik say for
X" using a session object, so nothing is saved and the app is untouched — much better than
creating a throwaway chart and forgetting to delete it.

Destructive tools refuse to run without `--allow-destructive` or `"confirm": true`, because
the Engine API has no undo beyond restoring a `.qvf` export.

---

## Choosing a workflow

Match what the user asked for to one of these five. Each has its own script.

If it is unclear which *API layer* a request belongs to, read the routing tables in
`AGENT.md` first. Most wasted time on Qlik automation comes from working the wrong
layer — Engine versus QRS versus QPS — rather than from wrong syntax, and the symptoms
of a layer mistake point at the wrong place entirely.

### 1. "What's in this app?" — inspection

Always do this first when working with an existing app. You cannot write correct
expressions without knowing the real field names.

```bash
python scripts/inspect_app.py --app "<app-id-or-name>" --out app_model.json
```

Produces: table/field data model, master dimensions and measures, variables, all sheets
with their objects, the load script, and lineage (the source connections and SQL each
table came from). Read `app_model.json` before writing any expression — hallucinated field
names are the single most common failure in Qlik automation.

Add `--sheet-detail` to also dump every chart's full hypercube definition.

### 2. "Build me a dashboard" — generation

Write a spec, then apply it. The spec is deliberately a separate reviewable artifact so
the user can correct field names before anything is written to the server.

```bash
python scripts/build_dashboard.py --spec my_dashboard.yaml --dry-run   # validate + preview
python scripts/build_dashboard.py --spec my_dashboard.yaml             # apply
```

Workflow to follow:
1. Run `inspect_app.py` to get real field names.
2. Draft the YAML spec (`assets/dashboard_spec.example.yaml` is a full working example).
3. Run with `--dry-run`, show the user the planned sheets/objects, get confirmation.
4. Apply, then re-run `inspect_app.py` to confirm what landed.

Read `references/object-schemas.md` for the property JSON of each visualization type
before adding a chart type not already in the example spec.

**Always `--dry-run` first on an app the user cares about.** `build_dashboard.py` writes
into a live app; there is no undo beyond restoring a `.qvf` backup.

### 3. "Give me the SQL behind this chart" — QA validation

This is the highest-value workflow for testing. It reads a chart's hypercube definition,
resolves its fields back to source tables via `GetLineage` and `GetTablesAndKeys`, and emits
an equivalent SQL query in your dialect.

```bash
python scripts/object_to_sql.py --app "<app-id>" --object "<object-id>" --dialect bigquery
```

Supported dialects: `bigquery`, `mssql`, `oracle`, `postgres`, `ansi`.

Then compare actual numbers:

```bash
python scripts/validate_object.py --app "<app-id>" --object "<object-id>" \
    --sql-results results.csv --tolerance 0.01
```

Read `references/object-to-sql.md` before trusting output. It documents exactly which Qlik
constructs translate faithfully, which translate approximately, and which cannot translate
at all (the script flags these inline as `-- REVIEW:` comments). Present those flags to the
user rather than quietly dropping them — a validation query that silently ignores a set
analysis modifier is worse than no query, because it manufactures a false discrepancy.

### 4. "Change the load script / reload the app" — data layer

```bash
python scripts/inspect_app.py --app "<app-id>" --script-only > current_script.qvs
# edit current_script.qvs
python scripts/qlik_client.py --config qlik_config.json --set-script current_script.qvs --app "<app-id>" --reload
```

Read `references/load-script.md` for `LOAD`/`SQL SELECT` patterns, incremental load with
QVDs, and how `lib://` data connections resolve on-prem.

Reloading rewrites the app's data. On a published app, prefer triggering the existing QMC
reload task through QRS instead of reloading directly, so the audit trail stays intact:

```bash
python scripts/qlik_client.py --config qlik_config.json --start-task "<task-name>"
```

### 5. "I'm new to Qlik" — teaching

Read `references/beginner-guide.md` and answer from it. It's structured as a progression
(associative model → load script → data model → expressions → set analysis → sheets →
publishing) with the specific misconceptions that trip up people coming from SQL or Power BI.

Adapt depth to the person. Someone who already writes SQL needs the associative-model
section and can skim the rest; someone new to BI needs the whole arc.

---

## Reference files

Read these on demand — don't load them all.

| File | Read it when |
|---|---|
| `references/auth-and-connection.md` | Connection fails, or setting up for the first time |
| `references/engine-api.md` | Calling any Engine method; contains the full method catalog with handle semantics |
| `references/api-catalog-engine.md` | **Complete QIX method catalog** by class, with the situation each method is for |
| `references/api-catalog-qrs.md` | **Complete QRS endpoint catalog** by resource family |
| `references/api-catalog-other.md` | QPS, Notification, App Integration, Capability, Extension, printing APIs — and which job each is for |
| `references/qrs-api.md` | Working with apps/streams/tasks/users at the platform level |
| `references/object-schemas.md` | Creating or modifying any visualization |
| `references/expressions-and-set-analysis.md` | Writing or debugging a Qlik expression |
| `references/load-script.md` | Touching the load script or data connections |
| `references/object-to-sql.md` | Generating or reviewing validation SQL |
| `references/beginner-guide.md` | Teaching someone Qlik |

---

## Working principles

**Verify, then write.** Qlik's Engine API accepts unknown properties silently. If you invent
a property name, `SetProperties` succeeds and the chart renders blank. So after every
create/modify, call `GetLayout` on the object and confirm the data actually came back
(`qHyperCube.qSize.qcy > 0`). `build_dashboard.py` does this automatically and reports
objects that built but returned no rows.

**Prefer master items over inline expressions.** When generating more than one chart that
uses the same measure, create it once as a master measure and reference it by `qLibraryId`.
This is what a Qlik developer would do by hand, and it means the user can fix a definition
in one place afterwards rather than in eleven charts.

**Say when something needs a human.** Layout aesthetics, colour semantics, whether a KPI
threshold is meaningful, and whether a set analysis expression matches business intent are
judgment calls. Generate the structure, then tell the user precisely what to check.

**Distinguish "no data" from "wrong data".** An empty chart usually means a bad field name
or an over-restrictive set analysis, not a broken API call. Check the field exists in
`app_model.json` first.

**Be careful with published apps.** Objects created in a published app land in the
*community* or *private* space, not the base sheet, unless the app is unpublished or you
use `Publish` on the object. `references/qrs-api.md` covers the publish lifecycle.
