# qlik-sense-onprem

A Claude Skill for driving **Qlik Sense Enterprise on Windows** (client-managed /
on-premises) from natural language, using only Qlik's own documented APIs and plain
Python. No MCP server, no daemon, no new listening port — which is the point if your
organisation has blocked MCP.

## What it does

- **Inspect** an app: data model, fields, master items, sheets, charts, load script, lineage
- **Build** entire dashboards from a reviewable YAML spec — sheets, KPIs, charts, filter panes, master items
- **Translate** a chart back into SQL so you can prove its numbers against the source database
- **Validate** Qlik figures against database results and explain discrepancies
- **Manage** the platform: reloads, tasks, streams, publishing, connections
- **Teach** Qlik to beginners, from the associative model through set analysis

## Install

```bash
pip install -r requirements.txt
```

Then export certificates from the QMC (*Certificates* → your machine name → **Platform
independent PEM-format**) and copy `assets/config.example.json` to `qlik_config.json`
with your server details.

```bash
python scripts/qlik_client.py --config qlik_config.json --selftest
```

This prints the engine version, QRS version, and visible app count. If it fails, read
`references/auth-and-connection.md` — it maps each error to its cause.

**Add `qlik_config.json` and your `*.pem` files to `.gitignore`.** Anyone holding
`client_key.pem` can impersonate any user on the site.

## Quickstart

```bash
# What's in this app?
python scripts/inspect_app.py --app "Sales Performance" --out model.json

# Build a dashboard
cp assets/dashboard_spec.example.yaml my_dashboard.yaml
# edit field names to match model.json
python scripts/build_dashboard.py --spec my_dashboard.yaml --dry-run
python scripts/build_dashboard.py --spec my_dashboard.yaml

# Prove a chart's number
python scripts/object_to_sql.py --app "Sales Performance" --object AbCdEf \
    --dialect bigquery --out validate.sql
# run validate.sql in your database, export results.csv, then:
python scripts/validate_object.py --app "Sales Performance" --object AbCdEf \
    --sql-results results.csv --clear-selections
```

## Layout

```
qlik-sense-onprem/
├── SKILL.md                  # entry point — Claude reads this first
├── AGENT.md                  # system prompt for running as a dedicated agent
├── scripts/
│   ├── qlik_client.py        # Engine (QIX) + QRS + QPS client, and CLI
│   ├── inspect_app.py        # app -> full JSON model
│   ├── build_dashboard.py    # YAML spec -> sheets and charts
│   ├── object_to_sql.py      # chart -> validation SQL
│   └── validate_object.py    # Qlik vs SQL diff
├── references/
│   ├── auth-and-connection.md
│   ├── engine-api.md
│   ├── qrs-api.md
│   ├── object-schemas.md
│   ├── expressions-and-set-analysis.md
│   ├── load-script.md
│   ├── object-to-sql.md
│   └── beginner-guide.md
└── assets/
    ├── config.example.json
    └── dashboard_spec.example.yaml
```

## Two modes

The scripts need network reach to the Qlik server. Where that exists, Claude runs them
directly. Where it does not — a chat sandbox, a locked-down VDI — Claude generates the
spec, the SQL, and the exact commands, and you run them. `--dry-run` works fully offline,
so the whole build can be reviewed before anything touches the server.

## Limits worth knowing

- Chart property schemas drift between Qlik releases. When a generated object looks wrong,
  build one by hand in the client and read it back with `inspect_app.py --sheet-detail` —
  copying a real object from your version beats any documentation.
- `AGGR`, `TOTAL`, inter-record functions and `$()` expansion have no flat-SQL equivalent.
  `object_to_sql.py` flags them rather than guessing. Read the `-- REVIEW:` lines.
- Published apps are read-only for objects. Develop unpublished, then use QRS `replace`.
- Section access means the identity you connect as changes the numbers you get back.

## Requirements

Python 3.9+, `websocket-client`, `requests`, `PyYAML`. Tested against Qlik Sense
Enterprise on Windows; the Engine and QRS APIs used here have been stable across recent
releases, but run `--selftest` on your version before relying on it.
