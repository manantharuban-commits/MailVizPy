# Repository Service (QRS) API — complete endpoint catalog

Every QRS resource family, with the situation each is for. Base path `/qrs/`; every call
needs an `xrfkey` in both the query string and the `X-Qlik-Xrfkey` header (see
`auth-and-connection.md`).

Conventions across the whole API:
- `/full` returns complete objects; without it you get id-only stubs. You almost always want `/full`.
- `/count` returns just a count — much cheaper than fetching and counting.
- `/table` returns a column-projected result for large collections.
- `PUT` requires the **complete** object with a current `modifiedDate`, or you get a 409 conflict.
- `?privileges=true` appends what the current user is allowed to do with each object.

## Contents
- [Apps](#apps)
- [App objects](#app-objects)
- [Streams](#streams)
- [Tasks and execution](#tasks-and-execution)
- [Triggers](#triggers)
- [Data connections](#data-connections)
- [Users and user directories](#users-and-user-directories)
- [Licensing](#licensing)
- [Security rules](#security-rules)
- [Custom properties and tags](#custom-properties-and-tags)
- [Extensions and content libraries](#extensions-and-content-libraries)
- [Services and nodes](#services-and-nodes)
- [Virtual proxies](#virtual-proxies)
- [System, logs, notifications](#system-logs-notifications)
- [Endpoint selection by situation](#endpoint-selection-by-situation)

---

## Apps

| Endpoint | Situation |
|---|---|
| `GET /qrs/app/full` | List apps |
| `GET /qrs/app/full?filter=...` | Find by name, stream, owner, tag |
| `GET /qrs/app/{id}` | One app |
| `GET /qrs/app/count` | Count without fetching |
| `PUT /qrs/app/{id}` | Rename, retag, change owner. Send the whole object |
| `DELETE /qrs/app/{id}` | Delete |
| `POST /qrs/app/{id}/copy?name=X` | Duplicate — your cheapest rollback before a risky change |
| `PUT /qrs/app/{id}/publish?stream={id}&name=X` | Publish |
| `POST /qrs/app/{id}/unpublish` | Back to personal work area |
| `PUT /qrs/app/{id}/replace?app={targetId}` | **The production update pattern.** Keeps the target's GUID, so bookmarks and embedded links survive |
| `POST /qrs/app/{id}/migrate` | Upgrade app format after a Qlik version upgrade |
| `POST /qrs/app/{id}/export/{token}` | Request export; returns `downloadPath`. Token is a GUID you generate |
| `POST /qrs/app/upload?name=X&keepdata=true` | Import a `.qvf` (binary body) |
| `POST /qrs/app/upload/replace?targetappid={id}` | Import over an existing app |
| `POST /qrs/app/{id}/reload` | Reload without a task |
| `GET /qrs/app/{id}/privileges` | What the current user may do with it |
| `PUT /qrs/app/{id}/owner` | Change ownership — needed when a departing employee owns production apps |

**Export before any bulk modification.** The Engine API has no undo; the `.qvf` is it.

---

## App objects

Sheets, stories, bookmarks, master items as the *repository* sees them.

| Endpoint | Situation |
|---|---|
| `GET /qrs/app/object/full?filter=app.id eq '{id}'` | All objects in an app with ownership and approval state |
| `GET /qrs/app/object/full?filter=objectType eq 'sheet'` | Sheets only |
| `PUT /qrs/app/object/{id}/approve` | Promote a community sheet to a base sheet |
| `PUT /qrs/app/object/{id}/unapprove` | Demote |
| `PUT /qrs/app/object/{id}/publish` / `unpublish` | Private ↔ community |
| `PUT /qrs/app/object/{id}/owner` | Reassign |
| `DELETE /qrs/app/object/{id}` | Remove |

This is the only place the **base / community / private** distinction is visible. The
Engine cannot tell them apart, which is why "I created a sheet and nobody can see it" is
diagnosed here and not in the Engine API.

---

## Streams

| Endpoint | Situation |
|---|---|
| `GET /qrs/stream/full` | List streams with GUIDs — needed before publishing |
| `POST /qrs/stream` | Create |
| `PUT /qrs/stream/{id}` | Rename, retag |
| `DELETE /qrs/stream/{id}` | Delete. Apps inside are orphaned, not deleted |

Stream access is governed by security rules, not by a property on the stream itself. See
[Security rules](#security-rules).

---

## Tasks and execution

| Endpoint | Situation |
|---|---|
| `GET /qrs/reloadtask/full` | List reload tasks |
| `GET /qrs/reloadtask/full?filter=app.name eq 'X'` | Tasks for one app |
| `POST /qrs/reloadtask` | Create a task |
| `PUT /qrs/reloadtask/{id}` | Modify |
| `POST /qrs/task/{id}/start` | Fire and forget |
| `POST /qrs/task/{id}/start/synchronous` | Returns a session id to poll |
| `POST /qrs/task/{id}/stop` | Abort |
| `GET /qrs/task/full` | All task types including external programs |
| `GET /qrs/externalprogramtask/full` | Non-reload tasks |
| `GET /qrs/executionresult/full?filter=...` | Outcome, duration, script log path |
| `GET /qrs/executionsession/full` | Currently running |
| `GET /qrs/reloadtask/{id}/scriptlog` | Fetch the reload log |

Status codes on execution results: 0 NeverStarted, 1 Triggered, 2 Started, 3 Queued,
4 AbortInitiated, 5 Aborting, 6 Aborted, **7 FinishedSuccess**, **8 FinishedFail**,
9 Skipped, 10 Retry, 11 Error, 12 Reset.

Prefer tasks over Engine `DoReload` for anything published: the task carries the correct
service account, writes the audit trail, and fires downstream task chains. A direct
reload leaves the QMC showing a stale "last successful reload" and silently breaks
dependent tasks.

---

## Triggers

| Endpoint | Situation |
|---|---|
| `GET /qrs/schemaevent/full` | Time-based triggers |
| `POST /qrs/schemaevent` | Schedule a task |
| `GET /qrs/compositeevent/full` | Dependency triggers (run B after A succeeds) |
| `POST /qrs/compositeevent` | Chain tasks |

Composite events are how you build a reload pipeline — extract job, then transform, then
the user-facing app — without external orchestration.

---

## Data connections

| Endpoint | Situation |
|---|---|
| `GET /qrs/dataconnection/full` | List with connection strings |
| `GET /qrs/dataconnection/full?filter=name eq 'X'` | Resolve a `LIB CONNECT TO` name |
| `POST /qrs/dataconnection` | Create |
| `PUT /qrs/dataconnection/{id}` | Modify |
| `PUT /qrs/dataconnection/{id}/owner` | Reassign |

Passwords are never returned and cannot be read back. A connection owned by another user
and not shared is invisible to your script even though an admin sees it in the QMC —
check `owner` here before debugging the script itself.

---

## Users and user directories

| Endpoint | Situation |
|---|---|
| `GET /qrs/user/full?filter=userId eq 'x'` | Find a user |
| `GET /qrs/user/full?filter=userDirectory eq 'DOM'` | Directory listing |
| `POST /qrs/user` | Create (usually synced instead) |
| `PUT /qrs/user/{id}` | Update attributes, custom properties |
| `DELETE /qrs/user/{id}` | Remove |
| `GET /qrs/userdirectory/full` | Configured directories |
| `POST /qrs/userdirectoryconnector/{id}/sync` | Force a directory sync |

---

## Licensing

| Endpoint | Situation |
|---|---|
| `GET /qrs/license` | Site licence |
| `GET /qrs/license/accesstypeinfo` | Allocated vs available — check before onboarding |
| `GET /qrs/license/professionalaccesstype/full` | Professional allocations |
| `GET /qrs/license/useraccesstype/full` | User (analyzer) allocations |
| `POST /qrs/license/professionalaccesstype` | Allocate |
| `DELETE /qrs/license/useraccesstype/{id}` | Deallocate |
| `GET /qrs/license/loginaccesstype/full` | Login pass usage |

"User cannot see the app" is usually one of: no licence allocated, no security rule, or
the app is not in a stream they can read. Check in that order — licences are the most
common and the fastest to verify.

---

## Security rules

| Endpoint | Situation |
|---|---|
| `GET /qrs/systemrule/full` | All rules |
| `GET /qrs/systemrule/full?filter=category eq 'Security'` | Security rules only |
| `POST /qrs/systemrule` | Create |
| `PUT /qrs/systemrule/{id}` | Modify |
| `GET /qrs/systemrule/{id}/audit` | Who this rule affects |
| `POST /qrs/systemrule/license/audit` | Licence-rule audit |
| `POST /qrs/systemrule/security/audit` | **Answers "why can this user see this app?"** with the actual rule evaluation |

The audit endpoints are far better than reading rule conditions by hand — they evaluate
the whole rule set for a given user and resource and tell you which rule granted or
denied access.

---

## Custom properties and tags

| Endpoint | Situation |
|---|---|
| `GET /qrs/custompropertydefinition/full` | Definitions and allowed values |
| `POST /qrs/custompropertydefinition` | Create |
| `GET /qrs/tag/full` | Tags |
| `POST /qrs/tag` | Create |

Custom properties usually drive security rules and task filtering in enterprise setups.
If a governance model depends on a `Department` property, an app created without it will
be invisible to its intended audience despite existing correctly — set them at creation
time, not later.

---

## Extensions and content libraries

| Endpoint | Situation |
|---|---|
| `GET /qrs/extension/full` | Installed visualization extensions — check before generating an object that references one |
| `POST /qrs/extension/upload` | Install |
| `DELETE /qrs/extension/{id}` | Remove |
| `GET /qrs/contentlibrary/full` | Image libraries |
| `POST /qrs/contentlibrary/{name}/uploadfile?externalpath=X` | Upload an image |
| `GET /qrs/staticcontentreference/full` | Static content refs |
| `GET /qrs/mimetype/full` | MIME registrations |

---

## Services and nodes

| Endpoint | Situation |
|---|---|
| `GET /qrs/servicestatus/full` | Per-node health. Check before concluding your code is broken |
| `GET /qrs/enginehealth` | Engine load and memory |
| `GET /qrs/engineservice/full` | Engine nodes |
| `GET /qrs/proxyservice/full` | Proxy nodes |
| `GET /qrs/repositoryservice/full` | Repository nodes |
| `GET /qrs/schedulerservice/full` | Scheduler nodes |
| `GET /qrs/printingservice/full` | Printing/export service |
| `GET /qrs/servernodeconfiguration/full` | Multi-node topology |
| `GET /qrs/servicecluster` | Cluster settings, shared persistence paths |

---

## Virtual proxies

| Endpoint | Situation |
|---|---|
| `GET /qrs/virtualproxyconfig/full` | Prefixes, auth methods, session cookie names |
| `POST /qrs/virtualproxyconfig` | Create — e.g. a header-auth proxy for automation |
| `PUT /qrs/virtualproxyconfig/{id}` | Modify |

Reading this tells you exactly which prefix and auth method to use when direct ports are
closed, rather than guessing. Creating a header-auth proxy is an authentication bypass if
it is not firewalled to your automation host — raise that explicitly with whoever
approves the change.

---

## System, logs, notifications

| Endpoint | Situation |
|---|---|
| `GET /qrs/about` | Version. First call when debugging |
| `GET /qrs/about/api/description?extended=true` | **The API's own schema** — authoritative for your exact version, better than any documentation |
| `GET /qrs/systeminfo` | Node layout |
| `POST /qrs/notification?name={type}` | Subscribe to change events via callback URL |
| `GET /qrs/event/full` | Task events |
| `GET /qrs/log/{id}` | Log files |
| `GET /qrs/download/...`, `GET /tempcontent/...` | Retrieve generated files |
| `POST /qrs/sync/snapshot` | Force node sync |

`/qrs/about/api/description?extended=true` is worth knowing about: it returns the full
endpoint and schema list for the version you are actually running. When this catalog and
your server disagree, that endpoint is right.

The notification API is the closest QRS gets to push: register a callback URL and Qlik
POSTs to it when the resource type changes. Useful for reacting to reload completion
without polling.

---

## Endpoint selection by situation

| Situation | Endpoint |
|---|---|
| Anything failing | `GET /qrs/about` |
| Find an app's GUID | `GET /qrs/app/full?filter=name eq 'X'` |
| Safe backup before changes | `POST /qrs/app/{id}/export/{token}` |
| Ship a dev app to production | `PUT /qrs/app/{id}/replace?app={prodId}` |
| Reload production properly | `POST /qrs/task/{id}/start` |
| Did the reload work? | `GET /qrs/executionresult/full` then the script log |
| User cannot see an app | `/qrs/user/full` → `/qrs/license/accesstypeinfo` → `POST /qrs/systemrule/security/audit` |
| Script says connection not found | `GET /qrs/dataconnection/full` — check exact name and owner |
| Sheet invisible to others | `GET /qrs/app/object/full` — check `approved` and `published` |
| Build a reload pipeline | `POST /qrs/compositeevent` |
| Is the server healthy? | `GET /qrs/servicestatus/full` |
| Which auth route is open? | `GET /qrs/virtualproxyconfig/full` |
| Version-accurate API reference | `GET /qrs/about/api/description?extended=true` |
