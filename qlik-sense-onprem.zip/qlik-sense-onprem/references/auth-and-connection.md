# Authentication and connection (Qlik Sense Enterprise on Windows)

Connection problems account for most of the time lost when automating on-prem Qlik, and
almost all of it is spent debugging the wrong layer. Work top-down: TLS → auth → port →
API. `qlik_client.py --selftest` does exactly this and tells you where it stopped.

## Contents
- [Ports](#ports)
- [The four auth modes](#the-four-auth-modes)
- [Certificate authentication (recommended)](#certificate-authentication-recommended)
- [Header authentication via virtual proxy](#header-authentication-via-virtual-proxy)
- [Ticket authentication](#ticket-authentication)
- [JWT authentication](#jwt-authentication)
- [The Xrfkey requirement](#the-xrfkey-requirement)
- [Error → cause table](#error--cause-table)

---

## Ports

| Port | Service | Used for |
|---|---|---|
| `4747` | Engine (QIX) | WebSocket JSON-RPC — direct, certificate auth only |
| `4242` | Repository (QRS) | REST — direct, certificate auth only |
| `4243` | Proxy (QPS) | Tickets, session management |
| `4244` | Scheduler (QSS) | Task execution |
| `443` | Proxy | Everything, when routed through a virtual proxy |

Two distinct routes exist and they are not interchangeable:

- **Direct service ports** (`4747`, `4242`) bypass the proxy entirely. Only certificate
  auth works here. Best for server-side automation, and immune to virtual proxy config
  drift.
- **Through the proxy** (`https://server/<vproxy-prefix>/...`, WebSocket
  `wss://server/<vproxy-prefix>/app/engineData`). Supports header, ticket, JWT, and
  Windows auth. Required when the security team has closed the direct ports — which,
  in a bank, they usually have.

Ask which route is open before writing anything. If `4242` is blocked and you assume
certificate auth, every call fails with a bare connection timeout that looks like a
network fault rather than a design mistake.

---

## The four auth modes

| Mode | Works on direct ports | Needs QMC change | Good for |
|---|---|---|---|
| Certificate | Yes | No (just export certs) | Server-side automation, scheduled jobs |
| Header | No — proxy only | Yes, new virtual proxy | Locked-down environments |
| Ticket | No — proxy only | No | Embedding, short-lived sessions |
| JWT | No — proxy only | Yes, new virtual proxy | SSO-integrated tooling |

---

## Certificate authentication (recommended)

**Export the certificates**: QMC → *Certificates* → enter the machine name running your
script → **Certificate password**: leave blank → **Export file format**: *Platform
independent PEM-format* → Export. You get three files:

```
client.pem        # the client certificate
client_key.pem    # its private key
root.pem          # the Qlik root CA, used to verify the server
```

These live on the server under `C:\ProgramData\Qlik\Sense\Repository\Exported Certificates\`.
Copy them to the machine running the script and lock down file permissions — anyone
holding `client_key.pem` can impersonate any user on the Qlik site, including admins.

**Every request must also declare who you are.** The certificate proves the *machine* is
trusted; the `X-Qlik-User` header states the *user* to act as:

```
X-Qlik-User: UserDirectory=INTERNAL;UserId=sa_repository
```

`INTERNAL\sa_repository` is the built-in service account with full access. For anything
touching user-visible data, prefer impersonating a real, appropriately-licensed user
(`UserDirectory=MYDOMAIN;UserId=jsmith`) so section access and audit trails behave the
way they would for that person. Section access silently returns *different numbers*
under a different identity — running QA as `sa_repository` and comparing against what a
business user sees is a classic false-discrepancy generator.

Engine WebSocket URL:
```
wss://qlikserver.company.local:4747/app/engineData
```
Append `/app/<app-id>` instead of `/app/engineData` to open a specific app on connect.

Note the URL header value must be URL-safe; the `X-Qlik-User` value is *not* URL-encoded
in the header itself.

**TLS verification.** The Qlik root CA is self-signed and usually not in the OS trust
store. Either pass `root.pem` as the CA bundle (correct) or set `verify_ssl: false`
(expedient, fine on an internal network, never for anything crossing a boundary).

---

## Header authentication via virtual proxy

Used when direct ports are closed. In QMC → *Virtual proxies* → Create:

- **Prefix**: e.g. `hdr` (this becomes part of every URL)
- **Authentication method**: `Header authentication dynamic user directory`
- **Header authentication header name**: e.g. `X-Qlik-HeaderAuth`
- **Header authentication dynamic user directory**: `$ud\$id` (lets the header carry
  `DOMAIN\user`)
- Link the virtual proxy to a proxy service, then restart the proxy

Then:
```
wss://qlikserver.company.local/hdr/app/engineData
X-Qlik-HeaderAuth: MYDOMAIN\svc_reporting
```

**The critical security caveat**: a header-auth virtual proxy will trust that header from
*anyone who can reach it*. It must be firewalled so only your automation host can
connect, otherwise it is an authentication bypass. Raise this explicitly with whoever
approves the change — it is the part that gets missed.

Some setups also require an `Origin` header matching the server on the WebSocket
handshake; add it if the handshake returns 400.

---

## Ticket authentication

No QMC change needed. Two steps: ask the proxy for a ticket, then redeem it.

```
POST https://qlikserver.company.local:4243/qps/<prefix>/ticket?xrfkey=abcdef1234567890
X-Qlik-Xrfkey: abcdef1234567890
Content-Type: application/json

{"UserDirectory":"MYDOMAIN","UserId":"svc_reporting","Attributes":[]}
```

Response contains `Ticket`. Redeem it by appending to the target URL:
```
wss://qlikserver.company.local/app/engineData?qlikTicket=<ticket>
```

Tickets are **single-use and expire in ~60 seconds by default**. Request a fresh one per
session; caching them causes intermittent 401s that look like a flaky network.

The ticket request itself needs certificate auth (or must originate from the server), so
this is usually layered on top of certs rather than replacing them.

---

## JWT authentication

QMC → Virtual proxy → Authentication method: `JWT`. Paste the **public key** (PEM
certificate) used to verify tokens, and set the attribute mapping:

- **JWT attribute for user ID**: e.g. `userId`
- **JWT attribute for user directory**: e.g. `userDirectory`

Sign tokens with the matching private key (RS256), including those claims:

```json
{"userId": "svc_reporting", "userDirectory": "MYDOMAIN", "exp": 1735689600}
```

Send as `Authorization: Bearer <token>`. Clock skew between the signing host and the
Qlik server is a frequent cause of "invalid token" — check NTP before rewriting code.

---

## The Xrfkey requirement

Every **QRS** REST call needs a cross-site request forgery key: exactly **16 alphanumeric
characters**, sent in *both* places, and they must match:

```
GET https://server:4242/qrs/app/full?xrfkey=abcdef1234567890
X-Qlik-Xrfkey: abcdef1234567890
```

Omitting either, or using a different length, returns **400 Bad Request** with no useful
body. This is the single most common QRS mistake. `QrsAPI` in `qlik_client.py` handles it
automatically — do not hand-roll QRS calls.

The Engine WebSocket API does **not** use xrfkey.

---

## Error → cause table

| Symptom | Cause |
|---|---|
| `400 Bad Request` on any QRS call | Missing/mismatched/wrong-length xrfkey |
| `401 Unauthorized` | `X-Qlik-User` header missing, or user unknown to Qlik, or expired ticket |
| `403 Forbidden` | Authenticated but the user lacks a security rule granting access |
| `SSL: CERTIFICATE_VERIFY_FAILED` | `root.pem` not supplied as CA bundle |
| `SSLError: bad handshake` / `tlsv1 alert` | Wrong client cert, or key does not match cert |
| `Connection refused` on 4747/4242 | Direct ports firewalled — switch to the virtual proxy route |
| WebSocket `HTTP 400` on handshake | Wrong virtual proxy prefix, or missing `Origin` header |
| Connects, but `GetDocList` returns `[]` | Auth worked; the impersonated user has no app access. Check security rules, not the connection |
| `App not found` for an app you can see in the hub | You are on a different virtual proxy than the hub, or the app is published to a stream the user cannot read |
| Works for `sa_repository`, wrong numbers for a real user | Section access is filtering data — this is correct behaviour, not a bug |
