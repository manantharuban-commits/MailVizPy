# Chart → SQL translation: what is faithful, what is not

`object_to_sql.py` turns a chart's hypercube definition into a SQL query so you can prove
the number independently. This file documents exactly how far to trust it.

The guiding principle: **a validation query that silently drops a modifier is worse than
no query**, because it manufactures a discrepancy and sends someone hunting a bug that
does not exist. So the translator flags rather than guesses, and every flag must reach the
user.

## Contents
- [How the translation works](#how-the-translation-works)
- [Translates faithfully](#translates-faithfully)
- [Translates approximately](#translates-approximately)
- [Cannot translate](#cannot-translate)
- [Structural mismatches to expect](#structural-mismatches-to-expect)
- [The validation workflow](#the-validation-workflow)
- [Reading a discrepancy](#reading-a-discrepancy)

---

## How the translation works

1. `GetProperties` on the object → `qHyperCubeDef`.
2. Dimensions → `SELECT` columns + `GROUP BY`.
3. Measures → aggregate expressions in `SELECT`.
4. Set analysis on a measure → a `CASE WHEN` **inside** that aggregate.
5. `GetLineage` → the `FROM` target.
6. Dimension limits (`qOtherTotalSpec`) → `LIMIT` / `TOP` / `FETCH FIRST`.

Set analysis becomes `CASE WHEN` rather than `WHERE` deliberately. Set analysis scopes to
one measure; a `WHERE` clause would wrongly restrict every other measure in the same
chart. So:

```
Sum({<Year={2024}>} SalesAmount)
```
becomes
```sql
SUM(CASE WHEN Year = 2024 THEN SalesAmount END)
```

---

## Translates faithfully

| Qlik | SQL | Notes |
|---|---|---|
| `Sum(X)`, `Avg(X)`, `Min(X)`, `Max(X)` | `SUM`/`AVG`/`MIN`/`MAX` | exact |
| `Count(X)` | `COUNT(X)` | both skip nulls |
| `Count(DISTINCT X)` | `COUNT(DISTINCT X)` | exact |
| Simple field dimensions | `GROUP BY` column | exact |
| `{<Field={a,b}>}` | `CASE WHEN Field IN (a,b)` | exact for literal lists |
| `{<Field={">=10<=20"}>}` | `BETWEEN` | numeric ranges only |
| Top-N dimension limit | `ORDER BY ... LIMIT n` | ties may break differently |
| `Num()`, `Money()`, `Date()` wrappers | unwrapped | formatting only, no value change |

---

## Translates approximately

**`Sum(A)/Sum(B)`** — translated term by term. SQL and Qlik differ on division by zero:
Qlik returns null, most databases raise an error or return null depending on settings.
Add an explicit guard when the denominator can be zero.

**Calculated dimensions** (`=If(Sales>1000,'High','Low')`) — passed through as-is. Qlik
`If()` and SQL `CASE` behave the same for simple predicates, but Qlik's implicit type
coercion is looser: `If(Status=1,...)` matches the string `'1'` in Qlik and does not in
most databases.

**`Only(X)`** — rendered as `MAX(X)`. These agree when the value is genuinely unique and
diverge silently when it is not. `Only()` returns null on ambiguity; `MAX` picks one.

**Wildcards** (`{<Region={'North*'}>}`) — become `LIKE 'North%'`. Qlik's matching is
case-insensitive by default; most databases are case-sensitive (BigQuery and Postgres
are, MSSQL depends on collation). This alone can account for a whole missing category.

**Multi-table charts** — Qlik associates on shared field names automatically. The
translator emits the first source table and a REVIEW note. You must add the JOINs, and
the join type matters: Qlik's association behaves like a full outer join with respect to
which values remain selectable, but aggregates behave like an inner join over matching
rows. When in doubt, write `LEFT JOIN` from the fact table and compare.

---

## Cannot translate

The translator emits `NULL /* original expression */` and a REVIEW line for these.

| Construct | Why | What to write instead |
|---|---|---|
| `AGGR(...)` | builds a virtual table | CTE or subquery |
| `TOTAL` | ignores chart dimensions | window function: `SUM(X) OVER ()` or `OVER (PARTITION BY ...)` |
| `Above()`, `Below()`, `Before()`, `After()` | inter-record, chart-order dependent | `LAG()` / `LEAD()` |
| `Rank()`, `RowNo()` | rank within chart, not table | `RANK() OVER (...)`, `ROW_NUMBER() OVER (...)` |
| `FirstSortedValue()` | ordered pick | correlated subquery, or `ARRAY_AGG(x ORDER BY y)[OFFSET(0)]` in BigQuery |
| `$(...)` expansion | resolved at runtime, text unknown statically | evaluate it in Qlik first (`EvaluateEx`), then paste the literal |
| `P()` / `E()` element functions | set-of-values from another field's selection | `IN (SELECT ...)` subquery |
| Set operators `+=`, `-=`, `*=` | modify the *current selection*, which SQL has no concept of | decide what selection state you are validating against, then hard-code it |
| Alternate states | parallel selection contexts | not expressible; validate each state separately |
| `Peek()`, `Previous()`, `RecNo()` | load-script row context | no query-time equivalent |

For `$(...)`, there is a good workaround: call Engine `EvaluateEx` on the inner
expression to get the literal Qlik would have substituted, then hand-edit it into the SQL.
That turns an untranslatable expression into an exactly translatable one.

---

## Structural mismatches to expect

Even a perfectly translated measure can produce different row counts, for reasons that
are not bugs:

**Null suppression.** `qNullSuppression: true` on a dimension hides null rows. SQL shows
them. Add `WHERE dim IS NOT NULL` to match.

**Zero suppression.** `qSuppressZero` hides rows where all measures are zero.

**Selection state.** Any selection active in the Engine session filters the chart.
Always `ClearAll` before reading data for validation — `validate_object.py --clear-selections`
does this.

**Section access.** The identity you authenticate as may see a reduced dataset. This is
correct behaviour and will look exactly like a data bug. Validate as the same user the
business is looking at.

**Load script filtering.** The app may only contain rows since 2023 while the table holds
ten years. Check the script's `WHERE` clauses — `inspect_app.py` returns the script and
lineage for this reason.

**Reload timing.** The app holds a snapshot. If it reloaded at 02:00 and you query the
source at 14:00, the two legitimately differ. Compare `GetAppLayout`'s last reload time
against the data.

**Aggregation precision.** Qlik aggregates in double precision. A `DECIMAL` column summed
over millions of rows in the database can differ in the last cents. Use a relative
tolerance (`--tolerance 0.0001`), not exact equality.

---

## The validation workflow

```bash
# 1. find the object
python scripts/inspect_app.py --app "Sales Performance" --sheet-detail --out model.json

# 2. generate SQL
python scripts/object_to_sql.py --app "Sales Performance" --object AbCdEf \
    --dialect bigquery --out validate.sql

# 3. READ THE REVIEW LINES. Fix what needs fixing. Run it in the database.
#    Export results as CSV with dimension columns first, in chart order.

# 4. diff
python scripts/validate_object.py --app "Sales Performance" --object AbCdEf \
    --sql-results results.csv --tolerance 0.001 --clear-selections
```

Step 3 is not optional. The REVIEW lines are the difference between a validation and a
false alarm.

---

## Reading a discrepancy

When `validate_object.py` reports a mismatch, work through these in order — they are
sorted by how often each turns out to be the cause:

1. **Selections** — was the session clean? Re-run with `--clear-selections`.
2. **Set analysis** — did a REVIEW line warn about a modifier you did not reproduce?
3. **Reload freshness** — does the app's data predate rows you just queried?
4. **Null/zero suppression** — do the row counts differ, rather than the values?
5. **Section access** — are you authenticated as a different user than the report reader?
6. **Load script filters** — does the script restrict dates, flags, or test records?
7. **Join fan-out** — does the SQL join a fact to a dimension that multiplies rows? Qlik's
   association does not multiply; a careless SQL join does. This inflates SQL totals above
   Qlik's, which is a distinctive signature.
8. **Rounding** — only after all the above, and only if differences are tiny and random.

Finding the app genuinely wrong is the least common outcome. Say so plainly when the
evidence points at the query instead — a QA process that cries wolf gets ignored.
