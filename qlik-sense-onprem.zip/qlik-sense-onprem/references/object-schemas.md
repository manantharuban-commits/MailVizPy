# Visualization object schemas

Property JSON for the objects `build_dashboard.py` creates, plus the shared building
blocks. Read this before adding a chart type the example spec does not cover.

**The rule that saves the most time**: the Engine accepts unknown properties silently.
If you invent a key, `CreateObject` succeeds and the chart renders empty or ignores the
setting. So when you are unsure of a shape, build one object by hand in the Qlik client
and read it back:

```bash
python scripts/inspect_app.py --app "<id>" --sheet-detail --out model.json
```

Copying a real object from the user's own Qlik version beats reproducing documentation,
because these schemas do drift between releases.

## Contents
- [Shared building blocks](#shared-building-blocks)
- [Sheet](#sheet)
- [KPI](#kpi)
- [Bar / line / combo](#bar--line--combo)
- [Pie and treemap](#pie-and-treemap)
- [Scatter plot](#scatter-plot)
- [Straight table](#straight-table)
- [Pivot table](#pivot-table)
- [Gauge](#gauge)
- [Filter pane and listbox](#filter-pane-and-listbox)
- [Text & image](#text--image)
- [Master items](#master-items)
- [Number formats](#number-formats)

---

## Shared building blocks

### Dimension
```json
{
  "qDef": {
    "qFieldDefs": ["Region"],
    "qFieldLabels": ["Region"],
    "qSortCriterias": [{"qSortByLoadOrder": 1, "qSortByNumeric": 1}]
  },
  "qNullSuppression": true,
  "qOtherTotalSpec": {}
}
```

- `qFieldDefs` with several entries makes a **drill-down group**.
- A leading `=` makes it a calculated dimension: `["=If(Sales>1000,'High','Low')"]`.
- To reference a master dimension, replace `qDef` with `"qLibraryId": "<dim-id>"`.
- `qNullSuppression: true` hides null dimension values — this is why a chart can show
  fewer rows than the equivalent SQL.

Top-N limiting lives in `qOtherTotalSpec`:
```json
{"qOtherTotalSpec": {
  "qOtherMode": "OTHER_COUNTED",
  "qOtherCounted": "10",
  "qOtherSortMode": "OTHER_SORT_DESCENDING",
  "qSuppressOther": true}}
```
`qSuppressOther: false` adds an "Others" bucket instead of dropping the tail.

### Measure
```json
{
  "qDef": {
    "qDef": "Sum(SalesAmount)",
    "qLabel": "Total Sales",
    "qNumFormat": {"qType": "F", "qFmt": "#,##0", "qDec": ".", "qThou": ","}
  },
  "qSortBy": {"qSortByNumeric": -1}
}
```
Note the doubled `qDef.qDef` — the outer is the wrapper, the inner is the expression
string. Master measure: `"qLibraryId": "<measure-id>"` in place of `qDef`.

`qLabelExpression` (a string starting with `=`) makes the label dynamic.

### Hypercube
```json
{
  "qHyperCubeDef": {
    "qDimensions": [ /* dimensions */ ],
    "qMeasures": [ /* measures */ ],
    "qInitialDataFetch": [{"qTop": 0, "qLeft": 0, "qHeight": 50, "qWidth": 10}],
    "qMode": "S",
    "qInterColumnSortOrder": [0, 1],
    "qSuppressZero": false,
    "qSuppressMissing": true
  }
}
```
`qMode`: `S` straight (most charts), `P` pivot, `K` stacked.
`qInterColumnSortOrder` is a list of column indices — sorting by measure means putting
the measure's index first.

---

## Sheet

```json
{
  "qInfo": {"qType": "sheet"},
  "qMetaDef": {"title": "Executive Overview", "description": ""},
  "rank": 0,
  "thumbnail": {"qStaticContentUrlDef": {"qUrl": ""}},
  "columns": 24,
  "rows": 12,
  "gridResolution": "small",
  "layoutOptions": {"mobileLayout": "LIST", "extendable": false},
  "customRowBase": 12,
  "cells": [
    {"name": "<child-object-id>", "type": "barchart",
     "col": 0, "row": 3, "colspan": 14, "rowspan": 5,
     "bounds": {"x": 0, "y": 25, "width": 58.33, "height": 41.67}}
  ]
}
```

The grid is **24 × 12**. `bounds` are percentages and newer clients prefer them; keep
both in sync or objects jump on first open. `build_dashboard.py` computes `bounds` from
the grid units automatically.

Create the child objects **first**, then write `cells` referencing their ids. A cell
naming a non-existent object renders as a broken tile with no error message.

---

## KPI

```json
{
  "qInfo": {"qType": "kpi"},
  "visualization": "kpi",
  "qHyperCubeDef": {"qDimensions": [], "qMeasures": [ /* 1-2 measures */ ],
                    "qInitialDataFetch": [{"qTop":0,"qLeft":0,"qHeight":1,"qWidth":2}]},
  "title": "Total Sales",
  "showTitles": true,
  "showMeasureTitle": true,
  "layoutBehavior": "responsive",
  "sharing": {"enabled": false}
}
```
Zero dimensions, one measure (a second becomes the comparison value). Conditional colour
goes in the measure's `coloring` block or via `qNumFormat`; simplest is a
`qLabelExpression` plus a colour expression on the measure.

---

## Bar / line / combo

```json
{
  "qInfo": {"qType": "barchart"},
  "visualization": "barchart",
  "qHyperCubeDef": { /* 1-2 dimensions, 1+ measures */ },
  "title": "Sales by Region",
  "showTitles": true,
  "orientation": "horizontal",
  "barGrouping": {"grouping": "grouped"},
  "color": {"auto": true, "mode": "primary"},
  "legend": {"show": true, "dock": "auto"},
  "dataPoint": {"showLabels": false},
  "gridLine": {"auto": true},
  "refLine": {"refLines": []}
}
```
`barGrouping.grouping`: `grouped` or `stacked` (stacked also needs `qMode: "K"` and a
second dimension).

`linechart` is the same shape plus:
```json
{"lineType": "line", "dataPoint": {"show": false}, "scrollbar": "miniChart"}
```
`lineType: "area"` gives an area chart.

`combochart` adds a per-measure series type:
```json
{"qMeasures": [{"qDef": {...}, "series": {"type": "bar"}},
               {"qDef": {...}, "series": {"type": "line"}, "qAttributeExpressions": []}],
 "axis": {"measureAxis": {"secondary": true}}}
```
Put the differently-scaled measure (a percentage next to a currency) on the secondary
axis, or the small series flattens to an invisible line at the bottom.

---

## Pie and treemap

```json
{"qInfo": {"qType": "piechart"}, "visualization": "piechart",
 "qHyperCubeDef": { /* exactly 1 dimension, 1 measure */ },
 "donut": true, "dataPoint": {"labelMode": "share"},
 "legend": {"show": true, "dock": "right"}}
```

```json
{"qInfo": {"qType": "treemap"}, "visualization": "treemap",
 "qHyperCubeDef": { /* 1-3 dimensions (nesting), 1-2 measures */ },
 "dataPoint": {"showLabels": true, "showValues": true},
 "color": {"auto": true}}
```
For treemap the **second measure colours** the tiles while the first sizes them.

---

## Scatter plot

```json
{"qInfo": {"qType": "scatterplot"}, "visualization": "scatterplot",
 "qHyperCubeDef": { /* 1 dimension, 2-3 measures: x, y, size */ },
 "compressionResolution": "high",
 "dataPoint": {"bubbleSizes": 5, "showLabels": false},
 "xAxis": {"show": "all"}, "yAxis": {"show": "all"}}
```
Measure order is positional and not labelled anywhere in the UI: **x, then y, then
bubble size**. Getting them backwards produces a chart that looks plausible and is wrong.

---

## Straight table

```json
{
  "qInfo": {"qType": "table"},
  "visualization": "table",
  "qHyperCubeDef": {
    "qDimensions": [...], "qMeasures": [...],
    "qColumnOrder": [0, 1, 2],
    "qInitialDataFetch": [{"qTop":0,"qLeft":0,"qHeight":20,"qWidth":10}]
  },
  "totals": {"show": true, "position": "top", "label": "Totals"},
  "scrolling": {"horizontal": false, "keepFirstColumnInView": false},
  "multiline": {"wrapTextInHeaders": true, "wrapTextInCells": false}
}
```
`qColumnOrder` indexes dimensions first, then measures.

---

## Pivot table

```json
{
  "qInfo": {"qType": "pivot-table"},
  "visualization": "pivot-table",
  "qHyperCubeDef": {
    "qDimensions": [ /* row dims first, then column dims */ ],
    "qMeasures": [...],
    "qMode": "P",
    "qNoOfLeftDims": 1,
    "qAlwaysFullyExpanded": true,
    "qIndentMode": true
  },
  "totals": {"show": true}
}
```
`qNoOfLeftDims` splits the dimension array: the first N become rows, the rest become
columns. Read data with `GetHyperCubePivotData`, not `GetHyperCubeData` — flat paging
returns nothing useful in mode `P`.

---

## Gauge

```json
{
  "qInfo": {"qType": "gauge"}, "visualization": "gauge",
  "qHyperCubeDef": {"qDimensions": [], "qMeasures": [ /* exactly 1 */ ]},
  "gaugetype": "radial",
  "useSegments": true,
  "segments": {"limits": [{"value": 0.25}, {"value": 0.35}],
               "paletteColors": [{"index": 4}, {"index": 8}, {"index": 3}]},
  "min": {"measure": 0}, "max": {"measure": 0.5},
  "showTitles": true
}
```
Segments need **one more colour than limits**. Mismatched counts render grey.

---

## Filter pane and listbox

A filter pane has no hypercube. Each field is a **child listbox**:

```json
{"qInfo": {"qType": "filterpane"}, "visualization": "filterpane",
 "qChildListDef": {"qData": {"title": "/title"}},
 "showTitles": true, "title": "Filters"}
```

Then, per field, `CreateChild` on the filter pane's handle:

```json
{"qInfo": {"qType": "listbox"},
 "qListObjectDef": {
   "qDef": {"qFieldDefs": ["Region"], "qFieldLabels": ["Region"]},
   "qAutoSortByState": {"qDisplayNumberOfRows": -1},
   "qFrequencyMode": "V",
   "qShowAlternatives": true,
   "qInitialDataFetch": [{"qTop":0,"qLeft":0,"qHeight":100,"qWidth":1}]},
 "title": "Region", "showTitles": true}
```

A standalone listbox (outside a filter pane) is the same object placed directly in a
sheet cell with `"type": "listbox"`.

---

## Text & image

```json
{"qInfo": {"qType": "text-image"}, "visualization": "text-image",
 "showTitles": false,
 "textAlign": "left",
 "layoutBehavior": "freeSize",
 "measures": [],
 "qHyperCubeDef": {"qDimensions": [], "qMeasures": []},
 "paragraphs": [{"content": "<h3>About</h3><p>Reloads nightly.</p>"}]}
```
Some versions store rich text in `paragraphs`, others in a single `text` property. Read
back a hand-built one if formatting does not appear.

To embed a live figure, add a measure and reference it in the text — plain HTML in this
object is static and will not evaluate Qlik expressions.

---

## Master items

Master dimension:
```json
{"qInfo": {"qType": "dimension"},
 "qDim": {"qGrouping": "N", "qFieldDefs": ["Region"], "qFieldLabels": ["Region"],
          "title": "Region", "qLabelExpression": ""},
 "qMetaDef": {"title": "Region", "description": "", "tags": []}}
```
`qGrouping`: `N` single field, `H` drill-down hierarchy.

Master measure:
```json
{"qInfo": {"qType": "measure"},
 "qMeasure": {"qLabel": "Total Sales", "qDef": "Sum(SalesAmount)", "qGrouping": "N",
              "qNumFormat": {"qType": "F", "qFmt": "#,##0"}, "qLabelExpression": ""},
 "qMetaDef": {"title": "Total Sales", "description": "", "tags": ["finance"]}}
```

`CreateDimension` / `CreateMeasure` return the id used as `qLibraryId` in charts.

---

## Number formats

`qNumFormat.qType`:

| Value | Meaning |
|---|---|
| `U` | auto / unknown (inherits) |
| `F` | fixed number |
| `M` | money |
| `D` | date |
| `T` | time |
| `TS` | timestamp |
| `IV` | interval |
| `R` | real |

```json
{"qType": "F",  "qFmt": "#,##0",   "qDec": ".", "qThou": ","}
{"qType": "F",  "qFmt": "0.0%",    "qDec": "."}
{"qType": "M",  "qFmt": "₹#,##0",  "qDec": ".", "qThou": ","}
{"qType": "D",  "qFmt": "DD/MM/YYYY"}
```

Indian lakh/crore grouping uses `"qFmt": "##,##,##0"` with `qThou: ","` — the repeated
two-digit group is what produces `1,23,45,678`.
