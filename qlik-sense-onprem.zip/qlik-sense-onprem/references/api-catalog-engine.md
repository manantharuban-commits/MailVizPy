# QIX Engine API — complete method catalog

Every method the Engine JSON API exposes, grouped by class, with the situation each is
for. Method availability varies slightly by Qlik version — call `EngineVersion` first and
verify anything unusual before relying on it.

Transport, handles, and paging are covered in `engine-api.md`. This file is the catalog.

## Contents
- [Class hierarchy](#class-hierarchy)
- [Global](#global)
- [Doc (App)](#doc-app)
- [GenericObject](#genericobject)
- [Field](#field)
- [Variable and GenericVariable](#variable-and-genericvariable)
- [GenericDimension / GenericMeasure](#genericdimension--genericmeasure)
- [GenericBookmark](#genericbookmark)
- [List definitions (session objects)](#list-definitions-session-objects)
- [Method selection by situation](#method-selection-by-situation)

---

## Class hierarchy

```
Global (handle -1)
└── Doc            OpenDoc / CreateApp
    ├── GenericObject      CreateObject / GetObject / CreateSessionObject
    │   └── GenericObject  CreateChild (containers, filter panes)
    ├── GenericDimension   CreateDimension / GetDimension
    ├── GenericMeasure     CreateMeasure / GetMeasure
    ├── GenericVariable    CreateVariableEx / GetVariableById
    ├── GenericBookmark    CreateBookmark / GetBookmark
    ├── Field              GetField
    └── Variable           GetVariable   (legacy, prefer GenericVariable)
```

---

## Global

### Connection and identity
| Method | Situation |
|---|---|
| `EngineVersion` | First call always. Schemas differ by version; this tells you which you are on |
| `ProductVersion`, `QTProduct`, `QvVersion` | Full version strings for support tickets |
| `GetAuthenticatedUser` | Confirm *who* the server thinks you are — critical when section access is in play |
| `OSName`, `OSVersion` | Rarely needed; server platform |
| `IsDesktopMode`, `IsPersonalMode` | Distinguish Qlik Sense Desktop from Enterprise; permission model differs entirely |
| `GetUniqueID` | Engine instance id, for correlating with server logs |

### App lifecycle
| Method | Situation |
|---|---|
| `OpenDoc(qDocName, qUserName, qPassword, qSerial, qNoData)` | Open an app. Pass `qNoData: true` whenever you only need structure — on a large app this saves minutes and gigabytes |
| `CreateApp(qAppName, qLocalizedScriptMainSection)` | New empty app |
| `CreateDocEx` | Create and open in one call |
| `CopyApp(qTargetAppId, qSrcAppId, qIds)` | Server-side copy; `qIds` optionally limits which objects come across |
| `DeleteApp(qAppId)` | Prefer QRS so the repository stays consistent |
| `ExportApp(qTargetPath, qSrcAppId, qIds)` | Server-side `.qvf` export |
| `ReplaceAppFromID` | Update a published app from a development copy |
| `PublishApp(qAppId, qName, qStreamId)` | Publish; QRS is usually the better route |
| `GetDocList` | Apps visible to this identity. Empty list + successful auth = permissions, not connectivity |
| `GetAppEntry(qAppID)` | One app's repository entry |
| `AllowCreateApp` | Whether this identity may create apps |

### Session apps
| Method | Situation |
|---|---|
| `CreateSessionApp` | Throwaway in-memory app. Ideal for testing a load script without leaving anything behind |
| `CreateSessionAppFromApp(qSrcAppId)` | Copy an existing app into a session — experiment on real data with zero risk to the original |

### Reload control
| Method | Situation |
|---|---|
| `ConfigureReload(qCancelOnScriptError, qUseErrorData, qInteractOnError)` | Set behaviour *before* `DoReload` |
| `CancelReload`, `AbortRequest(qRequestId)`, `AbortAll` | Stop a runaway reload |
| `GetProgress(qRequestId)` | Poll a long reload for progress text |
| `GetInteract`, `InteractDone` | Handle script `INPUT`/breakpoint prompts. Automation should avoid scripts that need these |

### Data source discovery
| Method | Situation |
|---|---|
| `GetCustomConnectors` | Which connectors are installed — check before writing a script that assumes one |
| `GetODBCDsns`, `GetOLEDBProviders` | Available DSNs and providers on the server |
| `GetDatabasesFromConnectionString` | Enumerate databases from a connection string |
| `IsValidConnectionString` | Validate before saving a connection |
| `GetFolderItemsForPath`, `GetLogicalDriveStrings`, `GetDefaultAppFolder` | Filesystem browsing; usually blocked in Standard Mode |
| `GetSupportedCodePages` | Encoding options for file loads |

### Language metadata
| Method | Situation |
|---|---|
| `GetFunctions(qGroup)` | Every Qlik function available on this version — useful for validating a generated expression against the actual install |
| `GetBNF`, `GetBaseBNFString`, `GetBNFHash` | The grammar itself. Underpins editor autocomplete; occasionally useful for building a validator |
| `GetConfiguration` | Engine limits and feature flags |

---

## Doc (App)

### Script
| Method | Situation |
|---|---|
| `GetScript` | Read before writing — `SetScript` replaces everything, so this is your only rollback |
| `SetScript(qScript)` | Full replacement. Preserve `///$tab` markers |
| `CheckScriptSyntax` | Always before `DoReload`. Instant, versus a ten-minute failed reload with the error buried in a log |
| `GetEmptyScript` | The default script skeleton with locale variables |
| `GetScriptBreakpoints`, `SetScriptBreakpoints` | Debugging; avoid in automation — a breakpoint hangs an unattended reload |
| `GetIncludeFileContent(qPath)` | Resolve `$(Include=...)` contents |
| `GetTextMacros` | Variables the script defines |
| `DoReload(qMode, qPartial, qDebug)` | Run the script |
| `DoReloadEx` | Same, but returns `{qSuccess, qLog}` — prefer it, the log is the diagnosis |
| `DoSave(qFileName)` | **Persists everything.** Without it, all Engine writes vanish on disconnect |

### Objects
| Method | Situation |
|---|---|
| `CreateObject(qProp)` | Persistent object |
| `CreateSessionObject(qProp)` | Transient — the right tool for ad-hoc data reads |
| `GetObject(qId)` | Handle for an existing object |
| `GetObjects(qOptions)` | Filtered list with metadata |
| `GetAllInfos` | `[{qId, qType}]` for everything. The starting point for any inspection |
| `DestroyObject`, `DestroySessionObject` | Remove |
| `CloneObject(qId)` | Duplicate — easiest way to make a variant of a working chart |
| `SaveObjects` | Persist object changes without a full app save |
| `ApplyPatches(qPatches, qSoftPatch)` | Targeted change. `qSoftPatch: true` is session-only and does not persist — good for "what if" |
| `ClearAllSoftPatches` | Discard those |
| `Publish` / `UnPublish` | Move objects between private and public in a published app |

### Master items
| Method | Situation |
|---|---|
| `CreateDimension`, `GetDimension`, `DestroyDimension`, `CloneDimension` | Master dimensions |
| `CreateMeasure`, `GetMeasure`, `DestroyMeasure`, `CloneMeasure` | Master measures |
| `CreateVariableEx`, `GetVariableById`, `GetVariableByName`, `DestroyVariableById`, `DestroyVariableByName`, `CloneVariable` | Variables |
| `CreateSessionVariable`, `DestroySessionVariable` | Temporary variables |
| `GetFavoriteVariables`, `SetFavoriteVariables` | Which variables show in the UI |
| `CreateBookmark`, `CreateBookmarkEx`, `GetBookmark`, `GetBookmarks`, `DestroyBookmark`, `CloneBookmark` | Saved selection states |

### Data model
| Method | Situation |
|---|---|
| `GetTablesAndKeys` | **The health check.** Tables, rows, keys, and synthetic keys. Run before trusting any number |
| `GetLineage` | Source connections and statements per table |
| `GetFields`, `GetField(qFieldName)` | Field handles |
| `GetFieldDescription(qFieldName)` | Tags, cardinality, source tables |
| `GetFieldOnTheFlyByName` | Fields created by `AddFieldFromExpression` |
| `AddFieldFromExpression(qName, qExpr)` | Calculated field at session level, without touching the script |
| `GetMatchingFields(qTags)` | Find fields by tag — e.g. all `$date` fields |
| `GetTableData(qOffset, qRows, qSyntheticMode, qTableName)` | Raw rows from one table. Bypasses charts entirely; useful for QA |
| `GetLooselyCoupledVector`, `SetLooselyCoupledVector` | Break a circular reference by disabling one association |
| `GetAssociationScores(qTable1, qTable2)` | How well two tables would associate — for diagnosing a suspect model |
| `GetHidePrefix` | Prefix marking fields hidden from users |
| `GetLocaleInfo` | Decimal separators, date formats. Read this before parsing `qText` values |

### Expressions
| Method | Situation |
|---|---|
| `CheckExpression(qExpr)` | Validate before creating a chart. Returns `qBadFieldNames` — catches the #1 cause of blank charts |
| `CheckNumberOrExpression` | For fields that accept either |
| `Evaluate(qExpression)` | Scalar result as a string |
| `EvaluateEx(qExpression)` | Typed result. Also the workaround for `$()` expansion when building validation SQL |
| `GetSetAnalysis(qStateName, qBookmarkId)` | Turn the *current selection* into a set analysis string. Excellent for reproducing what a user is looking at |
| `GetExpressionBNF` | Expression grammar |

### Selections and navigation
| Method | Situation |
|---|---|
| `ClearAll(qLockedAlso, qStateName)` | **Before any validation read.** A stale selection silently filters results |
| `Back`, `Forward` | Selection history |
| `Lock`/`Unlock` via Field | Prevent a selection being cleared |
| `AddAlternateState`, `RemoveAlternateState` | Parallel selection contexts for comparison charts |
| `SearchObjects`, `SearchResults`, `SearchSuggest`, `SearchAssociations`, `SelectAssociations` | Smart search across the app |
| `UndoLayout`, `RedoLayout`, `ClearUndoBuffer` | Layout undo stack |

### Connections
| Method | Situation |
|---|---|
| `GetConnections`, `GetConnection(qConnectionId)` | What this identity can use in a script |
| `CreateConnection`, `ModifyConnection`, `DeleteConnection` | Manage connections |
| `GetConnectionErrors` | Why a connection failed |
| `GetDatabases`, `GetDatabaseTables`, `GetDatabaseTableFields`, `GetDatabaseTablePreview`, `GetDatabaseOwners` | Browse a database through a connection — how you discover real table and column names before writing `SQL SELECT` |
| `GetFileTables`, `GetFileTableFields`, `GetFileTablePreview`, `GetFileTablesEx` | Same for files |
| `GetFolderItemsForConnection` | List files in a folder connection |
| `SendGenericCommandToCustomConnector` | Connector-specific commands |

### App metadata
| Method | Situation |
|---|---|
| `GetAppLayout` | Title, `qLastReloadTime`, `qHasData`. Check reload time before comparing against a live source |
| `GetAppProperties`, `SetAppProperties` | Title, description, thumbnail |
| `GetLibraryContent`, `GetMediaList` | Images and content libraries |
| `SetFetchLimit` | Cap rows returned per request |
| `ExportReducedData` | Export with section access reduction applied |

---

## GenericObject

### Reading
| Method | Situation |
|---|---|
| `GetLayout` | Evaluated state — what the user sees, including `qError`. Use to *check* an object |
| `GetProperties` | Definition — the JSON you would edit. Use to *change* an object |
| `GetEffectiveProperties` | Properties with linked-object inheritance resolved |
| `GetInfo` | Just `{qId, qType}` |
| `GetParent`, `GetChild`, `GetChildInfos` | Navigate containers and filter panes |
| `GetLinkedObjects` | Objects sharing a master item |
| `GetSnapshotObject` | The snapshot behind a storytelling slide |

### Data
| Method | Situation |
|---|---|
| `GetHyperCubeData(qPath, qPages)` | Straight mode `S`. Cap is 10,000 cells per page |
| `GetHyperCubePivotData` | Pivot mode `P`. Returns nested node trees, not a flat matrix |
| `GetHyperCubeStackData` | Stacked mode `K` |
| `GetHyperCubeTreeData` | Tree/sankey structures |
| `GetHyperCubeContinuousData` | Continuous-axis charts |
| `GetHyperCubeBinnedData` | Scatter plots with binning at high point counts |
| `GetHyperCubeReducedData` | Server-side downsample for very large sets |
| `GetListObjectData(qPath, qPages)` | Listbox values |
| `ExportData(qFileType, qPath, qFileName, qExportState)` | Server-side CSV/OOXML export; returns a download URL. `qExportState` `A` = all, `P` = possible only |

Picking the wrong getter is a common trap: `GetHyperCubeData` on a pivot table returns
nothing useful rather than erroring, so an empty result there means "wrong method", not
"no data".

### Writing
| Method | Situation |
|---|---|
| `SetProperties(qProp)` | Overwrites the WHOLE definition. Read-modify-write, always |
| `ApplyPatches(qPatches, qSoftPatch)` | Change one property without a full replace. Safer for surgical edits |
| `SetFullPropertyTree`, `GetFullPropertyTree` | Object plus all children in one call — the right way to build a filter pane atomically |
| `CreateChild(qProp)`, `DestroyChild`, `DestroyAllChildren` | Container children |
| `CopyFrom(qFromId)` | Clone another object's definition |
| `Approve`, `Publish`, `UnPublish` | Promote a private sheet to community, or community to base |
| `Lock`, `Unlock` | Prevent edits |

### Selection from within a chart
| Method | Situation |
|---|---|
| `BeginSelections`, `EndSelections(qAccept)`, `ResetMadeSelections` | Selection transaction — required before `SelectHyperCube*` in some clients |
| `SelectHyperCubeValues(qPath, qDimNo, qValues, qToggleMode)` | Select by element number |
| `SelectHyperCubeCells(qPath, qRowIndices, qColIndices)` | Select by cell position |
| `SelectHyperCubeContinuousRange`, `RangeSelectHyperCubeValues` | Range selection on a continuous axis |
| `SelectPivotCells`, `MultiRangeSelectTreeDataValues` | Pivot and tree selection |
| `SelectListObjectValues`, `SelectListObjectAll`, `SelectListObjectPossible`, `SelectListObjectExcluded`, `SelectListObjectAlternative`, `SelectListObjectContinuousRange` | Listbox selection variants |
| `SearchListObjectFor(qMatch)`, `AcceptListObjectSearch`, `AbortListObjectSearch` | Search within a listbox |
| `ClearSelections(qPath, qColIndices)` | Clear this object's selections only |
| `DrillUp(qPath, qDimNo, qNbrSteps)` | Step back up a drill-down group |

---

## Field

Get a handle with Doc `GetField(qFieldName, qStateName)`.

| Method | Situation |
|---|---|
| `Select(qMatch, qSoftLock, qExcludedValuesMode)` | Select by text match |
| `SelectValues(qFieldValues, qToggleMode, qSoftLock)` | Select specific values — the workhorse for automation |
| `SelectAll`, `SelectPossible`, `SelectExcluded`, `SelectAlternative` | Bulk selection by state |
| `ToggleSelect`, `LowLevelSelect` | Toggle, or select by element number |
| `Clear`, `ClearAllButThis` | Clear |
| `Lock`, `Unlock` | Prevent clearing |
| `GetCardinal` | Distinct value count — cheap way to sanity-check a join before building anything |
| `GetAndMode`, `SetAndMode` | AND-mode selection (all of, rather than any of). Rarely used, changes semantics substantially |
| `GetNxProperties`, `SetNxProperties` | One-and-only-one behaviour |

---

## Variable and GenericVariable

`GenericVariable` is current; `Variable` is legacy.

| Method | Situation |
|---|---|
| `GetContent`, `GetRawContent` | Evaluated vs literal text. The difference matters: a variable holding `=Max(Year)` returns different things from each |
| `SetContent`, `ForceContent` | Write |
| `GetLayout`, `GetProperties`, `SetProperties`, `ApplyPatches` | Standard generic-object surface |

---

## GenericDimension / GenericMeasure

| Method | Situation |
|---|---|
| `GetDimension` / `GetMeasure` | The definition |
| `GetLayout`, `GetProperties`, `SetProperties`, `ApplyPatches` | Standard surface |
| `GetLinkedObjects` | **Which charts use this master item** — essential before editing one, so you know the blast radius |
| `Publish`, `UnPublish` | Visibility in a published app |

---

## GenericBookmark

| Method | Situation |
|---|---|
| `Apply` | Restore a saved selection state — the exact way to reproduce what a user was looking at when they reported a number |
| `GetFieldValues` | What the bookmark selects, without applying it |
| `GetLayout`, `GetProperties`, `SetProperties`, `Publish`, `UnPublish` | Standard surface |

---

## List definitions (session objects)

Create a session object with one of these definitions to enumerate app contents. This is
how the Qlik client itself populates its asset panel.

| Definition | Returns |
|---|---|
| `qFieldListDef` | All fields with cardinality, tags, source tables |
| `qDimensionListDef` | Master dimensions |
| `qMeasureListDef` | Master measures |
| `qVariableListDef` | Variables |
| `qBookmarkListDef` | Bookmarks |
| `qAppObjectListDef` | Sheets, stories — set `qType: "sheet"` |
| `qSelectionObjectDef` | **Current selections** — what is filtered right now |
| `qMediaListDef` | Images in the app |

```json
{"qInfo": {"qType": "MeasureList"},
 "qMeasureListDef": {"qType": "measure",
                     "qData": {"title": "/qMetaDef/title", "expression": "/qMeasure/qDef"}}}
```

The `qData` block pulls arbitrary properties into the list result, which saves a round
trip per item.

---

## Method selection by situation

| Situation | Method |
|---|---|
| Anything is failing | `EngineVersion`, then `GetAuthenticatedUser` |
| Numbers look wrong | `GetTablesAndKeys` (synthetic keys), then `ClearAll`, then re-read |
| Need field names | `CreateSessionObject` + `qFieldListDef` |
| Need one number | `EvaluateEx` |
| Need a small result set | `CreateSessionObject` + `GetHyperCubeData` |
| Need a chart's numbers | `GetObject` + `GetLayout` + `GetHyperCubeData` |
| Need every row of a table | `GetTableData` |
| Editing a chart | `GetProperties` → modify → `SetProperties` → `DoSave` |
| Trying a change safely | `ApplyPatches` with `qSoftPatch: true` |
| Editing a master item | `GetLinkedObjects` first, to see what you will affect |
| Reproducing a user's view | `GetBookmark` + `Apply`, or `GetSetAnalysis` |
| Writing a load script | `GetScript` → edit → `SetScript` → `CheckScriptSyntax` → `DoReloadEx` → `DoSave` |
| Finding real DB table names | `GetDatabaseTables`, `GetDatabaseTableFields` |
| Testing a script safely | `CreateSessionAppFromApp` |
| Building a filter pane | `SetFullPropertyTree` — atomic, versus `CreateChild` per field |
| Exporting data for a user | `ExportData` |
| Long reload to supervise | `DoReloadEx` + `GetProgress` in a loop |
