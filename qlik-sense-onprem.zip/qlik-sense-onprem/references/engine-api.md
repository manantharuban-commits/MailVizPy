# Engine JSON API (QIX) reference

The Engine API is JSON-RPC 2.0 over a WebSocket. It controls everything *inside* an app.

## Contents
- [Protocol basics](#protocol-basics)
- [Handle semantics](#handle-semantics)
- [Global methods (handle -1)](#global-methods-handle--1)
- [Doc methods (app handle)](#doc-methods-app-handle)
- [GenericObject methods](#genericobject-methods)
- [Field and selection methods](#field-and-selection-methods)
- [Reading hypercube data](#reading-hypercube-data)
- [Session objects vs persistent objects](#session-objects-vs-persistent-objects)
- [Ordering rules that matter](#ordering-rules-that-matter)

---

## Protocol basics

Request:
```json
{"jsonrpc": "2.0", "id": 1, "handle": -1, "method": "OpenDoc",
 "params": {"qDocName": "c1f2b0e4-...-9a3d"}}
```

Response:
```json
{"jsonrpc": "2.0", "id": 1, "result": {"qReturn": {"qType": "Doc", "qHandle": 1}}}
```

Errors come back as `{"id": 1, "error": {"code": -32602, "message": "Invalid method"}}`.
Qlik also pushes **unsolicited notifications** (`OnConnected`, `OnAuthenticationInformation`,
and change events with no `id`). A client that assumes the next frame is its answer will
desynchronise; `qlik_client.py` drains these by matching on `id`.

Two conventions worth knowing because they explain confusing payloads:
- Parameters may be sent positionally (array) or by name (object). Always use names.
- Almost every parameter starts with `q`. Properties you invent yourself (chart titles,
  custom settings) do not — and the Engine **stores unknown properties without
  complaint**. That is why a typo produces a blank chart rather than an error.

---

## Handle semantics

A handle is a reference to a live object *within one WebSocket session*:

- `-1` — the Global class. Always available.
- App handle — returned by `OpenDoc` / `CreateApp`.
- Object handles — returned by `GetObject` / `CreateObject`.

Handles die with the socket. They cannot be shared between sockets, cached to disk, or
used concurrently on the same socket. `Invalid handle` almost always means the session
was reconnected, not that the object is gone.

---

## Global methods (handle -1)

| Method | Params | Returns |
|---|---|---|
| `EngineVersion` | — | `{qComponentVersion}` — call first, schemas vary by version |
| `OpenDoc` | `qDocName`, `qNoData` | app handle |
| `CreateApp` | `qAppName`, `qLocalizedScriptMainSection` | `{qAppId}` |
| `GetDocList` | — | array of `{qDocId, qDocName, qMeta}` |
| `CreateSessionApp` | — | in-memory app, discarded on disconnect |
| `AbortRequest` | `qRequestId` | cancels a long reload |
| `GetActiveDoc` | — | currently open app (only in a client context) |
| `ProductVersion` | — | full product version string |

`OpenDoc` with `qNoData: true` opens the app structure without loading data into memory.
Use it whenever you only need to read or write objects and scripts — on a 20 GB app the
difference is minutes and gigabytes of server RAM.

---

## Doc methods (app handle)

### Script and reload
| Method | Params | Notes |
|---|---|---|
| `GetScript` | — | returns the full load script |
| `SetScript` | `qScript` | replaces it entirely; there is no partial edit |
| `CheckScriptSyntax` | — | returns `qErrors[]` with line/column. **Always call before reload** |
| `DoReload` | `qMode`, `qPartial`, `qDebug` | `qMode`: 0 default, 1 error-tolerant, 2 abort on error |
| `DoReloadEx` | same | also returns `{qSuccess, qLog}` — prefer it, the log is the diagnosis |
| `DoSave` | `qFileName` | **persists everything.** Without it, all writes are lost |
| `GetProgress` | `qRequestId` | poll during a long reload |

### Objects
| Method | Params | Notes |
|---|---|---|
| `CreateObject` | `qProp` | persistent; survives save |
| `CreateSessionObject` | `qProp` | transient; ideal for ad-hoc data pulls |
| `GetObject` | `qId` | handle for an existing object |
| `DestroyObject` | `qId` | |
| `GetAllInfos` | — | `[{qId, qType}]` for everything in the app |
| `GetObjects` | `qOptions` | filtered list with metadata (newer versions) |

### Master items
| Method | Params |
|---|---|
| `CreateDimension` / `GetDimension` / `DestroyDimension` | `qProp` / `qId` |
| `CreateMeasure` / `GetMeasure` / `DestroyMeasure` | `qProp` / `qId` |
| `CreateVariableEx` / `GetVariableById` | `qProp` / `qId` |
| `CreateBookmark` / `ApplyBookmark` | `qProp` / `qId` |

### Data model and lineage
| Method | Returns |
|---|---|
| `GetTablesAndKeys` | tables, fields, row counts, key fields, synthetic keys |
| `GetLineage` | `[{qDiscriminator, qStatement}]` — where each table came from |
| `GetFieldDescription` | tags, cardinality for one field |
| `GetAppLayout` | app-level metadata, last reload time |
| `GetAppProperties` / `SetAppProperties` | title, description, thumbnail |

`GetTablesAndKeys` is the fastest way to find a **synthetic key** (`$Syn`) or a circular
reference — both silently distort every number in the app, so check for them before
trusting any figure.

### Expressions
| Method | Notes |
|---|---|
| `Evaluate` | `qExpression` → string result; wraps in an implicit aggregation context |
| `EvaluateEx` | returns typed `{qText, qNumber, qIsNumeric}` |
| `CheckExpression` | validates syntax; returns `qErrorMsg` and `qBadFieldNames` |

`CheckExpression` before creating a chart catches misspelled field names, which is the
main reason generated charts come out empty. `build_dashboard.py` runs it on every
expression in `--dry-run`.

### Data connections
| Method | Notes |
|---|---|
| `GetConnections` | list connections visible to this user |
| `CreateConnection` | `{qName, qConnectionString, qType, qUserName, qPassword}` |
| `ModifyConnection` / `DeleteConnection` | |

---

## GenericObject methods

| Method | Notes |
|---|---|
| `GetLayout` | evaluated state — data, titles, errors. What the user actually sees |
| `GetProperties` | definition — the JSON you would edit |
| `SetProperties` | overwrites the whole definition; read-modify-write, never partial |
| `GetHyperCubeData` | one page of data |
| `GetHyperCubePagesData` | multiple pages |
| `ApplyPatches` | targeted change without a full replace — use with `qSoftPatch: true` for temporary tweaks |
| `CreateChild` | for containers and filter panes (listboxes are children) |
| `GetChildInfos` | list children |
| `ExportData` | server-side CSV/OOXML export; returns a download URL |
| `Publish` / `UnPublish` | move an object between private and public in a published app |

**`GetProperties` vs `GetLayout`** is the distinction people get wrong. Properties contain
`qHyperCubeDef` — the definition you write. Layout contains `qHyperCube` — the evaluated
result including `qSize`, `qDataPages`, and `qError`. To *change* a chart, read
properties. To *check* a chart, read layout.

---

## Field and selection methods

Get a field handle with Doc method `GetField(qFieldName)`.

| Method | Notes |
|---|---|
| `Select` | `qMatch` string, `qSoftLock` |
| `SelectValues` | `[{qText, qIsNumeric, qNumber}]` |
| `SelectAll` / `Clear` / `ClearAllButThis` | |
| `Lock` / `Unlock` | |
| `GetCardinal` | distinct value count |

Doc-level `ClearAll(qLockedAlso)` resets everything. **Do this before reading data for
validation** — a stale selection from an earlier call in the same session silently
filters your results and produces a discrepancy that does not exist in the app.

---

## Reading hypercube data

Data comes in pages. Request a rectangle:

```json
{"handle": 4, "method": "GetHyperCubeData",
 "params": {"qPath": "/qHyperCubeDef",
            "qPages": [{"qTop": 0, "qLeft": 0, "qHeight": 500, "qWidth": 6}]}}
```

The Engine caps a single page at **10,000 cells** (`qHeight × qWidth`). Exceeding it
returns fewer rows without an error, which is how truncated exports happen unnoticed.
Compute page height as `floor(10000 / width)` and loop until you have `qSize.qcy` rows —
`iter_hypercube_rows()` in `qlik_client.py` does this.

Each cell:
```json
{"qText": "1,234", "qNum": 1234, "qElemNumber": 3, "qState": "O"}
```
`qText` is formatted for display; `qNum` is the real value. **Compare on `qNum`.**
`qState`: `S` selected, `O` optional, `X` excluded, `L` locked.

For a **pivot table**, the path is still `/qHyperCubeDef` but the mode is `P` and you must
use `GetHyperCubePivotData`, which returns nested `qLeft`/`qTop` node trees rather than a
flat matrix. For **stacked** charts, mode `K` and `GetHyperCubeStackData`. Flat-mode `S`
is what most charts use.

---

## Session objects vs persistent objects

To read data without leaving anything behind in the app, create a session object:

```json
{"qInfo": {"qType": "quick-query"},
 "qHyperCubeDef": {
   "qDimensions": [{"qDef": {"qFieldDefs": ["Region"]}}],
   "qMeasures": [{"qDef": {"qDef": "Sum(Sales)"}}],
   "qInitialDataFetch": [{"qTop": 0, "qLeft": 0, "qHeight": 500, "qWidth": 2}]}}
```

`CreateSessionObject` → `GetLayout` → read → disconnect. Nothing is saved, no `DoSave`
needed, and the app is untouched. This is the right tool for ad-hoc "what does Qlik say
for X?" questions during QA.

---

## Ordering rules that matter

1. `OpenDoc` before anything app-scoped.
2. `CheckExpression` before `CreateObject` — cheaper than debugging a blank chart.
3. `CheckScriptSyntax` before `DoReload` — instant vs. a ten-minute failed reload.
4. Create master items before the charts that reference them by `qLibraryId`.
5. Create child objects **before** writing the sheet's `cells` array — a cell pointing at
   a non-existent object id renders as a broken tile.
6. `DoSave` last, once. Saving mid-build on a large app is slow and gains nothing.
7. Close the socket cleanly; abandoned sessions hold app memory on the server until they
   time out.
