# Repository Service (QRS) API reference

QRS is the REST API for everything *around* an app: where it lives, who can see it, when
it reloads. It does not touch app contents — that is the Engine's job.

Base URL (direct): `https://server:4242/qrs/`
Base URL (proxy):  `https://server/<vproxy-prefix>/qrs/`

**Every call needs an xrfkey** (16 alphanumeric chars in both the query string and the
`X-Qlik-Xrfkey` header). See `auth-and-connection.md`. `QrsAPI` handles this.

## Contents
- [Smoke test](#smoke-test)
- [Filter syntax](#filter-syntax)
- [Apps](#apps)
- [Streams and publishing](#streams-and-publishing)
- [Reload tasks](#reload-tasks)
- [Data connections](#data-connections)
- [Users and licences](#users-and-licences)
- [App objects (sheets, bookmarks)](#app-objects-sheets-bookmarks)
- [Custom properties and tags](#custom-properties-and-tags)
- [System health](#system-health)

---

## Smoke test

```
GET /qrs/about
```
Returns the build version. No permissions required beyond authentication, so it isolates
"can I reach and authenticate to QRS" from "am I allowed to do this thing". Always the
first call when debugging.

---

## Filter syntax

Append `?filter=<expression>`. Reliable operators:

| Operator | Meaning |
|---|---|
| `eq`, `ne` | equals, not equals |
| `gt`, `ge`, `lt`, `le` | numeric/date comparison |
| `so` | "some of" — for collections like tags |
| `and`, `or`, `not` | logical |

String values are single-quoted. Dotted paths walk relationships:

```
?filter=name eq 'Sales Performance'
?filter=stream.name eq 'Finance' and published eq true
?filter=tags.name so 'Certified'
?filter=modifiedDate gt '2026-01-01T00:00:00.000Z'
```

Two gotchas: filter expressions are **case-sensitive on values**, and unquoted spaces in
the URL must be encoded. `/full` suffix on a collection returns complete objects rather
than id-only stubs — you almost always want it.

---

## Apps

| Call | Purpose |
|---|---|
| `GET /qrs/app/full` | list all visible apps |
| `GET /qrs/app/full?filter=name eq 'X'` | find by name |
| `GET /qrs/app/{id}` | one app |
| `PUT /qrs/app/{id}` | update metadata (send the full object with an incremented `modifiedDate`) |
| `POST /qrs/app/{id}/copy?name=New+Name` | duplicate |
| `DELETE /qrs/app/{id}` | delete |
| `POST /qrs/app/upload?keepdata=true&name=X` | import a `.qvf` (binary body) |
| `POST /qrs/app/{id}/export/{token}` | request export; returns `downloadPath` |
| `POST /qrs/app/{id}/reload` | reload without a task |

The export flow is two-step and the `{token}` is a GUID **you generate**:

```
POST /qrs/app/{appId}/export/{yourGuid}?skipdata=false
  -> { "downloadPath": "/tempcontent/<...>/App.qvf?serverNodeId=..." }
GET  https://server:4242<downloadPath>
```

**Take a `.qvf` export before any bulk modification.** There is no undo in the Engine
API; the export is the rollback.

---

## Streams and publishing

| Call | Purpose |
|---|---|
| `GET /qrs/stream/full` | list streams (you need the stream id to publish) |
| `PUT /qrs/app/{id}/publish?stream={streamId}&name={name}` | publish |
| `POST /qrs/app/{id}/unpublish` | back to personal work area |
| `PUT /qrs/app/{id}/replace?app={targetAppId}` | replace a published app's contents, keeping its id and permissions |

`replace` is the safe production-update pattern: develop in an unpublished copy, then
replace the published app. Users keep their bookmarks and the app URL does not change.
Publishing a fresh copy instead breaks every saved link and dashboard embed pointing at
the old id — the kind of thing that surfaces on Monday morning rather than at deploy time.

Published apps are **read-only for objects**. Engine `CreateObject` against one either
fails or lands the object in the user's private space where nobody else sees it.

---

## Reload tasks

| Call | Purpose |
|---|---|
| `GET /qrs/reloadtask/full` | list tasks |
| `GET /qrs/reloadtask/full?filter=app.name eq 'Sales'` | tasks for one app |
| `POST /qrs/task/{id}/start` | fire and forget |
| `POST /qrs/task/{id}/start/synchronous` | returns immediately with a session id to poll |
| `GET /qrs/executionresult/full?filter=...` | outcome, duration, log path |
| `POST /qrs/task/{id}/stop` | abort |

Prefer triggering the existing QMC task over Engine `DoReload` on anything published: the
task carries the correct service account, logging, and downstream task chain. A direct
`DoReload` bypasses all of it, so the QMC shows a stale "last successful reload" and
dependent tasks never fire.

`status` values on execution results: 0 NeverStarted, 1 Triggered, 2 Started,
3 Queued, 4 AbortInitiated, 5 Aborting, 6 Aborted, 7 **FinishedSuccess**,
8 **FinishedFail**, 9 Skipped, 10 Retry, 11 Error, 12 Reset.

---

## Data connections

| Call | Purpose |
|---|---|
| `GET /qrs/dataconnection/full` | list connections and their `connectionstring` |
| `GET /qrs/dataconnection/full?filter=name eq 'DW_Prod'` | find one |
| `POST /qrs/dataconnection` | create |

This is how you resolve the `lib://` name a load script needs. `LIB CONNECT TO 'DW_Prod'`
fails with a misleading "connection not found" if the name differs by even a space, or if
the connection is owned by another user and not shared — check ownership here before
debugging the script.

Passwords are never returned. They must be set through the QMC or on creation.

---

## Users and licences

| Call | Purpose |
|---|---|
| `GET /qrs/user/full?filter=userId eq 'jsmith'` | find a user |
| `GET /qrs/user/full?filter=userDirectory eq 'MYDOMAIN'` | directory listing |
| `GET /qrs/license/professionalaccesstype/full` | assigned professional licences |
| `GET /qrs/license/useraccesstype/full` | assigned user licences |
| `GET /qrs/systemrule/full` | security rules |

Useful when a user reports "I can't see the app": check they exist, have a licence
allocated, and that a security rule grants read on the stream. Those three cover most
access tickets, and none of them are visible from inside the app.

---

## App objects (sheets, bookmarks)

```
GET /qrs/app/object/full?filter=app.id eq '<appId>' and objectType eq 'sheet'
```

Returns sheet metadata including `published`, `approved`, and `owner`. This is how you
tell a **base sheet** (approved, visible to all) from a **community sheet** (published by
a user, visible to all, not approved) from a **private sheet**. The Engine cannot
distinguish these cleanly; QRS can.

`PUT /qrs/app/object/{id}/approve` promotes a community sheet to a base sheet.

---

## Custom properties and tags

```
GET  /qrs/custompropertydefinition/full
POST /qrs/custompropertydefinition
```

Custom properties drive security rules and task filtering in most enterprise setups (e.g.
a `Department` property that a rule reads to grant stream access). If a governance model
depends on them, set them when creating apps or the app becomes invisible to the intended
audience despite existing correctly.

---

## System health

| Call | Purpose |
|---|---|
| `GET /qrs/servicestatus/full` | per-node service state |
| `GET /qrs/engineservice/full` | engine nodes and health |
| `GET /qrs/schedulerservice/full` | scheduler state |
| `GET /qrs/systeminfo` | version and node layout |

Worth checking before concluding that your code is broken — a failed reload during a node
outage looks identical to a script error from the client side.
