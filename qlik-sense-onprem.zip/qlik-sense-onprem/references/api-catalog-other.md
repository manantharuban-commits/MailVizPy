# The other Qlik APIs

Engine and QRS cover most automation. These are the remaining APIs, what each is
uniquely for, and when reaching for one is the right call rather than a detour.

## Contents
- [Which API for which job](#which-api-for-which-job)
- [Proxy Service API (QPS)](#proxy-service-api-qps)
- [Scheduler Service API (QSS)](#scheduler-service-api-qss)
- [Notification API](#notification-api)
- [App Integration API](#app-integration-api)
- [Capability API (client-side JS)](#capability-api-client-side-js)
- [qlik-embed](#qlik-embed)
- [Extension API](#extension-api)
- [Printing / export](#printing--export)
- [Engine-adjacent SDKs](#engine-adjacent-sdks)
- [What has no API](#what-has-no-api)

---

## Which API for which job

| Job | API |
|---|---|
| Anything inside an app | Engine (QIX) |
| Anything about an app | QRS |
| Log a user in, manage sessions | QPS |
| React to a reload finishing | Notification API |
| Put a Qlik chart in a web page or portal | App Integration API or qlik-embed |
| Build a custom chart type | Extension API |
| Export a sheet to PDF/image | Printing service / `ExportData` |
| Interact with an app from inside a mashup | Capability API |
| Kill a stuck session | QPS |

The frequent mistake is reaching for a client-side API (Capability, qlik-embed) for
server-side automation. Those run in a browser and need a rendered app; server-side work
belongs in Engine and QRS.

---

## Proxy Service API (QPS)

Port `4243`, path `/qps/`. Sessions and tickets.

| Endpoint | Situation |
|---|---|
| `POST /qps/{prefix}/ticket` | Issue a single-use login ticket. Body: `{"UserDirectory","UserId","Attributes":[]}` |
| `GET /qps/{prefix}/session` | List active sessions |
| `GET /qps/{prefix}/session/{sessionId}` | One session |
| `DELETE /qps/{prefix}/session/{sessionId}` | Kill a session |
| `DELETE /qps/{prefix}/user/{userDirectory}/{userId}` | Kill all of a user's sessions |
| `GET /qps/{prefix}/user` | Users with active sessions |

Tickets are **single-use and expire in about 60 seconds**. Request one per session;
caching them produces intermittent 401s that look like a flaky network.

Killing sessions is the practical fix for "a user's licence is stuck allocated" and for
freeing an app that a hung client is holding open.

---

## Scheduler Service API (QSS)

Port `4244`. Mostly internal — trigger tasks through QRS instead. The one thing worth
knowing is that a task stuck in "Started" with no progress usually means the scheduler
lost the engine node, which `GET /qrs/schedulerservice/full` and
`GET /qrs/servicestatus/full` will show.

---

## Notification API

Push instead of polling. Register a callback URL and Qlik POSTs to it on change:

```
POST /qrs/notification?name=ExecutionResult
Body: <your callback URL>
```

Subscribe to `App`, `ExecutionResult`, `ReloadTask`, `User`, `Stream`, and others.
Qlik POSTs `{objectID, objectType, changeType, engineID}` — note it sends the *identity*
of what changed, not the changed data, so you still call QRS to fetch details.

The situation this fits: running a validation suite the moment a nightly reload finishes,
rather than polling every minute or guessing at a cron offset. Your listener needs to be
reachable from the Qlik server, which in a locked-down network is often the blocker.

---

## App Integration API

Embed a sheet or object as an iframe. No JavaScript required.

```
https://server/single/?appid={appId}&sheet={sheetId}&opt=ctxmenu,currsel
https://server/single/?appid={appId}&obj={objectId}&select=Region,North
https://server/sense/app/{appId}/sheet/{sheetId}/state/analysis
```

Query parameters worth knowing: `select=FIELD,value1,value2` pre-applies selections,
`bookmark={id}` restores a saved state, `theme={name}` applies a custom theme, `opt=`
controls chrome (`nointeraction`, `noselections`, `ctxmenu`, `currsel`).

This is the lowest-effort way to surface a Qlik chart in SharePoint, Confluence, or an
internal portal. The viewer still needs a Qlik licence and an authenticated session —
embedding does not bypass licensing, which is the assumption that most often derails an
embedding project late.

---

## Capability API (client-side JS)

Loaded in a browser via RequireJS from the Qlik server:

```javascript
require(['js/qlik'], function(qlik) {
  var app = qlik.openApp('appId', config);
  app.getObject('chartDiv', 'objectId');
  app.field('Region').selectValues([{qText: 'North'}], false, true);
  app.createCube({qDimensions: [...], qMeasures: [...]}, callback);
  app.getList('CurrentSelections', callback);
});
```

Key surfaces: `qlik.openApp`, `app.getObject` (render an existing chart into a div),
`app.visualization.create` (build a chart on the fly), `app.field(...)` (selections),
`app.createCube` / `app.createList` (data without rendering), `app.bookmark`,
`app.variable`, `app.doReload`, `app.getAppLayout`.

Situation: building a mashup — a custom web page composed of Qlik charts with your own
navigation. Not for server-side automation; it needs a browser and a rendered app.

Qlik has been steering new work toward qlik-embed, so treat Capability API as the
established option for existing client-managed mashups rather than the forward-looking
one.

---

## qlik-embed

The newer web-component embedding library:

```html
<qlik-embed ui="analytics/chart" app-id="..." object-id="..."></qlik-embed>
```

Cleaner than the Capability API and does not require RequireJS. Support on
client-managed (on-prem) sites depends on your version — verify against your specific
release before designing around it, and fall back to the App Integration API or
Capability API if it is not available.

---

## Extension API

For building a custom visualization type. An extension is a folder deployed via QRS
`POST /qrs/extension/upload` containing a `.qext` manifest, a JS entry point defining
`definition`, `initialProperties`, and `paint`/`component`, and optional CSS.

Situation: a chart type Qlik does not ship. Before writing one, check
`GET /qrs/extension/full` — the extension you need may already be installed, and in a
bank it very often is.

When generating objects that reference an extension, its properties follow the extension
author's schema, not Qlik's. Read a working instance with `qlik.object.properties` and
copy that shape; nothing else will tell you the correct keys.

---

## Printing / export

Three routes, in increasing order of effort:

1. **Engine `ExportData`** — data out of one object as CSV or OOXML. Server-side, returns
   a download URL. Best for data.
2. **Qlik Reporting / printing service** (`GET /qrs/printingservice/full` to confirm it is
   running) — sheet to PDF or image. Driven through the QMC or Qlik NPrinting rather than
   a clean public REST API on client-managed sites.
3. **Qlik NPrinting** — a separate product with its own REST API for scheduled,
   pixel-perfect, bursted reports.

For your case — HTML email built from BigQuery — none of these is the right path. Pulling
the numbers with Engine `qlik.query` and rendering them yourself gives you full control of
the markup, which a PDF export cannot.

---

## Engine-adjacent SDKs

Wrappers over the same JSON-RPC protocol. Nothing they do is unavailable to the raw
WebSocket client in this skill.

| SDK | Language | Note |
|---|---|---|
| enigma.js | JavaScript/Node | Official, generates a typed API from the Engine schema |
| Qlik Sense .NET SDK | C# | Official, deprecated in favour of enigma.js patterns |
| websocket-client + raw JSON-RPC | Python | What `qlik_client.py` does — no official Python SDK exists |

`enigma.js` ships the Engine API **schema JSON** per version. If you need an
authoritative method list for your exact release, that file is the source of truth — more
reliable than any prose documentation including this catalog.

---

## What has no API

Worth knowing so you do not spend an afternoon looking:

- **Section access reduction cannot be inspected remotely.** You can read the script, but
  the resulting per-user data reduction is only observable by connecting *as* that user.
- **Sheet thumbnails** are generated by the client, not the Engine. Programmatically
  created sheets have no thumbnail until someone opens them.
- **The QMC UI itself** has no API beyond QRS — anything the QMC does, QRS can do, but
  the mapping is not always obvious.
- **Insight Advisor** recommendations are not exposed on client-managed sites.
- **App-level colour themes** are deployed as extensions, not set through an API property.
