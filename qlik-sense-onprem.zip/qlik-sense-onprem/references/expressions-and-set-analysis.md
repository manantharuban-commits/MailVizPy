# Expressions and set analysis

Qlik expressions look like SQL but evaluate against a fundamentally different model.
Getting the model right first makes the syntax obvious; getting it wrong produces
expressions that are syntactically valid and numerically wrong.

## Contents
- [The one idea that explains everything](#the-one-idea-that-explains-everything)
- [Aggregation basics](#aggregation-basics)
- [Set analysis](#set-analysis)
- [The dollar-sign expansion](#the-dollar-sign-expansion)
- [AGGR](#aggr)
- [TOTAL](#total)
- [Conditionals and null handling](#conditionals-and-null-handling)
- [Common patterns](#common-patterns)
- [Debugging an expression](#debugging-an-expression)

---

## The one idea that explains everything

Every Qlik expression evaluates against **the current selection**, and every chart
aggregates within **its own dimensions**. So:

```
Sum(SalesAmount)
```

in a chart dimensioned by Region means "sum of sales for this region, among rows the
user's current selections leave possible". There is no `WHERE` and no `GROUP BY` because
both are implicit: selections are the WHERE, chart dimensions are the GROUP BY.

This is why the same expression yields different numbers in different charts, and why
comparing a Qlik figure against SQL requires reproducing *both* the selection state and
the chart dimensionality. When validating, clear selections first (`ClearAll`) so at
least one of the two variables is pinned.

---

## Aggregation basics

| Qlik | SQL equivalent | Note |
|---|---|---|
| `Sum(X)` | `SUM(X)` | |
| `Count(X)` | `COUNT(X)` | counts non-null |
| `Count(DISTINCT X)` | `COUNT(DISTINCT X)` | |
| `Avg(X)` | `AVG(X)` | |
| `Min(X)` / `Max(X)` | `MIN` / `MAX` | |
| `Only(X)` | — | returns X iff exactly one distinct value remains, else null |
| `Median(X)` | `MEDIAN(X)` | |
| `Sum(Distinct X)` | — | dedupes before summing; rarely what you want |

**A bare field without aggregation is an error inside a chart measure.** `SalesAmount`
alone works only in a dimension. This trips up SQL users constantly.

`Only()` is the honest way to show a value that should be unique — it returns null rather
than silently picking one when the assumption breaks, unlike `Max()`.

---

## Set analysis

Set analysis overrides the current selection for one aggregation. Syntax:

```
Sum( {<Year={2024}, Region={'North','South'}>} SalesAmount )
      ^-------------- set expression --------^ ^-- field --^
```

Three parts, in order: an **identifier**, **operators**, and **modifiers**.

### Identifiers — the starting set

| Identifier | Meaning |
|---|---|
| `$` | current selection (the default when omitted) |
| `1` | the entire dataset, ignoring all selections |
| `$1` | the previous selection (one step back) |
| `Bookmark01` | a saved bookmark's selection |
| `State1` | an alternate state |

```
Sum({1} SalesAmount)              // total sales regardless of what is selected
Sum({$<Year={2024}>} SalesAmount) // current selection, but force Year=2024
```

`{1<...>}` versus `{$<...>}` is the most consequential choice in the whole language: the
first ignores what the user clicked, the second respects it. A "% of total" measure needs
`{1}` in the denominator; a filtered comparison needs `{$}`.

### Modifiers

```
{<Year={2024}>}                        // equals
{<Year={2023,2024}>}                   // in list
{<Year={">=2020<=2024"}>}              // numeric range (note the quotes)
{<Region={'North*'}>}                  // wildcard match
{<Region=>}                            // clear selection on this field
{<Year={$(=Max(Year))}>}               // dynamic: the latest year in the data
{<Product={"=Sum(Sales)>10000"}>}      // search expression, like HAVING
```

### Operators

Applied between the modifier field and its value:

| Operator | Effect |
|---|---|
| `=` | replace the selection on that field |
| `+=` | union — add to it |
| `-=` | exclude |
| `*=` | intersect |

And between whole sets: `{$} + {1<Year={2024}>}`, `{$} - {<Region={'North'}>}`.

```
Sum({<Region-={'Test'}>} SalesAmount)  // everything except the Test region
```

Excluding with `-=` is safer than listing everything you want, because a new value
appearing in the data is included automatically rather than silently dropped.

---

## The dollar-sign expansion

`$(...)` is a **textual substitution evaluated before the expression runs**. It is not a
function.

```
Sum({<Year={$(=Max(Year))}>} SalesAmount)
```

Here `$(=Max(Year))` is computed once, producing e.g. `2026`, and the expression the
Engine actually evaluates is `Sum({<Year={2026}>} SalesAmount)`.

Two consequences:
- It runs in the **chart's outer context**, not per row. `$(=Max(Year))` inside a chart
  dimensioned by Region gives the global max year, not each region's max.
- It cannot be translated to SQL statically, because the substituted text is unknown
  until runtime. `object_to_sql.py` flags these rather than guessing — see
  `object-to-sql.md`.

Variables also expand this way: `$(vLastYear)` inserts the variable's text, and
`$(=vLastYear)` inserts its evaluated result. The difference matters when the variable
contains an expression.

---

## AGGR

`AGGR()` builds a **virtual table** of aggregated values, then lets you aggregate that.
It is Qlik's answer to a nested `GROUP BY`.

```
Avg( Aggr( Sum(SalesAmount), CustomerID ) )
```
= "sum sales per customer, then average those customer totals". In SQL:
```sql
SELECT AVG(t.total) FROM (
  SELECT CustomerID, SUM(SalesAmount) AS total FROM sales GROUP BY CustomerID
) t
```

`AGGR` is why some Qlik measures cannot become a flat SQL query — they need a subquery or
CTE. When you see it, write the SQL by hand rather than trusting a translator.

Common uses: ranking within a group, "average of a per-entity metric", median of an
aggregate, and dimensionality control in complex charts.

---

## TOTAL

`TOTAL` makes an aggregation **ignore the chart's dimensions**:

```
Sum(SalesAmount) / Sum(TOTAL SalesAmount)          // this row's share of the whole
Sum(SalesAmount) / Sum(TOTAL <Region> SalesAmount) // share within its region
```

The `<Region>` qualifier keeps that one dimension while ignoring the rest — equivalent to
a SQL window function with `PARTITION BY Region`. A bare `TOTAL` is `OVER ()`.

---

## Conditionals and null handling

```
If(Sum(Sales) > 1000, 'High', 'Low')
Pick(Match(Status,'A','B','C'), 'Active','Blocked','Closed')   // faster than nested If
Alt(Sales, 0)                                                   // first non-null
Coalesce(a, b, c)                                               // newer versions
NullDisplay / IsNull(X)
RangeSum(A, B)                                                  // nulls treated as 0
```

`Sum(A) + Sum(B)` returns **null if either side is null**; `RangeSum(Sum(A), Sum(B))`
treats null as zero. Silent nulls propagating through additions are a frequent cause of
blank KPIs.

Division by zero returns null, not an error, so a rate measure quietly disappears rather
than failing loudly. Guard it:
```
If(Sum(Cost) > 0, Sum(Margin)/Sum(Cost), 0)
```

---

## Common patterns

**Year over year**
```
Sum({<Year={$(=Max(Year))}>} Sales) / Sum({<Year={$(=Max(Year)-1)}>} Sales) - 1
```

**Rolling 12 months**
```
Sum({<DateKey={">=$(=Date(AddMonths(Max(DateKey),-12)))<=$(=Date(Max(DateKey)))"}>} Sales)
```

**Share of total, respecting filters**
```
Sum(Sales) / Sum(TOTAL Sales)
```

**Share of grand total, ignoring filters**
```
Sum(Sales) / Sum({1} TOTAL Sales)
```

**Count of customers above a threshold**
```
Count({<CustomerID={"=Sum(Sales)>100000"}>} DISTINCT CustomerID)
```

**Exclude a flag without disturbing user selections**
```
Sum({<IsTestRecord-={'Y'}>} Sales)
```

**Rank within dimension**
```
Aggr(Rank(Sum(Sales)), Region)
```

---

## Debugging an expression

1. **`CheckExpression` first.** Engine Doc method; returns `qErrorMsg` and
   `qBadFieldNames`. A misspelled field is the most common failure and this catches it in
   milliseconds.
2. **Strip it down.** Replace the whole thing with `Sum(1)`. If that shows rows, the
   dimension and data are fine and the problem is in the measure.
3. **Remove the set analysis.** If the number appears, the set expression is
   over-restrictive — usually a value that does not exist with that exact spelling or
   case.
4. **Check for a synthetic key.** `GetTablesAndKeys`; a `$Syn` table distorts aggregation
   across the join and no amount of expression fixing helps.
5. **Clear selections.** A leftover selection in the automation session filters
   everything and looks like a broken expression.
6. **Watch for null vs zero.** `qNullSuppression` on the dimension may be hiding the rows
   you expect.

An expression that returns nothing is far more often a data or selection problem than a
syntax problem — Qlik would have refused to save a syntax error.
