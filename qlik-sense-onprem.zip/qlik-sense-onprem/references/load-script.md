# Load script reference

The load script is where Qlik gets its data. It runs top to bottom on reload, pulls from
sources, shapes tables, and leaves a data model in memory.

## Contents
- [Anatomy of a statement](#anatomy-of-a-statement)
- [Data connections](#data-connections)
- [Preceding load](#preceding-load)
- [How tables associate](#how-tables-associate)
- [Joins and concatenation](#joins-and-concatenation)
- [QVD staging](#qvd-staging)
- [Incremental load](#incremental-load)
- [Master calendar](#master-calendar)
- [Variables and control flow](#variables-and-control-flow)
- [Section access](#section-access)
- [Writing scripts programmatically](#writing-scripts-programmatically)

---

## Anatomy of a statement

```qvs
LIB CONNECT TO 'DW_Prod';

Sales:
LOAD
    OrderID,
    CustomerID,
    Date(OrderDate) AS OrderDate,
    SalesAmount,
    SalesAmount - CostAmount AS Margin;
SQL SELECT
    ORDER_ID    AS OrderID,
    CUSTOMER_ID AS CustomerID,
    ORDER_DATE  AS OrderDate,
    AMOUNT      AS SalesAmount,
    COST        AS CostAmount
FROM SALES.FACT_ORDERS
WHERE ORDER_DATE >= '2023-01-01';
```

Reading it correctly matters: `SQL SELECT` runs **on the database**, and the `LOAD` above
it runs **in Qlik** over those results. The semicolon after the LOAD field list (not a
comma) is what binds them. This is a *preceding load*, covered below.

`Sales:` names the resulting table. Without a name, Qlik invents one and your data model
becomes hard to read.

**Push work down to `SQL SELECT` where you can.** Filtering and joining in the database
moves less data over the wire; the Qlik-side `LOAD` should be for shaping, renaming, and
calculations the database cannot do cheaply.

---

## Data connections

On-prem connections are created in the QMC or the data load editor and referenced by
name:

```qvs
LIB CONNECT TO 'DW_Prod';                    // database connection
LOAD * FROM [lib://QVD_Store/Sales.qvd] (qvd);
LOAD * FROM [lib://Landing/report.xlsx]
     (ooxml, embedded labels, table is Sheet1);
```

The name must match **exactly**, including case and spaces. Find real names with:
```
GET /qrs/dataconnection/full
```
A connection owned by another user and not shared produces "connection not found" even
though it is plainly visible in the QMC to an admin — check ownership before rewriting
anything.

Folder connections resolve to a path on the server, not on your machine. `lib://` paths
are the only supported form in a governed environment; absolute paths are usually blocked
by the Standard Mode setting.

---

## Preceding load

A `LOAD` with no `FROM`, sitting above another statement, consumes that statement's
output:

```qvs
LOAD
    *,
    Margin / SalesAmount AS MarginPct;      // can reuse fields from below
LOAD
    OrderID,
    SalesAmount,
    SalesAmount - CostAmount AS Margin;
SQL SELECT ORDER_ID AS OrderID, AMOUNT AS SalesAmount, COST AS CostAmount
FROM SALES.FACT_ORDERS;
```

This is how you build a calculation on top of another calculation in one pass. Without
it, `Margin / SalesAmount` in the same LOAD as `Margin` fails, because a field is not
available in the statement that creates it.

Read preceding loads bottom-up. They chain arbitrarily deep.

---

## How tables associate

Qlik joins tables **automatically on identically-named fields**. No `JOIN` keyword, no
foreign key declaration. `Sales.CustomerID` and `Customers.CustomerID` associate because
they share a name.

Three consequences that cause most data model bugs:

**Rename fields that should not associate.** Two tables both having `Name` or `ID` will
link on it and produce nonsense. Alias them: `LOAD ID AS CustomerID, Name AS CustomerName`.

**Two shared fields between the same pair of tables creates a synthetic key** (`$Syn`).
Qlik builds a hidden composite-key table, aggregations spread across it unpredictably, and
every number in the app becomes suspect. Fix by renaming one field or creating an explicit
composite key:
```qvs
LOAD CustomerID & '|' & ProductID AS %CustomerProductKey, ...
```

**Circular references** (three or more tables forming a loop) make Qlik mark one table as
"loosely coupled", which silently disables its associations. `GetTablesAndKeys` reports
both problems — check it before debugging expressions.

Prefixing key fields with `%` is a widely-used convention that keeps them out of the
user-facing field list while staying obvious in the data model.

---

## Joins and concatenation

```qvs
LEFT JOIN (Sales) LOAD CustomerID, Segment FROM ...;   // widen Sales with a column
CONCATENATE (Sales) LOAD ... FROM ...;                 // stack more rows onto Sales
NOCONCATENATE LOAD ...;                                // force a separate table
```

Qlik **auto-concatenates** two tables with identical field sets, which is convenient until
it merges two things you meant to keep apart. `NOCONCATENATE` is the guard.

`JOIN` physically merges tables at load time and destroys the association. Prefer letting
Qlik associate unless you specifically need denormalisation — joining a fact to a
dimension multiplies rows and inflates every `Sum()` on that fact.

`APPLYMAP` is usually better than a join for adding one column:
```qvs
CustomerMap:
MAPPING LOAD CustomerID, Segment FROM ...;

Sales:
LOAD *, ApplyMap('CustomerMap', CustomerID, 'Unknown') AS Segment
FROM ...;
```
It cannot multiply rows, which makes it safe by construction.

---

## QVD staging

QVDs are Qlik's native columnar files. The standard three-layer pattern:

```qvs
// --- Extract layer: source -> QVD, no transformation ---
LIB CONNECT TO 'DW_Prod';
Orders:
LOAD *;
SQL SELECT * FROM SALES.FACT_ORDERS;
STORE Orders INTO [lib://QVD_Store/Orders.qvd] (qvd);
DROP TABLE Orders;

// --- Transform layer: QVD -> shaped QVD ---
Orders:
LOAD OrderID, CustomerID, Date(OrderDate) AS OrderDate, Amount
FROM [lib://QVD_Store/Orders.qvd] (qvd);
STORE Orders INTO [lib://QVD_Store/Orders_Clean.qvd] (qvd);
```

Reading a QVD with a `LOAD` whose field list exactly matches the QVD's, with no
transformation and no `WHERE` (other than `EXISTS`), triggers an **optimised load** —
often 10× faster. Any calculated field breaks the optimisation. Worth designing for on
large tables.

---

## Incremental load

Reload only what changed, then merge with history:

```qvs
LET vLastReload = Date(Peek('MaxDate', 0, 'LastLoad'), 'YYYY-MM-DD');

// New and changed rows only
IncrementalOrders:
LOAD *;
SQL SELECT * FROM SALES.FACT_ORDERS
WHERE MODIFIED_DATE >= '$(vLastReload)';

// Everything else from the QVD, excluding keys we just reloaded
CONCATENATE (IncrementalOrders)
LOAD * FROM [lib://QVD_Store/Orders.qvd] (qvd)
WHERE NOT EXISTS(OrderID);

STORE IncrementalOrders INTO [lib://QVD_Store/Orders.qvd] (qvd);
```

`NOT EXISTS(OrderID)` is the deduplication: it keeps historic rows whose key was not in
the incremental batch. Order matters — the incremental load must come first so its keys
are already in memory.

This pattern does not handle **hard deletes** in the source. If rows can be deleted, also
pull the current key list and inner-join against it, or the app keeps showing records that
no longer exist.

---

## Master calendar

Almost every app needs one. Generate it rather than sourcing it:

```qvs
TempDates:
LOAD MIN(OrderDate) AS MinDate, MAX(OrderDate) AS MaxDate RESIDENT Sales;

LET vMinDate = Num(Peek('MinDate', 0, 'TempDates'));
LET vMaxDate = Num(Peek('MaxDate', 0, 'TempDates'));
DROP TABLE TempDates;

Calendar:
LOAD
    TempDate AS OrderDate,
    Year(TempDate)                AS Year,
    Month(TempDate)               AS Month,
    Day(TempDate)                 AS Day,
    'Q' & Ceil(Month(TempDate)/3) AS Quarter,
    Date(MonthStart(TempDate), 'MMM-YYYY') AS MonthYear,
    WeekDay(TempDate)             AS WeekDay,
    Week(TempDate)                AS Week
;
LOAD Date($(vMinDate) + IterNo() - 1) AS TempDate
AUTOGENERATE 1
WHILE $(vMinDate) + IterNo() - 1 <= $(vMaxDate);
```

Note the field is aliased back to `OrderDate` so it associates with the fact table. For an
Indian fiscal year (April–March), add:
```qvs
    Year(AddMonths(TempDate, -3))                        AS FiscalYear,
    'Q' & Ceil(Month(AddMonths(TempDate, -3))/3)         AS FiscalQuarter,
```

---

## Variables and control flow

```qvs
SET vPath = 'lib://QVD_Store/';      // literal assignment
LET vToday = Date(Today(), 'YYYY-MM-DD');  // evaluated assignment

FOR EACH vFile IN FileList('$(vPath)*.qvd')
    LOAD * FROM [$(vFile)] (qvd);
NEXT

IF '$(vEnvironment)' = 'PROD' THEN
    LIB CONNECT TO 'DW_Prod';
ELSE
    LIB CONNECT TO 'DW_Test';
END IF

TRACE Loading orders for $(vToday);   // writes to the reload log
EXIT SCRIPT WHEN vRowCount = 0;
```

`SET` stores text verbatim; `LET` evaluates first. Mixing them up is a standard source of
`$(vDate)` expanding to `Today()` instead of a date.

`TRACE` output lands in the reload log and is the main debugging tool for a script that
runs on a server you cannot watch interactively.

---

## Section access

Row-level security lives in the script:

```qvs
Section Access;
LOAD * INLINE [
    ACCESS, USERID,          REDUCTION
    ADMIN,  MYDOMAIN\admin,  *
    USER,   MYDOMAIN\jsmith, NORTH
    USER,   MYDOMAIN\apatel, SOUTH
];
Section Application;

Regions:
LOAD * INLINE [
    REDUCTION, Region
    NORTH,     North
    SOUTH,     South
];
```

Field names in the section access table must be **UPPERCASE**, and `USERID` values must
match the `UserDirectory\UserId` Qlik sees.

For automation this has a direct implication: **the identity you connect as changes the
numbers you get back**. Validating as `INTERNAL\sa_repository` against a business user's
view will show discrepancies that are section access working correctly. Impersonate the
real user when validating what that user sees.

Get section access wrong and you can lock everyone out of the app including yourself —
always keep an admin row, and test on a copy.

---

## Writing scripts programmatically

```python
with EngineAPI(cfg, app_id) as eng:
    doc = eng.open_doc(app_id, no_data=True)
    script = eng.get_script(doc)              # always read before you write
    eng.set_script(doc, new_script)

    errors = eng.call(doc, "CheckScriptSyntax")["qErrors"]
    if errors:
        raise SystemExit(errors)              # stop before a doomed reload

    eng.do_reload(doc)
    eng.do_save(doc)
```

`SetScript` **replaces the entire script**. There is no partial edit, so read-modify-write
is mandatory, and keeping a copy of the original is the only rollback you have.

Qlik scripts use `///$tab TabName` comments to mark editor tabs:
```qvs
///$tab Main
SET ThousandSep=',';
///$tab Extract
LIB CONNECT TO 'DW_Prod';
```
Preserve these when rewriting or the user's script collapses into one unreadable tab.
