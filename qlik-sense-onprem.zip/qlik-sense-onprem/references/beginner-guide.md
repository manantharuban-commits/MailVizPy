# Teaching Qlik Sense to a beginner

Use this to answer "how does Qlik work?" questions. It is arranged as a progression, with
the specific misconceptions that trip up people arriving from SQL or Power BI called out,
because those are what actually cost them time.

**Teach through their real task.** Someone asking how set analysis works while building a
sales dashboard learns it far better from their own `Sum({<Year={2024}>} Sales)` than from
an abstract example. Build the thing they asked for and explain each concept as it comes up.

**Calibrate.** A SQL developer needs the associative-model section and can skim the rest.
Someone new to BI needs the whole arc. Ask what they already use before choosing depth.

## Contents
- [1. The associative model](#1-the-associative-model)
- [2. Where things live](#2-where-things-live)
- [3. The load script](#3-the-load-script)
- [4. The data model](#4-the-data-model)
- [5. Expressions](#5-expressions)
- [6. Set analysis](#6-set-analysis)
- [7. Sheets and charts](#7-sheets-and-charts)
- [8. Master items](#8-master-items)
- [9. Publishing](#9-publishing)
- [Coming from SQL](#coming-from-sql)
- [Coming from Power BI](#coming-from-power-bi)
- [First-week checklist](#first-week-checklist)

---

## 1. The associative model

This is the one concept that makes everything else make sense.

In a SQL tool you ask a question and get an answer. In Qlik, the entire dataset is held in
memory, and clicking a value **splits every other field into three states**:

- **Green** — selected
- **White** — still possible given your selection
- **Grey** — excluded by your selection

That grey is the point. Select region "North" and the product list still shows products
that North *never bought* — greyed out. A `WHERE region='North'` query would simply omit
them, and you would never learn they exist. Qlik shows you the absence.

This is why there is no `WHERE` clause in Qlik expressions: your selections *are* the
WHERE, applied everywhere at once.

---

## 2. Where things live

| Place | What it is |
|---|---|
| **Hub** | The landing page. Streams and apps you can open |
| **App** | One self-contained analysis: data + script + sheets |
| **Sheet** | One page of charts inside an app |
| **Data load editor** | Where the load script lives |
| **Data model viewer** | Diagram of tables and their links |
| **QMC** | Admin console: users, licences, tasks, connections, security |
| **Stream** | A folder in the hub with access rules attached |

An app is the unit of everything — sharing, reloading, permissions. Two dashboards over
the same data can be one app with two sheets, or two apps. One app is usually right;
duplicating data across apps means reloading it twice and them drifting apart.

---

## 3. The load script

Runs on reload, pulls data in, shapes it. Read `load-script.md` for depth. The minimum
you need on day one:

```qvs
LIB CONNECT TO 'MyDatabase';

Sales:
LOAD
    OrderID,
    CustomerID,
    Date(OrderDate) AS OrderDate,
    Amount;
SQL SELECT ORDER_ID AS OrderID, CUSTOMER_ID AS CustomerID,
           ORDER_DATE AS OrderDate, AMOUNT AS Amount
FROM SALES.ORDERS;
```

`SQL SELECT` runs on the database. The `LOAD` above it runs in Qlik on those results.
`Sales:` names the table.

Reload = re-run the whole script. Data in the app is a **snapshot**, not live. If a number
looks stale, check when the app last reloaded before checking anything else.

---

## 4. The data model

Qlik links tables **automatically on identically-named fields**. No JOIN, no relationship
editor.

`Sales.CustomerID` and `Customers.CustomerID` link because the names match. This is
elegant and it is also the main source of beginner data bugs:

- Fields you did **not** mean to link will link if they share a name. Two tables each with
  a `Name` column will associate on it and produce nonsense. Rename them.
- Two shared fields between the same pair of tables creates a **synthetic key** (`$Syn`),
  and numbers become unreliable everywhere.
- Three or more tables forming a loop creates a **circular reference**, and Qlik silently
  disables part of it.

Open the **data model viewer** after every script change for the first few weeks. A clean
star — one fact table in the middle, dimensions around it — is what you want. Anything
labelled `$Syn` needs fixing before you build a single chart on top of it.

---

## 5. Expressions

Chart measures must be aggregated. A bare field is an error.

```
Sum(Amount)
Count(DISTINCT OrderID)
Avg(Amount)
Sum(Amount) / Count(DISTINCT OrderID)
```

There is no `GROUP BY` — the chart's dimensions supply it. Put `Region` as the dimension
and `Sum(Amount)` as the measure and you have `SELECT Region, SUM(Amount) ... GROUP BY
Region`, without writing either clause.

The corollary: **the same expression gives different numbers in different charts**,
because dimensionality differs. That is a feature, but it surprises people who expect a
measure to be a fixed value.

---

## 6. Set analysis

The way to override selections for one measure. Compare this year to last year, in a chart
where the user has selected this year:

```
Sum(Amount)                                   // respects selections
Sum({<Year={2025}>} Amount)                   // forces Year=2025
Sum({1} Amount)                               // ignores ALL selections
Sum({<Region=>} Amount)                       // clears the Region selection only
```

The braces hold a set expression. `$` means the current selection (the default), `1` means
everything.

Learn `{<Field={value}>}` first and stop there. It covers most real needs, and the rest of
the syntax makes more sense once you have used it. `expressions-and-set-analysis.md` has
the full picture when they are ready.

---

## 7. Sheets and charts

Sheets are a 24 × 12 grid. Drag a chart, give it dimensions and measures.

Chart selection, honestly: bar for comparing categories, line for time, KPI for a single
headline number, table for detail, filter pane for selectors. Pie only for a handful of
categories that sum to a meaningful whole. Most dashboards need four chart types, not
fourteen.

A layout that works: KPI strip across the top, filters below it, two or three charts in
the middle, a detail table at the bottom. Anything more on one sheet is usually a second
sheet.

---

## 8. Master items

Define a dimension or measure **once** in the library, then reuse it in every chart.

Worth doing from the start, not as cleanup later. When "Total Sales" needs to exclude
returns, you change one definition instead of finding it in eleven charts and missing two.
Master items also appear in the asset panel, so other people build on your definitions
instead of writing their own slightly-different version.

---

## 9. Publishing

Apps start in your personal work area, private. Publishing moves an app to a **stream**,
where access is controlled by security rules in the QMC.

The catch that surprises everyone: **a published app is read-only for objects**. You
cannot edit its sheets. The workflow is to keep an unpublished development copy, make
changes there, and use QRS `replace` to update the published app in place — which
preserves its id, so existing links and bookmarks keep working.

Sheets in a published app come in three flavours: **base** (from the original app, visible
to all), **community** (published by a user, visible to all), and **private**. A sheet you
create in a published app lands in your private space, which is why "I made a sheet and
nobody can see it" is such a common complaint.

---

## Coming from SQL

| You expect | In Qlik |
|---|---|
| `WHERE` | User selections, or set analysis |
| `GROUP BY` | The chart's dimensions |
| `JOIN` | Automatic on matching field names |
| `HAVING` | A search expression in set analysis: `{<Cust={"=Sum(Sales)>1000"}>}` |
| Nested `GROUP BY` | `AGGR()` |
| Window functions | `TOTAL`, `Above()`, `Rank()` |
| A query returns rows | The whole dataset is in memory; charts are views over it |

Biggest adjustment: you stop writing queries. You shape data once in the load script, then
express *what* to measure and let selections determine *which rows*.

Second biggest: automatic joins by field name. In SQL, joining is explicit and safe by
default. In Qlik, it is implicit and you must actively rename fields to *prevent* joins.

---

## Coming from Power BI

| Power BI | Qlik |
|---|---|
| Power Query (M) | Load script (QVS) |
| DAX measures | Qlik expressions |
| `CALCULATE(SUM(x), Year=2024)` | `Sum({<Year={2024}>} x)` |
| Relationships defined in model view | Automatic on field name |
| Filter context | Selection state |
| Workspace / App | Stream / App |
| Dataset refresh | Reload task |

Set analysis maps closely to `CALCULATE`. The genuine difference is the **grey state** —
Power BI filters excluded values out of view, Qlik keeps showing them as excluded. Once
that clicks, the rest is mostly vocabulary.

---

## First-week checklist

1. Load one table. Confirm rows appear in a table chart.
2. Load a second table sharing one field. Open the data model viewer and see the link.
3. Confirm there is no `$Syn` table. If there is, rename a field until it goes away.
4. Build one bar chart: one dimension, one measure.
5. Add a filter pane and watch the grey states.
6. Turn the measure into a master measure and reuse it in a KPI.
7. Write one set analysis expression comparing two years.
8. Add a master calendar so date filtering works properly.
9. Publish to a test stream and open it as a different user.

Steps 3 and 8 are the ones people skip and regret. A synthetic key quietly corrupts every
number, and without a calendar table every date question becomes painful.
