# pptx2py

PowerPoint → python-pptx code, and code → PowerPoint. The code contains no XML. It comes with a desktop app (PySide6) and a command line.

It reads PowerPoint 2007–365 decks (.pptx), decks with macros (.pptm), templates (.potx, .potm), slide shows (.ppsx, .ppsm) and old PowerPoint 97–2003 files (.ppt, see *File formats*).

```
pip install -r requirements.txt     # python-pptx 1.0+, plus PySide6 for the app (Python 3.9+)
python -m pptx2py                   # open the desktop app
```

On Windows you can also double-click `pptx2py_app.pyw`. The command line needs only python-pptx.

## Desktop app

The window has three parts: the deck's slides on the left, the code in the middle, and the conversion settings on the right. It follows your system's light or dark theme, and Ctrl+Shift+L switches between them.

| Area | What it does |
|---|---|
| **Slides** | Draws a wireframe of every slide from where its shapes sit, with shape colours, pictures, tables, charts and SmartArt. Click a slide to jump to its `def slideN` in the code. Ctrl or Shift-click selects more. Double-click converts just that slide. Hidden slides are dimmed. |
| **Slides to convert** | Choose **All**, **Selected** or **Numbers** (such as `3` or `1,4-6`). The button names what it will do, for example "Convert 3 slides". |
| **Start from** | **Deck template** gives an exact look and saves `<deck>_template.pptx` with the code. **Blank deck** starts from `Presentation()` and needs no template file. |
| **Code style** | **python-pptx** writes ordinary python-pptx statements. **Compact** writes one short call per shape. See below. |
| **Keep what python-pptx can't do** | On: shadows, transparency, arrowheads, bullets and the like come from named functions in `pptx_helpers`. Off: the code uses python-pptx commands only, and those details are left out and listed at the top. |
| **More options** | **Embed pictures and template** makes one self-contained file. You can also turn speaker notes and effects on or off. |
| **Paste / Open** | Pastes the clipboard over the code (Ctrl+Z brings the old code back) or opens a .py file. Any python-pptx script works, not only generated ones. |
| **Copy / Save** | Copies the code, or saves it as a .py or .zip. Saving also writes the files the code needs: the template, `assets/` pictures and `pptx_helpers.py`. |
| **Build PowerPoint (F5)** | Runs the code and saves the deck. Afterwards you can **Open** it or **Show in folder**. If the code fails, a message gives the line, with **Go to line** and the full error under **Output**. |
| **Check against original** | Shown after building code that was converted from the open deck. It compares the new deck with the original, shape by shape, and lists every difference under **Output** (see *Checking the result* below). |

You can drop a deck (.pptx, .ppt, .potx ...) or a .py file anywhere on the window to open it.

Shortcuts:

| Key | Action |
|---|---|
| Ctrl+O | Open deck |
| Ctrl+Shift+O | Open .py |
| Ctrl+Enter | Convert |
| F5 | Build |
| Ctrl+S / Ctrl+Shift+S | Save .py / .zip |
| Ctrl+Shift+C | Copy |
| Ctrl+Shift+V | Paste |
| Ctrl+F | Find |
| Ctrl+` | Output |
| Esc | Close the find bar or message |

Settings, the theme and the window layout are remembered between sessions.

## Command line

```
python -m pptx2py deck.pptx                      # -> deck_py/deck.py + deck_template.pptx + assets/
python -m pptx2py deck.pptx -s 2,5-7 -o out      # selected slides
python -m pptx2py deck.pptx --pure               # python-pptx commands only, nothing from pptx_helpers
python -m pptx2py deck.pptx --compact            # the short style: box(), pic() ... from pptx_helpers.py
python -m pptx2py deck.pptx --blank              # no template file: starts from Presentation()
python -m pptx2py deck.pptx --embed              # one self-contained .py
python -m pptx2py deck.pptx --verify             # also build it and compare with the deck, shape by shape
python -m pptx2py deck.pptx --list               # list slides
python -m pptx2py --run deck_py/deck.py out.pptx # code -> PowerPoint
python -m pptx2py --gui deck.pptx               # open a deck in the desktop app
```

From Python:

```python
from pptx2py import convert, run_code
r = convert('deck.pptx', slides=[1, 3])            # style='plain' | 'compact', extras=True | False
r.code, r.files                                     # the script, and {file name: bytes} it needs
r.skipped, r.notes                                  # what was left out, and what is converted with a difference

from pptx2py.verify import compare
print(compare('deck.pptx', 'deck_rebuilt.pptx', r.slides, known=r.skipped + r.notes).text())
```

## Running the generated code

```
python deck.py               # builds deck_rebuilt.pptx and prints where it saved it
python deck.py out.pptx      # or a name of your own
```

- Keep the files the script was saved with in one folder: the script, `<deck>_template.pptx`, `assets/` and `pptx_helpers.py`. **Save (.zip)** in the app writes them all. For a single file, turn on **Embed pictures and template**.
- The script also runs pasted into a notebook or an IDE: it finds its files in the current folder.
- It needs Python 3.9 or newer and python-pptx 0.6.22 or newer. The converter and the app need python-pptx 1.0 or newer.
- If a build stops, the app and `--run` say why and what to do: a missing file, or python-pptx not installed or too old.

## What the generated code looks like

### python-pptx style (default)

```python
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.util import Inches, Pt

from pptx_helpers import arrows, effects  # what python-pptx has no command for


def font3(f):                                   # formatting used more than once becomes a function
    f.bold = True
    f.size = Pt(14)
    f.name = 'Arial'
    f.color.rgb = RGBColor.from_string('000000')


def slide6(prs):
    s = prs.slides.add_slide(prs.slide_layouts.get_by_name('Title Only'))
    tf = s.placeholders[0].text_frame
    tf.text = 'Order Approval Process'
    sh = s.shapes.add_shape(MSO_SHAPE.FLOWCHART_TERMINATOR, Inches(0.2), Inches(3), Inches(1.6), Inches(1.1))
    sh.fill.solid()
    sh.fill.fore_color.rgb = RGBColor.from_string('FFFF99')
    sh.line.color.rgb = RGBColor.from_string('000000')
    effects(sh, shadow={'c': '000000/35', 'blur': 3.15, 'dist': 1.81, 'dir': 90})
    tf = sh.text_frame
    tf.text = 'Request'
    font3(tf.paragraphs[0].runs[0].font)
    c = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(1.8), Inches(3.55), Inches(2.15), Inches(3.55))
    arrows(c.line, None, 'stealth')
```

Free-form outlines become `shapes.build_freeform()` with line segments. Curves are traced as short straight segments, because python-pptx's freeform builder draws straight lines only.

python-pptx has no command for some things, so `pptx_helpers` supplies these functions:

| Area | Functions |
|---|---|
| Shapes | `effects` (shadow, glow, soft edges, reflection), `three_d` (3-D rotation, depth, bevels), `mirror` (flip), `preset` (outlines python-pptx has no name for, connector bends), `group_box` (the box a turned or flipped group turns about), `outline` (free-form outlines that reach outside their box), `hide`, `to_front` (a placeholder above shapes made before it: python-pptx makes placeholders first) |
| Colours and fills | `opacity` (transparency), `gradient` (three or more colours, radial), `picture_fill`, `picture_back` (fill behind a picture), `picture_effects`, `picture_background` |
| Lines and flowcharts | `arrows`, `glue` (connector ends attached to shapes, where python-pptx's `begin_connect()` would move them) |
| Text | `bullet` (characters, numbering styles and start numbers), `indent`, `empty_line`, `font_extras` (caps, spacing, superscript, strike, highlight), `text_direction`, `text_columns`, `autofit`, `field` (slide number, date) |
| WordArt | `text_warp` (text bent to a shape), `text_outline`, `text_effects` (shadow, glow, reflection on letters) |
| Tables | `cell_border`, `cell_direction` (vertical text), `table_style` |
| Charts | `combo_chart` (several chart types, second value axis), `series_labels` (labels per series, XY charts), `chart_area` (chart and plot area fill and border), `chart_3d` (3-D column, bar, pie and area charts, cylinders, cones and pyramids), `plot_layout` (plot area placed by hand), `pie_explode` (slices pulled out), `doughnut_hole` |
| SmartArt | `smartart` (SmartArt saved without its drawing, copied as it is; PowerPoint lays it out when the deck opens) |
| Slides | `transition`, `animate` (entrance, emphasis, exit, motion paths, triggers), `click_jump` (next / previous slide ...), `links` (clicks that jump to a slide, in the compact style), `hide_slide`, `hide_layout_graphics`, `set_theme`, `add_any_picture` (EMF, WMF, PDF, PICT, TIFF and other pictures Pillow cannot read) |

Each one takes plain Python values. With `--pure` (or the switch off in the app), these are not used and the script lists what was left out.

### Compact style

```python
from pptx_helpers import *

ST3 = dict(b=1, sz=36, f='Arial Black', c='1F497D')        # formatting shared by several shapes

def slide6(prs):
    s = add(prs, 'Title Only')                              # layout by name
    ph(s, 0, 'Order Approval Process', **ST3)               # fill a placeholder
    box(s, 0.2, 3, 1.6, 1.1, 'Request', shape='flowChartTerminator', **ST2)
    con(s, 1.8, 3.55, 2.15, 3.55, **ST4)
    pic(s, 'assets/img1.png', 7.2, 4.9, 2.4, 1.6, line='000000', lw=4)
```

Conventions for the compact style:

- Positions and sizes are in inches. Font sizes and line widths are in points.
- Colours are `'RRGGBB'` or theme names (`'accent1'`, `'tx1'`). Add `'+40'` for lighter, `'-25'` for darker, and `'/50'` for 50 % opacity.
- Text is `'line 1\nline 2'`, or a list of paragraphs. A paragraph can be `'text'`, a list of runs `[('bold ', {'b': 1}), 'plain']`, or `{'t': ..., 'align': 'c', 'bul': '•'}`.
- Effects are dicts, such as `fx={'shadow': {...}}`. Free-form outlines are path strings, such as `geom='10000 4032 M0 0 C3673 1670 7345 3340 10000 4032'`.

The compact helpers are:

- `add` (new slide)
- `ph` (placeholder)
- `box` (text box or preset shape)
- `pic`
- `con` (line)
- `grp` (group)
- `tbl` (table, with cell styles for all cells `'*'`, a row `'r0'`, a column `'c1'` or a cell `(r, c)`)
- `chart`
- `bg` (background)
- `notes`

## What converts

Text with full formatting, bullets, levels and fields; preset and free-form shapes; gradient, pattern and picture fills; shadows, glows, reflections, soft edges and 3-D; WordArt (bent text, outlined and gradient letters). Also:

- pictures, including cropping, transparency, recolouring, EMF/WMF, PDF and Mac PICT
- groups, including turned and flipped groups, and hidden shapes
- connectors, with their ends attached to the shapes they join (flowcharts keep working when shapes move)
- tables, with merged cells, borders, cell fills and vertical text
- charts: bar, column, line, pie, doughnut, area, scatter, bubble and radar, flat or 3-D (columns, bars, pies, areas, also as cylinders, cones and pyramids); combo charts with a second value axis; two-level categories; series and point colours and gradients, exploded slices, data labels, axis titles, number formats and steps; fonts of the title, legend and axes; axis and gridline colours; chart and plot area fills and a plot area placed by hand
- slide transitions (including PowerPoint 2010+ ones such as Vortex and Morph) and animations: entrance, emphasis, exit, motion paths, timing, triggers, by paragraph
- videos (with their poster picture), web links and clicks that jump to slides
- backgrounds, speaker notes, hidden slides, multiple masters and colour maps
- SmartArt, as the shapes it is drawn with (SmartArt saved without them is copied as it is)
- the stacking order of shapes, placeholders included
- OLE objects and ActiveX controls, as their preview pictures

## What python-pptx cannot create

The converter never drops anything silently. Every item it leaves out or draws another way is listed at the top of the script, in the app's message bar and **Output**, and by the command line, with the slide, the shape's name and the reason. For example:

```
# Left out (python-pptx cannot create these):
#   slide 7: 2 comments, left out (python-pptx cannot add comments)
#   slide 8: Object 3: an embedded MathType Equation object (OLE) without a preview picture, left out (python-pptx
#       cannot create it)
# Converted, but not exactly like the original:
#   slide 2: Chart 4: a 3-D line chart, drawn flat (python-pptx makes flat charts only)
#   slide 9: MyChart: an Office 2016 chart (waterfall, funnel, treemap ...): python-pptx cannot create it, so the
#       picture PowerPoint saved with it is used
```

| Item | What happens |
|---|---|
| 3-D line charts | drawn flat (3-D column, bar, pie and area charts are 3-D with the extras on, flat without) |
| Surface and stock charts | left out |
| Office 2016 charts (waterfall, funnel, treemap, sunburst, box and whisker, map), equations, 3-D models | the picture PowerPoint saved with them is used |
| OLE objects, ActiveX controls | shown as their preview picture; an object with no preview picture is left out and listed with the program it belongs to (Excel, Word, MathType Equation ...) |
| SmartArt saved without its drawing (Office templates, decks made by some other programs) | copied as it is with `smartart()`, and PowerPoint lays it out when it opens the deck; without the extras, its text is kept as a list in its place |
| Sounds, ink, comments, sections, custom shows, macros on clicks | left out |
| Linked (not embedded) videos | their picture is kept |
| Damaged files and Strict Open XML files | repaired in memory and converted; the repair is listed |
| Macros (.pptm, .potm, .ppsm) | left out: a .pptx cannot carry them; the script says so |
| Password-protected decks (.pptx or .ppt) | not converted: a message says to remove the password in PowerPoint (File > Info > Protect Presentation) first |

## File formats

| File | How it is read |
|---|---|
| .pptx (PowerPoint 2007–365, also Strict Open XML) | directly |
| .pptm, .potx, .potm, .ppsx, .ppsm | as an ordinary presentation; the rebuilt deck is a .pptx, macros are left out |
| .ppt (PowerPoint 97–2003) | converted to .pptx first, by PowerPoint (Windows, if installed) or LibreOffice (`soffice` on the PATH or in its usual folder), then read as a .pptx. With neither, a message says to save it as .pptx in PowerPoint. If they cannot open it either, the message says so. |

A .ppt converted by LibreOffice can lose the preview pictures of embedded objects (equations, Word or Excel objects); those are listed. Saving the .ppt as .pptx in PowerPoint keeps them.

## Checking the result

`compare()` (the app's **Check against original**, the command line's `--verify`) checks the rebuilt deck against the original without PowerPoint: the position, size, rotation and flip of every shape (lines by their two ends), text, paragraph alignment and indents, character formatting, fills and lines with theme colours resolved, pictures and cropping, table cells, chart types and data, click links, slide layouts, transitions, animations and speaker notes. Differences the converter already listed are marked as such, so what remains is what needs a look.

## Testing

Every deck below was converted, built from the code and compared with its original, in all three ways of writing the code (python-pptx style, compact, blank deck):

| Set | Decks | Result |
|---|---|---|
| Sample decks (python-pptx, LibreOffice and Apache POI test files, real-world decks) | 632 (1,074 slides) | all convert, build and match their original apart from the items the converter lists |
| Recent samples from the Open XML SDK, Apache POI, Aspose, Syncfusion, ShapeCrawler, LibreOffice and OnlyOffice repositories: saved by PowerPoint 2007, 2010, 2013 and 2016–365 (Windows and Mac) and by other programs; 680 .pptx, 46 .potx, 10 .pptm, 4 .ppsx, 2 .ppsm, 1 .potm | 743 (2,287 slides, 9,301 shapes) | 724 convert, build and match. 19 stop with a message: password-protected, damaged or deliberately broken (fuzzing) files |
| PowerPoint 97–2003 files (.ppt), through LibreOffice | 145 (1,151 slides) | 120 convert, build and match; the 170 items listed are mostly embedded objects whose pictures LibreOffice drops. 25 stop with a message: 11 password-protected, 14 that LibreOffice cannot open (damaged or fuzzing files) |

Rendered side by side, 36 of the recent decks with charts (3-D, combo, error bars), SmartArt, animations, video, tables, turned groups, glued connectors, WordArt and cropped pictures average 99.6 % pixel similarity per slide.

Scripts for 21 of these decks (charts, SmartArt, .ppt, templates), written in all five ways (python-pptx style, without extras, compact, blank deck, one self-contained file), were also run with Python 3.9, 3.10 and 3.11 and python-pptx 0.6.21, 0.6.23 and 1.0.2: all 420 builds succeed.
