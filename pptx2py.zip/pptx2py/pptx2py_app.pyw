"""Double-click to open the pptx2py desktop app (or run: python -m pptx2py)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pptx2py.gui import main  # noqa: E402

main(*sys.argv[1:2])
