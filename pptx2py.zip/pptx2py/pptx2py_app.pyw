"""Double-click to open the pptx2py desktop app (or run: python -m pptx2py)."""
import os
import sys


def fail(msg):
    """A message box even without a console (pythonw)."""
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, msg, 'pptx2py', 0x10)
    except Exception:  # noqa: BLE001  (not Windows)
        print(msg, file=sys.stderr)
    sys.exit(1)


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import PySide6  # noqa: F401
except ImportError:
    fail('The desktop app needs PySide6. Install it with:\n\n    pip install PySide6')
try:
    from pptx2py.gui import main  # noqa: E402
except ImportError as exc:
    fail(str(exc))

main(*sys.argv[1:2])
