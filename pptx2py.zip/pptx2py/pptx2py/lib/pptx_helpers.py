"""pptx_helpers: what pptx2py scripts need beyond python-pptx's own commands.

Part 1, extras: things python-pptx has no command for, such as shadows, transparency, arrowheads, bullets,
cell borders and picture fills. They are plain functions that take Python values; python-pptx scripts call
them by name. Inside, they set the few PowerPoint properties python-pptx does not cover.
Part 2, compact helpers: box(), ph(), pic(), tbl(), chart() and the rest, for the short code style.

Units: the extras take python-pptx lengths (Inches(1), Pt(2)); the compact helpers take inches and points
as plain numbers.
Colours: 'RRGGBB' or a theme colour ('accent1', 'tx1', 'bg2'). Add '+40' for lighter, '-25' for darker, and
'/50' for 50 % opaque.
"""
import base64
import io
import os
import re

from lxml import etree
from pptx import Presentation  # noqa: F401  (scripts get it from here too)
from pptx.chart.data import BubbleChartData, CategoryChartData, XyChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION
from pptx.enum.dml import MSO_LINE_DASH_STYLE, MSO_PATTERN, MSO_THEME_COLOR
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, MSO_UNDERLINE, PP_ALIGN
from pptx.oxml import parse_xml
from pptx.oxml.ns import qn
from pptx.util import Inches as In, Pt

HERE = os.path.dirname(os.path.abspath(__file__))
_NS = ' '.join(f'xmlns:{k}="http://schemas.openxmlformats.org/{v}"' for k, v in (
    ('a', 'drawingml/2006/main'), ('p', 'presentationml/2006/main'), ('c', 'drawingml/2006/chart'),
    ('r', 'officeDocument/2006/relationships')))
THEME = {'tx1': 'TEXT_1', 'tx2': 'TEXT_2', 'bg1': 'BACKGROUND_1', 'bg2': 'BACKGROUND_2', 'dk1': 'DARK_1',
         'lt1': 'LIGHT_1', 'dk2': 'DARK_2', 'lt2': 'LIGHT_2', 'hlink': 'HYPERLINK', 'folHlink': 'FOLLOWED_HYPERLINK',
         **{f'accent{i}': f'ACCENT_{i}' for i in range(1, 7)}}
SHAPES = {m.xml_value: m for m in MSO_SHAPE if getattr(m, 'xml_value', None)}
ANCHOR = {'t': MSO_ANCHOR.TOP, 'm': MSO_ANCHOR.MIDDLE, 'b': MSO_ANCHOR.BOTTOM}


def _xml(s):  # with python-pptx's element classes, so python-pptx objects can wrap the result
    return parse_xml(f'<w {_NS}>{s}</w>')[0]


def _clr(v):
    """A colour value as DrawingML."""
    v, _, a = v.partition('/')
    a = f'<a:alpha val="{round(float(a) * 1000)}"/>' if a else ''
    if re.fullmatch(r'[0-9A-Fa-f]{6}', v):
        return f'<a:srgbClr val="{v}">{a}</a:srgbClr>'
    m = re.fullmatch(r'([a-zA-Z]+\d?)([+-]\d+)?', v)
    b = int(m[2] or 0)
    mod = (f'<a:lumMod val="{(100 - b) * 1000}"/><a:lumOff val="{b * 1000}"/>' if b > 0 else
           f'<a:lumMod val="{(100 + b) * 1000}"/>' if b < 0 else '')
    return f'<a:schemeClr val="{m[1]}">{mod}{a}</a:schemeClr>'


def src(v):  # a file (in the current folder or next to this file), or base64 data
    p = next((p for p in (v, os.path.join(HERE, v)) if len(v) < 300 and os.path.exists(p)), None)
    return p or io.BytesIO(base64.b64decode(v))


# ════════════════════════════════════ Part 1: extras ════════════════════════════════════
def color(c, v):
    """Set a python-pptx ColorFormat from a colour value such as '1F497D', 'accent1+40' or 'FFFFFF/50'."""
    v, _, a = v.partition('/')
    m = re.fullmatch(r'([a-zA-Z]+\d?)([+-]\d+)?', v)
    if m and not re.fullmatch(r'[0-9A-Fa-f]{6}', v):
        c.theme_color = getattr(MSO_THEME_COLOR, THEME.get(m[1], 'TEXT_1'))
        if m[2]:
            c.brightness = int(m[2]) / 100
    else:
        c.rgb = RGBColor.from_string(v)
    if a:
        opacity(c, float(a))


def opacity(c, pct):
    """Make a colour pct % opaque (python-pptx has no transparency setting). c: a ColorFormat."""
    x = c._color._xClr
    for old in x.findall(qn('a:alpha')):
        x.remove(old)
    x.append(_xml(f'<a:alpha val="{round(pct * 1000)}"/>'))


def gradient(fill, stops, angle=90, radial=False):
    """A gradient with any number of stops: stops [(colour, position %), ...]; angle in degrees, clockwise.
    radial=True spreads from the middle; radial=('rect' | 'circle' | 'shape', left, top, right, bottom %) from the
    focus rectangle given by its insets."""
    fill.gradient()
    g = fill._xPr.find(qn('a:gradFill'))
    kind, *box = radial if isinstance(radial, (tuple, list)) else ('circle', 50, 50, 50, 50)
    focus = ''.join(f' {k}="{round(v * 1000)}"' for k, v in zip('ltrb', box) if v)
    g[:] = [_xml('<a:gsLst>' + ''.join(f'<a:gs pos="{round(p * 1000)}">{_clr(c)}</a:gs>' for c, p in stops) + '</a:gsLst>'),
            _xml(f'<a:path path="{kind}"><a:fillToRect{focus}/></a:path>' if radial
                 else f'<a:lin ang="{round(angle * 60000)}" scaled="0"/>')]


def _image_rel(part, img):
    """Relate a picture to a slide; formats Pillow cannot read (EMF, WMF, PDF ...) go in as they are."""
    try:
        return part.get_or_add_image_part(src(img) if isinstance(img, str) else img)[1]
    except Exception:  # noqa: BLE001
        from pptx.opc.constants import RELATIONSHIP_TYPE as RT
        from pptx.opc.package import Part
        d = src(img) if isinstance(img, str) else img
        d = open(d, 'rb').read() if isinstance(d, str) else d.getvalue()
        ext, ct = next(((e, c) for sig, e, c in (
            (b'%PDF', 'pdf', 'application/pdf'), (b'\xd7\xcd\xc6\x9a', 'wmf', 'image/x-wmf'),
            (b'\x01\x00\x09\x00', 'wmf', 'image/x-wmf'), (b'II*', 'tiff', 'image/tiff'),
            (b'MM\x00*', 'tiff', 'image/tiff')) if d.startswith(sig)),
            ('emf', 'image/x-emf') if d[40:44] == b' EMF' else ('png', 'image/png'))
        pkg = part.package
        return part.relate_to(Part(pkg.next_partname(f'/ppt/media/image%d.{ext}'), ct, pkg, d), RT.IMAGE)


def _blip_fx(blip, alpha=None, duotone=None, gray=False, bright=None, contrast=None, recolor=None, bilevel=None,
             tint=None):
    xml = ''
    if alpha is not None:
        xml += f'<a:alphaModFix amt="{round(alpha * 1000)}"/>'
    if bilevel is not None:
        xml += f'<a:biLevel thresh="{round(bilevel * 1000)}"/>'
    if recolor:
        xml += f'<a:clrChange><a:clrFrom>{_clr(recolor[0])}</a:clrFrom><a:clrTo>{_clr(recolor[1])}</a:clrTo></a:clrChange>'
    if duotone:
        xml += f'<a:duotone>{_clr(duotone[0])}{_clr(duotone[1])}</a:duotone>'
    if gray:
        xml += '<a:grayscl/>'
    if bright is not None or contrast is not None:
        xml += '<a:lum' + (f' bright="{round(bright * 1000)}"' if bright is not None else '') + \
               (f' contrast="{round(contrast * 1000)}"' if contrast is not None else '') + '/>'
    if tint:
        xml += f'<a:tint hue="{round(tint[0] * 60000)}" amt="{round(tint[1] * 1000)}"/>'
    for el in _xml(f'<a:x>{xml}</a:x>'):
        blip.append(el)


def picture_effects(picture, **pfx):
    """Transparency and recolouring of a picture: alpha (% opaque), duotone (colour, colour), gray=True,
    bright / contrast (%), recolor (from, to), bilevel (%), tint (hue, %)."""
    _blip_fx(picture._element.find('.//' + qn('a:blip')), **pfx)


def picture_back(picture, fill):
    """The fill behind a picture, seen through its transparent parts: a colour or a gradient, as gradient() takes it."""
    from pptx.dml.fill import FillFormat
    paint(FillFormat.from_fill_parent(picture._element.spPr), fill)


def picture_fill(shape, image, tile=False, **pfx):
    """Fill a shape with a picture, stretched or tiled (python-pptx fills only with colours)."""
    rid = _image_rel(shape.part, image)
    shape.fill.background()
    nf = shape._element.spPr.find(qn('a:noFill'))
    fill = _xml(f'<a:blipFill rotWithShape="1"><a:blip r:embed="{rid}"/>' +
                ('<a:tile tx="0" ty="0" sx="100000" sy="100000" algn="tl"/>' if tile else
                 '<a:stretch><a:fillRect/></a:stretch>') + '</a:blipFill>')
    nf.addnext(fill)
    nf.getparent().remove(nf)
    _blip_fx(fill.find(qn('a:blip')), **pfx)


def arrows(line, head=None, tail=None):
    """Arrowheads at the start / end of a line: 'triangle', 'stealth', 'arrow', 'oval' or 'diamond'."""
    ln = line._get_or_add_ln()
    for tag, kind in (('a:headEnd', head), ('a:tailEnd', tail)):
        for old in ln.findall(qn(tag)):
            ln.remove(old)
        if kind:
            ln.insert_element_before(_xml(f'<{tag} type="{kind}"/>'), *(('a:tailEnd',) if tag == 'a:headEnd' else ()),
                                     'a:extLst')


_FX = (('blur', 'blur'), ('glow', 'glow'), ('inner', 'innerShdw'), ('shadow', 'outerShdw'), ('preset', 'prstShdw'),
       ('reflect', 'reflection'), ('soft', 'softEdge'))
_FX_KEYS = {'blur': ('blurRad', 12700), 'dist': ('dist', 12700), 'dir': ('dir', 60000), 'r': ('rad', 12700),
            'sx': ('sx', 1000), 'sy': ('sy', 1000), 'kx': ('kx', 60000), 'ky': ('ky', 60000), 'align': ('algn', None),
            'rotate': ('rotWithShape', 'bool'), 'start': ('stA', 1000), 'startpos': ('stPos', 1000),
            'end': ('endA', 1000), 'endpos': ('endPos', 1000), 'fade': ('fadeDir', 60000), 'kind': ('prst', None),
            'grow': ('grow', 'bool')}


def _fx_xml(fx):
    xml = ''
    for key, tag in _FX:
        d = fx.get(key)
        if d is None:
            continue
        d = dict(d) if isinstance(d, dict) else {'r': d}
        c = d.pop('c', None if key in ('blur', 'soft', 'reflect') else '000000')
        attrs = ''.join(f' {_FX_KEYS[k][0]}="' + (('1' if v else '0') if _FX_KEYS[k][1] == 'bool' else
                                                 str(v) if _FX_KEYS[k][1] is None else str(round(v * _FX_KEYS[k][1])))
                        + '"' for k, v in d.items() if k in _FX_KEYS)
        xml += f'<a:{tag}{attrs}>{_clr(c) if c else ""}</a:{tag}>'
    return _xml(f'<a:effectLst>{xml}</a:effectLst>')


def effects(shape, **fx):
    """Shadow, glow, soft edges, reflection (python-pptx can only turn the theme's shadow off).
    effects(sh) clears them. Example: effects(sh, shadow={'c': '000000/35', 'blur': 4, 'dist': 3, 'dir': 90}).
    Sizes in points, angles in degrees, sx / sy / start / end in %."""
    sppr = shape._element.spPr
    for old in sppr.findall(qn('a:effectLst')):
        sppr.remove(old)
    sppr.insert_element_before(_fx_xml(fx), 'a:scene3d', 'a:sp3d', 'a:extLst')


_RPR_AFTER_FX = ('a:highlight', 'a:uLnTx', 'a:uLn', 'a:uFillTx', 'a:uFill', 'a:latin', 'a:ea', 'a:cs', 'a:sym',
                 'a:hlinkClick', 'a:hlinkMouseOver', 'a:rtl', 'a:extLst')


def text_effects(font, **fx):
    """Shadow, glow, reflection ... of text (WordArt styles), with the same settings as effects()."""
    r = font._rPr
    for old in r.findall(qn('a:effectLst')):
        r.remove(old)
    r.insert_element_before(_fx_xml(fx), *_RPR_AFTER_FX)


def text_outline(font, color, width=None):
    """Outline of the letters (WordArt): a colour ('' for none) and a width (Pt(1))."""
    r = font._rPr
    for old in r.findall(qn('a:ln')):
        r.remove(old)
    fill = f'<a:solidFill>{_clr(color)}</a:solidFill>' if color else '<a:noFill/>'
    r.insert(0, _xml(f'<a:ln{f' w="{int(width)}"' if width is not None else ''}>{fill}</a:ln>'))


def bullet(p, char, font=None, color=None, size=None, num=None, start=None):
    """Bullet of a paragraph: char '' none, '1.' numbered, '•' a character; font for the character (Wingdings ...),
    its colour and its size in % of the text; num: a numbering style ('romanUcPeriod', 'alphaLcParenR' ...) and
    start: the number it starts at."""
    if isinstance(char, dict):
        char, font, color, size, num, start = (char.get('char', '1.' if 'num' in char else '•'), char.get('font'),
                                               char.get('color'), char.get('size'), char.get('num'), char.get('start'))
    elif not isinstance(char, str):
        char, font = char
    pr = p._p.get_or_add_pPr()
    for tag in ('a:buClrTx', 'a:buClr', 'a:buSzTx', 'a:buSzPct', 'a:buSzPts', 'a:buFontTx', 'a:buFont', 'a:buNone',
                'a:buAutoNum', 'a:buChar', 'a:buBlip'):
        for old in pr.findall(qn(tag)):
            pr.remove(old)
    xml = [f'<a:buClr>{_clr(color)}</a:buClr>' if color and char else '',
           f'<a:buSzPct val="{round(size * 1000)}"/>' if size and char else '',
           f'<a:buFont typeface="{font}"/>' if font and char else '',
           '<a:buNone/>' if not char else f'<a:buAutoNum type="{num or "arabicPeriod"}"'
           + (f' startAt="{start}"' if start else '') + '/>' if char == '1.' or num else f'<a:buChar char="{char}"/>']
    for x in xml:
        if x:
            pr.insert_element_before(_xml(x), 'a:tabLst', 'a:defRPr', 'a:extLst')


def indent(p, left=None, first=None):
    """Left indent and first-line indent of a paragraph (lengths; a negative first line hangs)."""
    pr = p._p.get_or_add_pPr()
    for attr, v in (('marL', left), ('indent', first)):
        if v is not None:
            pr.set(attr, str(int(v)))


def font_extras(font, caps=None, spacing=None, baseline=None, strike=None, highlight=None):
    """caps 'all' / 'small', character spacing in points, baseline in % (30 superscript, -25 subscript),
    strike 'sngStrike' / 'dblStrike', highlight a colour behind the text."""
    r = font._rPr
    for attr, v in (('cap', caps), ('spc', None if spacing is None else round(spacing * 100)),
                    ('baseline', None if baseline is None else round(baseline * 1000)), ('strike', strike)):
        if v is not None:
            r.set(attr, str(v))
    if highlight:
        for old in r.findall(qn('a:highlight')):
            r.remove(old)
        r.insert_element_before(_xml(f'<a:highlight>{_clr(highlight)}</a:highlight>'), *_RPR_AFTER_FX[1:])


def field(p, kind, text=''):
    """A field PowerPoint keeps up to date, at the end of paragraph p: 'slidenum', 'datetime', 'datetime1' ...;
    text: what it shows until then. Returns the run, for its font (python-pptx adds only plain text runs)."""
    import uuid
    from pptx.text.text import _Run
    fld = _xml(f'<a:fld id="{{{str(uuid.uuid4()).upper()}}}" type="{kind}"><a:t/></a:fld>')
    fld.t.text = text
    end = p._p.find(qn('a:endParaRPr'))
    (end.addprevious(fld) if end is not None else p._p.append(fld))
    return _Run(fld, p)


def empty_line(p, size):
    """Height of an empty paragraph: the size of its end mark (python-pptx sizes only text runs)."""
    p._p.get_or_add_endParaRPr().set('sz', str(round(size.pt * 100)))


def text_direction(text_frame, vert=None, rotate=None):
    """Rotated or stacked text: vert 'vert', 'vert270', 'wordArtVert', 'eaVert' ...; rotate: degrees the text turns
    inside its shape."""
    if vert:
        text_frame._bodyPr.set('vert', vert)
    if rotate:
        text_frame._bodyPr.set('rot', str(round(rotate * 60000)))


def text_columns(text_frame, count, gap=0):
    """Text in `count` columns with `gap` (a length) between them."""
    text_frame._bodyPr.set('numCol', str(count))
    text_frame._bodyPr.set('spcCol', str(int(gap)))


def text_warp(text_frame, kind, *adj):
    """WordArt transform: the text bent to a shape, 'textArchUp', 'textWave1', 'textInflate', 'textSlantUp' ...;
    adj: its handles, as PowerPoint numbers them."""
    bp = text_frame._bodyPr
    for old in bp.findall(qn('a:prstTxWarp')):
        bp.remove(old)
    gd = ''.join(f'<a:gd name="adj{i + 1 if len(adj) > 1 else ""}" fmla="val {v}"/>' for i, v in enumerate(adj))
    bp.insert(0, _xml(f'<a:prstTxWarp prst="{kind}"><a:avLst>{gd}</a:avLst></a:prstTxWarp>'))


def _rot(r):
    return f'<a:rot lat="{round(r[0] * 60000)}" lon="{round(r[1] * 60000)}" rev="{round(r[2] * 60000)}"/>' if r else ''


def three_d(target, camera=None, rot=None, fov=None, zoom=None, light=None, light_rot=None, z=None, depth=None,
            contour=None, material=None, bevel=None, bevel_bottom=None, depth_color=None, contour_color=None):
    """3-D look of a shape, or of its text when target is a text frame: camera preset ('perspectiveFront',
    'isometricLeftDown' ...) and rotation (x, y, z degrees), light (rig, direction), depth / contour / z in points,
    bevel (width pt, height pt, kind), material ('matte', 'metal', 'plastic' ...)."""
    pr = target._bodyPr if hasattr(target, '_bodyPr') else target._element.spPr
    for tag in ('a:scene3d', 'a:sp3d'):
        for old in pr.findall(qn(tag)):
            pr.remove(old)
    cam = f'<a:camera prst="{camera or "orthographicFront"}"' + (f' fov="{round(fov * 60000)}"' if fov else '') + \
        (f' zoom="{round(zoom * 1000)}"' if zoom else '') + f'>{_rot(rot)}</a:camera>'
    rig, d = light or ('threePt', 't'), ''
    for tag, b in (('bevelT', bevel), ('bevelB', bevel_bottom)):
        if b:
            d += f'<a:{tag} w="{round(b[0] * 12700)}" h="{round(b[1] * 12700)}" prst="{b[2] if len(b) > 2 else "circle"}"/>'
    for tag, c in (('extrusionClr', depth_color), ('contourClr', contour_color)):
        if c:
            d += f'<a:{tag}>{_clr(c)}</a:{tag}>'
    attrs = ''.join(f' {a}="{round(v * 12700)}"' for a, v in (('z', z), ('extrusionH', depth), ('contourW', contour))
                    if v) + (f' prstMaterial="{material}"' if material else '')
    after = ('a:flatTx', 'a:extLst') if hasattr(target, '_bodyPr') else ('a:extLst',)
    pr.insert_element_before(_xml(f'<a:scene3d>{cam}<a:lightRig rig="{rig[0]}" dir="{rig[1]}">{_rot(light_rot)}'
                                  '</a:lightRig></a:scene3d>'), *after)
    pr.insert_element_before(_xml(f'<a:sp3d{attrs}>{d}</a:sp3d>'), *after)


def glue(connector, begin=None, end=None):
    """Attach a connector's ends to shapes, (shape, connection point), so it follows them when they move; the
    line stays where it is (python-pptx's begin_connect() also moves it, to one of four points)."""
    nv = connector._element.nvCxnSpPr.cNvCxnSpPr
    for tag, v in (('a:stCxn', begin), ('a:endCxn', end)):
        for old in nv.findall(qn(tag)):
            nv.remove(old)
        if v:
            nv.append(_xml(f'<{tag} id="{v[0].shape_id}" idx="{v[1]}"/>'))
    order = {qn('a:cxnSpLocks'): 0, qn('a:stCxn'): 1, qn('a:endCxn'): 2, qn('a:extLst'): 3}
    nv[:] = sorted(nv, key=lambda e: order.get(e.tag, 3))


def autofit(text_frame, scale=None, spacing=None):
    """Shrink text on overflow, with PowerPoint's font scale and line-spacing reduction in %."""
    text_frame.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
    fit = text_frame._bodyPr.find(qn('a:normAutofit'))
    for attr, v in (('fontScale', scale), ('lnSpcReduction', spacing)):
        if v:
            fit.set(attr, str(round(v * 1000)))


def mirror(shape, how):
    """Flip a shape: 'h' (left-right), 'v' (top-bottom) or 'hv'."""
    x = next(shape._element.iter(qn('a:xfrm')))  # a group's own comes before its shapes'
    for f in how:
        x.set('flipH' if f == 'h' else 'flipV', '1')


def _path_xml(g):
    tags, out = dict(M=('moveTo', 2), L=('lnTo', 2), C=('cubicBezTo', 6), Q=('quadBezTo', 4)), ''
    for p in g.split('|'):
        t = re.findall(r'[A-Za-z]+|-?\d+', p)
        a, body, i = f'w="{t[0]}" h="{t[1]}"', '', 2
        while i < len(t):
            c, i = t[i], i + 1
            if c in tags:
                tag, n = tags[c]
                body += f'<a:{tag}>' + ''.join(f'<a:pt x="{t[j]}" y="{t[j + 1]}"/>' for j in range(i, i + n, 2)) + f'</a:{tag}>'
                i += n
            elif c == 'A':
                body, i = body + '<a:arcTo wR="{}" hR="{}" stAng="{}" swAng="{}"/>'.format(*t[i:i + 4]), i + 4
            elif c == 'Z':
                body += '<a:close/>'
            else:
                a += ' stroke="0"' if c == 'nostroke' else f' fill="{c}"'
        out += f'<a:path {a}>{body}</a:path>'
    return ('<a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="l" t="t" r="r" b="b"/>'
            f'<a:pathLst>{out}</a:pathLst></a:custGeom>')


def outline(shape, path):
    """Give a shape a free-form outline: 'W H M x y L x y C x1 y1 x2 y2 x y A wR hR start swing Z | next ...'."""
    sp = shape._element.spPr
    old = sp.find(qn('a:prstGeom'))
    old.addprevious(_xml(_path_xml(path)))
    sp.remove(old)


def cell_border(cell, sides, width=None, color=None):
    """Borders of a table cell: sides any of 'LRTB'; width a length (Pt(1)), None or 0 for no line."""
    pr = cell._tc.get_or_add_tcPr()
    for sd in 'LRTB':
        if sd in sides:
            for old in pr.findall(qn(f'a:ln{sd}')):
                pr.remove(old)
    fill = f'<a:solidFill>{_clr(color)}</a:solidFill>' if width and color else '<a:noFill/>'
    for i, sd in enumerate(sd for sd in 'LRTB' if sd in sides):
        pr.insert(i, _xml(f'<a:ln{sd} w="{int(width or 0)}">{fill}</a:ln{sd}>'))
    order = {qn(f'a:ln{s}'): n for n, s in enumerate('LRTB')}
    lines = sorted((e for e in pr if e.tag in order), key=lambda e: order[e.tag])
    for i, e in enumerate(lines):
        pr.insert(i, e)


def cell_direction(cell, vert):
    """Text direction in a table cell: 'vert' (turned right), 'vert270' (turned left), 'wordArtVert' (stacked)."""
    cell._tc.get_or_add_tcPr().set('vert', vert)


def table_style(table, style_id):
    """Use one of PowerPoint's table styles, by its id ('{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}' ...)."""
    table._tbl.tblPr.find(qn('a:tableStyleId')).text = style_id


LINKS = []  # (shape, slide number): clicks that jump to a slide, set by links(prs) once all slides exist


def links(prs):
    """Point the clicks collected in LINKS at their slides (call it after the last slide is made)."""
    for sh, n in LINKS:
        sh.click_action.target_slide = prs.slides[n - 1]
    LINKS.clear()


def click_jump(shape, where):
    """What a click on the shape does in the slide show: 'nextslide', 'previousslide', 'firstslide', 'lastslide',
    'lastslideviewed' or 'endshow' (python-pptx sets only web links and jumps to a given slide)."""
    nv = shape._element[0].find(qn('p:cNvPr'))
    for old in nv.findall(qn('a:hlinkClick')):
        nv.remove(old)
    nv.insert(0, _xml(f'<a:hlinkClick r:id="" action="ppaction://hlinkshowjump?jump={where}"/>'))


def group_box(group, left, top, width, height):
    """Give a group its own box without moving its shapes (python-pptx fits the box to them): the box a group
    turns and flips about. Lengths (Inches(...)), or inches as plain numbers."""
    left, top, width, height = (v if isinstance(v, int) and abs(v) > 20000 else In(v) for v in (left, top, width, height))
    x = group._element.grpSpPr.find(qn('a:xfrm'))
    for tag, a, b, u, v in (('a:off', 'x', 'y', left, top), ('a:ext', 'cx', 'cy', width, height),
                            ('a:chOff', 'x', 'y', left, top), ('a:chExt', 'cx', 'cy', width, height)):
        e = x.find(qn(tag))
        e.set(a, str(int(u)))
        e.set(b, str(int(v)))


def preset(shape, name, *adj):
    """Give a shape or connector one of PowerPoint's outlines python-pptx has no MSO_SHAPE member for ('line',
    'bentConnector4', 'chartPlus' ...), with its adjustments as PowerPoint numbers them (50000 = half)."""
    pg = shape._element.spPr.find(qn('a:prstGeom'))
    pg.set('prst', name)
    av = pg.find(qn('a:avLst'))
    if av is None:
        av = _xml('<a:avLst/>')
        pg.append(av)
    av[:] = [_xml(f'<a:gd name="adj{"" if len(adj) == 1 else i + 1}" fmla="val {v}"/>') for i, v in enumerate(adj)]


def hide(shape):
    """Hide a shape: it stays on the slide, hidden as with PowerPoint's Selection Pane."""
    shape._element[0].find(qn('p:cNvPr')).set('hidden', '1')


def hide_slide(slide):
    """Hide a slide in the slide show."""
    slide._element.set('show', '0')


def hide_layout_graphics(slide):
    """Hide the master's and the layout's background graphics on this slide."""
    slide._element.set('showMasterSp', '0')


def picture_background(slide, image, tile=False, **pfx):
    """A picture as the slide background, stretched or tiled."""
    rid = _image_rel(slide.part, image)
    cs = slide._element.cSld
    for old in cs.findall(qn('p:bg')):
        cs.remove(old)
    bg = _xml(f'<p:bg><p:bgPr><a:blipFill><a:blip r:embed="{rid}"/>' +
              ('<a:tile tx="0" ty="0" sx="100000" sy="100000" algn="tl"/>' if tile else '<a:stretch><a:fillRect/></a:stretch>')
              + '</a:blipFill><a:effectLst/></p:bgPr></p:bg>')
    cs.insert(0, bg)
    _blip_fx(bg.find('.//' + qn('a:blip')), **pfx)


def add_any_picture(shapes, image, left, top, width, height):
    """add_picture() that also takes EMF, WMF and PDF pictures (python-pptx reads pictures with Pillow)."""
    try:
        return shapes.add_picture(src(image) if isinstance(image, str) else image, left, top, width, height)
    except Exception:  # noqa: BLE001
        sp = shapes._spTree.add_pic(shapes._next_shape_id, 'Picture', '', _image_rel(shapes.part, image),
                                    left, top, width, height)
        return shapes._shape_factory(sp)


_SER = {'line': ('idx', 'order', 'tx', 'spPr', 'marker', 'dPt', 'dLbls', 'trendline', 'errBars', 'cat', 'val', 'smooth',
                 'extLst'),
        'bar': ('idx', 'order', 'tx', 'spPr', 'invertIfNegative', 'pictureOptions', 'dPt', 'dLbls', 'trendline',
                'errBars', 'cat', 'val', 'shape', 'extLst'),
        'area': ('idx', 'order', 'tx', 'spPr', 'pictureOptions', 'dPt', 'dLbls', 'trendline', 'errBars', 'cat', 'val',
                 'extLst'),
        'radar': ('idx', 'order', 'tx', 'spPr', 'marker', 'dPt', 'dLbls', 'cat', 'val', 'extLst')}


def combo_chart(chart, kind, series, secondary=False):
    """Draw some series of a chart as another chart type (a combo chart): kind 'LINE_MARKERS', 'COLUMN_CLUSTERED',
    'AREA' ... (XL_CHART_TYPE names); series their numbers (0 = first); secondary=True puts them on a second value
    axis on the right. python-pptx makes charts of one type only."""
    from copy import deepcopy
    from pptx.chart.xmlwriter import ChartXmlWriter
    c = '{http://schemas.openxmlformats.org/drawingml/2006/chart}'
    cd = CategoryChartData()
    cd.categories = ['a']
    cd.add_series('s', [1])
    tpl = etree.fromstring(ChartXmlWriter(getattr(XL_CHART_TYPE, kind), cd).xml.encode())
    new = next(e for e in tpl.find(f'.//{c}plotArea') if e.tag.endswith('Chart'))
    model = new.find(f'{c}ser')
    new.remove(model)
    pa = chart._chartSpace.find(f'.//{c}plotArea')
    plots = [p for p in pa if p.tag.endswith('Chart')]
    sers = [s for p in plots for s in p.findall(f'{c}ser')]
    order = _SER[new.tag[len(c):].replace('Chart', '')]
    at = max(i for i, e in enumerate(new) if e.tag[len(c):] in ('barDir', 'grouping', 'varyColors', 'radarStyle')) + 1
    for k, i in enumerate(series):
        s = sers[i]
        kids = {}
        for e in list(s):
            kids.setdefault(e.tag[len(c):], []).append(e)
        for e in model:
            if e.tag[len(c):] not in kids and e.tag[len(c):] in ('marker', 'smooth', 'invertIfNegative'):
                kids[e.tag[len(c):]] = [deepcopy(e)]
        s[:] = [e for t in order for e in kids.get(t, ())]
        new.insert(at + k, s)
    axes = [a for a in pa if a.tag[len(c):] in ('catAx', 'valAx', 'dateAx', 'serAx')]
    ids = [a.get('val') for a in plots[0].findall(f'{c}axId')]
    if secondary:
        cat, val = (deepcopy(next(a for a in axes if a.tag == f'{c}{t}')) for t in ('catAx', 'valAx'))
        n = max(int(a.find(f'{c}axId').get('val')) for a in axes) + 1
        ids = [str(n), str(n + 1)]
        for ax, me, other, pos in ((cat, ids[0], ids[1], 'b'), (val, ids[1], ids[0], 'r')):
            ax.find(f'{c}axId').set('val', me)
            ax.find(f'{c}crossAx').set('val', other)
            ax.find(f'{c}axPos').set('val', pos)
            for t in ('majorGridlines', 'minorGridlines', 'title'):
                for e in ax.findall(f'{c}{t}'):
                    ax.remove(e)
        d = cat.find(f'{c}delete')
        d.set('val', '1')
        cr = val.find(f'{c}crosses') if val.find(f'{c}crosses') is not None else val.find(f'{c}crossesAt')
        cr.addprevious(etree.SubElement(val, f'{c}crosses', val='max'))
        val.remove(cr)
        axes[-1].addnext(val)
        axes[-1].addnext(cat)
    for e in new.findall(f'{c}axId'):
        new.remove(e)
    for i in ids:
        new.append(etree.Element(f'{c}axId', val=i))
    plots[-1].addnext(new)
    for p in plots:
        if p.find(f'{c}ser') is None:
            pa.remove(p)


def series_labels(series):
    """Data labels of one series, as python-pptx DataLabels (python-pptx gives XY charts none)."""
    from pptx.chart.datalabel import DataLabels
    return DataLabels(series._element.get_or_add_dLbls())


def doughnut_hole(chart, pct):
    """Hole size of a doughnut chart, % of its size."""
    chart._chartSpace.find('.//' + qn('c:holeSize')).set('val', str(pct))


def chart_area(chart, fill=None, line=None, width=None, plot=False):
    """Fill and border of the chart area (plot=True: the plot area): fill a colour, '' for none, or a gradient /
    pattern as gradient() takes it; line a colour or ''; width in points."""
    from pptx.dml.fill import FillFormat
    from pptx.dml.line import LineFormat
    el = chart._chartSpace.find('.//' + qn('c:plotArea')) if plot else chart._chartSpace
    sp = el.find(qn('c:spPr'))
    if sp is None:
        sp = _xml('<c:spPr/>')
        el.insert_element_before(sp, *(('c:extLst',) if plot else ('c:txPr', 'c:externalData', 'c:printSettings',
                                                                   'c:userShapes', 'c:extLst')))
    if fill is not None:
        paint(FillFormat.from_fill_parent(sp), fill)
    if line is not None or width:
        stroke(LineFormat(sp), line, width)


def set_theme(prs, fonts=None, colors=None):
    """Theme fonts (heading, body) and colours {'accent1': 'RRGGBB', ...} of a presentation."""
    from pptx.opc.constants import RELATIONSHIP_TYPE as RT
    part = prs.slide_master.part.part_related_by(RT.THEME)
    root, a = etree.fromstring(part.blob), '{http://schemas.openxmlformats.org/drawingml/2006/main}'
    for tag, face in zip(('majorFont', 'minorFont'), fonts or ()):
        root.find(f'.//{a}{tag}/{a}latin').set('typeface', face)
    for name, v in (colors or {}).items():
        root.find(f'.//{a}clrScheme/{a}{name}')[:] = [etree.Element(f'{a}srgbClr', val=v)]
    part._blob = etree.tostring(root)


def _no_style(shape):  # drop the look python-pptx gives new shapes (theme fill, line, shadow, white text)
    for st in shape._element.findall(qn('p:style')):
        shape._element.remove(st)


_MC = 'http://schemas.openxmlformats.org/markup-compatibility/2006'
_EXT = {'p14': 'http://schemas.microsoft.com/office/powerpoint/2010/main',
        'p15': 'http://schemas.microsoft.com/office/powerpoint/2012/main',
        'p159': 'http://schemas.microsoft.com/office/powerpoint/2015/09/main'}


def _slide_put(slide, el, before=('p:timing', 'p:extLst')):
    sld = slide._element
    for old in [c for c in sld if c.tag in (qn('p:transition'), f'{{{_MC}}}AlternateContent') and
                (c.tag == qn('p:transition') or c.find('.//' + qn('p:transition')) is not None)] if \
            el.tag != qn('p:timing') else sld.findall(qn('p:timing')):
        sld.remove(old)
    nxt = next((c for c in sld if c.tag in [qn(t) for t in before]), None)
    if nxt is not None:
        nxt.addprevious(el)
    else:
        sld.append(el)


def transition(slide, kind='fade', speed=None, duration=None, click=True, after=None, **opts):
    """Slide transition (python-pptx has none): kind 'fade', 'push', 'wipe', 'split', 'cover', 'zoom' ... or a
    PowerPoint 2010+ effect such as 'p14:vortex', 'p14:ripple', 'p159:morph'; speed 'slow' / 'med' / 'fast' or
    duration in seconds; click=False and after=3 advance by themselves; opts are the effect's own settings
    (dir='l', orient='vert' ...)."""
    pre, _, name = kind.rpartition(':')
    attrs = ''.join(f' {k}="{str(v).lower() if isinstance(v, bool) else v}"' for k, v in opts.items())
    eff = f'<{pre or "p"}:{name}{attrs}/>' if name != 'none' else ''
    base = (f' spd="{speed}"' if speed else '') + ('' if click else ' advClick="0"') + \
        (f' advTm="{round(after * 1000)}"' if after is not None else '')
    ns = f'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" ' \
         f'xmlns:mc="{_MC}" ' + ' '.join(f'xmlns:{k}="{v}"' for k, v in _EXT.items())
    if pre or duration is not None:
        req = pre or 'p14'
        dur = f' p14:dur="{round(duration * 1000)}"' if duration is not None else ''
        fallback = '<p:fade/>' if pre else eff
        el = etree.fromstring(f'<mc:AlternateContent {ns}><mc:Choice Requires="{req}{" p14" if req != "p14" and dur else ""}">'
                              f'<p:transition{base}{dur}>{eff}</p:transition></mc:Choice><mc:Fallback>'
                              f'<p:transition{base}>{fallback}</p:transition></mc:Fallback></mc:AlternateContent>')
    else:
        el = etree.fromstring(f'<p:transition {ns}{base}>{eff}</p:transition>')
    _slide_put(slide, el)


def _anim_value(v):
    if isinstance(v, bool):
        return f'<p:boolVal val="{int(v)}"/>'
    if isinstance(v, int):
        return f'<p:intVal val="{v}"/>'
    if isinstance(v, float):
        return f'<p:fltVal val="{v}"/>'
    if isinstance(v, dict):
        return f'<p:clrVal>{_clr(v["color"])}</p:clrVal>'
    return f'<p:strVal val="{_esc(str(v))}"/>'


def _esc(v):
    return v.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;')


def _step_time(st):
    dur = st.get('dur', 1 if 'set' in st or 'cmd' in st else 500)
    dur = 0 if dur == 'indefinite' else dur
    rep = st.get('repeat', 1000)
    rep = 1 if rep == 'indefinite' else rep / 1000
    return st.get('delay', 0) + dur * rep * (2 if st.get('autorev') else 1)


def animate(slide, effects, builds=()):
    """Animations (python-pptx has none). effects: dicts in play order with shape, start ('click' / 'with' /
    'after'), type ('entr', 'emph', 'exit', 'path'), preset and sub (PowerPoint's effect numbers), delay (ms),
    paras=(first, last) to animate paragraphs, on=shape for a click-on-shape trigger, and do: the steps --
    {'set': attribute, 'to': value}, {'filter': 'fade'}, {'anim': 'ppt_x', 'keys': [(time, value), ...]},
    {'scale': (x %, y %)}, {'rotate': degrees}, {'motion': 'M 0 0 L 0.2 0 E'}, {'color': 'FF0000'}, {'cmd': ...};
    each step may have dur, delay (ms), fill, accel, decel, autorev, repeat. builds: dict(shape=, grp=, build='p')."""
    ids = iter(range(3, 100000))

    def tgt(e):
        sp = f'<p:spTgt spid="{e["shape"].shape_id}">'
        if e.get('paras'):
            sp += f'<p:txEl><p:pRg st="{e["paras"][0]}" end="{e["paras"][1]}"/></p:txEl>'
        elif e.get('chars'):
            sp += f'<p:txEl><p:charRg st="{e["chars"][0]}" end="{e["chars"][1]}"/></p:txEl>'
        return f'<p:tgtEl>{sp}</p:spTgt></p:tgtEl>'

    def ctn(st, extra='', default_fill=None):
        a = ''
        for k, attr in (('dur', 'dur'), ('accel', 'accel'), ('decel', 'decel'), ('autorev', 'autoRev'),
                        ('repeat', 'repeatCount'), ('fill', 'fill'), ('speed', 'spd')):
            v = st.get(k, default_fill if k == 'fill' else None)
            if v is not None:
                a += f' {attr}="{int(v) if isinstance(v, bool) else v}"'
        cond = f'<p:stCondLst><p:cond delay="{st["delay"]}"/></p:stCondLst>' if st.get('delay') else ''
        return f'<p:cTn id="{next(ids)}"{a}{extra}>{cond}</p:cTn>'

    def behaviour(e, st):
        t = tgt(e)
        cb = ''.join(f' {attr}="{st[k]}"' for k, attr in (('additive', 'additive'), ('accumulate', 'accumulate'),
                                                          ('xfrm', 'xfrmType'), ('rctx', 'rctx'),
                                                          ('override', 'override')) if k in st)

        def names(*n):
            return '<p:attrNameLst>' + ''.join(f'<p:attrName>{x}</p:attrName>' for x in n) + '</p:attrNameLst>'
        if 'set' in st:
            d = dict(st, dur=st.get('dur', 1))
            to = f'<p:to>{_anim_value(st["to"])}</p:to>' if st.get('to') is not None else ''
            return f'<p:set><p:cBhvr{cb}>{ctn(d, default_fill="hold")}{t}{names(st["set"])}</p:cBhvr>{to}</p:set>'
        if 'filter' in st:
            return (f'<p:animEffect transition="{st.get("transition", "in")}" filter="{st["filter"]}"'
                    + (f' prLst="{st["props"]}"' if st.get('props') else '') + f'><p:cBhvr{cb}>{ctn(st)}{t}</p:cBhvr>'
                    '</p:animEffect>')
        if 'anim' in st:
            a = ''.join(f' {attr}="{st[k]}"' for k, attr in (('calc', 'calcmode'), ('type', 'valueType'), ('from', 'from'),
                                                             ('to', 'to'), ('by', 'by')) if k in st)
            keys = ''.join(f'<p:tav tm="{k[0]}"' + (f' fmla="{_esc(k[2])}"' if len(k) > 2 and k[2] else '') + '>' +
                           (f'<p:val>{_anim_value(k[1])}</p:val>' if k[1] is not None else '') + '</p:tav>'
                           for k in st.get('keys', ()))
            return (f'<p:anim{a}><p:cBhvr{cb}>{ctn(st)}{t}{names(st["anim"])}</p:cBhvr>' +
                    (f'<p:tavLst>{keys}</p:tavLst>' if keys else '') + '</p:anim>')
        if 'scale' in st:
            def xy(tag, v):
                return f'<p:{tag} x="{round(v[0] * 1000)}" y="{round(v[1] * 1000)}"/>' if v else ''
            return ('<p:animScale' + (' zoomContents="1"' if st.get('zoom') else '') +
                    f'><p:cBhvr{cb}>{ctn(st)}{t}</p:cBhvr>{xy("by", st.get("scale"))}'
                    f'{xy("from", st.get("from"))}{xy("to", st.get("to"))}</p:animScale>')
        if 'rotate' in st:
            a = ''.join(f' {k}="{round(st[k] * 60000)}"' for k in ('from', 'to') if k in st)
            return (f'<p:animRot by="{round(st["rotate"] * 60000)}"{a}><p:cBhvr{cb}>{ctn(st)}{t}'
                    f'{names("r")}</p:cBhvr></p:animRot>')
        if 'motion' in st:
            a = ''.join(f' {attr}="{st[k]}"' for k, attr in (('origin', 'origin'), ('edit', 'pathEditMode'),
                                                             ('pts', 'ptsTypes')) if k in st)
            a += f' rAng="{round(st["rang"] * 60000)}"' if 'rang' in st else ''
            rc = f'<p:rCtr x="{st["center"][0]}" y="{st["center"][1]}"/>' if st.get('center') else ''
            return (f'<p:animMotion path="{_esc(st["motion"])}"{a}><p:cBhvr{cb}>{ctn(st)}{t}'
                    f'{names("ppt_x", "ppt_y")}</p:cBhvr>{rc}</p:animMotion>')
        if 'color' in st:
            a = ''.join(f' {attr}="{st[k]}"' for k, attr in (('space', 'clrSpc'), ('dir', 'dir')) if k in st)
            by = ''
            if st.get('by'):
                if st.get('by_space', 'hsl') == 'hsl':
                    h, s_, l_ = st['by']
                    by = f'<p:by><p:hsl h="{round(h * 60000)}" s="{round(s_ * 1000)}" l="{round(l_ * 1000)}"/></p:by>'
                else:
                    r, g, b = st['by']
                    by = f'<p:by><p:rgb r="{round(r * 1000)}" g="{round(g * 1000)}" b="{round(b * 1000)}"/></p:by>'
            to = f'<p:to>{_clr(st["color"])}</p:to>' if st.get('color') else ''
            return (f'<p:animClr{a}><p:cBhvr{cb}>{ctn(st)}{t}{names(st.get("attr", "style.color"))}'
                    f'</p:cBhvr>{by}{to}</p:animClr>')
        if 'cmd' in st:
            return (f'<p:cmd type="{st.get("type", "call")}" cmd="{_esc(st["cmd"])}"><p:cBhvr{cb}>'
                    f'{ctn(st)}{t}</p:cBhvr></p:cmd>')
        return ''

    def effect(e):
        node = {'click': 'clickEffect', 'after': 'afterEffect'}.get(e.get('start'), 'withEffect')
        a = ''.join(f' {attr}="{e[k]}"' for k, attr in (('preset', 'presetID'), ('type', 'presetClass'),
                                                         ('sub', 'presetSubtype')) if k in e)
        a += ' fill="hold"' + (f' grpId="{e["grp"]}"' if 'grp' in e else '')
        for k, attr in (('accel', 'accel'), ('decel', 'decel'), ('autorev', 'autoRev'), ('repeat', 'repeatCount'),
                        ('dur', 'dur')):
            if k in e:
                a += f' {attr}="{int(e[k]) if isinstance(e[k], bool) else e[k]}"'
        steps = ''.join(behaviour(e, st) for st in e.get('do', ()))
        return (f'<p:par><p:cTn id="{next(ids)}"{a} nodeType="{node}"><p:stCondLst><p:cond delay="{e.get("delay", 0)}"/>'
                f'</p:stCondLst><p:childTnLst>{steps}</p:childTnLst></p:cTn></p:par>')

    def groups(effs, interactive=False):
        clicks = []
        for e in effs:
            if not clicks or e.get('start') == 'click':
                clicks.append([])
            if not clicks[-1] or e.get('start') == 'after':
                clicks[-1].append([])
            clicks[-1][-1].append(e)
        xml = ''
        for n, click in enumerate(clicks):
            auto = click[0][0].get('start') != 'click' and n == 0 and not interactive
            subs, at = '', 0
            for sub in click:
                inner = ''.join(effect(e) for e in sub)
                subs += (f'<p:par><p:cTn id="{next(ids)}" fill="hold"><p:stCondLst><p:cond delay="{round(at)}"/>'
                         f'</p:stCondLst><p:childTnLst>{inner}</p:childTnLst></p:cTn></p:par>')
                at += max(e.get('delay', 0) + max((_step_time(st) for st in e.get('do', ())), default=0) for e in sub)
            start = ('<p:cond delay="indefinite"/><p:cond evt="onBegin" delay="0"><p:tn val="2"/></p:cond>' if auto
                     else '<p:cond delay="0"/>' if interactive and n == 0 else '<p:cond delay="indefinite"/>')
            xml += (f'<p:par><p:cTn id="{next(ids)}" fill="hold"><p:stCondLst>{start}</p:stCondLst>'
                    f'<p:childTnLst>{subs}</p:childTnLst></p:cTn></p:par>')
        return xml

    main = [e for e in effects if e.get('on') is None]
    seqs = ''
    if main:
        seqs += ('<p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>'
                 + groups(main) + '</p:childTnLst></p:cTn><p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl>'
                 '<p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst><p:nextCondLst><p:cond evt="onNext" delay="0">'
                 '<p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq>')
    triggers = []
    for e in effects:
        if e.get('on') is not None and all(e['on'] is not t for t in triggers):
            triggers.append(e['on'])
    for trig in triggers:
        effs = [e for e in effects if e.get('on') is trig]
        sid = trig.shape_id
        seqs += (f'<p:seq concurrent="1" nextAc="seek"><p:cTn id="{next(ids)}" restart="whenNotActive" fill="hold" '
                 f'evtFilter="cancelBubble" nodeType="interactiveSeq"><p:stCondLst><p:cond evt="onClick" delay="0">'
                 f'<p:tgtEl><p:spTgt spid="{sid}"/></p:tgtEl></p:cond></p:stCondLst><p:endSync evt="end" delay="0">'
                 f'<p:rtn val="all"/></p:endSync><p:childTnLst>{groups(effs, True)}</p:childTnLst></p:cTn>'
                 f'<p:nextCondLst><p:cond evt="onClick" delay="0"><p:tgtEl><p:spTgt spid="{sid}"/></p:tgtEl></p:cond>'
                 f'</p:nextCondLst></p:seq>')
    blds = ''
    for b in builds or ():
        a = ''.join(f' {attr}="{(int(b[k]) if isinstance(b[k], bool) else b[k])}"'
                    for k, attr in (('build', 'build'), ('bg', 'animBg'), ('expand', 'uiExpand'),
                                    ('reverse', 'rev'), ('auto', 'advAuto')) if k in b)
        blds += f'<p:bldP spid="{b["shape"].shape_id}" grpId="{b.get("grp", 0)}"{a}/>'
    xml = (f'<p:timing xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.'
           f'openxmlformats.org/drawingml/2006/main"><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" '
           f'nodeType="tmRoot"><p:childTnLst>{seqs}</p:childTnLst></p:cTn></p:par></p:tnLst>'
           + (f'<p:bldLst>{blds}</p:bldLst>' if blds else '') + '</p:timing>')
    new = etree.fromstring(xml)
    old = slide._element.find(qn('p:timing'))
    media = old.findall('.//' + qn('p:video')) + old.findall('.//' + qn('p:audio')) if old is not None else []
    if media:  # the playback nodes add_movie() made: kept, with fresh ids
        last = max(int(c.get('id')) for c in new.iter(qn('p:cTn')))
        kids = new.find('.//' + qn('p:childTnLst'))
        for m in media:
            for c in m.iter(qn('p:cTn')):
                last += 1
                c.set('id', str(last))
            kids.append(m)
    _slide_put(slide, new, before=('p:extLst',))


# ════════════════════════════════ Part 2: compact helpers ════════════════════════════════
def paint(f, v):  # '' no fill | colour | ['grad', angle, (colour, pos %), ...] ('path': radial) | ['patt', ...]
    if v == '':
        return f.background()
    if isinstance(v, str):
        f.solid()
        return color(f.fore_color, v)
    if v[0] == 'patt':  # ['patt', pattern, foreground, background]
        f.patterned()
        f.pattern = MSO_PATTERN.from_xml(v[1])
        color(f.fore_color, v[2])
        return color(f.back_color, v[3])
    gradient(f, v[2:], 90 if v[0] == 'path' else v[1], (v[1] or True) if v[0] == 'path' else False)


def pfill(sh, v):  # fill= for a shape: as paint(), or ['img', file, tile, picture effects]
    if isinstance(v, list) and v[0] == 'img':
        return picture_fill(sh, v[1], bool(v[2]) if len(v) > 2 else False, **(v[3] if len(v) > 3 else {}))
    paint(sh.fill, v)


def stroke(ln, v=None, w=None, dash=None, ends=None):
    if v == '' or isinstance(v, list):
        paint(ln.fill, v)
    elif v:
        ln.fill.solid()
        color(ln.fill.fore_color, v)
    if w:
        ln.width = Pt(w)
    if dash:
        ln.dash_style = MSO_LINE_DASH_STYLE.from_xml(dash) if dash in {m.xml_value for m in MSO_LINE_DASH_STYLE} \
            else MSO_LINE_DASH_STYLE.DASH
    if ends:
        arrows(ln, *ends)


def font(fo, k):
    for key, attr in (('b', 'bold'), ('i', 'italic'), ('u', 'underline')):
        if key in k:
            setattr(fo, attr, MSO_UNDERLINE.from_xml(k[key]) if isinstance(k[key], str) else bool(k[key]))
    if 'sz' in k:
        fo.size = Pt(k['sz'])
    if 'f' in k:
        fo.name = k['f']
    if 'c' in k:  # a colour, '' (outline only), a gradient or a pattern
        paint(fo.fill, k['c']) if isinstance(k['c'], list) or k['c'] == '' else color(fo.color, k['c'])
    if any(x in k for x in ('cap', 'spc', 'base', 'strike', 'mark')):
        font_extras(fo, k.get('cap'), k.get('spc'), k.get('base'), k.get('strike'), k.get('mark'))
    if 'ol' in k:  # outline (colour, width pt)
        text_outline(fo, k['ol'][0], Pt(k['ol'][1]))
    if 'tfx' in k:
        text_effects(fo, **k['tfx'])


def para(p, k):
    if 'align' in k:
        p.alignment = {'l': PP_ALIGN.LEFT, 'c': PP_ALIGN.CENTER, 'r': PP_ALIGN.RIGHT, 'j': PP_ALIGN.JUSTIFY}[k['align']]
    for key, attr, f in (('lvl', 'level', int), ('ls', 'line_spacing', float), ('lsp', 'line_spacing', Pt),
                         ('sb', 'space_before', Pt), ('sa', 'space_after', Pt)):
        if key in k:
            setattr(p, attr, f(k[key]))
    if 'ml' in k or 'ind' in k:
        indent(p, In(k['ml']) if 'ml' in k else None, In(k['ind']) if 'ind' in k else None)
    if 'bul' in k:
        bullet(p, k['bul'])


def text(tf, t, k=None):
    for n, p in enumerate(t.split('\n') if isinstance(t, str) else t):
        q = tf.paragraphs[0] if n == 0 else tf.add_paragraph()
        o = dict(k or {})
        if isinstance(p, dict):
            o.update(p)
            p = o.pop('t', '')
        para(q, o)
        for r in [p] if isinstance(p, str) else p:
            s, ro = (r, o) if isinstance(r, str) else (r[0], {**o, **r[1]})
            for i, part in enumerate(s.split('\v')):
                if i:
                    q.add_line_break()
                if part:
                    if 'fld' in ro:
                        run = field(q, ro['fld'], part)
                    else:
                        run = q.add_run()
                        run.text = part
                    font(run.font, ro)
                    if 'hl' in ro:
                        run.hyperlink.address = ro['hl']
        if not p and 'sz' in o:
            empty_line(q, Pt(o['sz']))


def frame(sh, k):  # text-frame keys: wrap, fit ('none' | 'shape' | ('text', scale %)), anchor, m (margins), vert
    tf = sh.text_frame
    if 'wrap' in k:
        tf.word_wrap = k.pop('wrap')
    if 'fit' in k:
        f = k.pop('fit')
        f = f if isinstance(f, (list, tuple)) else (f,)
        if f[0] == 'text':
            autofit(tf, *f[1:])
        else:
            tf.auto_size = MSO_AUTO_SIZE.NONE if f[0] == 'none' else MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT
    if 'anchor' in k:
        tf.vertical_anchor = ANCHOR[k.pop('anchor')]
    if 'm' in k:
        tf.margin_left, tf.margin_top, tf.margin_right, tf.margin_bottom = (In(v) for v in k.pop('m'))
    if 'vert' in k or 'trot' in k:
        text_direction(tf, k.pop('vert', None), k.pop('trot', None))
    if 'cols' in k:
        text_columns(tf, k['cols'][0], In(k.pop('cols')[1]))
    if 'warp' in k:
        text_warp(tf, *k.pop('warp'))
    if 'd3t' in k:
        three_d(tf, **k.pop('d3t'))
    return tf


def _prst(sh, shape, adj=None):  # a preset outline python-pptx has no enum member for, and its adjustments
    preset(sh, shape, *(adj or ()))


def _click(sh, link=None, goto=None, jump=None):  # a web link, a jump to slide `goto`, or 'nextslide' ...
    if link:
        sh.click_action.hyperlink.address = link
    if goto:
        LINKS.append((sh, goto))
    if jump:
        click_jump(sh, jump)


def box(s, x, y, w, h, t=None, shape=None, fill=None, line=None, lw=None, dash=None, ends=None, adj=None, rot=0,
        flip=None, fx=None, geom=None, d3=None, link=None, goto=None, jump=None, **k):  # a text box or a shape ('roundRect', 'ellipse' ...)
    if shape or geom:
        sh = s.shapes.add_shape(SHAPES.get(shape, MSO_SHAPE.RECTANGLE), In(x), In(y), In(w), In(h))
        _no_style(sh)
        if geom:
            outline(sh, geom)
        elif shape not in SHAPES:
            _prst(sh, shape, adj)
        else:
            for i, v in enumerate((adj or ())[:len(sh.adjustments)]):
                sh.adjustments[i] = v / 100000
    else:
        sh = s.shapes.add_textbox(In(x), In(y), In(w), In(h))
    if rot:
        sh.rotation = rot
    if flip:
        mirror(sh, flip)
    if fx is not None:
        effects(sh, **fx)
    if fill is not None:
        pfill(sh, fill)
    if line is not None or lw or dash or ends:
        stroke(sh.line, line, lw, dash, ends)
    if d3:
        three_d(sh, **d3)
    _click(sh, link, goto, jump)
    frame(sh, k)
    if t is not None:
        text(sh.text_frame, t, k)
    return sh


def ph(s, idx, t=None, pos=None, fill=None, line=None, lw=None, dash=None, fx=None, d3=None, link=None, goto=None,
       jump=None, **k):  # a layout placeholder
    sh = s.placeholders[idx]
    if pos:
        sh.left, sh.top, sh.width, sh.height = (In(v) for v in pos)
    if fill is not None:
        pfill(sh, fill)
    if fx is not None:
        effects(sh, **fx)
    if d3:
        three_d(sh, **d3)
    _click(sh, link, goto, jump)
    if line is not None or lw or dash:
        stroke(sh.line, line, lw, dash)
    tf = frame(sh, k)
    if t is not None:
        tf.clear()
        text(tf, t, k)
    return sh


def pic(s, img, x, y, w, h, crop=None, shape=None, line=None, lw=None, rot=0, flip=None, fx=None, pfx=None, d3=None,
        link=None, goto=None, jump=None, fill=None):
    p = add_any_picture(s.shapes, img, In(x), In(y), In(w), In(h))
    if not w or not h:  # python-pptx reads a zero size as "the picture's own size"
        p.width, p.height = In(w), In(h)
    if fill:
        picture_back(p, fill)
    if d3:
        three_d(p, **d3)
    _click(p, link, goto, jump)
    if pfx:
        picture_effects(p, **pfx)
    if crop:
        p.crop_left, p.crop_top, p.crop_right, p.crop_bottom = crop
    if shape:
        if shape in SHAPES:
            p.auto_shape_type = SHAPES[shape]
        else:
            _prst(p, shape)
    if line is not None or lw:
        stroke(p.line, line, lw)
    if rot:
        p.rotation = rot
    if flip:
        mirror(p, flip)
    if fx is not None:
        effects(p, **fx)
    return p


def con(s, x1, y1, x2, y2, line=None, lw=None, dash=None, ends=None, shape=None, adj=None):
    kind = {'bentConnector3': MSO_CONNECTOR.ELBOW, 'curvedConnector3': MSO_CONNECTOR.CURVE}.get(shape, MSO_CONNECTOR.STRAIGHT)
    c = s.shapes.add_connector(kind, In(x1), In(y1), In(x2), In(y2))
    _no_style(c)
    if shape and kind == MSO_CONNECTOR.STRAIGHT or adj:
        _prst(c, shape or 'line', adj)
    stroke(c.line, line, lw, dash, ends)
    return c


def grp(s):
    return s.shapes.add_group_shape()


def movie(s, video, x, y, w, h, poster=None, mime='video/mp4', crop=None):  # a video, shown with its poster picture
    mv = s.shapes.add_movie(src(video), In(x), In(y), In(w), In(h), poster_frame_image=src(poster) if poster else None,
                            mime_type=mime)
    if crop:
        mv.crop_left, mv.crop_top, mv.crop_right, mv.crop_bottom = crop
    return mv


def tbl(s, x, y, w, h, rows, cw, rh, cs=None, merge=(), style=None, flags=None):
    """cs: cell styles for all cells '*', a row 'r0', a column 'c1' or a cell (r, c); bd: borders (sides, pt, colour)."""
    gf = s.shapes.add_table(len(rows), len(cw), In(x), In(y), In(w), In(h))
    t = gf.table
    for i, v in enumerate(cw):
        t.columns[i].width = In(v)
    for i, v in enumerate(rh):
        t.rows[i].height = In(v)
    if style:
        table_style(t, style)
    if flags is not None:
        for a, attr in (('firstRow', 'first_row'), ('firstCol', 'first_col'), ('lastRow', 'last_row'),
                        ('lastCol', 'last_col'), ('bandRow', 'horz_banding'), ('bandCol', 'vert_banding')):
            setattr(t, attr, a in flags.split())
    cs = cs or {}
    for r, row in enumerate(rows):
        for c, v in enumerate(row):
            k, cell = {**cs.get('*', {}), **cs.get(f'r{r}', {}), **cs.get(f'c{c}', {}), **cs.get((r, c), {})}, t.cell(r, c)
            if 'fill' in k:
                paint(cell.fill, k.pop('fill'))
            if 'anchor' in k:
                cell.vertical_anchor = ANCHOR[k.pop('anchor')]
            if 'vert' in k:
                cell_direction(cell, k.pop('vert'))
            if 'm' in k:
                cell.margin_left, cell.margin_top, cell.margin_right, cell.margin_bottom = (In(v) for v in k.pop('m'))
            for b in k.pop('bd', ()):
                cell_border(cell, b[0], Pt(b[1]) if len(b) > 1 else None, b[2] if len(b) > 2 else None)
            if v != '':
                text(cell.text_frame, v, k)
    for r, c, r2, c2 in merge:
        t.cell(r, c).merge(t.cell(r2, c2))
    return gf


def chart(s, kind, x, y, w, h, cats, series, legend=None, title=None, labels=None, colors=None, pts=None, nf=None,
          sz=None, hole=None, area=None, plotfill=None, style=None, combo=(), vary=None, vtitle=None, ctitle=None, **o):
    """series {name: values} ({name: [(x, y), ...]} for XY); combo [(kind, [series numbers], secondary axis)];
    pts colours of points (of series 0, or {series: [...]}); o: gap, overlap, grid, vaxis, caxis, vmin, vmax, smooth."""
    if kind.startswith(('XY_', 'BUBBLE')):
        cd = BubbleChartData() if kind.startswith('BUBBLE') else XyChartData()
        for name, points in series.items():
            sr = cd.add_series(name)
            for p in points:
                sr.add_data_point(*p)
    else:
        cd = CategoryChartData(number_format=nf or 'General')
        if cats and isinstance(cats[0], (tuple, list)):  # two levels: [(group, [category, ...]), ...]
            for group, leaves in cats:
                g = cd.add_category(group)
                for leaf in leaves:
                    g.add_sub_category(leaf)
        else:
            cd.categories = cats
        for name, vals in series.items():
            cd.add_series(name, vals)
    gf = s.shapes.add_chart(getattr(XL_CHART_TYPE, kind), In(x), In(y), In(w), In(h), cd)
    ch = gf.chart
    if legend is not None:
        ch.has_legend = bool(legend)
        if legend:
            ch.legend.position, ch.legend.include_in_layout = XL_LEGEND_POSITION.from_xml(legend), False
    if title is not None:
        ch.has_title = bool(title)
        if title:
            ch.chart_title.text_frame.text = title
    plot = ch.plots[0]
    if labels:
        lb = labels if isinstance(labels, dict) else {}
        each = kind.startswith(('XY_', 'BUBBLE')) or 'series' in lb  # labels per series (python-pptx: per plot)
        if not each:
            plot.has_data_labels = True
        for dl in [series_labels(ch.series[i]) for i in lb.get('series', range(len(series)))] if each else \
                [plot.data_labels]:
            if 'nf' in lb:
                dl.number_format, dl.number_format_is_linked = lb['nf'], False
            if 'pos' in lb:
                dl.position = XL_LABEL_POSITION.from_xml(lb['pos'])
            if 'sz' in lb:
                dl.font.size = Pt(lb['sz'])
            if 'c' in lb:
                color(dl.font.color, lb['c'])
            dl.show_percentage = bool(lb.get('pct'))
            dl.show_value = bool(lb.get('val', 1))
    kinds = [kind] * len(series)
    for k, idx, _ in combo:
        for i in idx:
            kinds[i] = k
    for i, (sr, c) in enumerate(zip(ch.series, colors or ())):
        if c:
            (stroke(sr.format.line, c) if kinds[i].startswith(('LINE', 'XY_', 'RADAR')) else paint(sr.format.fill, c))
    for si, cs in (pts.items() if isinstance(pts, dict) else enumerate([pts] if pts else [])):
        for i, c in enumerate(cs):
            if c:
                paint(ch.series[si].points[i].format.fill, c)
    if vary is not None:
        plot.vary_by_categories = vary
    for k, idx, second in combo:  # after the colours: they follow the series into their new plot
        combo_chart(ch, k, idx, second)
    for axis, t in (('value_axis', vtitle), ('category_axis', ctitle)):
        if t:
            getattr(ch, axis).has_title = True
            getattr(ch, axis).axis_title.text_frame.text = t
    for key, attr in (('gap', 'gap_width'), ('overlap', 'overlap')):
        if key in o:
            setattr(plot, attr, o[key])
    for sr in plot.series if 'smooth' in o else ():
        sr.smooth = o['smooth']
    for key, attr in (('grid', 'has_major_gridlines'), ('vaxis', 'visible'), ('vmin', 'minimum_scale'),
                      ('vmax', 'maximum_scale')):
        if key in o:
            setattr(ch.value_axis, attr, o[key])
    if 'caxis' in o:
        ch.category_axis.visible = o['caxis']
    if sz:
        ch.font.size = Pt(sz)
    if style:
        ch.chart_style = style
    if hole:
        doughnut_hole(ch, hole)
    if area:
        chart_area(ch, **area)
    if plotfill:
        chart_area(ch, **plotfill, plot=True)
    return gf


def bg(s, v=None, img=None, tile=False, pfx=None):  # slide background: a colour, a gradient or a picture
    if v is not None:
        paint(s.background.fill, v)
    if img:
        picture_background(s, img, tile, **(pfx or {}))


def notes(s, t):
    s.notes_slide.notes_text_frame.text = t


def add(prs, layout, keep=None, hidden=False, graphics=True):  # layout: name, index or (master, index)
    if isinstance(layout, str):
        layout = next(l for m in prs.slide_masters for l in m.slide_layouts if l.name == layout)
    elif isinstance(layout, tuple):
        layout = prs.slide_masters[layout[0]].slide_layouts[layout[1]]
    else:
        layout = prs.slide_layouts[layout]
    s = prs.slides.add_slide(layout)
    for p in list(s.placeholders) if keep is not None else ():
        if p.placeholder_format.idx not in keep:
            p.element.getparent().remove(p.element)
    if hidden:
        hide_slide(s)
    if not graphics:
        hide_layout_graphics(s)
    return s

