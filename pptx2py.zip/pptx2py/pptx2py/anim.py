"""Slide transitions and animations as Python values.

read_transition() and read_timing() turn a slide's XML into plain dicts and lists; pptx_helpers.transition()
and pptx_helpers.animate() write them back. verify.py uses the same readers to compare two decks.
"""
import re

P = 'http://schemas.openxmlformats.org/presentationml/2006/main'
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
MC = 'http://schemas.openxmlformats.org/markup-compatibility/2006'
EXT = {'http://schemas.microsoft.com/office/powerpoint/2010/main': 'p14',
       'http://schemas.microsoft.com/office/powerpoint/2012/main': 'p15',
       'http://schemas.microsoft.com/office/powerpoint/2015/09/main': 'p159'}
START = {'clickEffect': 'click', 'withEffect': 'with', 'afterEffect': 'after'}


def _ln(el):
    return el.tag.split('}')[-1] if isinstance(el.tag, str) else ''


def _ns(el):
    return el.tag[1:].split('}')[0] if isinstance(el.tag, str) and el.tag.startswith('{') else ''


def _kid(el, name, ns=P):
    return None if el is None else el.find(f'{{{ns}}}{name}')


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return v
    return int(f) if f == int(f) else round(f, 4)


# ── transitions ─────────────────────────────────────────────────────────────────────────────────────────────
def read_transition(sld):
    """{'kind': 'fade' | 'p14:vortex' ..., 'opts': {...}, 'speed', 'dur' (ms), 'click', 'after' (ms), 'sound'}."""
    tr = None
    for el in sld:
        if _ln(el) == 'transition':
            tr = el
        elif _ln(el) == 'AlternateContent' and len(el) and _kid(el[0], 'transition') is not None:
            tr = _kid(el[0], 'transition')
    if tr is None:
        return None
    out = {}
    kid = next((c for c in tr if _ln(c) not in ('sndAc', 'extLst')), None)
    if kid is not None:
        pre = EXT.get(_ns(kid))
        out['kind'] = f'{pre}:{_ln(kid)}' if pre else _ln(kid)
        opts = {k.split('}')[-1]: _num(v) for k, v in kid.attrib.items()}
        if opts:
            out['opts'] = opts
    else:
        out['kind'] = 'none'
    if tr.get('spd'):
        out['speed'] = tr.get('spd')
    dur = next((v for k, v in tr.attrib.items() if k.endswith('}dur')), None)
    if dur:
        out['dur'] = int(dur)
    if tr.get('advClick') in ('0', 'false'):
        out['click'] = False
    if tr.get('advTm'):
        out['after'] = int(tr.get('advTm'))
    if tr.find(f'.//{{{P}}}sndAc') is not None:
        out['sound'] = True
    return out


# ── animations ──────────────────────────────────────────────────────────────────────────────────────────────
def _val(v):
    """A p:val / p:to / p:from element -> Python value."""
    if v is None or not len(v):
        return None
    x = v[0]
    n = _ln(x)
    if n == 'fltVal':
        return float(x.get('val'))
    if n == 'intVal':
        return int(x.get('val'))
    if n == 'boolVal':
        return x.get('val') in ('1', 'true')
    if n == 'strVal':
        return x.get('val', '')
    if n == 'clrVal':
        return {'color': _colour(x)}
    return None


def _colour(el):
    for c in el.iter():
        n = _ln(c)
        if n == 'srgbClr':
            return c.get('val')
        if n == 'schemeClr':
            return c.get('val')
        if n == 'prstClr':
            return c.get('val')
    return None


def _target(cbhvr):
    t = _kid(cbhvr, 'tgtEl')
    if t is None:
        return None
    sp = _kid(t, 'spTgt')
    if sp is None:
        return {'other': _ln(t[0]) if len(t) else '?'}
    out = {'spid': sp.get('spid')}
    if sp.get('bg') in ('1', 'true'):
        out['bg'] = True
    tx = _kid(sp, 'txEl')
    if tx is not None and len(tx):
        r = tx[0]
        out['paras' if _ln(r) == 'pRg' else 'chars'] = (int(r.get('st', 0)), int(r.get('end', 0)))
    sub = next((x for x in (_kid(sp, 'subSp'), _kid(sp, 'graphicEl'), _kid(sp, 'oleChartEl'), _kid(sp, 'inkTgt'))
                if x is not None), None)
    if sub is not None:
        out['part'] = _ln(sub)
    return out


CTN_KEYS = {'dur': 'dur', 'accel': 'accel', 'decel': 'decel', 'autoRev': 'autorev', 'repeatCount': 'repeat',
            'fill': 'fill', 'spd': 'speed', 'restart': 'restart'}


def _ctn_opts(ctn, skip=()):
    d = {}
    for a, k in CTN_KEYS.items():
        v = ctn.get(a)
        if v is not None and k not in skip:
            d[k] = v if v in ('indefinite', 'hold', 'remove', 'freeze', 'transition', 'never', 'always',
                              'whenNotActive') else _num(v)
    cond = _kid(_kid(ctn, 'stCondLst'), 'cond')
    if cond is not None and cond.get('delay') not in (None, '0', 'indefinite'):
        d['delay'] = _num(cond.get('delay'))
    return d


def _behaviour(el, notes):
    n = _ln(el)
    cb = _kid(el, 'cBhvr')
    ctn = _kid(cb, 'cTn')
    d = {}
    names = [a.text for a in cb.findall(f'{{{P}}}attrNameLst/{{{P}}}attrName')] if cb is not None else []
    if n == 'set':
        d['set'] = names[0] if names else ''
        d['to'] = _val(_kid(el, 'to'))
    elif n == 'animEffect':
        d['filter'] = el.get('filter', '')
        if el.get('transition', 'in') != 'in':
            d['transition'] = el.get('transition')
        if el.get('prLst'):
            d['props'] = el.get('prLst')
    elif n == 'anim':
        d['anim'] = names[0] if names else ''
        keys = []
        for tav in el.findall(f'{{{P}}}tavLst/{{{P}}}tav'):
            k = [_num(tav.get('tm', 0)), _val(_kid(tav, 'val'))]
            if tav.get('fmla'):
                k.append(tav.get('fmla'))
            keys.append(tuple(k))
        if keys:
            d['keys'] = keys
        for a, k in (('calcmode', 'calc'), ('valueType', 'type'), ('from', 'from'), ('to', 'to'), ('by', 'by')):
            if el.get(a) is not None:
                d[k] = _num(el.get(a)) if k in ('from', 'to', 'by') else el.get(a)
    elif n == 'animScale':
        by, fr, to = _kid(el, 'by'), _kid(el, 'from'), _kid(el, 'to')
        d['scale'] = (_num(int(by.get('x', 100000)) / 1000), _num(int(by.get('y', 100000)) / 1000)) if by is not None \
            else None
        for e, k in ((fr, 'from'), (to, 'to')):
            if e is not None:
                d[k] = (_num(int(e.get('x', 100000)) / 1000), _num(int(e.get('y', 100000)) / 1000))
        if el.get('zoomContents') in ('1', 'true'):
            d['zoom'] = True
    elif n == 'animRot':
        d['rotate'] = _num(int(el.get('by', 0)) / 60000)
        for a in ('from', 'to'):
            if el.get(a):
                d[a] = _num(int(el.get(a)) / 60000)
    elif n == 'animMotion':
        d['motion'] = el.get('path', '')
        for a, k in (('origin', 'origin'), ('pathEditMode', 'edit'), ('ptsTypes', 'pts')):
            if el.get(a):
                d[k] = el.get(a)
        if el.get('rAng'):
            d['rang'] = _num(int(el.get('rAng')) / 60000)
        rc = _kid(el, 'rCtr')
        if rc is not None:
            d['center'] = (_num(rc.get('x')), _num(rc.get('y')))
    elif n == 'animClr':
        d['color'] = _colour(_kid(el, 'to')) if _kid(el, 'to') is not None else None
        d['attr'] = names[0] if names else 'style.color'
        for a, k in (('clrSpc', 'space'), ('dir', 'dir')):
            if el.get(a):
                d[k] = el.get(a)
        by = _kid(el, 'by')
        if by is not None and len(by):
            b = by[0]
            d['by'] = tuple(_num(int(b.get(x, 0)) / (60000 if x == 'h' else 1000)) for x in
                            (('h', 's', 'l') if _ln(b) == 'hsl' else ('r', 'g', 'b')))
            d['by_space'] = _ln(b)
    elif n == 'cmd':
        d['cmd'] = el.get('cmd', '')
        d['type'] = el.get('type', 'call')
    else:
        notes.append(f'"{n}" animation step')
        return None
    if cb is not None:
        for a, k in (('additive', 'additive'), ('accumulate', 'accumulate'), ('xfrmType', 'xfrm'), ('rctx', 'rctx'),
                     ('override', 'override')):
            if cb.get(a) is not None:
                d[k] = cb.get(a)
    if ctn is not None:
        d.update(_ctn_opts(ctn))
    tgt = _target(cb)
    if tgt:
        d['_target'] = tgt
    return d


def _effects(seq_ctn, notes):
    out = []
    for click in seq_ctn.findall(f'{{{P}}}childTnLst/{{{P}}}par'):
        for sub in _kid(click, 'cTn').findall(f'{{{P}}}childTnLst/{{{P}}}par'):
            for par in _kid(sub, 'cTn').findall(f'{{{P}}}childTnLst/{{{P}}}par'):
                ctn = _kid(par, 'cTn')
                eff = {'start': START.get(ctn.get('nodeType'), 'with')}
                if ctn.get('presetClass'):
                    eff['class'] = ctn.get('presetClass')
                if ctn.get('presetID'):
                    eff['preset'] = int(ctn.get('presetID'))
                if ctn.get('presetSubtype') not in (None, '0'):
                    eff['sub'] = int(ctn.get('presetSubtype'))
                if ctn.get('grpId') not in (None, '0'):
                    eff['grp'] = int(ctn.get('grpId'))
                eff.update(_ctn_opts(ctn, skip=('fill',)))
                steps = []
                for b in _kid(ctn, 'childTnLst') if _kid(ctn, 'childTnLst') is not None else ():
                    s = _behaviour(b, notes)
                    if s is not None:
                        steps.append(s)
                targets = [s.pop('_target') for s in steps if '_target' in s]
                main = next((t for t in targets if 'spid' in t), None)
                if main is None:
                    notes.append('an animation without a shape')
                    continue
                if main.get('part'):
                    notes.append(f'animation of part of a {main["part"]} (chart series, diagram parts ...)')
                eff['target'] = main
                eff['do'] = steps
                out.append(eff)
    return out


def read_timing(sld):
    """{'seqs': [{'trigger': spid | None, 'effects': [...]}, ...], 'builds': [...], 'notes': [...]} or None.
    An effect: {'target': {'spid', 'paras'?}, 'start': 'click'|'with'|'after', 'class', 'preset', 'sub', 'delay',
    'do': [steps]}; a step is one of set / filter / anim / scale / rotate / motion / color / cmd with its options."""
    tm = _kid(sld, 'timing')
    if tm is None:
        return None
    notes, seqs = [], []
    root = tm.find(f'{{{P}}}tnLst/{{{P}}}par/{{{P}}}cTn')
    for node in root.findall(f'{{{P}}}childTnLst/*') if root is not None else ():
        if _ln(node) == 'video':
            notes.append("the video's own playback settings (volume, looping, full screen): python-pptx's defaults "
                         'are used')
            continue
        if _ln(node) == 'audio':
            continue  # the sound itself is reported as left out
        if _ln(node) != 'seq':
            notes.append(f'"{_ln(node)}" timing node')
            continue
        ctn = _kid(node, 'cTn')
        kind = ctn.get('nodeType')
        trig = None
        if kind == 'interactiveSeq':
            sp = ctn.find(f'{{{P}}}stCondLst/{{{P}}}cond/{{{P}}}tgtEl/{{{P}}}spTgt')
            trig = sp.get('spid') if sp is not None else None
        elif kind != 'mainSeq':
            notes.append(f'"{kind}" animation sequence')
            continue
        effs = _effects(ctn, notes)
        if effs:
            seqs.append({'trigger': trig, 'effects': effs})
    builds = []
    for b in tm.findall(f'{{{P}}}bldLst/*'):
        if _ln(b) == 'bldP':
            d = {'spid': b.get('spid'), 'grp': int(b.get('grpId', 0))}
            for a, k in (('build', 'build'), ('animBg', 'bg'), ('uiExpand', 'expand'), ('rev', 'reverse'),
                         ('advAuto', 'auto')):
                if b.get(a) is not None:
                    d[k] = b.get(a) in ('1', 'true') if k in ('bg', 'expand', 'reverse') else b.get(a)
            builds.append(d)
        elif _ln(b) in ('bldGraphic', 'bldDgm', 'bldOleChart'):
            notes.append({'bldGraphic': 'chart built series by series', 'bldDgm': 'SmartArt built one part at a time',
                          'bldOleChart': 'embedded chart built series by series'}[_ln(b)])
    if not seqs and not notes:
        return None
    return {'seqs': seqs, 'builds': builds, 'notes': notes}


def summary(timing, spid_map=None):
    """A comparable digest: [(trigger, start, class, preset, sub, target, [step kinds]), ...]."""
    out = []
    for seq in (timing or {}).get('seqs', ()):
        trig = seq['trigger']
        if spid_map is not None and trig is not None:
            trig = spid_map.get(trig, '?')
        for e in seq['effects']:
            t = e['target']['spid']
            if spid_map is not None:
                t = spid_map.get(t, '?')
            out.append((trig, e['start'], e.get('class'), e.get('preset'), e.get('sub', 0), t,
                        e['target'].get('paras'), tuple(sorted(k for s in e['do'] for k in s
                                                               if k in ('set', 'filter', 'anim', 'scale', 'rotate',
                                                                        'motion', 'color', 'cmd')))))
    return out


SPIDS = re.compile(r'spid="(\d+)"')
