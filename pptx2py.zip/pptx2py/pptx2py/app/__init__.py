"""The pptx2py desktop app (PySide6)."""
import sys


def main(deck=None):
    from PySide6.QtWidgets import QApplication

    from .theme import mark, ui_font
    from .window import Window
    if sys.platform.startswith('win'):
        try:  # its own taskbar icon instead of python's
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('pptx2py.app')
        except Exception:  # noqa: BLE001
            pass
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName('pptx2py')
    app.setOrganizationName('pptx2py')
    app.setWindowIcon(mark())
    app.setStyle('Fusion')
    app.setFont(ui_font())
    w = Window(deck)
    w.show()
    return app.exec()
