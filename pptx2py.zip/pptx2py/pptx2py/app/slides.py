"""The slide list: a wireframe of every slide, drawn from where its shapes sit."""
from PySide6.QtCore import QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QListWidget, QListWidgetItem, QPushButton, QStyle,
                               QStyledItemDelegate, QVBoxLayout, QWidget)

from .theme import T, icon
from .widgets import label

PAD, NUM = 12, 24  # outer padding, width of the slide-number column


def _qc(spec, alpha=1.0):
    if not spec:
        return None
    c = QColor(spec[0])
    c.setAlphaF(spec[1] * alpha)
    return c


def paint_slide(p, r, slide):
    """Draw a slide as a wireframe: its background, shapes by kind and colour, text as bars."""
    bg = _qc(slide['bg']) or QColor('#FFFFFF')
    bg.setAlpha(255)
    dark = bg.lightnessF() < 0.45
    path = QPainterPath()
    path.addRoundedRect(r, 3, 3)
    p.save()
    p.setClipPath(path)
    p.fillRect(r, bg)
    neutral = QColor('#8E97A4') if not dark else QColor('#AEB6C2')
    ink = QColor(255, 255, 255, 190) if dark else QColor(54, 60, 72, 165)
    accent = QColor(T['accent'])
    for s in slide['shapes']:
        rr = QRectF(r.x() + s['x'] * r.width(), r.y() + s['y'] * r.height(),
                    max(1.0, s['w'] * r.width()), max(1.0, s['h'] * r.height()))
        p.save()
        if s['rot']:
            p.translate(rr.center())
            p.rotate(s['rot'])
            p.translate(-rr.center())
        k, fill, line = s['k'], _qc(s['fill']), _qc(s['line'])
        p.setBrush(Qt.NoBrush)
        if k == 'line':
            p.setPen(QPen(line or neutral, 1.1))
            a, b = rr.topLeft(), rr.bottomRight()
            if s['flip'][0] != s['flip'][1]:
                a, b = rr.topRight(), rr.bottomLeft()
            p.drawLine(a, b)
        elif k == 'pic':
            p.setPen(Qt.NoPen)
            p.setBrush(QColor('#C5CDD8') if not dark else QColor('#596170'))
            p.drawRect(rr)
            if rr.width() > 14 and rr.height() > 10:  # a small landscape glyph
                m = min(rr.width(), rr.height()) * 0.22
                g = QColor('#8F99A8') if not dark else QColor('#8A93A3')
                p.setBrush(g)
                p.drawPolygon([QPointF(rr.left() + m, rr.bottom() - m), QPointF(rr.center().x() - m * 0.2, rr.top() + m * 1.6),
                               QPointF(rr.center().x() + m * 0.9, rr.bottom() - m)])
                p.drawEllipse(QPointF(rr.right() - m * 1.4, rr.top() + m * 1.3), m * 0.45, m * 0.45)
        elif k == 'table':
            p.setPen(QPen(neutral, 0.8))
            p.setBrush(QColor(neutral.red(), neutral.green(), neutral.blue(), 40))
            p.drawRect(rr)
            p.fillRect(QRectF(rr.x(), rr.y(), rr.width(), rr.height() / 4), QColor(neutral.red(), neutral.green(),
                                                                               neutral.blue(), 110))
            for i in (1, 2, 3):
                p.drawLine(QPointF(rr.x(), rr.y() + rr.height() * i / 4), QPointF(rr.right(), rr.y() + rr.height() * i / 4))
                p.drawLine(QPointF(rr.x() + rr.width() * i / 4, rr.y()), QPointF(rr.x() + rr.width() * i / 4, rr.bottom()))
        elif k == 'chart':
            p.setPen(QPen(neutral, 0.8))
            p.drawLine(rr.bottomLeft(), rr.bottomRight())
            bw = rr.width() / 9
            for i, v in enumerate((0.45, 0.72, 0.58, 0.9)):
                c = QColor(accent)
                c.setAlphaF(0.55 + 0.1 * i)
                p.fillRect(QRectF(rr.x() + bw * (1 + 2 * i), rr.bottom() - rr.height() * v * 0.9, bw, rr.height() * v * 0.9), c)
        else:
            outline = line or (None if fill or s['text'] else neutral)
            p.setPen(QPen(outline, 0.9, Qt.SolidLine if line or k != 'object' else Qt.DashLine) if outline else Qt.NoPen)
            if k == 'object':
                p.setPen(QPen(neutral, 0.9, Qt.DashLine))
            p.setBrush(fill or Qt.NoBrush)
            p.drawEllipse(rr) if k == 'ellipse' else p.drawRect(rr)
        if s['text'] and k not in ('pic', 'table', 'chart', 'line'):
            on = ink
            if fill and fill.alphaF() > 0.4:
                on = QColor(255, 255, 255, 200) if fill.lightnessF() < 0.55 else QColor(40, 44, 52, 170)
            lines = 1 if s['title'] else min(4, 1 + s['text'] // 50)
            bh = max(1.3, min(rr.height() * (0.2 if s['title'] else 0.1), 3.4 if s['title'] else 2.2))
            gap = bh * 1.9
            pad = min(rr.width(), rr.height()) * 0.08 + 1
            total = lines * gap - (gap - bh)
            y = rr.center().y() - total / 2 if s['title'] or lines == 1 and fill else rr.y() + pad + 1
            p.setPen(Qt.NoPen)
            p.setBrush(on)
            for i in range(lines):
                if y + bh > rr.bottom() + 0.5:
                    break
                w = (rr.width() - 2 * pad) * ((0.72 if s['title'] else 0.9) - 0.15 * (i % 3))
                p.drawRoundedRect(QRectF(rr.x() + pad, y, max(2.0, w), bh), bh / 2, bh / 2)
                y += gap
        p.restore()
    p.restore()
    p.setPen(QPen(QColor(T['border']), 1))
    p.setBrush(Qt.NoBrush)
    p.drawRoundedRect(r.adjusted(0.5, 0.5, -0.5, -0.5), 3, 3)


class SlideDelegate(QStyledItemDelegate):
    def __init__(self, view):
        super().__init__(view)
        self.view, self.cache = view, {}

    def geometry(self, width, aspect):
        tw = max(80, width - PAD * 2 - NUM)
        return tw, tw / aspect

    def sizeHint(self, option, index):
        s = index.data(Qt.UserRole)
        tw, th = self.geometry(self.view.viewport().width(), s['aspect'])
        return QSize(int(tw), int(th + 34))

    def paint(self, p, option, index):
        s = index.data(Qt.UserRole)
        r = option.rect
        sel, hover = option.state & QStyle.State_Selected, option.state & QStyle.State_MouseOver
        tw, th = self.geometry(r.width(), s['aspect'])
        thumb = QRectF(r.x() + PAD + NUM, r.y() + 8, tw, th)
        p.save()
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QColor(T['accent'] if sel else T['muted']))
        f = p.font()
        f.setBold(bool(sel))
        p.setFont(f)
        p.drawText(QRectF(r.x(), thumb.y(), PAD + NUM - 6, 18), Qt.AlignRight | Qt.AlignTop, str(s['n']))
        key = (s['n'], int(tw), int(th), T['name'], p.device().devicePixelRatioF())
        pm = self.cache.get(key)
        if pm is None:
            dpr = key[-1]
            pm = QPixmap(int(tw * dpr) + 2, int(th * dpr) + 2)
            pm.setDevicePixelRatio(dpr)
            pm.fill(Qt.transparent)
            q = QPainter(pm)
            q.setRenderHint(QPainter.Antialiasing)
            paint_slide(q, QRectF(0.5, 0.5, tw - 1, th - 1), s)
            q.end()
            self.cache[key] = pm
        if s['hidden']:
            p.setOpacity(0.45)
        p.drawPixmap(thumb.topLeft(), pm)
        p.setOpacity(1)
        if sel or hover:
            p.setPen(QPen(QColor(T['accent'] if sel else T['strong']), 2 if sel else 1))
            p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(thumb.adjusted(-2, -2, 2, 2), 5, 5)
        cap = QRectF(thumb.x(), thumb.bottom() + 5, tw, 18)
        if s['hidden']:
            p.setPen(QColor(T['muted']))
            p.drawText(cap, Qt.AlignRight | Qt.AlignVCenter, 'Hidden')
            cap.setRight(cap.right() - p.fontMetrics().horizontalAdvance('Hidden') - 8)
        f.setBold(False)
        p.setFont(f)
        p.setPen(QColor(T['text'] if sel else T['muted']))
        p.drawText(cap, Qt.AlignLeft | Qt.AlignVCenter, p.fontMetrics().elidedText(s['title'], Qt.ElideRight,
                                                                                    int(cap.width())))
        p.restore()


class SlideStrip(QListWidget):
    """Slides in order; click to select (Ctrl / Shift for more), double-click to convert one."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('Strip')
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setMouseTracking(True)
        self.setUniformItemSizes(True)
        self.setSpacing(2)
        self.delegate = SlideDelegate(self)
        self.setItemDelegate(self.delegate)

    def set_slides(self, slides):
        self.clear()
        self.delegate.cache.clear()
        for s in slides:
            it = QListWidgetItem()
            it.setData(Qt.UserRole, s)
            it.setToolTip(f'Slide {s["n"]}: {s["title"]}\n{s["count"]} shapes' + ('  (hidden)' if s['hidden'] else ''))
            self.addItem(it)

    def selected_numbers(self):
        return sorted(it.data(Qt.UserRole)['n'] for it in self.selectedItems())

    def restyle(self):
        self.delegate.cache.clear()
        self.viewport().update()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.delegate.cache.clear()
        self.doItemsLayout()


class EmptyDeck(QWidget):
    """What the slide panel says before a deck is open."""
    openClicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 20, 20, 20)
        lay.addStretch(2)
        self.pic = label('')
        self.pic.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.pic)
        t = label('Open a PowerPoint deck', 'EmptyTitle')
        t.setAlignment(Qt.AlignCenter)
        lay.addWidget(t)
        x = label('Drop a .pptx file anywhere in this window, or choose one.', 'EmptyText', wrap=True)
        x.setAlignment(Qt.AlignCenter)
        lay.addWidget(x)
        lay.addSpacing(6)
        self.btn = QPushButton('Open deck…')
        self.btn.setCursor(Qt.PointingHandCursor)
        self.btn.clicked.connect(self.openClicked)
        lay.addWidget(self.btn, 0, Qt.AlignHCenter)
        lay.addStretch(3)
        self.restyle()

    def restyle(self):
        self.pic.setPixmap(icon('slides', T['faint'], 40).pixmap(40, 40))
        self.btn.setIcon(icon('folder'))
