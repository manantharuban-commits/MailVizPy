"""Colours, fonts, icons and the style sheet. Graphite surfaces with one amber accent, in dark and light."""
import sys

from PySide6.QtCore import QByteArray, Qt
from PySide6.QtGui import QFont, QFontDatabase, QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

DARK = dict(
    name='dark', bg='#16181C', surface='#1D2025', raised='#252930', hover='#2D323B', border='#30353F',
    strong='#474E5A', text='#E8EAEE', muted='#9AA1AD', faint='#6F7684',
    accent='#F0A63A', accent_hover='#F6B657', accent_press='#DB9126', on_accent='#1B1305', accent_soft='#3A2F1D',
    danger='#F2756A', danger_soft='#3A2426', success='#5CC98E', success_soft='#1E3327', info='#7FB0F0',
    info_soft='#212B39', editor='#141619', gutter='#646B78', line='#1B1E24', selection='#4A3A1E', find='#6A5022',
    kw='#F0A63A', helper='#79B2FF', str='#A5D48F', num='#D2A8FF', com='#7D8594', defn='#FFD68A', arg='#A9B1BE')
LIGHT = dict(
    name='light', bg='#ECEEF1', surface='#F7F8FA', raised='#FFFFFF', hover='#EEF0F3', border='#DADEE4',
    strong='#BEC5CF', text='#1B1F26', muted='#5D6675', faint='#8C94A0',
    accent='#A85A0C', accent_hover='#94500B', accent_press='#7E4409', on_accent='#FFFFFF', accent_soft='#F6E7D3',
    danger='#C2352B', danger_soft='#FBEAE8', success='#23804F', success_soft='#E3F3EA', info='#2F62B0',
    info_soft='#E7EEF8', editor='#FFFFFF', gutter='#9AA1AC', line='#F8F5EF', selection='#F5DDB9', find='#FBE0AE',
    kw='#A8520A', helper='#1D5FC2', str='#2F7A35', num='#7E3FC8', com='#737B88', defn='#7A4300', arg='#4F5867')
T = dict(DARK)  # the theme in use; widgets read it when they paint


def use(name):
    T.clear()
    T.update(DARK if name == 'dark' else LIGHT)


ICONS = {
    'folder': '<path d="M3 7.5A1.5 1.5 0 0 1 4.5 6H9l2 2h8.5A1.5 1.5 0 0 1 21 9.5v8A1.5 1.5 0 0 1 19.5 19h-15A1.5 1.5 0 0 1 3 '
              '17.5z"/>',
    'paste': '<rect x="5.5" y="4.5" width="13" height="16" rx="2"/><path d="M9 4.5V3.8a.8.8 0 0 1 .8-.8h4.4a.8.8 0 0 1 '
             '.8.8v.7M9 10h6M9 13.5h6M9 17h3.5"/>',
    'code-file': '<path d="M13.5 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.5z"/><path d="M13.5 3v5.5H19"/>'
                 '<path d="M10.3 12.2 8.5 14l1.8 1.8M13.7 12.2l1.8 1.8-1.8 1.8"/>',
    'copy': '<rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2"/><path d="M15.5 8.5V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 '
            '2v7.5a2 2 0 0 0 2 2h2.5"/>',
    'save': '<path d="M12 4v10.5M7.5 10.5 12 15l4.5-4.5M5 19.5h14"/>',
    'play': '<path d="M8 5.8v12.4a.6.6 0 0 0 .9.5l9.8-6.2a.6.6 0 0 0 0-1L8.9 5.3a.6.6 0 0 0-.9.5z" fill="currentColor"/>',
    'code': '<path d="M9 7.5 4.5 12 9 16.5M15 7.5l4.5 4.5-4.5 4.5"/>',
    'sun': '<circle cx="12" cy="12" r="4"/><path d="M12 2.8v2M12 19.2v2M2.8 12h2M19.2 12h2M5.5 5.5l1.4 1.4M17.1 17.1l1.4 '
           '1.4M5.5 18.5l1.4-1.4M17.1 6.9l1.4-1.4"/>',
    'moon': '<path d="M19.5 14.6A7.8 7.8 0 1 1 9.4 4.5a6.2 6.2 0 0 0 10.1 10.1z"/>',
    'search': '<circle cx="10.8" cy="10.8" r="6.3"/><path d="m15.5 15.5 4.5 4.5"/>',
    'x': '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    'up': '<path d="M6.5 14.5 12 9l5.5 5.5"/>',
    'down': '<path d="M6.5 9.5 12 15l5.5-5.5"/>',
    'terminal': '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 10l2.8 2L7 14M12.5 15h4.5"/>',
    'external': '<path d="M14 4h6v6M20 4l-8.5 8.5M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 '
                '1 5.5 6H10"/>',
    'check': '<path d="M5 12.5 9.5 17 19 7.5"/>',
    'alert': '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.8v5M12 16.2v.1"/>',
    'info': '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.2M12 7.8v.1"/>',
    'slides': '<rect x="3" y="4.5" width="18" height="12" rx="1.5"/><path d="M12 16.5v3M8.5 19.5h7"/>',
    'arrow-goto': '<path d="M5 12h12M13 7.5l4.5 4.5-4.5 4.5"/>',
}


def icon(name, color=None, size=18):
    """A crisp line icon in the given colour (default: the text colour)."""
    color = color or T['text']
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="{color}" '
           f'stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" color="{color}">{ICONS[name]}</svg>')
    renderer, ic = QSvgRenderer(QByteArray(svg.encode())), QIcon()
    for scale in (1, 2, 3):
        pm = QPixmap(size * scale, size * scale)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        renderer.render(p)
        p.end()
        pm.setDevicePixelRatio(scale)
        ic.addPixmap(pm)
    return ic


def mark(size=26):
    """The app's mark: a slide with code brackets on an amber tile."""
    a, on = DARK['accent'], DARK['on_accent']
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect x="1" y="1" width="22" height="22" rx="5.5" '
           f'fill="{a}"/><rect x="5" y="6.5" width="14" height="9.5" rx="1.3" fill="none" stroke="{on}" stroke-width="1.5"/>'
           f'<path d="M10.2 9.4 8.6 11.2l1.6 1.8M13.8 9.4l1.6 1.8-1.6 1.8" fill="none" stroke="{on}" stroke-width="1.4" '
           f'stroke-linecap="round" stroke-linejoin="round"/><path d="M9 18.5h6" stroke="{on}" stroke-width="1.5" '
           f'stroke-linecap="round"/></svg>')
    renderer, ic = QSvgRenderer(QByteArray(svg.encode())), QIcon()
    for s in (size, size * 2, 64, 128, 256):
        pm = QPixmap(s, s)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        renderer.render(p)
        p.end()
        ic.addPixmap(pm)
    return ic


def _first(names, fallback):
    fams = set(QFontDatabase.families())
    return next((n for n in names if n in fams), fallback)


def ui_font():
    f = QFont(_first(['Segoe UI Variable Text', 'Segoe UI', 'Inter', 'Cantarell', 'Noto Sans', 'DejaVu Sans'],
                     QFont().family()) if sys.platform != 'darwin' else QFont().family())
    f.setPointSizeF(10)
    return f


def code_font():
    f = QFont(_first(['Cascadia Code', 'Cascadia Mono', 'JetBrains Mono', 'Consolas', 'SF Mono', 'Menlo',
                      'DejaVu Sans Mono'], 'monospace'))
    f.setStyleHint(QFont.Monospace)
    f.setPointSizeF(10.5)
    return f


def qss(t):
    return f"""
QWidget {{ color: {t['text']}; }}
QMainWindow, #Root {{ background: {t['bg']}; }}
#Header {{ background: {t['surface']}; border-bottom: 1px solid {t['border']}; }}
#Side {{ background: {t['surface']}; }}
#Options, #OptionsScroll, #OptionsInner {{ background: {t['surface']}; }}
#Center {{ background: {t['editor']}; }}
#EditorHead {{ background: {t['surface']}; border-bottom: 1px solid {t['border']}; }}
#SideHead {{ border-bottom: 1px solid {t['border']}; }}
#AppName {{ font-size: 11pt; font-weight: 600; }}
#DeckName, #FileName {{ font-weight: 600; }}
#Muted {{ color: {t['muted']}; }}
#Hint {{ color: {t['muted']}; font-size: 9pt; }}
#Section {{ font-weight: 600; }}
#Dirty {{ color: {t['accent']}; }}
#Divider {{ background: {t['border']}; }}
#EmptyTitle {{ font-size: 12pt; font-weight: 600; }}
#EmptyText {{ color: {t['muted']}; }}

QPushButton, QToolButton {{ background: {t['raised']}; border: 1px solid {t['border']}; border-radius: 6px;
    padding: 5px 11px; }}
QPushButton:hover, QToolButton:hover {{ background: {t['hover']}; border-color: {t['strong']}; }}
QPushButton:pressed, QToolButton:pressed {{ background: {t['border']}; }}
QPushButton:focus, QToolButton:focus {{ border-color: {t['accent']}; }}
QPushButton:disabled, QToolButton:disabled {{ color: {t['faint']}; background: {t['surface']}; border-color: {t['border']}; }}
QPushButton::menu-indicator {{ subcontrol-position: right center; right: 6px; width: 0; }}
QPushButton#Primary {{ background: {t['accent']}; color: {t['on_accent']}; border: 1px solid {t['accent']};
    font-weight: 600; padding: 9px 14px; }}
QPushButton#Primary:hover {{ background: {t['accent_hover']}; border-color: {t['accent_hover']}; }}
QPushButton#Primary:pressed {{ background: {t['accent_press']}; }}
QPushButton#Primary:focus {{ border: 1px solid {t['text']}; }}
QPushButton#Primary:disabled {{ background: {t['border']}; color: {t['faint']}; border-color: {t['border']}; }}
QPushButton#Accent {{ background: transparent; color: {t['accent']}; border: 1px solid {t['accent']}; font-weight: 600; }}
QPushButton#Accent:hover {{ background: {t['accent_soft']}; }}
QPushButton#Accent:disabled {{ color: {t['faint']}; border-color: {t['border']}; }}
QPushButton#Flat, QToolButton#Flat {{ background: transparent; border: 1px solid transparent; padding: 4px 8px; }}
QPushButton#Flat:hover, QToolButton#Flat:hover {{ background: {t['hover']}; }}
QPushButton#Flat:focus, QToolButton#Flat:focus {{ border-color: {t['accent']}; }}
QToolButton#Flat:checked {{ background: {t['accent_soft']}; }}

#Seg {{ background: {t['bg']}; border: 1px solid {t['border']}; border-radius: 7px; }}
#Seg QPushButton {{ background: transparent; border: 1px solid transparent; border-radius: 5px; padding: 5px 6px;
    color: {t['muted']}; }}
#Seg QPushButton:hover {{ color: {t['text']}; }}
#Seg QPushButton:focus {{ border-color: {t['accent']}; }}
#Seg QPushButton:checked {{ background: {t['raised']}; border-color: {t['border']}; color: {t['text']}; font-weight: 600; }}

QLineEdit {{ background: {t['raised']}; border: 1px solid {t['border']}; border-radius: 6px; padding: 6px 8px;
    selection-background-color: {t['selection']}; selection-color: {t['text']}; }}
QLineEdit:focus {{ border-color: {t['accent']}; }}
QLineEdit[bad="true"] {{ border-color: {t['danger']}; }}

QListWidget#Strip {{ background: {t['surface']}; border: none; outline: 0; }}
QPlainTextEdit#Editor {{ background: {t['editor']}; border: none; selection-background-color: {t['selection']};
    selection-color: {t['text']}; }}
#OutputPanel {{ background: {t['surface']}; border-top: 1px solid {t['border']}; }}
QPlainTextEdit#Output {{ background: {t['surface']}; border: none; color: {t['muted']}; }}

QScrollBar:vertical {{ background: transparent; width: 12px; margin: 2px 2px 2px 2px; }}
QScrollBar:horizontal {{ background: transparent; height: 12px; margin: 2px; }}
QScrollBar::handle {{ background: {t['strong']}; border-radius: 4px; min-height: 28px; min-width: 28px; }}
QScrollBar::handle:hover {{ background: {t['faint']}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}
QAbstractScrollArea::corner {{ background: transparent; }}

QSplitter::handle {{ background: {t['border']}; }}
QMenu {{ background: {t['raised']}; border: 1px solid {t['border']}; border-radius: 8px; padding: 4px; }}
QMenu::item {{ padding: 6px 22px 6px 10px; border-radius: 5px; }}
QMenu::item:selected {{ background: {t['accent_soft']}; }}
QToolTip {{ background: {t['raised']}; color: {t['text']}; border: 1px solid {t['border']}; padding: 4px 6px; }}
QStatusBar {{ background: {t['surface']}; border-top: 1px solid {t['border']}; }}
QStatusBar::item {{ border: none; }}
QStatusBar QLabel {{ color: {t['muted']}; padding: 0 8px; }}

#Banner {{ border-radius: 8px; border: 1px solid {t['border']}; background: {t['info_soft']}; }}
#Banner[kind="error"] {{ background: {t['danger_soft']}; border-color: {t['danger']}; }}
#Banner[kind="success"] {{ background: {t['success_soft']}; border-color: {t['success']}; }}
#Banner[kind="info"] {{ background: {t['info_soft']}; border-color: {t['info']}; }}
#Banner QPushButton {{ padding: 4px 10px; }}
#Toast {{ background: {t['text']}; color: {t['bg']}; border-radius: 8px; padding: 8px 14px; }}
#FindBar {{ background: {t['surface']}; border-bottom: 1px solid {t['border']}; }}
QMessageBox {{ background: {t['surface']}; }}
"""
