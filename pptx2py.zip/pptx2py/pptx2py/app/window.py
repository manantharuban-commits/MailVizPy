"""The main window: the deck's slides on the left, the code in the middle, how to convert on the right."""
import html
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from pathlib import Path

from PySide6.QtCore import QEvent, QObject, QSettings, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QGuiApplication, QKeySequence, QPalette, QShortcut
from PySide6.QtWidgets import (QApplication, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMenu,
                               QMessageBox, QPlainTextEdit, QPushButton, QScrollArea, QSplitter, QStackedWidget,
                               QStatusBar, QToolButton, QVBoxLayout, QWidget)

from ..convert import HELPERS, convert, parse_slides, run_code
from ..preview import wireframes
from ..verify import compare
from . import theme
from .editor import CodeEditor, FindBar
from .slides import EmptyDeck, SlideStrip
from .theme import T, code_font, icon, mark, qss
from .widgets import Banner, BusyLine, Segmented, Switch, Toast, divider, label, repolish

DECKS, CODE = ('.pptx', '.pptm'), ('.py',)


def open_file(p):
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(p)))


def reveal(p):
    p = str(Path(p))
    if sys.platform.startswith('win'):
        subprocess.Popen(['explorer', '/select,', p])  # noqa: S603, S607
    elif sys.platform == 'darwin':
        subprocess.Popen(['open', '-R', p])  # noqa: S603, S607
    else:
        open_file(Path(p).parent)


class Bridge(QObject):
    done = Signal(object, object, object)  # callback, result, error


class Window(QMainWindow):
    def __init__(self, deck=None):
        super().__init__()
        self.settings = QSettings('pptx2py', 'pptx2py')
        self.deck, self.files, self.workdir, self.code_dir, self.code_name = None, {}, None, None, None
        self.busy, self.errors, self.temps, self.iconed = False, 0, [], []
        self.bridge = Bridge()
        self.bridge.done.connect(self._finished)
        self.setWindowTitle('pptx2py')
        self.setWindowIcon(mark())
        self.setAcceptDrops(True)
        self.setMinimumSize(1080, 660)
        self.build_ui()
        self.restore()
        self.shortcuts()
        self.update_convert()
        self.set_file_label()
        self.code_changed()
        QTimer.singleShot(0, self.editor.setFocus)
        if deck:
            QTimer.singleShot(0, lambda: self.load_deck(deck))

    # ── building blocks ──
    def button(self, text, name, fn, kind=None, tip=None, colour='text'):
        b = QPushButton(text)
        if kind:
            b.setObjectName(kind)
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(fn)
        if tip:
            b.setToolTip(tip)
            b.setAccessibleName(tip.split(' (')[0])
        if name:
            self.iconed.append((b, name, colour))
        return b

    def build_ui(self):
        root = QWidget(objectName='Root')
        rv = QVBoxLayout(root)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.setSpacing(0)
        rv.addWidget(self.build_header())
        self.busy_line = BusyLine()
        rv.addWidget(self.busy_line)
        self.split = QSplitter(Qt.Horizontal)
        self.split.setHandleWidth(1)
        self.split.setChildrenCollapsible(False)
        self.split.addWidget(self.build_side())
        self.split.addWidget(self.build_center())
        self.split.addWidget(self.build_options())
        self.split.setStretchFactor(1, 1)
        rv.addWidget(self.split, 1)
        self.setCentralWidget(root)
        self.build_status()

    def build_header(self):
        head = QFrame(objectName='Header')
        head.setFixedHeight(54)
        h = QHBoxLayout(head)
        h.setContentsMargins(14, 0, 12, 0)
        h.setSpacing(10)
        logo = QLabel()
        logo.setPixmap(mark().pixmap(26, 26))
        sep = QFrame(objectName='Divider')
        sep.setFixedSize(1, 22)
        self.deck_name, self.deck_meta = label('No deck open', 'DeckName'), label('', 'Muted')
        for w in (logo, label('pptx2py', 'AppName')):
            h.addWidget(w)
        h.addSpacing(6)
        h.addWidget(sep)
        h.addSpacing(6)
        h.addWidget(self.deck_name)
        h.addWidget(self.deck_meta)
        h.addStretch(1)
        h.addWidget(self.button('Open deck…', 'folder', self.open_deck, tip='Open a PowerPoint deck (Ctrl+O)'))
        self.theme_btn = self.button('', None, self.toggle_theme, 'Flat', 'Switch between light and dark (Ctrl+Shift+L)')
        h.addWidget(self.theme_btn)
        return head

    def build_side(self):
        side = QFrame(objectName='Side')
        side.setMinimumWidth(210)
        sv = QVBoxLayout(side)
        sv.setContentsMargins(0, 0, 0, 0)
        sv.setSpacing(0)
        sh = QFrame(objectName='SideHead')
        sh.setFixedHeight(49)
        shl = QHBoxLayout(sh)
        shl.setContentsMargins(16, 0, 8, 0)
        shl.setSpacing(6)
        self.slide_count = label('', 'Muted')
        shl.addWidget(label('Slides', 'Section'))
        shl.addWidget(self.slide_count)
        shl.addStretch(1)
        self.all_btn = self.button('All', None, lambda: self.strip.selectAll(), 'Flat', 'Select every slide (Ctrl+A)')
        self.none_btn = self.button('None', None, lambda: self.strip.clearSelection(), 'Flat', 'Clear the selection')
        shl.addWidget(self.all_btn)
        shl.addWidget(self.none_btn)
        self.all_btn.hide()
        self.none_btn.hide()
        sv.addWidget(sh)
        self.side_stack = QStackedWidget()
        self.empty_deck = EmptyDeck()
        self.empty_deck.openClicked.connect(self.open_deck)
        self.strip = SlideStrip()
        self.strip.itemSelectionChanged.connect(self.selection_changed)
        self.strip.itemClicked.connect(self.slide_clicked)
        self.strip.itemDoubleClicked.connect(lambda it: self.convert(only=it.data(Qt.UserRole)['n']))
        self.side_stack.addWidget(self.empty_deck)
        self.side_stack.addWidget(self.strip)
        sv.addWidget(self.side_stack, 1)
        return side

    def build_center(self):
        center = QWidget(objectName='Center')
        cv = QVBoxLayout(center)
        cv.setContentsMargins(0, 0, 0, 0)
        cv.setSpacing(0)
        eh = QFrame(objectName='EditorHead')
        eh.setFixedHeight(49)
        e = QHBoxLayout(eh)
        e.setContentsMargins(14, 0, 10, 0)
        e.setSpacing(4)
        self.file_ico = QLabel()
        self.file_name, self.dirty, self.file_meta = label('', 'FileName'), label('●', 'Dirty'), label('', 'Muted')
        self.dirty.setToolTip('Changed since it was converted, opened or saved')
        for w in (self.file_ico, self.file_name, self.dirty):
            e.addWidget(w)
        e.addSpacing(6)
        e.addWidget(self.file_meta)
        e.addStretch(1)
        e.addWidget(self.button('Paste', 'paste', self.paste, 'Flat', 'Replace the code with what is on the clipboard '
                                                                         '(Ctrl+Shift+V)'))
        e.addWidget(self.button('Open', 'code-file', self.open_py, 'Flat', 'Open a .py file (Ctrl+Shift+O)'))
        self.copy_btn = self.button('Copy', 'copy', self.copy, 'Flat', 'Copy all the code (Ctrl+Shift+C)')
        e.addWidget(self.copy_btn)
        save = self.save_btn = self.button('Save', 'save', lambda: None, 'Flat', 'Save the code and the files it needs')
        menu = QMenu(save)
        for text, fn, keys in (('Save as .py…', self.save_py, 'Ctrl+S'), ('Save as .zip…', self.save_zip, 'Ctrl+Shift+S')):
            act = menu.addAction(text)
            act.triggered.connect(lambda _=False, f=fn: f())
            act.setShortcut(QKeySequence(keys))  # shown in the menu; the window shortcut does the work
            act.setShortcutContext(Qt.WidgetShortcut)
        save.setMenu(menu)
        e.addWidget(save)
        e.addSpacing(8)
        self.build_btn = self.button('Build PowerPoint', 'play', self.build, 'Accent',
                                     'Run this code and save the PowerPoint it makes (F5)', 'accent')
        e.addWidget(self.build_btn)
        cv.addWidget(eh)

        self.banner = Banner()
        self.banner_box = QWidget()
        bl = QVBoxLayout(self.banner_box)
        bl.setContentsMargins(12, 10, 12, 2)
        bl.addWidget(self.banner)
        self.banner.close_btn.clicked.connect(self.banner_box.hide)
        self.banner_box.hide()
        cv.addWidget(self.banner_box)

        self.editor = CodeEditor()
        self.editor.textChanged.connect(self.code_changed)
        self.editor.modificationChanged.connect(lambda m: self.dirty.setVisible(m))
        self.editor.cursorInfo.connect(lambda ln, col: self.pos_lbl.setText(f'Ln {ln}, Col {col}'))
        self.editor.fileDropped.connect(self.open_path)
        self.editor.installEventFilter(self)
        self.find_bar = FindBar(self.editor)
        cv.addWidget(self.find_bar)

        self.vsplit = QSplitter(Qt.Vertical)
        self.vsplit.setHandleWidth(1)
        self.vsplit.setChildrenCollapsible(False)
        self.vsplit.addWidget(self.editor)
        self.vsplit.addWidget(self.build_output())
        self.vsplit.setStretchFactor(0, 1)
        cv.addWidget(self.vsplit, 1)

        self.empty_code = QWidget(self.editor)
        ev = QVBoxLayout(self.empty_code)
        ev.setSpacing(6)
        self.empty_pic = QLabel(alignment=Qt.AlignCenter)
        t = label('No code yet', 'EmptyTitle')
        t.setAlignment(Qt.AlignCenter)
        x = label('Convert slides from a deck, or paste python-pptx code and build a PowerPoint from it.',
                  'EmptyText', wrap=True)
        x.setAlignment(Qt.AlignCenter)
        x.setFixedWidth(330)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self.button('Paste code', 'paste', self.paste))
        row.addWidget(self.button('Open .py…', 'code-file', self.open_py))
        row.addStretch(1)
        for w in (self.empty_pic, t, x):
            ev.addWidget(w, 0, Qt.AlignHCenter)
        ev.addSpacing(6)
        ev.addLayout(row)
        self.empty_code.setFont(QApplication.font())
        self.empty_code.adjustSize()
        self.toast = Toast(self.editor)
        self.toast.setFont(QApplication.font())
        return center

    def build_output(self):
        self.out_panel = QFrame(objectName='OutputPanel')
        ov = QVBoxLayout(self.out_panel)
        ov.setContentsMargins(0, 0, 0, 0)
        ov.setSpacing(0)
        head = QHBoxLayout()
        head.setContentsMargins(14, 6, 8, 2)
        head.addWidget(label('Output', 'Section'))
        head.addStretch(1)
        head.addWidget(self.button('Clear', None, self.clear_output, 'Flat', 'Clear the messages'))
        close = self.button('', 'x', lambda: self.out_btn.setChecked(False), 'Flat', 'Hide the output', 'muted')
        head.addWidget(close)
        ov.addLayout(head)
        self.output = QPlainTextEdit(objectName='Output', readOnly=True)
        f = code_font()
        f.setPointSizeF(9.5)
        self.output.setFont(f)
        self.output.setMaximumBlockCount(2000)
        self.output.document().setDocumentMargin(10)
        ov.addWidget(self.output, 1)
        self.out_panel.hide()
        return self.out_panel

    def build_options(self):
        op = QFrame(objectName='Options')
        op.setMinimumWidth(290)
        op.setMaximumWidth(390)
        outer = QVBoxLayout(op)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        scroll = QScrollArea(objectName='OptionsScroll')
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        inner = QWidget(objectName='OptionsInner')
        scroll.setWidget(inner)
        outer.addWidget(scroll, 1)
        v = QVBoxLayout(inner)
        v.setContentsMargins(18, 14, 18, 8)
        v.setSpacing(8)
        v.addWidget(label('Slides to convert', 'Section'))
        self.scope = Segmented([('all', 'All'), ('sel', 'Selected'), ('num', 'Numbers')])
        self.scope.setValue('all')
        self.scope.changed.connect(self.scope_changed)
        v.addWidget(self.scope)
        self.numbers = QLineEdit(placeholderText='e.g. 3 or 1,4-6')
        self.numbers.setAccessibleName('Slide numbers')
        self.numbers.textChanged.connect(self.update_convert)
        self.numbers.returnPressed.connect(self.convert)
        v.addWidget(self.numbers)
        self.scope_hint = label('', 'Hint', wrap=True)
        v.addWidget(self.scope_hint)
        v.addSpacing(8)
        v.addWidget(divider())
        v.addSpacing(8)
        v.addWidget(label('Start from', 'Section'))
        self.base = Segmented([('template', 'Deck template'), ('blank', 'Blank deck')])
        self.base.changed.connect(self.options_changed)
        v.addWidget(self.base)
        self.base_hint = label('', 'Hint', wrap=True)
        v.addWidget(self.base_hint)
        v.addSpacing(8)
        v.addWidget(divider())
        v.addSpacing(8)
        v.addWidget(label('Code style', 'Section'))
        self.style = Segmented([('plain', 'python-pptx'), ('compact', 'Compact')])
        self.style.changed.connect(self.options_changed)
        v.addWidget(self.style)
        self.style_hint = label('', 'Hint', wrap=True)
        v.addWidget(self.style_hint)
        v.addSpacing(4)
        self.sw, self.sw_hint = {}, {}
        for key, text, hint in (
                ('extras', "Keep what python-pptx can't do", ''),
                ('embed', 'Embed pictures and template', 'One self-contained .py file.'),
                ('notes', 'Speaker notes', None), ('fx', 'Shadows and effects', None)):
            sw = Switch(text)
            sw.toggled.connect(self.options_changed)
            self.sw[key] = sw
            v.addWidget(sw)
            if hint is not None:
                h = label(hint, 'Hint', wrap=True)
                h.setContentsMargins(44, 0, 0, 4)
                self.sw_hint[key] = h
                v.addWidget(h)
        v.addStretch(1)
        foot = QVBoxLayout()
        foot.setContentsMargins(18, 8, 18, 14)
        foot.setSpacing(6)
        self.convert_btn = self.button('Convert', 'code', self.convert, 'Primary', 'Convert to python-pptx code '
                                                                                 '(Ctrl+Enter)', 'on_accent')
        foot.addWidget(self.convert_btn)
        k = label('Ctrl+Enter', 'Hint')
        k.setAlignment(Qt.AlignCenter)
        foot.addWidget(k)
        outer.addLayout(foot)
        return op

    def build_status(self):
        sb = QStatusBar()
        sb.setSizeGripEnabled(False)
        self.setStatusBar(sb)
        self.msg = QLabel()
        self.pos_lbl, self.lines_lbl = QLabel('Ln 1, Col 1'), QLabel('')
        self.out_btn = QToolButton(objectName='Flat', text='Output', checkable=True)
        self.out_btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.out_btn.setToolTip('Show messages and errors (Ctrl+`)')
        self.out_btn.setCursor(Qt.PointingHandCursor)
        self.out_btn.toggled.connect(self.out_panel.setVisible)
        self.iconed.append((self.out_btn, 'terminal', 'muted'))
        sb.addWidget(self.msg, 1)
        for w in (self.pos_lbl, self.lines_lbl, self.out_btn):
            sb.addPermanentWidget(w)

    def shortcuts(self):
        for keys, fn in (('Ctrl+O', self.open_deck), ('Ctrl+Shift+O', self.open_py), ('Ctrl+Return', self.convert),
                         ('Ctrl+Enter', self.convert), ('F5', self.build), ('Ctrl+S', self.save_py),
                         ('Ctrl+Shift+S', self.save_zip), ('Ctrl+Shift+C', self.copy), ('Ctrl+Shift+V', self.paste),
                         ('Ctrl+F', self.find_bar.open_bar), ('Ctrl+`', self.out_btn.toggle),
                         ('Ctrl+Shift+L', self.toggle_theme), ('Escape', self.escape)):
            QShortcut(QKeySequence(keys), self, activated=fn)

    # ── theme and settings ──
    def apply_theme(self, name):
        self.theme_name = name
        theme.use(name)
        app = QApplication.instance()
        app.setStyleSheet(qss(T))
        pal = QPalette()
        for role, key in ((QPalette.Window, 'surface'), (QPalette.WindowText, 'text'), (QPalette.Base, 'raised'),
                          (QPalette.AlternateBase, 'surface'), (QPalette.Text, 'text'), (QPalette.Button, 'raised'),
                          (QPalette.ButtonText, 'text'), (QPalette.Highlight, 'selection'),
                          (QPalette.HighlightedText, 'text'), (QPalette.ToolTipBase, 'raised'),
                          (QPalette.ToolTipText, 'text'), (QPalette.PlaceholderText, 'faint'), (QPalette.Link, 'accent')):
            pal.setColor(role, QColor(T[key]))
        app.setPalette(pal)
        try:  # native title bar colours where the platform supports it
            app.styleHints().setColorScheme(Qt.ColorScheme.Dark if name == 'dark' else Qt.ColorScheme.Light)
        except AttributeError:
            pass
        for w, ic, colour in self.iconed:
            w.setIcon(icon(ic, T[colour]))
        self.theme_btn.setIcon(icon('sun' if name == 'dark' else 'moon', T['muted']))
        self.file_ico.setPixmap(icon('code-file', T['muted'], 16).pixmap(16, 16))
        self.empty_pic.setPixmap(icon('code', T['faint'], 40).pixmap(40, 40))
        for w in (self.editor, self.strip, self.banner, self.find_bar, self.empty_deck):
            w.restyle()
        for sw in self.sw.values():
            sw.update()

    def toggle_theme(self):
        self.apply_theme('light' if self.theme_name == 'dark' else 'dark')

    def restore(self):
        s = self.settings
        if s.value('geometry'):
            self.restoreGeometry(s.value('geometry'))
        else:
            screen = QGuiApplication.primaryScreen().availableGeometry()
            self.resize(min(1480, int(screen.width() * 0.88)), min(920, int(screen.height() * 0.88)))
        if s.value('split'):
            self.split.restoreState(s.value('split'))
        else:
            self.split.setSizes([270, 900, 300])
        self.vsplit.setSizes([600, 160])
        self.base.setValue(s.value('base', 'template'))
        self.style.setValue(s.value('style', 'plain') if s.value('style', 'plain') in ('plain', 'compact') else 'plain')
        for key, default in (('extras', True), ('embed', False), ('notes', True), ('fx', True)):
            self.sw[key].setChecked(s.value(key, default, type=bool))
        name = s.value('theme')
        if name not in ('dark', 'light'):
            scheme = QGuiApplication.styleHints().colorScheme()
            name = 'light' if scheme == Qt.ColorScheme.Light else 'dark'
        self.apply_theme(name)
        self.options_changed()

    def save_settings(self):
        s = self.settings
        s.setValue('geometry', self.saveGeometry())
        s.setValue('split', self.split.saveState())
        s.setValue('theme', self.theme_name)
        s.setValue('base', self.base.value())
        s.setValue('style', self.style.value())
        for key, sw in self.sw.items():
            s.setValue(key, sw.isChecked())

    def last_dir(self):
        return self.settings.value('lastdir', str(Path.home()))

    # ── state that follows the controls ──
    def wanted(self):
        """Slides to convert: None for all, [] when the choice is empty or invalid."""
        if not self.deck:
            return []
        k = self.scope.value()
        if k == 'all':
            return None
        if k == 'sel':
            return self.strip.selected_numbers()
        try:
            return parse_slides(self.numbers.text(), len(self.deck['slides']))
        except ValueError:
            return []

    def update_convert(self):
        total = len(self.deck['slides']) if self.deck else 0
        k, w = self.scope.value(), self.wanted()
        self.numbers.setVisible(k == 'num')
        if not self.deck:
            text, ok = 'Convert to Python', False
        elif w is None:
            text, ok = f'Convert all {total} slides' if total != 1 else 'Convert the slide', total > 0
        elif not w:
            text, ok = 'Select slides to convert' if k == 'sel' else 'Enter slide numbers', False
        else:
            text, ok = f'Convert slide {w[0]}' if len(w) == 1 else f'Convert {len(w)} slides', True
        self.convert_btn.setText(text)
        self.convert_btn.setEnabled(ok and not self.busy)
        bad = k == 'num' and bool(self.numbers.text().strip()) and not w
        if bool(self.numbers.property('bad')) != bad:
            self.numbers.setProperty('bad', bad)
            repolish(self.numbers)
        self.scope_hint.setText(
            'Open a deck first.' if not self.deck else
            f'Every slide in this deck, {total} in all.' if k == 'all' else
            'Click slides on the left. Ctrl or Shift adds more; double-click converts just that one.' if k == 'sel'
            else f'Use numbers from 1 to {total}, e.g. 3 or 1,4-6.')

    def scope_changed(self, key):
        self.update_convert()
        if key == 'num':
            self.numbers.setFocus()

    def options_changed(self, *_):
        plain = self.style.value() == 'plain'
        self.sw['extras'].setEnabled(plain)
        self.style_hint.setText(
            'Ordinary python-pptx statements: add_shape(), fill.solid(), font.size … No helper calls.' if plain else
            'The shortest code: one call per shape, such as box() and pic(), from pptx_helpers.py.')
        extras = self.sw['extras'].isChecked()
        self.sw_hint['extras'].setText(
            'Not used by the compact style, which always keeps them.' if not plain else
            'Shadows, transparency, arrowheads, bullets … through named functions from pptx_helpers.' if extras else
            'Pure python-pptx. Those details are left out and listed at the top of the script.')
        self.sw_hint['embed'].setText(
            'One self-contained .py file' + (', with the helpers it uses inside.' if extras or not plain else '.'))
        tpl = f"{self.deck['name']}_template.pptx" if self.deck else "the deck's template"
        self.base_hint.setText(
            f'Exact masters, layouts and theme. Saves {tpl} with the code.'
            if self.base.value() == 'template' else
            "No template file: starts from Presentation() with this deck's theme colours and fonts.")

    def selection_changed(self):
        if self.strip.selectedItems() and self.scope.value() != 'num':
            self.scope.setValue('sel')
        self.update_convert()

    def slide_clicked(self, it):
        n = it.data(Qt.UserRole)['n']
        if self.editor.goto_def(f'slide{n}'):
            self.msg.setText(f'Slide {n} is at line {self.editor.textCursor().blockNumber() + 1} of the code.')

    def code_changed(self):
        doc = self.editor.document()
        empty = doc.isEmpty()
        self.empty_code.setVisible(empty)
        n = doc.blockCount() if not empty else 0
        self.lines_lbl.setText(f'{n} line{"s" if n != 1 else ""}')
        for b in (self.copy_btn, self.save_btn):
            b.setEnabled(not empty)
        self.build_btn.setEnabled(not empty and not self.busy)
        self.file_meta.setText(f'{n} lines' if n else '')
        if not self.msg.text():
            self.msg.setText('Open a deck to start, or paste python-pptx code.')
        self._place_empty()

    def set_file_label(self):
        self.file_name.setText(f'{self.code_name}.py' if self.code_name else 'Untitled.py')
        self.dirty.setVisible(self.editor.document().isModified())

    def _place_empty(self):
        e = self.empty_code
        e.adjustSize()
        e.move((self.editor.width() - e.width()) // 2, max(20, (self.editor.height() - e.height()) // 2 - 30))

    def eventFilter(self, obj, ev):
        if obj is self.editor and ev.type() == QEvent.Resize:
            self._place_empty()
        return super().eventFilter(obj, ev)

    # ── messages ──
    def say(self, text, kind='info'):
        colour = {'error': T['danger'], 'ok': T['success']}.get(kind, T['muted'])
        stamp = time.strftime('%H:%M:%S')
        body = html.escape(text).replace('\n', '<br>')
        self.output.appendHtml(f'<span style="color:{T["faint"]}">{stamp}</span>&nbsp; '
                               f'<span style="color:{colour}">{body}</span>')
        if kind == 'error':
            self.errors += 1
            self.out_btn.setText(f'Output ({self.errors} error{"s" if self.errors > 1 else ""})')

    def clear_output(self):
        self.output.clear()
        self.errors = 0
        self.out_btn.setText('Output')

    def show_output(self):
        self.out_btn.setChecked(True)

    def notify(self, kind, text, actions=()):
        self.banner.show_message(kind, text, actions)
        self.banner_box.show()

    def escape(self):
        if self.find_bar.isVisible():
            self.find_bar.close_bar()
        elif self.banner_box.isVisible():
            self.banner_box.hide()

    # ── background work ──
    def run_bg(self, work, done, msg):
        if self.busy:
            return
        self.busy = True
        self.busy_line.start()
        self.msg.setText(msg)
        self.build_btn.setEnabled(False)
        self.update_convert()

        def job():
            try:
                res, err = work(), None
            except Exception as e:  # noqa: BLE001  (reported in the window)
                res, err = None, e
            self.bridge.done.emit(done, res, err)
        threading.Thread(target=job, daemon=True).start()

    def _finished(self, done, res, err):
        self.busy = False
        self.busy_line.stop()
        self.build_btn.setEnabled(not self.editor.document().isEmpty())
        self.update_convert()
        done(res, err)

    # ── deck → code ──
    def open_deck(self):
        p, _ = QFileDialog.getOpenFileName(self, 'Open a PowerPoint deck', self.last_dir(),
                                           'PowerPoint (*.pptx *.pptm);;All files (*)')
        if p:
            self.load_deck(p)

    def open_path(self, p):
        p = Path(p)
        if p.suffix.lower() in DECKS:
            self.load_deck(p)
        elif p.suffix.lower() in CODE:
            self.open_py(p)
        else:
            self.notify('error', f'{p.name} is not a deck or a script. pptx2py opens .pptx decks and .py files.')

    def load_deck(self, path):
        path = Path(path)

        def work():
            data = path.read_bytes()
            return data, wireframes(data)
        self.run_bg(work, lambda r, e: self.deck_loaded(path, r, e), f'Opening {path.name}…')

    def deck_loaded(self, path, r, err):
        if err is not None:
            self.say(f'{path}: {err}', 'error')
            self.msg.setText('')
            return self.notify('error', f"{path.name} couldn't be opened as a PowerPoint deck: {err}")
        data, slides = r
        self.deck = dict(path=path, data=data, name=path.stem, slides=slides)
        self.result = None
        self.strip.set_slides(slides)
        self.side_stack.setCurrentIndex(1)
        size = f'{len(data) / 1e6:.1f} MB' if len(data) >= 100_000 else f'{max(1, len(data) // 1024)} KB'
        self.deck_name.setText(path.name)
        self.deck_name.setToolTip(str(path))
        self.deck_meta.setText(f'{len(slides)} slide{"s" if len(slides) != 1 else ""}, {size}')
        self.slide_count.setText(str(len(slides)))
        self.all_btn.show()
        self.none_btn.show()
        self.scope.setValue('all')
        self.numbers.clear()
        self.settings.setValue('lastdir', str(path.parent))
        self.setWindowTitle(f'{path.name} – pptx2py')
        self.banner_box.hide()
        self.options_changed()
        self.update_convert()
        self.msg.setText('Choose the slides, then Convert. Double-click a slide to convert just that one.')
        self.say(f'Opened {path} ({len(slides)} slides)')

    def convert(self, only=None):
        if self.busy:
            return
        if not self.deck:
            return self.open_deck()
        w = [only] if only else self.wanted()
        if w == []:
            return
        embed = self.sw['embed'].isChecked()
        opts = dict(template=self.base.value() == 'template', embed=embed, notes=self.sw['notes'].isChecked(),
                    fx=self.sw['fx'].isChecked(), style=self.style.value(), extras=self.sw['extras'].isChecked(),
                    helpers='inline' if embed else 'file')
        d = self.deck
        what = 'all slides' if w is None else f'slide {w[0]}' if len(w) == 1 else f'{len(w)} slides'
        self.run_bg(lambda: convert(d['data'], slides=w, name=d['name'], **opts), self.converted,
                    f'Converting {what}…')

    def converted(self, r, err):
        if err is not None:
            self.say(f'Conversion failed: {err!r}', 'error')
            self.msg.setText('Conversion failed.')
            return self.notify('error', f'The conversion stopped: {err}', [('Show output', self.show_output)])
        work = Path(tempfile.mkdtemp(prefix='pptx2py_'))
        self.temps.append(work)
        for name, blob in r.files.items():
            (work / name).parent.mkdir(parents=True, exist_ok=True)
            (work / name).write_bytes(blob)
        self.files, self.workdir, self.code_dir, self.code_name = r.files, work, None, self.deck['name']
        self.result = dict(r=r, data=self.deck['data'], template=self.base.value() == 'template')
        self.editor.replace_all(r.code)
        self.editor.document().setModified(False)
        self.set_file_label()
        n = len(r.slides)
        what = f'slide {r.slides[0]}' if n == 1 else f'{n} slides'
        self.toast.pop(f'Converted {what} into {r.lines} lines')
        pics = sum(1 for f in r.files if f.startswith('assets/'))
        self.say(f'Converted {what} of {self.deck["name"]} into {r.lines} lines'
                 + (f', {pics} picture{"s" if pics != 1 else ""}' if pics else '') + '.', 'ok')
        for s in r.skipped:
            self.say(f'Left out: {s}')
        for s in r.notes:
            self.say(f'Not exact: {s}')
        k, m = len(r.skipped), len(r.notes)
        if k or m:
            parts = ([f'{k} item{"s" if k != 1 else ""} python-pptx can’t make {"were" if k != 1 else "was"} left out'] if k
                     else []) + ([f'{m} {"are" if m != 1 else "is"} converted with a difference'] if m else [])
            first = (r.skipped or r.notes)[0].split(': ', 1)[-1]
            self.notify('info', f'{" and ".join(parts)}, e.g. {first}. The list is also at the top of the code.',
                        [('Show details', self.show_output)])
        else:
            self.banner_box.hide()
        self.msg.setText(f'Converted {what}. Press F5 to build a PowerPoint from this code.')

    # ── code → deck ──
    def build(self):
        if self.busy:
            return
        code = self.editor.toPlainText()
        if not code.strip():
            return self.notify('info', 'There is no code to build yet. Convert a deck, or paste python-pptx code.',
                               [('Paste code', self.paste)])
        start = os.path.join(self.last_dir(), f'{self.code_name or "presentation"}_rebuilt.pptx')
        out, _ = QFileDialog.getSaveFileName(self, 'Save the PowerPoint as', start, 'PowerPoint (*.pptx)')
        if not out:
            return
        out = out if out.lower().endswith('.pptx') else out + '.pptx'
        work = self.code_dir or self.workdir
        if work is None:
            work = Path(tempfile.mkdtemp(prefix='pptx2py_'))
            self.temps.append(work)
        self.run_bg(lambda: run_code(code, out, work), self.built, 'Building the PowerPoint…')

    def built(self, out, err):
        if err is not None:
            text = str(err)
            lines = re.findall(r'File "your code", line (\d+)', text)
            line = int(lines[-1]) if lines else None
            last = [x for x in text.splitlines() if x.strip()][-1].strip()
            self.say(text, 'error')
            self.msg.setText('The build stopped with an error.')
            acts = ([(f'Go to line {line}', lambda: self.editor.goto_line(line))] if line else []) + \
                [('Show output', self.show_output)]
            return self.notify('error', f'The build stopped{f" at line {line}" if line else ""}: {last}', acts)
        self.settings.setValue('lastdir', str(Path(out).parent))
        self.say(f'Built {out}', 'ok')
        self.msg.setText(f'Built {out}')
        acts = [('Open', lambda: open_file(out)), ('Show in folder', lambda: reveal(out))]
        if getattr(self, 'result', None) and self.code_name == (self.deck or {}).get('name'):
            acts.insert(0, ('Check against original', lambda: self.check(out)))
        self.notify('success', f'Built {Path(out).name}', acts)

    def check(self, out):
        """Compare the built deck with the original, shape by shape."""
        res = self.result
        r = res['r']

        def work():
            return compare(res['data'], str(out), r.slides, res['template'], r.skipped + r.notes)
        self.run_bg(work, lambda rep, e: self.checked(out, rep, e), 'Comparing with the original…')

    def checked(self, out, rep, err):
        if err is not None:
            self.say(f'The comparison stopped: {err!r}', 'error')
            return self.notify('error', f'The comparison stopped: {err}', [('Show output', self.show_output)])
        for line in rep.text().splitlines():
            self.say(line.strip(), 'error' if line.strip().startswith('!') else 'info')
        n = len(rep.errors)
        listed = sum(1 for i in rep.issues if i.level == 'listed')
        head = f'{rep.matched} of {rep.shapes} shapes in place'
        if n == 0:
            self.notify('success', f'Matches the original: {head}, no differences'
                        + (f' beyond the {listed} listed at the top of the code' if listed else '') + '.',
                        [('Open', lambda: open_file(out)), ('Show details', self.show_output)])
        else:
            first = rep.errors[0]
            self.notify('info', f'{head}; {n} difference{"s" if n != 1 else ""} from the original, e.g. {first}.',
                        [('Show details', self.show_output), ('Open', lambda: open_file(out))])
        self.msg.setText(f'Compared with the original: {n} difference{"s" if n != 1 else ""}.')

    # ── code box ──
    def paste(self):
        text = QGuiApplication.clipboard().text()
        if not text.strip():
            return self.toast.pop('The clipboard has no text to paste')
        self.editor.replace_all(text)
        self.code_dir, self.code_name = None, 'pasted'
        self.set_file_label()
        n = text.count('\n') + 1
        self.toast.pop(f'Pasted {n} lines. Press F5 to build.')
        self.msg.setText('Pasted code. Ctrl+Z brings back the previous code.')

    def open_py(self, path=None):
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, 'Open python code', self.last_dir(), 'Python (*.py);;All files (*)')
        if not path:
            return
        p = Path(path)
        try:
            text = p.read_text(encoding='utf-8', errors='replace')
        except OSError as e:
            return self.notify('error', f"{p.name} couldn't be read: {e}")
        self.editor.replace_all(text)
        self.editor.document().setModified(False)
        self.code_dir, self.code_name = p.parent, p.stem
        self.set_file_label()
        self.msg.setText(f'Opened {p}. Pictures and the template are looked up next to it.')
        self.say(f'Opened {p}')

    def copy(self):
        code = self.editor.toPlainText()
        QGuiApplication.clipboard().setText(code)
        n = code.count('\n') + 1 if code else 0
        self.toast.pop(f'Copied {n} lines')

    def companions(self, code):
        """Files the code reads: the template, pictures and pptx_helpers.py."""
        out = {n: b for n, b in self.files.items() if Path(n).name in code or n in code}
        if re.search(r'^\s*from pptx_helpers import', code, re.M):
            out['pptx_helpers.py'] = HELPERS.read_bytes()
        return out

    def save_py(self):
        code = self.editor.toPlainText()
        start = os.path.join(self.last_dir(), f'{self.code_name or "presentation"}.py')
        p, _ = QFileDialog.getSaveFileName(self, 'Save the code as', start, 'Python (*.py)')
        if not p:
            return False
        p = Path(p if p.endswith('.py') else p + '.py')
        p.write_text(code, encoding='utf-8')
        extra = self.companions(code)
        for name, blob in extra.items():
            (p.parent / name).parent.mkdir(parents=True, exist_ok=True)
            (p.parent / name).write_bytes(blob)
        self.editor.document().setModified(False)
        self.code_dir, self.code_name = p.parent, p.stem
        self.set_file_label()
        self.settings.setValue('lastdir', str(p.parent))
        kinds = [k for k, hit in (('the template', any(n.endswith('_template.pptx') for n in extra)),
                                  ('pictures', any(n.startswith('assets/') for n in extra)),
                                  ('pptx_helpers.py', 'pptx_helpers.py' in extra)) if hit]
        self.toast.pop(f'Saved {p.name}' + (f' with {", ".join(kinds)}' if kinds else ''))
        self.say(f'Saved {p}' + (f' with {", ".join(sorted(extra))}' if extra else ''), 'ok')
        return True

    def save_zip(self):
        code = self.editor.toPlainText()
        stem = self.code_name or 'presentation'
        start = os.path.join(self.last_dir(), f'{stem}_python.zip')
        p, _ = QFileDialog.getSaveFileName(self, 'Save the code and its files as', start, 'ZIP archive (*.zip)')
        if not p:
            return
        p = p if p.endswith('.zip') else p + '.zip'
        with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr(f'{stem}.py', code)
            for name, blob in self.companions(code).items():
                z.writestr(name, blob)
        self.toast.pop(f'Saved {Path(p).name}')
        self.say(f'Saved {p}', 'ok')

    # ── window events ──
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls() and any(u.toLocalFile().lower().endswith(DECKS + CODE) for u in e.mimeData().urls()):
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            if u.toLocalFile().lower().endswith(DECKS + CODE):
                return self.open_path(u.toLocalFile())

    def closeEvent(self, e):
        if self.editor.document().isModified() and self.editor.toPlainText().strip():
            box = QMessageBox(QMessageBox.Question, 'Save the code?',
                              'The code has changes that are not saved.', parent=self)
            save = box.addButton('Save…', QMessageBox.AcceptRole)
            box.addButton("Don't save", QMessageBox.DestructiveRole)
            cancel = box.addButton('Cancel', QMessageBox.RejectRole)
            box.exec()
            if box.clickedButton() is cancel or (box.clickedButton() is save and not self.save_py()):
                return e.ignore()
        self.save_settings()
        for t in self.temps:
            shutil.rmtree(t, ignore_errors=True)
        e.accept()
