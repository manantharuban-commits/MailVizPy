"""The code editor: line numbers, Python colouring, find, jump to a slide's function."""
import keyword
import re

from PySide6.QtCore import QRect, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QSyntaxHighlighter, QTextCharFormat, QTextCursor, QTextFormat
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton, QTextEdit, QWidget

from .theme import T, code_font, icon

HELPERS = ('add', 'ph', 'box', 'pic', 'con', 'grp', 'tbl', 'chart', 'bg', 'notes', 'set_theme', 'build', 'Presentation',
           'opacity', 'gradient', 'picture_fill', 'arrows', 'effects', 'picture_effects', 'bullet', 'indent',
           'font_extras', 'text_direction', 'autofit', 'mirror', 'cell_border', 'table_style', 'hide_slide',
           'hide_layout_graphics', 'picture_background', 'add_any_picture', 'doughnut_hole', 'chart_area', 'empty_line',
           'transition', 'animate', 'text_effects', 'text_outline', 'field', 'text_columns', 'text_warp', 'three_d',
           'glue', 'combo_chart', 'series_labels', 'hide', 'outline', 'click_jump', 'cell_direction', 'picture_back',
           'links', 'movie', 'preset', 'group_box')
RULES = [
    ('arg', re.compile(r'\b[a-z_]\w*(?==[^=])')),
    ('num', re.compile(r'\b\d+(?:\.\d+)?\b')),
    ('defn', re.compile(r'\b[A-Z][A-Z0-9_]+\b')),
    ('helper', re.compile(r'\b(?:%s)\b(?=\()' % '|'.join(HELPERS))),
    ('kw', re.compile(r'\b(?:%s)\b' % '|'.join(keyword.kwlist))),
    ('defn', re.compile(r'(?<=\bdef )\w+')),
]


class Highlighter(QSyntaxHighlighter):
    def __init__(self, doc):
        super().__init__(doc)
        self.restyle()

    def restyle(self):
        self.f = {}
        for k in ('kw', 'helper', 'str', 'num', 'com', 'defn', 'arg'):
            f = QTextCharFormat()
            f.setForeground(QColor(T[k]))
            if k == 'com':
                f.setFontItalic(True)
            if k == 'kw':
                f.setFontWeight(QFont.DemiBold)
            self.f[k] = f
        self.rehighlight()

    def highlightBlock(self, text):
        for k, rx in RULES:
            for m in rx.finditer(text):
                self.setFormat(m.start(), m.end() - m.start(), self.f[k])
        self.setCurrentBlockState(0)
        i, n, prev = 0, len(text), self.previousBlockState()
        if prev in (1, 2):  # inside a ''' or """ string
            q = "'''" if prev == 1 else '"""'
            end = text.find(q)
            if end < 0:
                self.setFormat(0, n, self.f['str'])
                return self.setCurrentBlockState(prev)
            self.setFormat(0, end + 3, self.f['str'])
            i = end + 3
        while i < n:
            c = text[i]
            if c == '#':
                self.setFormat(i, n - i, self.f['com'])
                break
            if c in '\'"':
                if text.startswith(c * 3, i):
                    end = text.find(c * 3, i + 3)
                    if end < 0:
                        self.setFormat(i, n - i, self.f['str'])
                        return self.setCurrentBlockState(1 if c == "'" else 2)
                    self.setFormat(i, end + 3 - i, self.f['str'])
                    i = end + 3
                    continue
                j = i + 1
                while j < n and text[j] != c:
                    j += 2 if text[j] == '\\' else 1
                self.setFormat(i, j + 1 - i, self.f['str'])
                i = j + 1
                continue
            i += 1


class Gutter(QWidget):
    def __init__(self, ed):
        super().__init__(ed)
        self.ed = ed

    def sizeHint(self):
        return QSize(self.ed.gutter_width(), 0)

    def paintEvent(self, e):
        self.ed.paint_gutter(e)


class CodeEditor(QPlainTextEdit):
    fileDropped = Signal(str)
    cursorInfo = Signal(int, int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('Editor')
        self.setFont(code_font())
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(' ') * 4)
        self.setPlaceholderText('')
        self.gutter = Gutter(self)
        self.hl = Highlighter(self.document())
        self.matches, self.flash_line = [], None
        self.blockCountChanged.connect(self._fit_gutter)
        self.updateRequest.connect(self._scroll_gutter)
        self.cursorPositionChanged.connect(self._cursor)
        self._fit_gutter()
        self._cursor()

    # ── gutter ──
    def gutter_width(self):
        return 22 + self.fontMetrics().horizontalAdvance('9') * max(3, len(str(self.blockCount())))

    def _fit_gutter(self, *_):
        self.setViewportMargins(self.gutter_width(), 0, 0, 0)

    def _scroll_gutter(self, rect, dy):
        if dy:
            self.gutter.scroll(0, dy)
        else:
            self.gutter.update(0, rect.y(), self.gutter.width(), rect.height())

    def resizeEvent(self, e):
        super().resizeEvent(e)
        cr = self.contentsRect()
        self.gutter.setGeometry(QRect(cr.left(), cr.top(), self.gutter_width(), cr.height()))

    def paint_gutter(self, e):
        p = QPainter(self.gutter)
        p.fillRect(e.rect(), QColor(T['editor']))
        p.setFont(self.font())
        block = self.firstVisibleBlock()
        top = round(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        current = self.textCursor().blockNumber()
        w, h = self.gutter.width() - 12, self.fontMetrics().height()
        while block.isValid() and top <= e.rect().bottom():
            bottom = top + round(self.blockBoundingRect(block).height())
            if block.isVisible() and bottom >= e.rect().top():
                p.setPen(QColor(T['text'] if block.blockNumber() == current else T['gutter']))
                p.drawText(0, top, w, h, Qt.AlignRight, str(block.blockNumber() + 1))
            block, top = block.next(), bottom

    # ── highlights: current line, find matches, a line we jumped to ──
    def _cursor(self):
        c = self.textCursor()
        self.cursorInfo.emit(c.blockNumber() + 1, c.positionInBlock() + 1)
        self.refresh_marks()

    def refresh_marks(self):
        sels = []
        cur = QTextEdit.ExtraSelection()
        cur.format.setBackground(QColor(T['line']))
        cur.format.setProperty(QTextFormat.FullWidthSelection, True)
        cur.cursor = self.textCursor()
        cur.cursor.clearSelection()
        sels.append(cur)
        if self.flash_line is not None:
            fl = QTextEdit.ExtraSelection()
            fl.format.setBackground(QColor(T['accent_soft']))
            fl.format.setProperty(QTextFormat.FullWidthSelection, True)
            fl.cursor = QTextCursor(self.document().findBlockByNumber(self.flash_line))
            sels.append(fl)
        for m in self.matches:
            s = QTextEdit.ExtraSelection()
            s.format.setBackground(QColor(T['find']))
            s.cursor = m
            sels.append(s)
        self.setExtraSelections(sels)

    def restyle(self):
        self.hl.restyle()
        self.refresh_marks()
        self.gutter.update()

    # ── editing ──
    def keyPressEvent(self, e):
        c = self.textCursor()
        if e.key() == Qt.Key_Tab and not c.hasSelection():
            return self.insertPlainText('    ')
        if e.key() in (Qt.Key_Tab, Qt.Key_Backtab) and c.hasSelection():
            return self._indent(e.key() == Qt.Key_Tab)
        if e.key() in (Qt.Key_Return, Qt.Key_Enter) and not e.modifiers():
            line = c.block().text()[:c.positionInBlock()]
            pad = len(line) - len(line.lstrip(' ')) + (4 if line.rstrip().endswith(':') else 0)
            return self.insertPlainText('\n' + ' ' * pad)
        super().keyPressEvent(e)

    def _indent(self, more):
        c = self.textCursor()
        a, b = sorted((c.selectionStart(), c.selectionEnd()))
        doc = self.document()
        first, last = doc.findBlock(a).blockNumber(), doc.findBlock(max(a, b - 1)).blockNumber()
        c.beginEditBlock()
        for n in range(first, last + 1):
            blk = doc.findBlockByNumber(n)
            k = QTextCursor(blk)
            if more:
                k.insertText('    ')
            else:
                spaces = len(blk.text()) - len(blk.text().lstrip(' '))
                for _ in range(min(4, spaces)):
                    k.deleteChar()
        c.endEditBlock()

    def replace_all(self, text):
        """New content as one step that Ctrl+Z can undo."""
        c = QTextCursor(self.document())
        c.beginEditBlock()
        c.select(QTextCursor.Document)
        c.insertText(text)
        c.endEditBlock()
        self.moveCursor(QTextCursor.Start)
        self.centerCursor()

    def canInsertFromMimeData(self, md):
        return md.hasUrls() or super().canInsertFromMimeData(md)

    def insertFromMimeData(self, md):
        files = [u.toLocalFile() for u in md.urls() if u.isLocalFile()] if md.hasUrls() else []
        if files:
            return self.fileDropped.emit(files[0])
        super().insertFromMimeData(md)

    # ── navigation ──
    def goto_line(self, n, flash=True):
        blk = self.document().findBlockByNumber(max(0, n - 1))
        self.setTextCursor(QTextCursor(blk))
        self.centerCursor()
        if flash:
            self.flash(n - 1)

    def goto_def(self, name):
        m = re.search(rf'^def {re.escape(name)}\(', self.toPlainText(), re.M)
        if not m:
            return False
        blk = self.document().findBlock(m.start())
        self.setTextCursor(QTextCursor(blk))
        self.verticalScrollBar().setValue(max(0, blk.blockNumber() - 2))  # the function near the top
        self.flash(blk.blockNumber())
        return True

    def flash(self, line):
        self.flash_line = line
        self.refresh_marks()
        QTimer.singleShot(1300, self._unflash)

    def _unflash(self):
        self.flash_line = None
        self.refresh_marks()

    def find_all(self, text):
        self.matches = []
        if text:
            c = QTextCursor(self.document())
            while True:
                c = self.document().find(text, c)
                if c.isNull():
                    break
                self.matches.append(QTextCursor(c))
        self.refresh_marks()
        return len(self.matches)

    def find_step(self, back=False):
        if not self.matches:
            return 0
        pos = self.textCursor().selectionStart() if back else self.textCursor().selectionEnd()
        order = range(len(self.matches) - 1, -1, -1) if back else range(len(self.matches))
        pick = next((i for i in order if (self.matches[i].selectionEnd() <= pos if back else
                                          self.matches[i].selectionStart() >= pos)), order[0])
        self.setTextCursor(self.matches[pick])
        self.centerCursor()
        return pick + 1


class FindBar(QFrame):
    """Ctrl+F: find in the code."""

    def __init__(self, editor, parent=None):
        super().__init__(parent)
        self.setObjectName('FindBar')
        self.ed = editor
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 6, 10, 6)
        lay.setSpacing(6)
        self.box = QLineEdit(placeholderText='Find in code')
        self.box.setClearButtonEnabled(True)
        self.box.setMaximumWidth(320)
        self.count = QLabel()
        self.count.setObjectName('Muted')
        self.prev, self.next, self.close_btn = QPushButton(), QPushButton(), QPushButton()
        for b, tip in ((self.prev, 'Previous (Shift+Enter)'), (self.next, 'Next (Enter)'), (self.close_btn, 'Close (Esc)')):
            b.setObjectName('Flat')
            b.setToolTip(tip)
            b.setAccessibleName(tip.split(' (')[0])
        lay.addWidget(self.box)
        lay.addWidget(self.count)
        lay.addWidget(self.prev)
        lay.addWidget(self.next)
        lay.addStretch(1)
        lay.addWidget(self.close_btn)
        self.box.textChanged.connect(self.search)
        self.box.returnPressed.connect(lambda: self.step(False))
        self.prev.clicked.connect(lambda: self.step(True))
        self.next.clicked.connect(lambda: self.step(False))
        self.close_btn.clicked.connect(self.close_bar)
        self.restyle()
        self.hide()

    def restyle(self):
        self.prev.setIcon(icon('up', T['muted'], 16))
        self.next.setIcon(icon('down', T['muted'], 16))
        self.close_btn.setIcon(icon('x', T['muted'], 16))

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            return self.close_bar()
        if e.key() in (Qt.Key_Return, Qt.Key_Enter) and e.modifiers() & Qt.ShiftModifier:
            return self.step(True)
        super().keyPressEvent(e)

    def open_bar(self):
        sel = self.ed.textCursor().selectedText()
        if sel and ' ' not in sel:
            self.box.setText(sel)
        self.show()
        self.box.setFocus()
        self.box.selectAll()
        self.search(self.box.text())

    def close_bar(self):
        self.hide()
        self.ed.find_all('')
        self.ed.setFocus()

    def search(self, text):
        n = self.ed.find_all(text)
        self.count.setText('' if not text else 'No matches' if not n else f'{n} match{"es" if n > 1 else ""}')
        if n:
            self.step(False)

    def step(self, back):
        n = len(self.ed.matches)
        if n:
            i = self.ed.find_step(back)
            self.count.setText(f'{i} of {n}')
