"""Small widgets: switch, segmented control, banner, toast and the busy line."""
from PySide6.QtCore import QEasingCurve, QPropertyAnimation, QRectF, QSize, Qt, QTimer, QVariantAnimation, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (QAbstractButton, QButtonGroup, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel,
                               QPushButton, QSizePolicy, QWidget)

from .theme import T, icon


def mix(a, b, k):
    a, b = QColor(a), QColor(b)
    return QColor(*(round(x + (y - x) * k) for x, y in zip(a.getRgb()[:3], b.getRgb()[:3])))


def repolish(w):
    w.style().unpolish(w)
    w.style().polish(w)


class Switch(QAbstractButton):
    """An on/off switch with its label; the knob slides when it changes."""

    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.setText(text)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._k = 0.0
        self._anim = QVariantAnimation(self, duration=140, easingCurve=QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._step)
        self.toggled.connect(self._go)

    def _go(self, on):
        if not self.isVisible():
            self._k = 1.0 if on else 0.0
            return self.update()
        self._anim.stop()
        self._anim.setStartValue(self._k)
        self._anim.setEndValue(1.0 if on else 0.0)
        self._anim.start()

    def _step(self, v):
        self._k = v
        self.update()

    def sizeHint(self):
        return QSize(46 + self.fontMetrics().horizontalAdvance(self.text()), max(24, self.fontMetrics().height() + 6))

    def hitButton(self, pos):
        return self.rect().contains(pos)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        h = self.height()
        track = QRectF(1, (h - 18) / 2, 32, 18)
        on = self.isEnabled()
        p.setPen(Qt.NoPen)
        p.setBrush(mix(T['strong'], T['accent'], self._k) if on else QColor(T['border']))
        p.drawRoundedRect(track, 9, 9)
        p.setBrush(QColor('#FFFFFF') if on else QColor(T['surface']))
        p.drawEllipse(QRectF(track.x() + 2 + self._k * 14, track.y() + 2, 14, 14))
        if self.hasFocus():
            p.setPen(QPen(QColor(T['accent']), 1.2))
            p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(track.adjusted(-2.5, -2.5, 2.5, 2.5), 11, 11)
        p.setPen(QColor(T['text'] if on else T['faint']))
        p.drawText(QRectF(44, 0, self.width() - 44, h), Qt.AlignVCenter | Qt.AlignLeft, self.text())


class Segmented(QFrame):
    """A row of mutually exclusive choices."""
    changed = Signal(str)

    def __init__(self, items, parent=None):
        super().__init__(parent)
        self.setObjectName('Seg')
        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(2)
        self.group, self.buttons = QButtonGroup(self), {}
        for key, label in items:
            b = QPushButton(label)
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self.changed.emit(k))
            self.group.addButton(b)
            self.buttons[key] = b
            lay.addWidget(b, 1)

    def value(self):
        return next(k for k, b in self.buttons.items() if b.isChecked())

    def setValue(self, key):
        self.buttons[key].setChecked(True)


class Banner(QFrame):
    """A message across the top of the code: what happened, and what you can do about it."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('Banner')
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 8, 8, 8)
        lay.setSpacing(10)
        self.ico = QLabel()
        self.text = QLabel()
        self.text.setWordWrap(True)
        self.text.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.actions = QHBoxLayout()
        self.actions.setSpacing(6)
        self.close_btn = QPushButton()
        self.close_btn.setObjectName('Flat')
        self.close_btn.setToolTip('Dismiss (Esc)')
        self.close_btn.setAccessibleName('Dismiss message')
        self.close_btn.clicked.connect(self.hide)
        lay.addWidget(self.ico, 0, Qt.AlignTop)
        lay.addWidget(self.text, 1)
        lay.addLayout(self.actions)
        lay.addWidget(self.close_btn, 0, Qt.AlignTop)
        self.kind = 'info'
        self.hide()

    def show_message(self, kind, text, actions=()):
        self.kind = kind
        self.setProperty('kind', kind)
        repolish(self)
        self.text.setText(text)
        while self.actions.count():
            w = self.actions.takeAt(0).widget()
            w.deleteLater()
        for label, fn in actions:
            b = QPushButton(label)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(fn)
            self.actions.addWidget(b)
        self.restyle()
        self.show()

    def restyle(self):
        name = {'error': 'alert', 'success': 'check'}.get(self.kind, 'info')
        colour = {'error': T['danger'], 'success': T['success']}.get(self.kind, T['info'])
        self.ico.setPixmap(icon(name, colour, 18).pixmap(18, 18))
        self.close_btn.setIcon(icon('x', T['muted'], 16))


class Toast(QLabel):
    """A short confirmation that fades out by itself."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setObjectName('Toast')
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.fx = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.fx)
        self.anim = QPropertyAnimation(self.fx, b'opacity', self)
        self.timer = QTimer(self, singleShot=True, timeout=self.fade)
        self.hide()

    def pop(self, text, ms=2600):
        self.setText(text)
        self.adjustSize()
        par = self.parentWidget()
        self.move((par.width() - self.width()) // 2, par.height() - self.height() - 28)
        self.raise_()
        self.show()
        self.anim.stop()
        self.anim.setDuration(140)
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)
        self.anim.start()
        self.timer.start(ms)

    def fade(self):
        self.anim.stop()
        self.anim.setDuration(380)
        self.anim.setStartValue(1.0)
        self.anim.setEndValue(0.0)
        self.anim.start()


class BusyLine(QWidget):
    """A thin moving line under the header while something runs."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(2)
        self.x = 0.0
        self.timer = QTimer(self, interval=16, timeout=self._tick)

    def start(self):
        self.x = -0.3
        self.timer.start()

    def stop(self):
        self.timer.stop()
        self.update()

    def _tick(self):
        self.x = self.x + 0.012 if self.x < 1.0 else -0.3
        self.update()

    def paintEvent(self, _):
        if not self.timer.isActive():
            return
        p = QPainter(self)
        w = self.width()
        p.fillRect(QRectF(self.x * w, 0, w * 0.3, 2), QColor(T['accent']))


def label(text, name=None, wrap=False):
    lb = QLabel(text)
    if name:
        lb.setObjectName(name)
    lb.setWordWrap(wrap)
    return lb


def divider():
    f = QFrame()
    f.setObjectName('Divider')
    f.setFixedHeight(1)
    return f
