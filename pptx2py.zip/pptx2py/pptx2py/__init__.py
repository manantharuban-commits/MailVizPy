"""pptx2py: PowerPoint -> compact python-pptx code, and code -> PowerPoint."""
from .convert import HELPERS, Result, convert, make_template, outline, parse_slides, run_code

__all__ = ['convert', 'outline', 'make_template', 'parse_slides', 'run_code', 'Result', 'HELPERS']
__version__ = '1.0.0'
