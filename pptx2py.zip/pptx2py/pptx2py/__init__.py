"""pptx2py: PowerPoint -> python-pptx code, and code -> PowerPoint."""
import re as _re
import sys as _sys

if _sys.version_info < (3, 9):
    raise ImportError(f'pptx2py needs Python 3.9 or newer; this is Python {_sys.version.split()[0]}.')
try:
    import pptx as _pptx
except ImportError:
    raise ImportError('pptx2py needs python-pptx. Install it with:  pip install python-pptx') from None
if tuple(int(x) for x in _re.findall(r'\d+', getattr(_pptx, '__version__', '0'))[:2]) < (1, 0):
    raise ImportError(f'pptx2py needs python-pptx 1.0 or newer; this Python has python-pptx {_pptx.__version__}. '
                      'Update it with:  pip install -U python-pptx')

from .convert import HELPERS, Result, convert, make_template, outline, parse_slides, run_code  # noqa: E402

__all__ = ['convert', 'outline', 'make_template', 'parse_slides', 'run_code', 'Result', 'HELPERS']
__version__ = '1.1.0'
