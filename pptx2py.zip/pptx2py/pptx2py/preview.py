"""Slide wireframes for the app's slide list: where each shape sits, its kind and colour. No rendering here."""
import re

from lxml import etree
from pptx.enum.shapes import MSO_SHAPE_TYPE

from .convert import DSP, A, P, R, Theme, fill_spec, kid, line_spec, ln, open_deck

TITLES = {'title', 'ctrTitle'}


def hex_of(spec, th):
    """A fill spec -> ('#RRGGBB', alpha 0..1) with theme colours resolved, or None."""
    if isinstance(spec, list):  # gradient: its first stop; pattern: its foreground
        spec = spec[2] if spec[0] == 'patt' else next((c for c, _ in spec[2:] if c), None)
    if not isinstance(spec, str) or not spec:
        return None
    v, _, a = spec.partition('/')
    m = re.fullmatch(r'([0-9A-Fa-f]{6})|([A-Za-z]+\d?)([+-]\d+)?', v)
    if not m:
        return None
    rgb = [int((m.group(1) or th.hex(m.group(2)))[i:i + 2], 16) for i in (0, 2, 4)]
    if m.group(3):  # +40 lighter / -25 darker
        k = int(m.group(3)) / 100
        rgb = [round(c + (255 - c) * k) if k > 0 else round(c * (1 + k)) for c in rgb]
    return '#' + ''.join(f'{c:02X}' for c in rgb), (int(a) / 100 if a else 1.0)


def _bg(slide, th):
    for owner in (slide, slide.slide_layout, slide.slide_layout.slide_master):
        bg = owner._element.find(f'{{{P}}}cSld/{{{P}}}bg')
        if bg is not None:
            pr, ref = kid(bg, 'bgPr', P), kid(bg, 'bgRef', P)
            return hex_of(fill_spec(pr, th) if pr is not None else fill_spec(None, th, ref), th)
    return None


def _kind(sh, el):
    if sh.shape_type == MSO_SHAPE_TYPE.PICTURE or ln(el) == 'pic':
        return 'pic'
    if ln(el) == 'graphicFrame':
        return 'table' if sh.has_table else 'chart' if sh.has_chart else 'object'
    if ln(el) == 'cxnSp':
        return 'line'
    g = el.find(f'.//{{{A}}}prstGeom')
    if g is not None and g.get('prst') in ('line', 'straightConnector1'):
        return 'line'
    return 'ellipse' if g is not None and g.get('prst') == 'ellipse' else 'shape'


def _walk(shapes, xf, th, out):
    for sh in shapes:
        el = sh._element
        try:
            box = [sh.left, sh.top, sh.width, sh.height]
        except Exception:  # noqa: BLE001  (a shape without a position)
            continue
        if None in box:
            continue
        if xf:
            ox, oy, sx, sy, cx, cy = xf
            box = [ox + (box[0] - cx) * sx, oy + (box[1] - cy) * sy, box[2] * sx, box[3] * sy]
        if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
            x = el.find(f'{{{P}}}grpSpPr/{{{A}}}xfrm')
            co, ce = kid(x, 'chOff'), kid(x, 'chExt')
            if co is not None and ce is not None and int(ce.get('cx', 0)) and int(ce.get('cy', 0)):
                _walk(sh.shapes, (box[0], box[1], box[2] / int(ce.get('cx')), box[3] / int(ce.get('cy')),
                                  int(co.get('x')), int(co.get('y'))), th, out)
            continue
        if ln(el) == 'graphicFrame' and _smartart(sh, box, th, out):
            continue
        sppr, st = el.find(f'{{{P}}}spPr'), el.find(f'{{{P}}}style')
        refs = {ln(c): c for c in st} if st is not None else {}
        xfrm = kid(sppr, 'xfrm') if sppr is not None else None
        ph = el.find(f'.//{{{P}}}nvPr/{{{P}}}ph')
        text = sh.text_frame.text if getattr(sh, 'has_text_frame', False) and sh.has_text_frame else ''
        out.append(dict(
            k=_kind(sh, el), box=box, text=len(text.strip()),
            title=ph is not None and ph.get('type') in TITLES,
            fill=hex_of(fill_spec(sppr, th, refs.get('fillRef')), th) if sppr is not None else None,
            line=hex_of(line_spec(sppr, th, refs.get('lnRef')).get('line'), th) if sppr is not None else None,
            rot=int(xfrm.get('rot', 0)) / 60000 if xfrm is not None else 0,
            flip=(xfrm is not None and xfrm.get('flipH') == '1', xfrm is not None and xfrm.get('flipV') == '1')))


def _smartart(sh, box, th, out):
    """SmartArt: the shapes PowerPoint drew for it, placed inside the frame."""
    ids = sh._element.find(f'.//{{{A}}}graphicData/*')
    dm = ids.get(f'{{{R}}}dm') if ids is not None else None
    rels = sh.part.rels
    if dm not in rels:
        return False
    m = re.search(rb'dataModelExt[^>]*relId="([^"]+)"', sh.part.related_part(dm).blob)
    if not m or m.group(1).decode() not in rels:
        return False
    tree = etree.fromstring(sh.part.related_part(m.group(1).decode()).blob)
    sx = box[2] / max(1, int(sh.width)) if sh.width else 1
    sy = box[3] / max(1, int(sh.height)) if sh.height else 1
    for sp in tree.iter(f'{{{DSP}}}sp'):
        sppr, st = sp.find(f'{{{DSP}}}spPr'), sp.find(f'{{{DSP}}}style')
        x = kid(sppr, 'xfrm')
        if x is None or kid(x, 'off') is None:
            continue
        o, e = kid(x, 'off'), kid(x, 'ext')
        refs = {ln(c): c for c in st} if st is not None else {}
        g = kid(sppr, 'prstGeom')
        text = ''.join(t.text or '' for t in sp.iter(f'{{{A}}}t'))
        out.append(dict(
            k='ellipse' if g is not None and g.get('prst') == 'ellipse' else 'shape',
            box=[box[0] + int(o.get('x')) * sx, box[1] + int(o.get('y')) * sy, int(e.get('cx')) * sx, int(e.get('cy')) * sy],
            text=len(text.strip()), title=False, label=text.strip(),
            fill=hex_of(fill_spec(sppr, th, refs.get('fillRef')), th),
            line=hex_of(line_spec(sppr, th, refs.get('lnRef')).get('line'), th),
            rot=int(x.get('rot', 0)) / 60000, flip=(x.get('flipH') == '1', x.get('flipV') == '1')))
    return True


def wireframes(source):
    """[{n, title, hidden, count, aspect, bg, shapes: [{k, x, y, w, h (0..1), fill, line, text, title, rot, flip}]}]"""
    prs = open_deck(source)
    W, H = prs.slide_width or 12192000, prs.slide_height or 6858000
    themes, slides = {}, []
    for n, s in enumerate(prs.slides, 1):
        master = s.slide_layout.slide_master
        th = themes.setdefault(id(master.part), Theme(master))
        shapes = []
        _walk(s.shapes, None, th, shapes)
        for d in shapes:
            x, y, w, h = d.pop('box')
            d.update(x=x / W, y=y / H, w=w / W, h=h / H)
        texts = [sh.text_frame.text for sh in ([s.shapes.title] if s.shapes.title is not None else []) +
                 list(s.shapes) if getattr(sh, 'has_text_frame', False) and sh.text_frame.text.strip().strip('0123456789')] + \
            [d['label'] for d in shapes if d.get('label')]
        slides.append(dict(n=n, title=' '.join(texts[0].split())[:90] if texts else 'No text on this slide',
                           hidden=s._element.get('show') in ('0', 'false'), count=len(s.shapes),
                           aspect=W / H, bg=_bg(s, th), shapes=shapes))
    return slides
