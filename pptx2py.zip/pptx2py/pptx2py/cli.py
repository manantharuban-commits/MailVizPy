"""Command line.  python -m pptx2py                       -> the desktop app
                 python -m pptx2py deck.pptx [options]    -> deck.py (+ template, pictures)
                 python -m pptx2py --run deck.py [out.pptx] -> runs code, writes a PowerPoint"""
import argparse
import sys
from pathlib import Path

from . import __version__
from .convert import convert, outline, parse_slides, run_code


def main(argv=None):
    ap = argparse.ArgumentParser(prog='pptx2py', description='PowerPoint -> python-pptx code, and back.')
    ap.add_argument('deck', nargs='?', help='.pptx to convert (no arguments: open the desktop app)')
    ap.add_argument('-V', '--version', action='version', version=f'pptx2py {__version__}')
    ap.add_argument('-s', '--slides', help='slide numbers, e.g. 3 or 1,4-6 (default: all)')
    ap.add_argument('-o', '--out', help='output folder (default: <deck>_py next to the deck)')
    ap.add_argument('--blank', action='store_true', help='start from a blank python-pptx deck, no template file')
    ap.add_argument('--embed', action='store_true', help='one self-contained .py: pictures and template inside')
    ap.add_argument('--compact', action='store_true', help='short helper calls (box(), pic() ...) instead of plain '
                                                           'python-pptx statements')
    ap.add_argument('--pure', action='store_true', help="python-pptx commands only: leave out what python-pptx can't "
                                                        "do (shadows, transparency, bullets ...)")
    ap.add_argument('--inline', action='store_true', help='compact: helpers inside the script, not pptx_helpers.py')
    ap.add_argument('--no-notes', action='store_true', help='leave out speaker notes')
    ap.add_argument('--no-fx', action='store_true', help='leave out shadows, glow and other effects')
    ap.add_argument('--list', action='store_true', help='list the slides and stop')
    ap.add_argument('--run', metavar='SCRIPT', help='run python-pptx code and save the PowerPoint it builds')
    ap.add_argument('--verify', action='store_true', help='also build the PowerPoint and compare it with the deck, '
                                                          'shape by shape')
    ap.add_argument('--gui', action='store_true', help='open the desktop app')
    a, rest = ap.parse_known_args(argv)

    if a.run:
        script = Path(a.run).resolve()
        out = Path(rest[0] if rest else a.deck or script.with_name(script.stem + '_rebuilt.pptx')).resolve()
        notes = []
        built = run_code(script.read_text(encoding='utf-8'), out, script.parent, notes=notes)
        for note in notes:
            print(note)
        print(built)
        return 0
    if a.gui or not a.deck:
        from .gui import main as gui
        gui(a.deck)
        return 0
    deck = Path(a.deck)
    info = outline(deck.read_bytes())
    if a.list:
        for n, title, items, hidden in info:
            print(f'{n:>3}  {title}{"  (hidden)" if hidden else ""}  [{items} shapes]')
        return 0
    slides = parse_slides(a.slides, len(info)) if a.slides else None
    if a.slides and not slides:
        ap.error(f'no slides in 1-{len(info)} match {a.slides!r}')
    r = convert(deck, slides=slides, template=not a.blank, embed=a.embed, notes=not a.no_notes, fx=not a.no_fx,
                helpers='inline' if a.inline or a.embed else 'file', style='compact' if a.compact else 'plain',
                extras=not a.pure)
    out = Path(a.out or deck.with_name(deck.stem + '_py'))
    out.mkdir(parents=True, exist_ok=True)
    (out / f'{deck.stem}.py').write_text(r.code, encoding='utf-8')
    for name, blob in r.files.items():
        (out / name).parent.mkdir(parents=True, exist_ok=True)
        (out / name).write_bytes(blob)
    print(f'{out / (deck.stem + ".py")}: {len(r.slides)} slide{"s" if len(r.slides) != 1 else ""}, {r.lines} lines'
          + (f', + {len(r.files)} files' if r.files else ''))
    for s in r.skipped:
        print('  left out:', s)
    for s in r.notes:
        print('  not exact:', s)
    if a.verify:
        from .verify import compare
        built = run_code(r.code, out / f'{deck.stem}_rebuilt.pptx', out)
        rep = compare(str(deck), str(built), r.slides, not a.blank, r.skipped + r.notes)
        print(f'{built}:')
        print(rep.text())
        return 1 if rep.errors else 0
    return 0


if __name__ == '__main__':
    sys.exit(main())
