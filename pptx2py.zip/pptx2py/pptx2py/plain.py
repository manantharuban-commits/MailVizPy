"""The python-pptx code style: every shape written as ordinary python-pptx statements, with no helper calls and
no XML.

python-pptx has no command for a few things: shadows, transparency, arrowheads, bullets, cell borders, picture
fills and the like. With extras on, the code calls a named function from pptx_helpers for each. With extras
off, they are left out and listed at the top of the script.
"""
import ast
import math
import re
import textwrap
from collections import Counter

from pptx.enum.chart import XL_LABEL_POSITION, XL_LEGEND_POSITION
from pptx.enum.dml import MSO_PATTERN_TYPE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_UNDERLINE
from pptx.shapes.autoshape import AutoShapeType

from .convert import HELPERS, HELPERS_GUARD, SCRIPT_HERE, SCRIPT_MAIN, Raw, _deps, animate_code, inch, lit, num, report_lines, tall

THEME = {'tx1': 'TEXT_1', 'tx2': 'TEXT_2', 'bg1': 'BACKGROUND_1', 'bg2': 'BACKGROUND_2', 'dk1': 'DARK_1',
         'lt1': 'LIGHT_1', 'dk2': 'DARK_2', 'lt2': 'LIGHT_2', 'hlink': 'HYPERLINK', 'folHlink': 'FOLLOWED_HYPERLINK',
         **{f'accent{i}': f'ACCENT_{i}' for i in range(1, 7)}}
SHAPES = {m.xml_value: m for m in MSO_SHAPE if getattr(m, 'xml_value', None)}
ALIGN = {'l': 'LEFT', 'c': 'CENTER', 'r': 'RIGHT', 'j': 'JUSTIFY', 'd': 'DISTRIBUTE', 'jl': 'JUSTIFY_LOW',
         'td': 'THAI_DISTRIBUTE'}
ANCHOR = {'t': 'TOP', 'm': 'MIDDLE', 'b': 'BOTTOM'}
DASH = {'dash': 'DASH', 'dashDot': 'DASH_DOT', 'lgDashDotDot': 'DASH_DOT_DOT', 'lgDash': 'LONG_DASH',
        'lgDashDot': 'LONG_DASH_DOT', 'sysDot': 'ROUND_DOT', 'sysDash': 'SQUARE_DOT', 'dot': 'ROUND_DOT',
        'sysDashDot': 'DASH_DOT', 'sysDashDotDot': 'DASH_DOT_DOT', 'solid': 'SOLID'}
FRAME_KEYS = ('wrap', 'fit', 'anchor', 'm', 'vert', 'trot', 'cols', 'warp', 'd3t')
PARA_KEYS = ('align', 'lvl', 'ls', 'lsp', 'sb', 'sa', 'ml', 'ind', 'bul')
FONT_KEYS = ('b', 'i', 'u', 'sz', 'f', 'c', 'cap', 'spc', 'base', 'strike', 'hl', 'ol', 'tfx', 'mark', 'fld')
VECTOR = ('emf', 'wmf', 'pdf', 'tif', 'tiff', 'svg')
IMPORTS = {'Presentation': 'pptx', 'Inches': 'pptx.util', 'Pt': 'pptx.util', 'Centipoints': 'pptx.util', 'RGBColor': 'pptx.dml.color',
           'MSO_THEME_COLOR': 'pptx.enum.dml', 'MSO_LINE_DASH_STYLE': 'pptx.enum.dml', 'MSO_PATTERN': 'pptx.enum.dml',
           'MSO_SHAPE': 'pptx.enum.shapes',
           'MSO_CONNECTOR': 'pptx.enum.shapes', 'PP_ALIGN': 'pptx.enum.text', 'MSO_ANCHOR': 'pptx.enum.text',
           'MSO_AUTO_SIZE': 'pptx.enum.text', 'MSO_UNDERLINE': 'pptx.enum.text', 'CategoryChartData': 'pptx.chart.data', 'XyChartData': 'pptx.chart.data',
           'BubbleChartData': 'pptx.chart.data', 'XL_CHART_TYPE': 'pptx.enum.chart',
           'XL_LEGEND_POSITION': 'pptx.enum.chart', 'XL_LABEL_POSITION': 'pptx.enum.chart'}
EXTRAS = ('opacity', 'gradient', 'picture_fill', 'arrows', 'effects', 'picture_effects', 'bullet', 'indent',
          'font_extras', 'text_direction', 'autofit', 'mirror', 'cell_border', 'table_style', 'hide_slide',
          'hide_layout_graphics', 'picture_background', 'add_any_picture', 'doughnut_hole', 'chart_area', 'set_theme',
          'empty_line', 'transition', 'animate', 'text_effects', 'text_outline', 'field', 'text_columns', 'text_warp',
          'three_d', 'glue', 'combo_chart', 'series_labels', 'hide', 'outline', 'click_jump', 'cell_direction', 'picture_back',
          'group_box', 'preset', 'to_front', 'smartart', 'chart_3d', 'plot_layout', 'chart_text', 'pie_explode')
UNDERLINE = {m.xml_value: m.name for m in MSO_UNDERLINE if getattr(m, 'xml_value', None)}
PATTERNS = {m.xml_value: m.name for m in MSO_PATTERN_TYPE if getattr(m, 'xml_value', None)}
V = '@V@'  # stands for the variable in a factored block
WIDTH = 118


def size(pt):
    """Pt(...) for a font size, or Centipoints(...) when Pt() would round it off (17.99 pt)."""
    return f'Pt({lit(pt)})' if int(pt * 12700) // 127 == round(pt * 100) else f'Centipoints({round(pt * 100)})'


def In(v):
    return f'Inches({lit(num(v, 3))})'


def X(code, what):
    """A statement that needs an extra from pptx_helpers (python-pptx has no command for it)."""
    return ('X', code, what)


def dense(seq, indent):
    """A list written several items to a line."""
    items = [lit(x) for x in seq]
    one = '[' + ', '.join(items) + ']'
    if len(one) + indent <= WIDTH:
        return one
    pad, lines, cur = ' ' * (indent + 4), [], ''
    for it in items:
        if cur and len(pad) + len(cur) + len(it) + 2 > WIDTH:
            lines.append(cur.rstrip())
            cur = ''
        cur += it + ', '
    lines.append(cur.rstrip())
    return '[\n' + '\n'.join(pad + x for x in lines) + '\n' + ' ' * indent + ']'


def kwargs(d):
    return ', '.join(f'{k}={lit(v)}' for k, v in d.items())


# ── free-form outlines as line segments (python-pptx's freeform builder draws straight lines only) ──
def flatten(geom):
    """'W H M x y C ... Z | ...' -> ([(start, [points], closed), ...], filled), in 0..10000 of the shape box."""
    subs, filled, cur, start, pts = [], False, (0, 0), (0, 0), []

    def push(closed):
        nonlocal pts
        if pts:
            subs.append((start, pts, closed))
        pts = []

    for path in geom.split('|'):
        t = re.findall(r'[A-Za-z]+|-?\d+', path)
        pw, ph, i = int(t[0]) or 1, int(t[1]) or 1, 2
        sx, sy = 10000 / pw, 10000 / ph
        path_filled = True
        while i < len(t):
            c, i = t[i], i + 1
            if c in ('none', 'nostroke', 'norm', 'lighten', 'lightenLess', 'darken', 'darkenLess'):
                path_filled = path_filled and c != 'none'
                continue
            if c == 'M':
                push(False)
                cur = start = (int(t[i]) * sx, int(t[i + 1]) * sy)
                i += 2
            elif c == 'L':
                cur = (int(t[i]) * sx, int(t[i + 1]) * sy)
                pts.append(cur)
                i += 2
            elif c in ('C', 'Q'):
                n = 6 if c == 'C' else 4
                ctrl = [(int(t[j]) * sx, int(t[j + 1]) * sy) for j in range(i, i + n, 2)]
                i += n
                ps = [cur] + ctrl
                steps = max(2, min(12, math.ceil(math.dist(ps[0], ps[-1]) / 700)))
                for k in range(1, steps + 1):
                    u = k / steps
                    if c == 'C':
                        x = sum(b * p[0] for b, p in zip(((1 - u) ** 3, 3 * u * (1 - u) ** 2, 3 * u * u * (1 - u), u ** 3), ps))
                        y = sum(b * p[1] for b, p in zip(((1 - u) ** 3, 3 * u * (1 - u) ** 2, 3 * u * u * (1 - u), u ** 3), ps))
                    else:
                        x = sum(b * p[0] for b, p in zip(((1 - u) ** 2, 2 * u * (1 - u), u * u), ps))
                        y = sum(b * p[1] for b, p in zip(((1 - u) ** 2, 2 * u * (1 - u), u * u), ps))
                    pts.append((x, y))
                cur = ps[-1]
            elif c == 'A':
                wr, hr, st, sw = int(t[i]) * sx, int(t[i + 1]) * sy, int(t[i + 2]) / 60000, int(t[i + 3]) / 60000
                i += 4

                def on(a):
                    r = math.radians(a)
                    q = math.atan2(wr * math.sin(r), hr * math.cos(r))
                    return wr * math.cos(q), hr * math.sin(q)
                ex, ey = on(st)
                cx, cy = cur[0] - ex, cur[1] - ey
                steps = max(2, math.ceil(abs(sw) / 10))
                for k in range(1, steps + 1):
                    ox, oy = on(st + sw * k / steps)
                    pts.append((cx + ox, cy + oy))
                cur = pts[-1]
            elif c == 'Z':
                push(True)
                cur = start
        filled = filled or path_filled
        push(False)
    out = []
    for st, ps, closed in subs:
        q = [(round(x), round(y)) for x, y in ps]
        q = [p for k, p in enumerate(q) if k == 0 or p != q[k - 1]]
        out.append(((round(st[0]), round(st[1])), q, closed))
    return out, filled


class Writer:
    def __init__(self, cv):
        self.cv, self.extras = cv, cv.extras
        self.dropped, self.blocks = Counter(), Counter()
        self.links = False

    # ── output plumbing: items are str or X(...); out holds (indent, text | block) ──
    def put(self, out, ind, items):
        for it in items:
            if isinstance(it, tuple):
                if self.extras:
                    out.append((ind, it[1]))
                else:
                    self.dropped[it[2]] += 1
            else:
                out.append((ind, it))

    def resolve(self, items):
        tmp = []
        self.put(tmp, 0, items)
        return [t for _, t in tmp]

    def block(self, out, ind, kind, items, var):
        """Statements on one object; the same ones used twice or more become a function."""
        lines = tuple(self.resolve(items))
        if lines:
            self.blocks[(kind, lines)] += 1
            out.append((ind, ('BLK', (kind, lines), var)))

    def assign(self, ind, lhs, value):
        return f'{lhs} = {tall(value, 4 + 4 * ind, WIDTH)}'

    # ── values ──
    def colour(self, t, spec):
        v, _, a = spec.partition('/')
        items = []
        if re.fullmatch(r'[0-9A-Fa-f]{6}', v):
            items.append(f"{t}.rgb = RGBColor.from_string('{v.upper()}')")
        else:
            m = re.fullmatch(r'([a-zA-Z]+\d?)([+-]\d+)?', v)
            items.append(f'{t}.theme_color = MSO_THEME_COLOR.{THEME.get(m[1] if m else v, "TEXT_1")}')
            if m and m[2]:
                items.append(f'{t}.brightness = {lit(num(int(m[2]) / 100, 2))}')
        if a:
            items.append(X(f'opacity({t}, {lit(num(float(a), 1))})', 'transparency'))
        return items

    def hex(self, spec):
        """A colour as RRGGBB: theme colours worked out with the deck's first theme, tints applied, alpha dropped."""
        v = spec.split('/')[0]
        if re.fullmatch(r'[0-9A-Fa-f]{6}', v):
            return v.upper()
        m = re.fullmatch(r'([a-zA-Z]+\d?)([+-]\d+)?', v)
        rgb = [int(self.cv.base.hex(m[1] if m else v)[i:i + 2], 16) for i in (0, 2, 4)]
        k = int(m[2]) / 100 if m and m[2] else 0
        rgb = [round(c + (255 - c) * k) if k > 0 else round(c * (1 + k)) for c in rgb]
        return ''.join(f'{c:02X}' for c in rgb)

    def src(self, img):
        return f'io.BytesIO(base64.b64decode({img}))' if isinstance(img, Raw) else f'os.path.join(HERE, {img!r})'

    def fill(self, t, v, shape=None):
        if v == '':
            return [f'{t}.background()']
        if isinstance(v, str):
            return [f'{t}.solid()'] + self.colour(f'{t}.fore_color', v)
        if v[0] == 'img':
            if shape is None:
                return []
            extra = (', tile=True' if len(v) > 2 and v[2] else '') + (', ' + kwargs(v[3]) if len(v) > 3 and v[3] else '')
            return [X(f'picture_fill({shape}, {self.src(v[1])}{extra})', 'picture fills')]
        if v[0] == 'patt':
            return [f'{t}.patterned()', f'{t}.pattern = MSO_PATTERN.{PATTERNS.get(v[1], "PERCENT_5")}'] + \
                self.colour(f'{t}.fore_color', v[2]) + self.colour(f'{t}.back_color', v[3])
        radial, ang, stops = v[0] == 'path', v[1], v[2:]
        hexes = all(re.fullmatch(r'[0-9A-Fa-f]{6}', c) for c, _ in stops)  # python-pptx's stops keep theme tints
        line = t.endswith('line.fill')  # python-pptx makes line gradients without stops or angle
        simple = len(stops) == 2 and not radial and hexes and not line
        if not simple and self.extras:
            return [X(f'gradient({t}, {lit(list(stops))}' + (f', radial={lit(ang or True)}' if radial else
                                                              f', angle={lit(ang)}') + ')', 'gradients')]
        if line:
            self.dropped['gradient lines (drawn in their first colour)'] += 1
            return [f'{t}.solid()'] + self.colour(f'{t}.fore_color', stops[0][0] or '000000')
        if not simple and not (len(stops) == 2 and not radial):
            self.dropped['gradients with three or more colours, radial or see-through (simplified)'] += 1
        items = [f'{t}.gradient()'] + ([] if radial else [f'{t}.gradient_angle = {lit(num((360 - ang) % 360, 1))}'])
        for i, (c, pos) in enumerate((stops[0], stops[-1])):
            items += self.colour(f'{t}.gradient_stops[{i}].color', self.hex(c))
            if pos != (0, 100)[i]:
                items.append(f'{t}.gradient_stops[{i}].position = {lit(num(pos / 100, 3))}')
        return items

    def line(self, v, kw):
        c, w, dash, ends = kw.get('line'), kw.get('lw'), kw.get('dash'), kw.get('ends')
        items = []
        if c == '':
            items.append(f'{v}.line.fill.background()')
        elif isinstance(c, list):  # a gradient or patterned line
            items += self.fill(f'{v}.line.fill', c)
        elif c:
            items += self.colour(f'{v}.line.color', c)
        if w:
            items.append(f'{v}.line.width = Pt({lit(w)})')
        if dash and dash != 'solid':
            items.append(f'{v}.line.dash_style = MSO_LINE_DASH_STYLE.{DASH.get(dash, "DASH")}')
        if ends and any(ends):
            items.append(X(f'arrows({v}.line, {lit(ends[0])}, {lit(ends[1])})', 'arrowheads'))
        return items

    def look(self, v, kw, autoshape=False):
        """Fill, line and effects. New python-pptx shapes have the theme's fill, line and shadow, so a shape
        without them says so."""
        kw = dict(kw)
        if autoshape:
            kw.setdefault('fill', '')
            if 'line' not in kw and not kw.get('lw'):
                kw['line'] = ''
        items = self.fill(f'{v}.fill', kw['fill'], v) if 'fill' in kw else []
        items += self.line(v, kw)
        if kw.get('fx'):
            items.append(X(f'effects({v}, {kwargs(kw["fx"])})', 'shadows and other effects'))
        elif autoshape:
            items.append(f'{v}.shadow.inherit = False')
        if kw.get('d3'):
            items.append(X(f'three_d({v}, {kwargs(kw["d3"])})', '3-D rotation, depth and bevels'))
        return items

    def link(self, out, ind, var, kw):
        if kw.get('link'):
            out.append((ind, f'{var}.click_action.hyperlink.address = {lit(kw["link"])}'))
        if kw.get('goto'):
            self.links = True
            out.append((ind, f'LINKS.append(({var}, {kw["goto"]}))  # a click jumps to slide {kw["goto"]}'))
        if kw.get('jump'):
            self.put(out, ind, [X(f'click_jump({var}, {lit(kw["jump"])})', 'clicks that go to the next or previous slide')])

    # ── text ──
    def frame(self, tf, fr):
        items = []
        if 'wrap' in fr:
            items.append(f'{tf}.word_wrap = {bool(fr["wrap"])}')
        if 'fit' in fr:
            f = fr['fit'] if isinstance(fr['fit'], (list, tuple)) else (fr['fit'],)
            if f[0] == 'text' and len(f) > 1 and self.extras:
                items.append(X(f'autofit({tf}, {", ".join(lit(x) for x in f[1:])})', 'shrink-on-overflow scale'))
            else:
                items.append(f'{tf}.auto_size = MSO_AUTO_SIZE.' +
                             {'none': 'NONE', 'shape': 'SHAPE_TO_FIT_TEXT', 'text': 'TEXT_TO_FIT_SHAPE'}[f[0]])
        if 'anchor' in fr:
            items.append(f'{tf}.vertical_anchor = MSO_ANCHOR.{ANCHOR[fr["anchor"]]}')
        items += self.margins(tf, fr.get('m'))
        if 'vert' in fr or 'trot' in fr:
            args = (lit(fr['vert']) if 'vert' in fr else '') + (', ' if 'vert' in fr and 'trot' in fr else '') + \
                (f'rotate={lit(fr["trot"])}' if 'trot' in fr else '')
            items.append(X(f'text_direction({tf}, {args})', 'vertical or turned text'))
        if 'cols' in fr:
            items.append(X(f'text_columns({tf}, {fr["cols"][0]}, {In(fr["cols"][1])})', 'text columns'))
        if 'warp' in fr:
            items.append(X(f'text_warp({tf}, {", ".join(lit(x) for x in fr["warp"])})', 'WordArt text transforms'))
        if 'd3t' in fr:
            items.append(X(f'three_d({tf}, {kwargs(fr["d3t"])})', '3-D text'))
        return items

    def margins(self, v, m):
        """Inner margins that differ from python-pptx's (0.1, 0.05, 0.1, 0.05 in): in one line when it can."""
        if not m:
            return []
        sides = [(side, val) for side, val, default in zip(('left', 'top', 'right', 'bottom'), m, (0.1, 0.05, 0.1, 0.05))
                 if val != default]
        if len(sides) == 4 and len(set(m)) == 1:
            return [' = '.join(f'{v}.margin_{side}' for side, _ in sides) + f' = {In(m[0])}']
        if len(sides) >= 3:
            return [', '.join(f'{v}.margin_{side}' for side, _ in sides) + ' = ' + ', '.join(In(val) for _, val in sides)]
        return [f'{v}.margin_{side} = {In(val)}' for side, val in sides]

    def para(self, p, pp):
        items = []
        if 'align' in pp:
            items.append(f'{p}.alignment = PP_ALIGN.{ALIGN[pp["align"]]}')
        if 'lvl' in pp:
            items.append(f'{p}.level = {pp["lvl"]}')
        if 'ls' in pp:
            items.append(f'{p}.line_spacing = {lit(pp["ls"])}')
        if 'lsp' in pp:
            items.append(f'{p}.line_spacing = Pt({lit(pp["lsp"])})')
        if 'sb' in pp:
            items.append(f'{p}.space_before = Pt({lit(pp["sb"])})')
        if 'sa' in pp:
            items.append(f'{p}.space_after = Pt({lit(pp["sa"])})')
        if 'ml' in pp or 'ind' in pp:
            items.append(X(f'indent({p}, {In(pp["ml"]) if "ml" in pp else None}, '
                           f'{In(pp["ind"]) if "ind" in pp else None})', 'paragraph indents'))
        if 'bul' in pp:
            b = pp['bul']
            if isinstance(b, dict):
                args = lit(b.get('char', '1.' if 'num' in b else '•')) + \
                    ''.join(f', {k}={lit(b[k])}' for k in ('font', 'color', 'size', 'num', 'start') if k in b)
            elif isinstance(b, (list, tuple)):
                args = f'{lit(b[0])}, font={lit(b[1])}'
            else:
                args = lit(b)
            items.append(X(f'bullet({p}, {args})', 'bullets'))
        return items

    def font(self, f, d):
        items = []
        for k, attr in (('b', 'bold'), ('i', 'italic'), ('u', 'underline')):
            if k in d and isinstance(d[k], str):
                items.append(f'{f}.{attr} = MSO_UNDERLINE.{UNDERLINE.get(d[k], "SINGLE_LINE")}')
            elif k in d:
                items.append(f'{f}.{attr} = {bool(d[k])}')
        if 'sz' in d:
            items.append(f'{f}.size = {size(d["sz"])}')
        if 'f' in d:
            items.append(f'{f}.name = {lit(d["f"])}')
        if 'c' in d:
            c = d['c']
            items += self.fill(f'{f}.fill', c) if c == '' or isinstance(c, list) else self.colour(f'{f}.color', c)
        ex = {k2: d[k] for k, k2 in (('cap', 'caps'), ('spc', 'spacing'), ('base', 'baseline'), ('strike', 'strike'),
                                     ('mark', 'highlight')) if k in d}
        if ex:
            items.append(X(f'font_extras({f}, {kwargs(ex)})',
                           'character spacing, small caps, superscript, strike and highlight'))
        if 'ol' in d:
            items.append(X(f'text_outline({f}, {lit(d["ol"][0])}, Pt({lit(d["ol"][1])}))', 'outlined text (WordArt)'))
        if 'tfx' in d:
            items.append(X(f'text_effects({f}, {kwargs(d["tfx"])})', 'text shadows and glows (WordArt)'))
        return items

    def text(self, out, ind, tf, t, kw, autoshape=False):
        self.put(out, ind, self.frame(tf, {k: kw[k] for k in FRAME_KEYS if k in kw}))
        if t is None:
            return
        shape_para = {k: kw[k] for k in PARA_KEYS if k in kw}
        shape_font = {k: kw[k] for k in FONT_KEYS if k in kw}
        paras = []
        for p in t.split('\n') if isinstance(t, str) else t:
            pp = {}
            if isinstance(p, dict):
                pp, p = {k: v for k, v in p.items() if k != 't'}, p.get('t', '')
            runs = [(p, {})] if isinstance(p, str) else [(r, {}) if isinstance(r, str) else (r[0], dict(r[1])) for r in p]
            rs = []
            for txt, rp in runs:
                f = {**shape_font, **{k: v for k, v in pp.items() if k not in PARA_KEYS}, **rp}
                if autoshape and 'c' not in f:
                    f['c'] = 'tx1'  # new python-pptx shapes have white text
                if f.get('cap') == 'all' and not self.extras:  # python-pptx has no capitals setting: written out
                    txt = txt.upper()
                    f.pop('cap')
                rs.append((txt, f))
            paras.append(({**shape_para, **{k: v for k, v in pp.items() if k in PARA_KEYS}}, rs))
        fonts = {repr(sorted(f.items())) for _, rs in paras for txt, f in rs if txt}
        empty_sized = any(not ''.join(txt for txt, _ in rs) and any('sz' in f for _, f in rs) for _, rs in paras)
        uniform = len(fonts) <= 1 and len({repr(sorted(pp.items())) for pp, _ in paras}) == 1 and \
            not any('hl' in f or 'fld' in f for _, rs in paras for _, f in rs) and not empty_sized
        if uniform:
            joined = '\n'.join(''.join(txt for txt, _ in rs) for _, rs in paras)
            pp = paras[0][0]
            f = next((f for _, rs in paras for txt, f in rs if txt), {})
            out.append((ind, self.assign(ind, f'{tf}.text', joined)))
            para_items, font_items = self.resolve(self.para(V, pp)), self.resolve(self.font(V, f))
            if len(paras) == 1 and '\v' not in joined:
                if para_items:
                    out.append((ind, f'p = {tf}.paragraphs[0]'))
                    self.block(out, ind, 'para', para_items, 'p')
                self.block(out, ind, 'font', font_items, ('p' if para_items else f'{tf}.paragraphs[0]') + '.runs[0].font')
            elif para_items or font_items:
                out.append((ind, f'for p in {tf}.paragraphs:'))
                self.block(out, ind + 1, 'para', para_items, 'p')
                if font_items:
                    out.append((ind + 1, 'for r in p.runs:'))
                    self.block(out, ind + 2, 'font', font_items, 'r.font')
            return
        for i, (pp, rs) in enumerate(paras):
            out.append((ind, f'p = {tf}.paragraphs[0]' if i == 0 else f'p = {tf}.add_paragraph()'))
            self.block(out, ind, 'para', self.para(V, pp), 'p')
            if not ''.join(txt for txt, _ in rs):  # an empty line keeps its height with an empty run
                sz = next((f['sz'] for _, f in rs if 'sz' in f), None)
                if sz:
                    out.append((ind, f'empty_line(p, Pt({lit(sz)}))' if self.extras else
                                f'p.add_run().font.size = Pt({lit(sz)})'))
                continue
            for txt, f in rs:
                for j, part in enumerate(txt.split('\v')):
                    if j:
                        out.append((ind, 'p.add_line_break()'))
                    if part:
                        if 'fld' in f and self.extras:  # a slide number or date PowerPoint keeps up to date
                            out.append((ind, f'r = field(p, {lit(f["fld"])}, {lit(part)})'))
                        else:
                            if 'fld' in f:
                                self.dropped['slide-number and date fields (written as plain text)'] += 1
                            out.append((ind, 'r = p.add_run()'))
                            out.append((ind, self.assign(ind, 'r.text', part)))
                        self.block(out, ind, 'font', self.font(V, f), 'r.font')
                        if 'hl' in f:
                            out.append((ind, f'r.hyperlink.address = {lit(f["hl"])}'))

    # ── shapes ──
    def shape_head(self, out, ind, parent, kw, x, y, w, h):
        """Creates `sh`; returns whether python-pptx gave it the theme's look."""
        shapes = f'{parent}.shapes'
        if kw.get('geom'):
            subs, filled = flatten(kw['geom'])
            if not filled and 'fill' not in kw:
                kw['fill'] = ''
            xs = [p[0] for _, pts, _ in subs for p in pts] + [st[0] for st, _, _ in subs]
            ys = [p[1] for _, pts, _ in subs for p in pts] + [st[1] for st, _, _ in subs]
            if xs and (min(xs) < 0 or min(ys) < 0 or max(xs) > 10000 or max(ys) > 10000) and self.extras:
                # an outline reaching outside its box (callout pointers ...): build_freeform would grow the box
                out.append((ind, f'sh = {shapes}.add_shape(MSO_SHAPE.RECTANGLE, {In(x)}, {In(y)}, {In(w)}, {In(h)})'))
                self.put(out, ind, [X(f'outline(sh, {lit(kw["geom"])})', 'free-form outlines reaching outside their box')])
                return True
            if xs and (min(xs) < 0 or min(ys) < 0 or max(xs) > 10000 or max(ys) > 10000):
                self.dropped['free-form outlines reaching outside their box (the box grows to hold them)'] += 1
            (sx, sy), first = subs[0][0] if subs else (0, 0), True
            out.append((ind, f'ff = {shapes}.build_freeform({sx}, {sy}, scale=({In(w)} / 10000, {In(h)} / 10000))'))
            for start, pts, closed in subs:
                if not first:
                    out.append((ind, f'ff.move_to({start[0]}, {start[1]})'))
                first = False
                out.append((ind, f'ff.add_line_segments({dense(pts, 4 + 4 * ind)}, close={closed})'))
            if xs and (min(xs) > 0 or min(ys) > 0 or max(xs) < 10000 or max(ys) < 10000):
                out.append((ind, 'ff.move_to(0, 0)  # the two corners keep the original box'))
                out.append((ind, 'ff.move_to(10000, 10000)'))
            out.append((ind, f'sh = ff.convert_to_shape({In(x)}, {In(y)})'))
            return True
        if kw.get('shape'):
            m = SHAPES.get(kw['shape'])
            out.append((ind, f'sh = {shapes}.add_shape(MSO_SHAPE.{m.name if m else "RECTANGLE"}, '
                             f'{In(x)}, {In(y)}, {In(w)}, {In(h)})'))
            if m is None and self.extras:
                self.put(out, ind, [X(f'preset(sh, {lit(kw["shape"])}' + ''.join(f', {lit(v)}' for v in kw.get('adj') or ())
                                      + ')', 'outlines python-pptx has no name for')])
                return True
            if m is None:
                self.dropped[f'outline "{kw["shape"]}" (drawn as a rectangle)'] += 1
            defaults = AutoShapeType.default_adjustment_values(m) if m else ()
            for i, v in enumerate((kw.get('adj') or ())[:len(defaults)]):
                if v != defaults[i][1]:
                    out.append((ind, f'sh.adjustments[{i}] = {lit(num(v / 100000, 5))}'))
            return True
        out.append((ind, f'sh = {shapes}.add_textbox({In(x)}, {In(y)}, {In(w)}, {In(h)})'))
        return False

    def name(self, out, start, var, ref):
        """`a12 = sh = ...` for a shape animations or connectors refer to."""
        if ref:
            i = max(i for i in range(start, len(out)) if isinstance(out[i][1], str) and out[i][1].startswith(f'{var} = '))
            out[i] = (out[i][0], f'{ref} = {out[i][1]}')

    def emit_box(self, out, ind, c):
        parent, x, y, w, h = c.args[:5]
        kw = dict(c.kw)
        t = c.args[5] if len(c.args) > 5 else kw.pop('t', None)
        start = len(out)
        auto = self.shape_head(out, ind, parent, kw, x, y, w, h)
        self.name(out, start, 'sh', c.ref)
        if kw.get('rot'):
            out.append((ind, f'sh.rotation = {lit(kw["rot"])}'))
        if kw.get('flip'):
            self.put(out, ind, [X(f'mirror(sh, {lit(kw["flip"])})', 'flipped shapes')])
        self.block(out, ind, 'look', self.look(V, kw, auto), 'sh')
        self.link(out, ind, 'sh', kw)
        if t is not None or any(k in kw for k in FRAME_KEYS):
            out.append((ind, 'tf = sh.text_frame'))
            self.text(out, ind, 'tf', t, kw, auto)
        self.tidy(out, start, 'sh')

    def tidy(self, out, start, var):
        """`sh = s.shapes.add_...(...)` with nothing after it: just the call; used only for its text frame:
        `tf = s.shapes.add_...(...).text_frame`."""
        first = out[start][1] if len(out) > start else None
        if not isinstance(first, str) or not first.startswith(f'{var} = '):
            return
        uses = [i for i in range(start + 1, len(out)) if re.search(rf'\b{var}\b', out[i][1][2] if isinstance(
            out[i][1], tuple) else out[i][1])]
        if not uses:
            out[start] = (out[start][0], re.sub(r'\.(chart|table)$', '', first[len(var) + 3:]))
        elif len(uses) == 1 and out[uses[0]][1] == f'tf = {var}.text_frame' and uses[0] == start + 1:
            out[start: start + 2] = [(out[start][0], f'tf = {first[len(var) + 3:]}.text_frame')]

    def emit_ph(self, out, ind, c):
        idx = c.args[1]
        kw = dict(c.kw)
        t = c.args[2] if len(c.args) > 2 else kw.pop('t', None)
        start = len(out)
        out.append((ind, f'sh = s.placeholders[{idx}]'))
        self.name(out, start, 'sh', c.ref)
        if kw.get('front'):  # above the shapes made before it, as in the original
            self.put(out, ind, [X('to_front(sh)', 'stacking order of placeholders')])
        if kw.get('pos'):
            out.append((ind, 'sh.left, sh.top, sh.width, sh.height = ' + ', '.join(In(v) for v in kw['pos'])))
        self.block(out, ind, 'look', self.look(V, kw), 'sh')
        self.link(out, ind, 'sh', kw)
        if t is not None or any(k in kw for k in FRAME_KEYS):
            out.append((ind, 'tf = sh.text_frame'))
            self.text(out, ind, 'tf', t, kw)
        rest = out[start:]
        if not c.ref and len(rest) == 3 and all(isinstance(r[1], str) for r in rest) and rest[1][1] == 'tf = sh.text_frame' \
                and rest[2][1].startswith('tf.text = '):
            out[start:] = [(ind, f's.placeholders[{idx}].text = ' + rest[2][1][len('tf.text = '):])]
        else:
            self.tidy(out, start, 'sh')

    def emit_pic(self, out, ind, c):
        parent, img, x, y, w, h = c.args[:6]
        kw = c.kw
        name = str(img).rsplit('/', 1)[-1] if not isinstance(img, Raw) else \
            next((n for n, _ in self.cv.images.values() if repr(n.split('.')[0]) in img), 'img.png')
        ext = name.rsplit('.', 1)[-1].lower()
        start = len(out)
        args = f'{self.src(img)}, {In(x)}, {In(y)}, {In(w)}, {In(h)}'
        if ext in VECTOR or name in self.cv.odd:
            if not self.extras:
                self.dropped[f'{ext.upper()} pictures'] += 1
                out.append((ind, f'# left out: a {ext.upper()} picture (python-pptx cannot insert this picture type)'))
                return
            out.append((ind, f'pic = add_any_picture({parent}.shapes, {args})'))
        else:
            out.append((ind, f'pic = {parent}.shapes.add_picture({args})'))
        if not w or not h:  # python-pptx reads a zero size as "the picture's own size"
            out.append((ind, f'pic.width, pic.height = {In(w)}, {In(h)}'))
        self.name(out, start, 'pic', c.ref)
        for side, val in zip(('left', 'top', 'right', 'bottom'), kw.get('crop', ())):
            if val:
                out.append((ind, f'pic.crop_{side} = {lit(val)}'))
        if kw.get('shape') in SHAPES:
            out.append((ind, f'pic.auto_shape_type = MSO_SHAPE.{SHAPES[kw["shape"]].name}'))
        if kw.get('rot'):
            out.append((ind, f'pic.rotation = {lit(kw["rot"])}'))
        items = [X(f'mirror(pic, {lit(kw["flip"])})', 'flipped shapes')] if kw.get('flip') else []
        if kw.get('pfx'):
            items.append(X(f'picture_effects(pic, {kwargs(kw["pfx"])})', 'picture transparency and recolouring'))
        if kw.get('fill'):
            items.append(X(f'picture_back(pic, {lit(kw["fill"])})', 'fills behind pictures'))
        self.put(out, ind, items)
        self.block(out, ind, 'look', self.look(V, {k: v for k, v in kw.items() if k in ('line', 'lw', 'fx', 'd3')}), 'pic')
        self.link(out, ind, 'pic', kw)
        self.tidy(out, start, 'pic')

    def emit_movie(self, out, ind, c):
        parent, video, x, y, w, h = c.args[:6]
        start = len(out)
        poster = f', poster_frame_image={self.src(c.kw["poster"])}' if c.kw.get('poster') else ''
        out.append((ind, f'mv = {parent}.shapes.add_movie({self.src(video)}, {In(x)}, {In(y)}, {In(w)}, {In(h)}'
                         f'{poster}, mime_type={lit(c.kw.get("mime", "video/mp4"))})'))
        self.name(out, start, 'mv', c.ref)
        for side, val in zip(('left', 'top', 'right', 'bottom'), c.kw.get('crop') or ()):
            if val:
                out.append((ind, f'mv.crop_{side} = {lit(val)}'))
        self.tidy(out, start, 'mv')

    def emit_glue(self, out, ind, c):
        api = getattr(c, 'api', ())
        var, rest = c.args[0], {}
        for end in ('begin', 'end'):
            v = c.kw.get(end)
            if not v:
                continue
            if end in api:
                out.append((ind, f'{var}.{end}_connect({v[0]}, {v[1]})'))
            else:
                rest[end] = v
        if rest:
            args = ', '.join(f'{k}=({v[0]}, {v[1]})' for k, v in rest.items())
            self.put(out, ind, [X(f'glue({var}, {args})',
                                  'connectors attached to shapes (they are drawn in place, unattached)')])

    def emit_con(self, out, ind, c):
        parent, x1, y1, x2, y2 = c.args[:5]
        kw = c.kw
        shape = kw.get('shape') or ''
        kind = 'ELBOW' if shape.startswith('bent') else 'CURVE' if shape.startswith('curved') else 'STRAIGHT'
        start = len(out)
        out.append((ind, f'c = {parent}.shapes.add_connector(MSO_CONNECTOR.{kind}, {In(x1)}, {In(y1)}, {In(x2)}, '
                         f'{In(y2)})'))
        self.name(out, start, 'c', c.ref)
        if shape not in ('', 'bentConnector3', 'curvedConnector3') or kw.get('adj'):  # another elbow, or a moved bend
            self.put(out, ind, [X(f'preset(c, {lit(shape or "straightConnector1")}' +
                                  ''.join(f', {lit(v)}' for v in kw.get('adj') or ()) + ')', 'connector bends')])
        self.block(out, ind, 'look', self.line(V, kw), 'c')
        self.tidy(out, start, 'c')

    def emit_tbl(self, out, ind, c):
        x, y, w, h, rows, cw, rh = c.args[1:8]
        kw = c.kw
        nr, nc = len(rows), len(cw)
        if c.ref:
            out.append((ind, f'{c.ref} = s.shapes.add_table({nr}, {nc}, {In(x)}, {In(y)}, {In(w)}, {In(h)})'))
            out.append((ind, f't = {c.ref}.table'))
        else:
            out.append((ind, f't = s.shapes.add_table({nr}, {nc}, {In(x)}, {In(y)}, {In(w)}, {In(h)}).table'))
        for what, sizes, attr in (('columns', cw, 'width'), ('rows', rh, 'height')):
            if len(set(sizes)) == 1:
                out.append((ind, f'for x in t.{what}:'))
                out.append((ind + 1, f'x.{attr} = {In(sizes[0])}'))
            else:
                out.append((ind, f'for i, v in enumerate({lit(list(sizes))}):'))
                out.append((ind + 1, f't.{what}[i].{attr} = Inches(v)'))
        if kw.get('style'):
            self.put(out, ind, [X(f'table_style(t, {lit(kw["style"])})', 'table styles')])
        if kw.get('flags') is not None:
            on = kw['flags'].split()
            for a, attr, default in (('firstRow', 'first_row', True), ('firstCol', 'first_col', False),
                                     ('lastRow', 'last_row', False), ('lastCol', 'last_col', False),
                                     ('bandRow', 'horz_banding', True), ('bandCol', 'vert_banding', False)):
                if (a in on) != default:
                    out.append((ind, f't.{attr} = {a in on}'))
        plain = [[v if isinstance(v, str) else '' for v in row] for row in rows]
        if any(v for row in plain for v in row):
            out.append((ind, self.assign(ind, 'rows', plain)))
            out.append((ind, 'for r, row in enumerate(rows):'))
            out.append((ind + 1, 'for i, text in enumerate(row):'))
            out.append((ind + 2, 't.cell(r, i).text = text'))
        cs = kw.get('cs') or {}
        order = ['*'] + sorted((k for k in cs if isinstance(k, str) and k[0] == 'r'), key=lambda k: int(k[1:])) + \
            sorted((k for k in cs if isinstance(k, str) and k[0] == 'c'), key=lambda k: int(k[1:])) + \
            sorted(k for k in cs if isinstance(k, tuple))
        for key in order:
            st = cs.get(key)
            if not st:
                continue
            if isinstance(key, tuple):
                out.append((ind, f'cell = t.cell{key}'))
                n = len(out)
                self.cell_style(out, ind, st, single=True)
                if len(out) == n:
                    out.pop()
                continue
            if key == '*':
                out.append((ind, 'for cell in t.iter_cells():'))
            elif key[0] == 'r':
                out.append((ind, f'for cell in t.rows[{key[1:]}].cells:'))
            else:
                out.append((ind, f'for cell in (t.cell(r, {key[1:]}) for r in range({nr})):'))
            self.cell_style(out, ind + 1, st)
        for (r, ci), v in ((rc, rows[rc[0]][rc[1]]) for rc in ((r, i) for r in range(nr) for i in range(nc))):
            if not isinstance(v, str):
                out.append((ind, f'tf = t.cell({r}, {ci}).text_frame'))
                st = {**cs.get('*', {}), **cs.get(f'r{r}', {}), **cs.get(f'c{ci}', {}), **cs.get((r, ci), {})}
                self.text(out, ind, 'tf', v, {k: x for k, x in st.items() if k in PARA_KEYS + FONT_KEYS})
        for r, ci, r2, c2 in kw.get('merge') or ():
            out.append((ind, f't.cell({r}, {ci}).merge(t.cell({r2}, {c2}))'))

    def cell_style(self, out, ind, st, single=False):
        n = len(out)
        if 'fill' in st:
            self.put(out, ind, self.fill('cell.fill', st['fill']))
        if 'anchor' in st:
            out.append((ind, f'cell.vertical_anchor = MSO_ANCHOR.{ANCHOR[st["anchor"]]}'))
        if 'vert' in st:
            self.put(out, ind, [X(f'cell_direction(cell, {lit(st["vert"])})', 'vertical text in table cells')])
        for x in self.margins('cell', st.get('m')):
            out.append((ind, x))
        for b in st.get('bd', ()):
            self.put(out, ind, [X(f'cell_border(cell, {lit(b[0])}' + (f', Pt({lit(b[1])}), {lit(b[2])}' if len(b) > 2 and b[1]
                                                                      else '') + ')', 'cell borders')])
        pp, f = {k: v for k, v in st.items() if k in PARA_KEYS}, {k: v for k, v in st.items() if k in FONT_KEYS}
        para_items, font_items = self.resolve(self.para(V, pp)), self.resolve(self.font(V, f))
        if para_items or font_items:
            out.append((ind, 'for p in cell.text_frame.paragraphs:'))
            self.block(out, ind + 1, 'para', para_items, 'p')
            if font_items:
                out.append((ind + 1, 'for r in p.runs:'))
                self.block(out, ind + 2, 'font', font_items, 'r.font')
        if len(out) == n and not single:
            out.append((ind, 'pass'))

    def emit_chart(self, out, ind, c):
        parent, kind, x, y, w, h, cats, series = c.args[:8]
        o = dict(c.kw)
        if kind.startswith(('XY_', 'BUBBLE')):
            out.append((ind, f'cd = {"BubbleChartData" if kind.startswith("BUBBLE") else "XyChartData"}()'))
            for name, pts in series.items():
                out.append((ind, f'sr = cd.add_series({lit(name)})'))
                out.append((ind, f'for point in {dense(pts, 4 + 4 * ind)}:'))
                out.append((ind + 1, 'sr.add_data_point(*point)'))
        else:
            out.append((ind, 'cd = CategoryChartData(' + (f'number_format={lit(o["nf"])}' if o.get('nf') else '') + ')'))
            if cats and isinstance(cats[0], tuple):  # two levels of categories
                out.append((ind, f'for group, names in {dense(cats, 4 + 4 * ind)}:'))
                out.append((ind + 1, 'g = cd.add_category(group)'))
                out.append((ind + 1, 'for name in names:'))
                out.append((ind + 2, 'g.add_sub_category(name)'))
            else:
                out.append((ind, f'cd.categories = {dense(cats, 4 + 4 * ind)}'))
            for name, vals in series.items():
                out.append((ind, f'cd.add_series({lit(name)}, {dense(vals, 4 + 4 * ind)})'))
        start = len(out)
        if c.ref:
            out.append((ind, f'{c.ref} = {parent}.shapes.add_chart(XL_CHART_TYPE.{kind}, {In(x)}, {In(y)}, {In(w)}, '
                             f'{In(h)}, cd)'))
            out.append((ind, f'ch = {c.ref}.chart'))
            start += 1
        else:
            out.append((ind, f'ch = {parent}.shapes.add_chart(XL_CHART_TYPE.{kind}, {In(x)}, {In(y)}, {In(w)}, {In(h)}, '
                             f'cd).chart'))
        if 'legend' in o:
            out.append((ind, f'ch.has_legend = {bool(o["legend"])}'))
            if o['legend']:
                out.append((ind, f'ch.legend.position = XL_LEGEND_POSITION.{XL_LEGEND_POSITION.from_xml(o["legend"]).name}'))
                out.append((ind, 'ch.legend.include_in_layout = False'))
        if 'title' in o:
            out.append((ind, f'ch.has_title = {bool(o["title"])}'))
            if o['title']:
                out.append((ind, f'ch.chart_title.text_frame.text = {lit(o["title"])}'))
        combo = o.get('combo') or ()
        line_like = ('LINE', 'XY_', 'RADAR')
        kinds = [kind] * len(series)
        for k, idx, _ in combo if self.extras else ():
            for i in idx:
                kinds[i] = k
        plot = []
        lb = o.get('labels')
        lb = (lb if isinstance(lb, dict) else {}) if lb else None
        each = lb is not None and (kind.startswith(('XY_', 'BUBBLE')) or 'series' in lb)  # labels per series
        if each and not self.extras:
            self.dropped['data labels of XY charts and of single series'] += 1
        elif lb is not None:
            if each:
                which = lb.get('series', list(range(len(series))))
                plot += [f'for i in {lit(which)}:' if which != list(range(len(series))) else 'for i in range(len(ch.series)):',
                         '    dl = series_labels(ch.series[i])']
            else:
                plot += ['plot.has_data_labels = True', 'dl = plot.data_labels']
            pad = '    ' if each else ''
            if 'nf' in lb:
                plot += [f'{pad}dl.number_format = {lit(lb["nf"])}', f'{pad}dl.number_format_is_linked = False']
            if 'pos' in lb:
                plot.append(f'{pad}dl.position = XL_LABEL_POSITION.{XL_LABEL_POSITION.from_xml(lb["pos"]).name}')
            if 'sz' in lb:
                plot.append(f'{pad}dl.font.size = Pt({lit(lb["sz"])})')
            if 'c' in lb:
                plot += [pad + x for x in self.resolve(self.colour('dl.font.color', lb['c']))]
            plot += [f'{pad}dl.show_percentage = {bool(lb.get("pct"))}', f'{pad}dl.show_value = {bool(lb.get("val", 1))}']
        for i, col in enumerate(o.get('colors') or ()):
            if col:
                plot += self.resolve(self.colour(f'ch.series[{i}].format.line.color', col)
                                     if kinds[i].startswith(line_like) else self.fill(f'ch.series[{i}].format.fill', col))
        pts = o.get('pts') or {}
        for si, cols in (pts.items() if isinstance(pts, dict) else [(0, pts)]):
            for i, col in enumerate(cols):
                if col:
                    plot += self.resolve(self.fill(f'ch.series[{si}].points[{i}].format.fill', col))
        if 'vary' in o:
            plot.append(f'plot.vary_by_categories = {bool(o["vary"])}')
        if 'gap' in o:
            plot.append(f'plot.gap_width = {o["gap"]}')
        if 'overlap' in o:
            plot.append(f'plot.overlap = {o["overlap"]}')
        if 'smooth' in o:
            plot += ['for sr in plot.series:', f'    sr.smooth = {bool(o["smooth"])}']
        if plot:
            if any('plot.' in p for p in plot):
                out.append((ind, 'plot = ch.plots[0]'))
            for p in plot:
                out.append((ind + (1 if p.startswith('    ') else 0), p.strip()))
        for key, axis in (('vtitle', 'value_axis'), ('ctitle', 'category_axis')):
            if o.get(key):
                out += [(ind, f'ch.{axis}.has_title = True'),
                        (ind, f'ch.{axis}.axis_title.text_frame.text = {lit(o[key])}')]
        for key, attr in (('grid', 'has_major_gridlines'), ('vaxis', 'visible'), ('vmin', 'minimum_scale'),
                          ('vmax', 'maximum_scale')):
            if key in o:
                out.append((ind, f'ch.value_axis.{attr} = {lit(o[key])}'))
        if 'caxis' in o:
            out.append((ind, f'ch.category_axis.visible = {bool(o["caxis"])}'))
        if o.get('vnf'):
            out += [(ind, f'ch.value_axis.tick_labels.number_format = {lit(o["vnf"])}'),
                    (ind, 'ch.value_axis.tick_labels.number_format_is_linked = False')]
        if o.get('vunit'):
            out.append((ind, f'ch.value_axis.major_unit = {lit(o["vunit"])}'))
        if o.get('sz'):
            out.append((ind, f'ch.font.size = Pt({lit(o["sz"])})'))
        for key, target in (('tfont', 'ch.chart_title.text_frame.paragraphs[0].font'), ('lfont', 'ch.legend.font'),
                            ('cfont', 'ch.category_axis.tick_labels.font'), ('vfont', 'ch.value_axis.tick_labels.font')):
            if o.get(key):
                self.block(out, ind, 'font', self.font(V, o[key]), target)
        items = []
        for key, target in (('cline', 'ch.category_axis.format.line'), ('vline', 'ch.value_axis.format.line'),
                            ('gridline', 'ch.value_axis.major_gridlines.format.line')):
            if o.get(key):
                if 'line' in o[key]:
                    items += self.fill(f'{target}.fill', o[key]['line']) if o[key]['line'] == '' or \
                        isinstance(o[key]['line'], list) else self.colour(f'{target}.color', o[key]['line'])
                if o[key].get('width'):
                    items.append(f'{target}.width = Pt({lit(o[key]["width"])})')
        self.put(out, ind, items)
        if o.get('style'):
            out.append((ind, f'ch.chart_style = {o["style"]}'))
        if combo and self.extras:  # after the colours: they follow the series into their new plot
            for k, idx, second in combo:
                out.append((ind, f'combo_chart(ch, {lit(k)}, {lit(idx)}' + (', secondary=True' if second else '') + ')'))
        elif combo:
            self.dropped['combo charts (drawn as one chart type)'] += 1
        items = [X(f'doughnut_hole(ch, {o["hole"]})', 'doughnut hole size')] if o.get('hole') else []
        if o.get('layout'):
            items.append(X(f'plot_layout(ch, {", ".join(lit(v) for v in o["layout"])})', 'plot areas placed by hand'))
        if o.get('explode'):
            items.append(X(f'pie_explode(ch, {lit(o["explode"])})', 'pie slices pulled out'))
        if o.get('d3'):
            items.append(X('chart_3d(ch' + (', ' + kwargs(o['d3']) if isinstance(o['d3'], dict) else '') + ')',
                           '3-D charts (drawn flat)'))
        if o.get('area'):
            items.append(X(f'chart_area(ch, {kwargs(o["area"])})', 'chart and plot area fills and borders'))
        if o.get('plotfill'):
            items.append(X(f'chart_area(ch, {kwargs(o["plotfill"])}, plot=True)', 'chart and plot area fills and borders'))
        self.put(out, ind, items)
        self.tidy(out, start, 'ch')

    def emit_bg(self, out, ind, c):
        if len(c.args) > 1:
            self.put(out, ind, self.fill('s.background.fill', c.args[1]))
        if c.kw.get('img'):
            extra = (', tile=True' if c.kw.get('tile') else '') + (', ' + kwargs(c.kw['pfx']) if c.kw.get('pfx') else '')
            self.put(out, ind, [X(f'picture_background(s, {self.src(c.kw["img"])}{extra})', 'picture backgrounds')])

    def head(self, c):
        layout, kw = c.args[1], c.kw
        prs = self.cv.prs
        if isinstance(layout, str):
            mi = next((i for i, m in enumerate(prs.slide_masters) if any(l.name == layout for l in m.slide_layouts)), 0)
            expr = ('prs.slide_layouts' if mi == 0 else f'prs.slide_masters[{mi}].slide_layouts') + \
                f'.get_by_name({lit(layout)})'
        elif isinstance(layout, tuple):
            expr = f'prs.slide_masters[{layout[0]}].slide_layouts[{layout[1]}]'
        else:
            expr = f'prs.slide_layouts[{layout}]'
        out = [(0, f's = prs.slides.add_slide({expr})')]
        if kw.get('keep') is not None:
            keep = tuple(kw['keep'])
            out.append((0, 'for ph in list(s.placeholders):  # placeholders this slide does not use'))
            if keep:
                out.append((1, f'if ph.placeholder_format.idx not in {lit(keep)}:'))
                out.append((2, 'ph.element.getparent().remove(ph.element)'))
            else:
                out.append((1, 'ph.element.getparent().remove(ph.element)'))
        items = [X('hide_slide(s)', 'hidden slides')] if kw.get('hidden') else []
        if kw.get('graphics') is False:
            items.append(X('hide_layout_graphics(s)', 'hidden background graphics'))
        self.put(out, 0, items)
        return out

    def body(self, items):
        out = []
        for it in items:
            if isinstance(it, str):
                m = re.fullmatch(r'(\w+) = grp\((\w+)\)', it)
                out.append((0, f'{m[1]} = {m[2]}.shapes.add_group_shape()' if m else it))
                continue
            fn = {'box': self.emit_box, 'ph': self.emit_ph, 'pic': self.emit_pic, 'con': self.emit_con,
                  'tbl': self.emit_tbl, 'chart': self.emit_chart, 'bg': self.emit_bg, 'movie': self.emit_movie,
                  'glue': self.emit_glue}.get(it.fn)
            if fn:
                fn(out, 0, it)
            elif it.fn == 'group_box':
                self.put(out, 0, [X(f'group_box({it.args[0]}, ' + ', '.join(In(v) for v in it.args[1:]) + ')',
                                    'the turning point of turned groups')])
            elif it.fn == 'mirror':
                self.put(out, 0, [X(f'mirror({it.args[0]}, {lit(it.args[1])})', 'flipped shapes')])
            elif it.fn == 'hide':
                self.put(out, 0, [X(f'hide({it.args[0]})', 'hidden shapes')])
            elif it.fn == 'smartart':
                self.put(out, 0, [X((f'{it.ref} = ' if it.ref else '') + f'smartart({it.args[0]}, {self.src(it.args[1])}, '
                                    + ', '.join(In(v) for v in it.args[2:6]) + ')', 'SmartArt')])
            elif it.fn == 'notes':
                out.append((0, self.assign(0, 's.notes_slide.notes_text_frame.text', it.args[1])))
            elif it.fn == 'transition':
                self.put(out, 0, [X(f'transition(s, {lit(it.args[1])}' + ''.join(f', {k}={lit(v)}' for k, v in it.kw.items())
                                    + ')', 'slide transitions')])
            elif it.fn == 'animate':
                lines = animate_code(it.args[1], it.kw.get('builds'), 4, WIDTH)
                if self.extras:
                    out += [(0, x) for x in lines]
                else:
                    self.dropped['animations (effects)'] += len(it.args[1])
        return out


def _defs(names):
    """Source of the pptx_helpers extras the script uses, with what they need (one-file scripts)."""
    src = HELPERS.read_text(encoding='utf-8')
    tree = ast.parse(src)
    defs, imports = {}, []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.Assign)):
            name = node.name if isinstance(node, ast.FunctionDef) else node.targets[0].id
            defs[name] = ast.get_source_segment(src, node)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            imports.append(ast.get_source_segment(src, node))
    need, todo = [], list(names)
    while todo:
        n = todo.pop()
        if n in need or n not in defs:
            continue
        need.append(n)
        todo += [x for x in _deps(defs[n]) if x in defs]
    return [defs[n] for n in defs if n in need], imports


def assemble(cv, blocks, wanted, tname, files):
    w = Writer(cv)
    funcs = [(name, w.body(items)) for name, items in cv.layout_funcs.values() if items]
    for n, head, items in blocks:
        funcs.append((f'slide{n}', w.head(head) + w.body(items)))
    # blocks used twice or more become functions
    named, defs = {}, []
    for (kind, lines), count in w.blocks.items():
        if count >= 2 and len(lines) >= 2:
            name = f'{kind}{sum(1 for k in named if k[0] == kind) + 1}'
            named[(kind, lines)] = name
            var = {'font': 'f', 'para': 'p'}.get(kind, 'sh')
            defs += [f'def {name}({var}):'] + ['    ' + ln.replace(V, var) for ln in lines] + ['', '']

    def render(out):
        lines = []
        for ind, item in out:
            pad = '    ' * (ind + 1)
            if isinstance(item, tuple):
                _, key, var = item
                if key in named:
                    lines.append(f'{pad}{named[key]}({var})')
                elif len(key[1]) >= 2 and len(var) > 8:  # a short name for a long expression
                    short = 'f' if key[0] == 'font' else 'sh'
                    lines += [f'{pad}{short} = {var}'] + [pad + ln.replace(V, short) for ln in key[1]]
                else:
                    lines += [pad + ln.replace(V, var) for ln in key[1]]
            else:
                lines.append(pad + item)
        return lines
    body = []
    for name, out in funcs:
        args = 's' if name.startswith('layout') else 'prs'
        body += [f'def {name}({args}):'] + render(out) + ['', '']
    if cv.template:
        start = ["prs = Presentation(io.BytesIO(base64.b64decode(TEMPLATE)))"] if cv.embed else \
            [f"prs = Presentation(os.path.join(HERE, {tname!r}))"]
    else:
        sw, sh = cv.prs.slide_width, cv.prs.slide_height
        colors = {k: v for k, v in cv.base.colors.items() if k.startswith(('accent', 'dk', 'lt', 'hlink', 'folH'))}
        colors.update({std: cv.base.hex(slot) for slot, std in (('tx1', 'dk1'), ('bg1', 'lt1'), ('tx2', 'dk2'),
                                                                ('bg2', 'lt2'))})
        start = ['prs = Presentation()', f'prs.slide_width, prs.slide_height = {int(sw)}, {int(sh)}  # EMU: '
                 f'{inch(sw):g} x {inch(sh):g} in']
        if cv.extras:
            start.append(f'set_theme(prs, {lit(tuple(cv.base.fonts))}, {tall(colors, 4, WIDTH)})')
    names = ', '.join(f'slide{n}' for n in wanted)
    main = [f'def build(out={cv.name + "_rebuilt.pptx"!r}):', *['    ' + x for x in start],
            f'    for make in ({names}{"," if len(wanted) == 1 else ""}):', '        make(prs)'] + \
        (['    for sh, n in LINKS:  # clicks that jump to a slide, once all slides exist',
          '        sh.click_action.target_slide = prs.slides[n - 1]'] if w.links else []) + ['    prs.save(out)', '    return out']
    run = SCRIPT_MAIN
    data = []
    if cv.embed:
        if '__template__' in files:
            data.append(f"TEMPLATE = {__import__('base64').b64encode(files['__template__']).decode()!r}")
        if cv.images:
            data += ['IMG = {'] + [f"    {name.split('.')[0]!r}: {__import__('base64').b64encode(blob).decode()!r},"
                                   for name, blob in cv.images.values()] + ['}']
    code = '\n'.join(defs + body + main)
    used_extras = sorted({m for m in re.findall(r'(?<![\w.])(\w+)\(', code) if m in EXTRAS})
    mods = {}
    for name, mod in IMPORTS.items():
        if re.search(rf'\b{name}\b', code):
            mods.setdefault(mod, []).append(name)
    imp = ['import ' + m for m in ('base64', 'io', 'os', 'sys') if m in ('os', 'sys') or f'{m}.' in code]
    imp += [''] + [f'from {m} import {", ".join(sorted(v))}' for m, v in sorted(mods.items())]
    extra_src = []
    if used_extras and not cv.embed:
        files['pptx_helpers.py'] = HELPERS.read_bytes()
        imp += ['', 'try:  # what python-pptx has no command for',
                f'    from pptx_helpers import {", ".join(used_extras)}', *HELPERS_GUARD]
    elif used_extras:
        extra_src, extra_imp = _defs(used_extras)
        joined = '\n'.join(extra_src)
        for line in extra_imp:  # the imports those functions use
            names = [n.split(' as ')[-1].strip() for n in line.split(' import ', 1)[1].split('#')[0].split(',')] \
                if ' import ' in line else [line.split()[-1]]
            if line not in imp and any(re.search(rf'\b{re.escape(n)}\b', joined) for n in names):
                imp.append(line)
    title = cv.name
    head = [f'"""Rebuilds {title}.{cv.ext}{"" if cv.ext == "pptx" else " as a .pptx"} with python-pptx ({len(wanted)} slide{"s" if len(wanted) != 1 else ""}): '
            f'python {title}.py [out.pptx]']
    if used_extras:
        head += [''] + textwrap.wrap(
            f'Plain python-pptx code. {", ".join(f"{e}()" for e in used_extras)} '
            f'{"come" if len(used_extras) > 1 else "comes"} from pptx_helpers: python-pptx has no command '
            f'for {"them" if len(used_extras) > 1 else "it"}.', 100)
    if w.dropped:
        head += ['', 'python-pptx has no command for these, so they are left out:'] + \
            [f'  {what} ({n})' for what, n in sorted(w.dropped.items())]
        cv.approx += [f'all slides: {what}: left out {n} time{"s" if n != 1 else ""} (python-pptx has no command for '
                      'it; keep extras on to include it)' for what, n in sorted(w.dropped.items())]
    head.append('"""')
    here = 'os.path.join(HERE' in code
    if here:
        imp += ['', SCRIPT_HERE]
    if w.links:
        imp += ([] if here else ['']) + ['LINKS = []  # (shape, slide number) for clicks that jump to another slide']
    skipped = report_lines(cv)
    parts = head + imp + [''] + skipped + ['', ''] + defs + body + main + \
        ((['', '', '# ── what python-pptx has no command for (from pptx_helpers) ──'] + [x + '\n\n' for x in extra_src])
         if extra_src else []) + (['', '', '# pictures and template, base64'] + data if data else []) + run
    out = '\n'.join(parts)
    return re.sub(r'\n{3,}', '\n\n\n', out).rstrip() + '\n'
