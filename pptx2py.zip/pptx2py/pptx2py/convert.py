"""PowerPoint -> compact python-pptx code.

    from pptx2py import convert
    res = convert('deck.pptx', slides=[1, 3])          # all slides when slides is None
    res.code                                           # the script
    res.files                                          # {'deck_template.pptx': bytes, 'assets/img1.png': bytes}

The script rebuilds the slides on the deck's own template (masters, layouts, theme - saved next to it), so
it only has to describe what is on each slide: one line per shape, positions in inches, only the
formatting the slide sets itself. With template=False it starts from a blank presentation instead
(one self-contained file: placeholders become text boxes with their inherited formatting written out).
"""
import ast
import base64
import colorsys
import copy
import hashlib
import io
import math
import posixpath
import re
from dataclasses import dataclass, field
from pathlib import Path

from lxml import etree
from pptx import Presentation

from .anim import read_timing, read_transition

A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
P = 'http://schemas.openxmlformats.org/presentationml/2006/main'
C = 'http://schemas.openxmlformats.org/drawingml/2006/chart'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
DSP = 'http://schemas.microsoft.com/office/drawing/2008/diagram'
P14 = 'http://schemas.microsoft.com/office/powerpoint/2010/main'
RUNTIME = HELPERS = Path(__file__).parent / 'lib' / 'pptx_helpers.py'  # the helpers scripts use
EMU_IN = 914400


def ln(el):
    return etree.QName(el).localname if isinstance(el.tag, str) else ''


def kid(el, name, ns=A):
    return None if el is None else el.find(f'{{{ns}}}{name}')


def inch(v):
    x = round(int(v) / EMU_IN, 3)
    return int(x) if x == int(x) else x


def num(v, nd=2):
    x = round(float(v), nd)
    return int(x) if x == int(x) else x


# ── colours, fills, lines ────────────────────────────────────────────────────
SCHEME = {'tx1': 'dk1', 'bg1': 'lt1', 'tx2': 'dk2', 'bg2': 'lt2'}
PRESET = {'black': '000000', 'white': 'FFFFFF', 'red': 'FF0000', 'green': '008000', 'blue': '0000FF',
          'yellow': 'FFFF00', 'gray': '808080', 'grey': '808080', 'orange': 'FFA500', 'navy': '000080'}


class Theme:
    """Colours, fonts and the shape style matrix of the first slide master's theme."""

    def __init__(self, master):
        self.colors, self.fonts, self.fills, self.lines, self.effects, self.bgfills = {}, ('', ''), [], [], [], []
        cm = master._element.find(f'{{{P}}}clrMap')  # which theme slot bg1, tx1, bg2 ... stand for
        self.map = dict(SCHEME, **({k: v for k, v in cm.attrib.items()} if cm is not None else {}))
        for rel in master.part.rels.values():
            if rel.reltype.endswith('/theme'):
                root = etree.fromstring(rel.target_part.blob)
                for c in root.find(f'.//{{{A}}}clrScheme'):
                    v = c[0] if len(c) else None
                    if v is not None:
                        self.colors[ln(c)] = (v.get('lastClr') if ln(v) == 'sysClr' else v.get('val') or '000000')
                f = [root.find(f'.//{{{A}}}{t}/{{{A}}}latin') for t in ('majorFont', 'minorFont')]
                self.fonts = tuple(x.get('typeface') if x is not None else '' for x in f)
                fs = root.find(f'.//{{{A}}}fmtScheme')
                if fs is not None:
                    self.fills = list(kid(fs, 'fillStyleLst') if kid(fs, 'fillStyleLst') is not None else [])
                    self.lines = list(kid(fs, 'lnStyleLst') if kid(fs, 'lnStyleLst') is not None else [])
                    self.effects = list(kid(fs, 'effectStyleLst') if kid(fs, 'effectStyleLst') is not None else [])
                    self.bgfills = list(kid(fs, 'bgFillStyleLst') if kid(fs, 'bgFillStyleLst') is not None else [])

    def hex(self, name):
        return self.colors.get(self.map.get(name, name), '000000')


COLOUR_MODS = ('lumMod', 'lumOff', 'tint', 'shade', 'satMod', 'satOff', 'hueMod', 'hueOff', 'hue', 'sat', 'lum')
NEUTRAL = {'lumMod': 100000, 'satMod': 100000, 'hueMod': 100000, 'lumOff': 0, 'satOff': 0, 'hueOff': 0}


def _hls_mods(hexv, mods):
    r, g, b = (int(hexv[i:i + 2], 16) / 255 for i in (0, 2, 4))
    d = dict(mods)
    if 'tint' in d or 'shade' in d:  # PowerPoint tints and shades in linear light
        lin = [x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in (r, g, b)]
        t, sh = d.get('tint', 100000) / 100000, d.get('shade', 100000) / 100000
        lin = [(x * t + (1 - t)) * sh for x in lin]
        r, g, b = (12.92 * x if x <= 0.0031308 else 1.055 * x ** (1 / 2.4) - 0.055 for x in lin)
    h, l_, s_ = colorsys.rgb_to_hls(r, g, b)
    h = d['hue'] / 21600000 if 'hue' in d else h
    h = (h * d.get('hueMod', 100000) / 100000 + d.get('hueOff', 0) / 21600000) % 1  # SmartArt colour variations
    s_ = d['sat'] / 100000 if 'sat' in d else s_
    l_ = d['lum'] / 100000 if 'lum' in d else l_
    l_ = min(1, max(0, l_ * d.get('lumMod', 100000) / 100000 + d.get('lumOff', 0) / 100000))
    s_ = min(1, max(0, s_ * d.get('satMod', 100000) / 100000 + d.get('satOff', 0) / 100000))
    return ''.join(f'{round(x * 255):02X}' for x in colorsys.hls_to_rgb(h, l_, s_))


def cspec(el, th, ph=None):
    """A colour element -> 'RRGGBB' / 'accent1' / 'accent1+40' / 'tx1-25', with '/50' for transparency."""
    if el is None:
        return None
    n = ln(el)
    if n == 'schemeClr' and el.get('val') == 'phClr' and ph is not None:
        merged = copy.deepcopy(ph)
        for m in el:
            merged.append(copy.deepcopy(m))
        return cspec(merged, th)
    mods = [(ln(m), int(m.get('val', '0'))) for m in el]
    alpha = next((v for k, v in mods if k == 'alpha'), None)
    mods = [(k, v) for k, v in mods if k in COLOUR_MODS and NEUTRAL.get(k) != v]
    if n == 'schemeClr':
        name, d = el.get('val'), dict(mods)
        lm, lo = d.get('lumMod', 100000), d.get('lumOff', 0)
        if getattr(th, 'hexify', False) or (getattr(th, 'remapped', False) and name in ('dk1', 'lt1', 'dk2', 'lt2')):
            # a second theme in blank-template mode: write the colour itself
            spec = _hls_mods(th.hex(name), mods)
        elif not mods:
            spec = name
        elif set(d) <= {'lumMod', 'lumOff'} and lo == 0 and lm < 100000:
            spec = f'{name}-{round((100000 - lm) / 1000)}'
        elif set(d) <= {'lumMod', 'lumOff'} and lo > 0 and abs(lm + lo - 100000) <= 500:
            spec = f'{name}+{round(lo / 1000)}'
        else:
            spec = _hls_mods(th.hex(name), mods)
    else:
        base = (el.get('val') if n == 'srgbClr' else el.get('lastClr') if n == 'sysClr' else
                PRESET.get(el.get('val'), '808080') if n == 'prstClr' else
                ''.join(f'{round(int(el.get(k, 0)) / 100000 * 255):02X}' for k in 'rgb') if n == 'scrgbClr' else None)
        if base is None:
            return None
        spec = _hls_mods(base.upper(), mods) if mods else base.upper()
    if alpha is not None and alpha < 99500:
        spec += f'/{round(alpha / 1000)}'
    return spec


def colour_of(el, th, ph=None):
    """First colour child of a fill-ish element."""
    for c in el if el is not None else ():
        if ln(c) in ('srgbClr', 'schemeClr', 'sysClr', 'prstClr', 'scrgbClr'):
            return cspec(c, th, ph)
    return None


def fill_spec(parent, th, ref=None):
    """'' (no fill), a colour, ['grad', angle, (colour, pos %), ...], ('img', rId) or None (inherit)."""
    for c in parent if parent is not None else ():
        n = ln(c)
        if n == 'noFill':
            return ''
        if n == 'solidFill':
            return colour_of(c, th, ref)
        if n == 'pattFill':  # ['patt', pattern, foreground, background]
            fg, bg = colour_of(kid(c, 'fgClr'), th, ref), colour_of(kid(c, 'bgClr'), th, ref)
            return ['patt', c.get('prst', 'pct5'), fg or '000000', bg or 'FFFFFF']
        if n == 'blipFill':
            blip = kid(c, 'blip')
            if blip is None:
                return None
            return ('img', blip.get(f'{{{R}}}embed'), kid(c, 'tile') is not None, picture_fx(blip, th, ref))
        if n == 'gradFill':
            stops = sorted(((int(g.get('pos', 0)), g) for g in c.iter(f'{{{A}}}gs')), key=lambda t: t[0])
            lin, path = kid(c, 'lin'), kid(c, 'path')
            focus = 0  # a radial gradient from the middle; else (kind, l, t, r, b %) of its focus rectangle
            if path is not None:
                ftr = kid(path, 'fillToRect')
                box = tuple(num(int(ftr.get(k, 0)) / 1000, 1) for k in 'ltrb') if ftr is not None else (0, 0, 0, 0)
                if path.get('path', 'circle') != 'circle' or box != (50, 50, 50, 50):
                    focus = (path.get('path', 'circle'), *box)
            head = ['path', focus] if path is not None else ['grad', num(int(lin.get('ang', 0)) / 60000 if lin is not None
                                                                        else 90, 1)]
            return head + [(colour_of(g, th, ref), num(p / 1000, 1)) for p, g in stops]
    if ref is not None and ln(ref) in ('fillRef', 'bgRef'):
        idx = int(ref.get('idx', '0'))
        styles = th.bgfills if idx >= 1001 else th.fills
        i = idx - 1001 if idx >= 1001 else idx - 1
        if idx == 0:
            return ''
        if 0 <= i < len(styles):
            return fill_spec([styles[i]], th, ref[0] if len(ref) else None)
    return None


CMD = {'moveTo': 'M', 'lnTo': 'L', 'cubicBezTo': 'C', 'quadBezTo': 'Q', 'arcTo': 'A', 'close': 'Z'}


def _fmla(f, v):
    """One DrawingML guide formula, e.g. '*/ w 1 2' or 'pin 0 adj 50000'."""
    op, *a = f.split()
    x = [float(t) if re.fullmatch(r'-?\d+(?:\.\d+)?', t) else float(v.get(t, 0)) for t in a] + [0.0] * 3
    ang = math.radians(x[1] / 60000)
    return {'val': lambda: x[0], '*/': lambda: x[0] * x[1] / x[2] if x[2] else 0.0, '+-': lambda: x[0] + x[1] - x[2],
            '+/': lambda: (x[0] + x[1]) / x[2] if x[2] else 0.0, '?:': lambda: x[1] if x[0] > 0 else x[2],
            'abs': lambda: abs(x[0]), 'at2': lambda: math.degrees(math.atan2(x[1], x[0])) * 60000,
            'cat2': lambda: x[0] * math.cos(math.atan2(x[2], x[1])), 'cos': lambda: x[0] * math.cos(ang),
            'max': lambda: max(x[0], x[1]), 'min': lambda: min(x[0], x[1]),
            'mod': lambda: math.sqrt(x[0] ** 2 + x[1] ** 2 + x[2] ** 2), 'pin': lambda: min(max(x[1], x[0]), x[2]),
            'sat2': lambda: x[0] * math.sin(math.atan2(x[2], x[1])), 'sin': lambda: x[0] * math.sin(ang),
            'sqrt': lambda: math.sqrt(max(0.0, x[0])), 'tan': lambda: x[0] * math.tan(ang)}.get(op, lambda: 0.0)()


def _guides(cg, w, h):
    """The values of a free-form shape's guides for a shape of w x h EMU."""
    v = {'w': w, 'h': h, 'l': 0, 't': 0, 'r': w, 'b': h, 'hc': w / 2, 'vc': h / 2, 'ss': min(w, h), 'ls': max(w, h),
         'cd2': 10800000, 'cd4': 5400000, 'cd8': 2700000, '3cd4': 16200000, '3cd8': 8100000, '5cd8': 13500000,
         '7cd8': 18900000}
    for d in (2, 3, 4, 5, 6, 8, 10, 12, 16, 32):
        v[f'wd{d}'], v[f'hd{d}'], v[f'ssd{d}'] = w / d, h / d, min(w, h) / d
    for lst in ('avLst', 'gdLst'):
        for gd in kid(cg, lst) if kid(cg, lst) is not None else ():
            v[gd.get('name')] = _fmla(gd.get('fmla', 'val 0'), v)
    return v


def path_spec(cg, w=0, h=0):
    """A free-form shape as a short path string ('W H M x y L x y C ... Z'), its guide formulas worked out."""
    v = _guides(cg, w, h)

    def val(t):
        return float(t) if t is not None and re.fullmatch(r'-?\d+(?:\.\d+)?', t) else v.get(t)
    out = []
    for p in cg.iter(f'{{{A}}}path'):
        pw, ph = int(p.get('w', 0)) or w, int(p.get('h', 0)) or h  # no size: the shape's own
        if not pw or not ph:
            return None
        k = 10000 / max(pw, ph) if max(pw, ph) > 10000 else 1  # 4-5 digit coordinates are plenty
        toks = [str(round(pw * k)), str(round(ph * k))]
        if p.get('fill'):
            toks.append(p.get('fill'))
        if p.get('stroke') in ('0', 'false'):
            toks.append('nostroke')
        for c in p:
            cmd = CMD.get(ln(c))
            raw = [c.get(a) for a in ('wR', 'hR', 'stAng', 'swAng')] if cmd == 'A' else \
                [t for pt in c for t in (pt.get('x'), pt.get('y'))]
            vals = [val(t) for t in raw]
            if cmd is None or None in vals:
                return None
            vals = [str(round(x * k)) if cmd != 'A' or i < 2 else str(round(x)) for i, x in enumerate(vals)]
            toks.append(cmd + (vals[0] if vals else ''))
            toks += vals[1:]
        out.append(' '.join(toks))
    return ' | '.join(out) if out else None


def text_inset(sppr, w, h):
    """How far in from its edges a preset shape puts its text (rect, roundRect, ellipse; others: unknown)."""
    pg = kid(sppr, 'prstGeom')
    prst = pg.get('prst') if pg is not None else None
    gd = pg.find(f'{{{A}}}avLst/{{{A}}}gd') if pg is not None else None
    if prst == 'roundRect':
        adj = int(re.sub(r'[^\d-]', '', gd.get('fmla', '')) or 0) if gd is not None else 16667
        return (0.29289 * adj / 100000 * min(w, h),) * 2
    if prst == 'ellipse':
        return w * 0.146447, h * 0.146447
    return (0, 0) if prst == 'rect' else (1e12, 1e12)  # unknown: the text gets a box of its own


def solid_of(grad):
    """One colour for a gradient (or pattern) where only a solid colour fits: its first opaque stop."""
    if grad[0] == 'patt':
        return grad[2]
    stops = [c for c, _ in grad[2:] if c]
    return next((c for c in stops if '/' not in c), stops[0] if stops else None)


def line_spec(sppr, th, ref=None):
    out = {}
    lnel = kid(sppr, 'ln')
    phc = ref[0] if ref is not None and len(ref) else None
    if lnel is not None:
        f = fill_spec(lnel, th, phc)
        if f is not None and not isinstance(f, tuple):
            out['line'] = f  # a colour, '' (none), or a gradient / pattern list
        if lnel.get('w'):
            out['lw'] = num(int(lnel.get('w')) / 12700)
        d = kid(lnel, 'prstDash')
        if d is not None and d.get('val', 'solid') != 'solid':
            out['dash'] = d.get('val')
        ends = [kid(lnel, e) for e in ('headEnd', 'tailEnd')]
        ends = [e.get('type') if e is not None and e.get('type', 'none') != 'none' else None for e in ends]
        if any(ends):
            out['ends'] = tuple(ends)
    if 'line' not in out and ref is not None and int(ref.get('idx', '0')) > 0:
        i = int(ref.get('idx')) - 1
        if i < len(th.lines):
            st = th.lines[i]
            f = fill_spec(st, th, phc)
            if f is not None:
                out['line'] = f if isinstance(f, (str, list)) else None
            if 'lw' not in out and st.get('w'):
                out['lw'] = num(int(st.get('w')) / 12700)
            d = kid(st, 'prstDash')
            if 'dash' not in out and d is not None and d.get('val', 'solid') != 'solid':
                out['dash'] = d.get('val')
    if out.get('line') is None:
        out.pop('line', None)
    return out


def _pt(v):
    return num(int(v) / 12700, 2)


def _deg(v):
    return num(int(v) / 60000, 1)


def _pc(v):
    return num(int(v) / 1000, 1)


EFFECTS = {'blur': 'blur', 'glow': 'glow', 'innerShdw': 'inner', 'outerShdw': 'shadow', 'prstShdw': 'preset',
           'reflection': 'reflect', 'softEdge': 'soft'}
EFFECT_KEYS = {'blurRad': ('blur', _pt), 'dist': ('dist', _pt), 'dir': ('dir', _deg), 'rad': ('r', _pt),
               'sx': ('sx', _pc), 'sy': ('sy', _pc), 'kx': ('kx', _deg), 'ky': ('ky', _deg), 'algn': ('align', str),
               'rotWithShape': ('rotate', lambda v: v in ('1', 'true')), 'stA': ('start', _pc),
               'stPos': ('startpos', _pc), 'endA': ('end', _pc), 'endPos': ('endpos', _pc), 'fadeDir': ('fade', _deg),
               'prst': ('kind', str), 'grow': ('grow', lambda v: v in ('1', 'true'))}


def effect_spec(eff, th, ph=None):
    """Shadow, glow, soft edges ... as {'shadow': {'c': '000000/35', 'blur': 3.15, 'dist': 1.8, 'dir': 90}, ...}.
    Sizes in points, angles in degrees, the rest in %."""
    out = {}
    for e in eff:
        name = EFFECTS.get(ln(e))
        if name:
            d = {EFFECT_KEYS[a][0]: EFFECT_KEYS[a][1](v) for a, v in e.attrib.items() if a in EFFECT_KEYS}
            c = colour_of(e, th, ph)
            out[name] = {**({'c': c} if c else {}), **d}
    return out


def effects(sppr, th, ref=None):
    eff = kid(sppr, 'effectLst')
    if eff is not None:
        return effect_spec(eff, th) or None
    if ref is not None and int(ref.get('idx', '0')) > 0 and int(ref.get('idx')) - 1 < len(th.effects):
        e = kid(th.effects[int(ref.get('idx')) - 1], 'effectLst')
        if e is not None and len(e):
            return effect_spec(e, th, ref[0] if len(ref) else None) or None
    return None


def picture_fx(blip, th, ph=None):
    """Picture effects as values: alpha (% opaque), duotone (2 colours), gray, bright, contrast,
    recolor (from, to), bilevel (%), tint (hue, %)."""
    out = {}
    for e in blip:
        n = ln(e)
        if n == 'alphaModFix':
            out['alpha'] = _pc(e.get('amt', '100000'))
        elif n == 'duotone':
            cs = [cspec(c, th, ph) for c in e if ln(c).endswith('Clr')]
            if len(cs) == 2 and all(cs):
                out['duotone'] = tuple(cs)
        elif n == 'grayscl':
            out['gray'] = True
        elif n == 'lum':
            for a in ('bright', 'contrast'):
                if e.get(a):
                    out[a] = _pc(e.get(a))
        elif n == 'clrChange':
            a, b = colour_of(kid(e, 'clrFrom'), th, ph), colour_of(kid(e, 'clrTo'), th, ph)
            if a and b:
                out['recolor'] = (a, b)
        elif n == 'biLevel':
            out['bilevel'] = _pc(e.get('thresh', '50000'))
        elif n == 'tint':
            out['tint'] = (_deg(e.get('hue', '0')), _pc(e.get('amt', '0')))
    return out


# ── text ─────────────────────────────────────────────────────────────────────
ALIGN = {'l': 'l', 'ctr': 'c', 'r': 'r', 'just': 'j', 'dist': 'd', 'justLow': 'jl', 'thaiDist': 'td'}
ANCHOR = {'t': 't', 'ctr': 'm', 'b': 'b'}
INSETS = (('lIns', 91440), ('tIns', 45720), ('rIns', 91440), ('bIns', 45720))
PARA_KEYS = ('align', 'lvl', 'ls', 'lsp', 'sb', 'sa', 'ml', 'ind', 'bul', 'sbp', 'sap', 'bulc', 'buls')


def rpr_props(rpr, th):
    o = {}
    if rpr is None:
        return o
    for a, k in (('b', 'b'), ('i', 'i')):
        if rpr.get(a) is not None:
            o[k] = 1 if rpr.get(a) in ('1', 'true') else 0
    if rpr.get('u') is not None:
        o['u'] = 0 if rpr.get('u') == 'none' else 1 if rpr.get('u') == 'sng' else rpr.get('u')  # 'dbl', 'wavy' ...
    if rpr.get('sz'):
        o['sz'] = num(int(rpr.get('sz')) / 100, 2)
    for a, k in (('cap', 'cap'), ('spc', 'spc'), ('baseline', 'base'), ('strike', 'strike')):
        if rpr.get(a) is not None and rpr.get(a) not in ('none', 'noStrike'):
            o[k] = num(int(rpr.get(a)) / 100, 2) if a == 'spc' else num(int(rpr.get(a)) / 1000, 3) \
                if a == 'baseline' else rpr.get(a)  # spacing in points, baseline in %
    lat = kid(rpr, 'latin')
    if lat is not None and lat.get('typeface'):
        o['f'] = lat.get('typeface')
        if getattr(th, 'hexify', False) and o['f'] in ('+mj-lt', '+mn-lt'):
            o['f'] = th.fonts[0 if o['f'] == '+mj-lt' else 1]
    for c in rpr:
        n = ln(c)
        if n == 'solidFill':
            col = colour_of(c, th)
            if col:
                o['c'] = col
        elif n in ('gradFill', 'noFill', 'pattFill'):  # gradient text, outline-only text, patterned text
            f = fill_spec([c], th)
            if f is not None and not isinstance(f, tuple):
                o['c'] = f
        elif n == 'ln':  # text outline
            f = fill_spec(c, th)
            col = '' if f == '' else f if isinstance(f, str) else solid_of(f) if isinstance(f, list) else None
            if col is not None or c.get('w'):
                o['ol'] = (col if col is not None else 'tx1', num(int(c.get('w', 12700)) / 12700, 2))
        elif n == 'effectLst' and len(c):
            e = effect_spec(c, th)
            if e:
                o['tfx'] = e
        elif n == 'highlight':
            col = colour_of(c, th)
            if col:
                o['mark'] = col
    return o


def ppr_props(ppr, th):
    o = {}
    if ppr is None:
        return o
    if ppr.get('algn') in ALIGN:
        o['align'] = ALIGN[ppr.get('algn')]
    if ppr.get('lvl') not in (None, '0'):
        o['lvl'] = int(ppr.get('lvl'))
    for a, k in (('marL', 'ml'), ('indent', 'ind')):
        if ppr.get(a) is not None:
            o[k] = inch(ppr.get(a))
    ls = kid(ppr, 'lnSpc')
    if ls is not None and len(ls):
        o['ls' if ln(ls[0]) == 'spcPct' else 'lsp'] = num(int(ls[0].get('val')) / (100000 if ln(ls[0]) == 'spcPct'
                                                                                   else 100))
    for tag, k in (('spcBef', 'sb'), ('spcAft', 'sa')):
        e = kid(ppr, tag)
        if e is not None and len(e) and ln(e[0]) == 'spcPts':
            o[k] = num(int(e[0].get('val')) / 100, 2)
        elif e is not None and len(e) and ln(e[0]) == 'spcPct':  # % of a line: points once the size is known
            o[k + 'p'] = int(e[0].get('val')) / 1000
    c = colour_of(kid(ppr, 'buClr'), th)
    if c:
        o['bulc'] = c
    sz = kid(ppr, 'buSzPct')
    if sz is not None and sz.get('val'):
        o['buls'] = num(int(sz.get('val')) / 1000, 1)
    face = kid(ppr, 'buFont')
    for c in ppr:
        if ln(c) == 'buNone':
            o['bul'] = ''
        elif ln(c) == 'buAutoNum':  # '1.', or {'num': 'romanUcPeriod', 'start': 4}
            kind, start = c.get('type', 'arabicPeriod'), c.get('startAt')
            o['bul'] = '1.' if kind == 'arabicPeriod' and start in (None, '1') else \
                {'num': kind, **({'start': int(start)} if start not in (None, '1') else {})}
        elif ln(c) == 'buChar':
            ch = c.get('char', '•')
            o['bul'] = [ch, face.get('typeface')] if face is not None and face.get('typeface') and \
                face.get('typeface') not in ('Arial', '+mj-lt', '+mn-lt') else ch
    return o


def three_d(parent, th):
    """3-D look of a shape (spPr) or of its text (bodyPr): camera, light, depth, bevels, material."""
    if parent is None:
        return None
    sc, sp = kid(parent, 'scene3d'), kid(parent, 'sp3d')
    d = {}
    if sc is not None:
        cam, rig = kid(sc, 'camera'), kid(sc, 'lightRig')
        if cam is not None:
            d['camera'] = cam.get('prst')
            r = kid(cam, 'rot')
            if r is not None:
                d['rot'] = tuple(num(int(r.get(k, 0)) / 60000, 2) for k in ('lat', 'lon', 'rev'))
            if cam.get('fov'):
                d['fov'] = num(int(cam.get('fov')) / 60000, 1)
            if cam.get('zoom'):
                d['zoom'] = num(int(cam.get('zoom')) / 1000, 1)
        if rig is not None:
            d['light'] = (rig.get('rig'), rig.get('dir'))
            r = kid(rig, 'rot')
            if r is not None:
                d['light_rot'] = tuple(num(int(r.get(k, 0)) / 60000, 2) for k in ('lat', 'lon', 'rev'))
    if sp is not None:
        for a, k in (('z', 'z'), ('extrusionH', 'depth'), ('contourW', 'contour')):
            if sp.get(a):
                d[k] = num(int(sp.get(a)) / 12700, 2)
        if sp.get('prstMaterial'):
            d['material'] = sp.get('prstMaterial')
        for tag, k in (('bevelT', 'bevel'), ('bevelB', 'bevel_bottom')):
            b = kid(sp, tag)
            if b is not None:
                d[k] = (num(int(b.get('w', 76200)) / 12700, 2), num(int(b.get('h', 76200)) / 12700, 2),
                        b.get('prst', 'circle'))
        for tag, k in (('extrusionClr', 'depth_color'), ('contourClr', 'contour_color')):
            c = colour_of(kid(sp, tag), th) if th is not None else None
            if c:
                d[k] = c
    flat = d.get('camera') in (None, 'orthographicFront') and not d.get('rot') and \
        not any(k in d for k in ('depth', 'contour', 'bevel', 'bevel_bottom', 'z'))
    return None if flat else d


def body_props(bp, th=None):
    """bodyPr -> explicit frame settings."""
    o = {}
    if bp is None:
        return o
    if bp.get('numCol') not in (None, '1'):
        o['cols'] = (int(bp.get('numCol')), inch(bp.get('spcCol', 0)))
    if bp.get('rot') not in (None, '0'):
        o['trot'] = num(int(bp.get('rot')) / 60000, 1)
    warp = kid(bp, 'prstTxWarp')
    if warp is not None and warp.get('prst') not in (None, 'textNoShape'):
        adj = [int(re.sub(r'[^\d-]', '', g.get('fmla', '0')) or 0) for g in warp.findall(f'{{{A}}}avLst/{{{A}}}gd')]
        o['warp'] = (warp.get('prst'), *adj)
    d3 = three_d(bp, th)
    if d3:
        o['d3t'] = d3
    if bp.get('wrap'):
        o['wrap'] = bp.get('wrap') != 'none'
    if bp.get('anchor') in ANCHOR:
        o['anchor'] = ANCHOR[bp.get('anchor')]
    ins = [bp.get(a) for a, _ in INSETS]
    if any(v is not None for v in ins):
        o['m'] = tuple(inch(v if v is not None else d) for v, (_, d) in zip(ins, INSETS))
    for c in bp:
        if ln(c) == 'spAutoFit':
            o['fit'] = 'shape'
        elif ln(c) == 'noAutofit':
            o['fit'] = 'none'
        elif ln(c) == 'normAutofit':
            fs, lr = c.get('fontScale'), c.get('lnSpcReduction')
            o['fit'] = ('text', num(int(fs) / 1000, 1)) + ((num(int(lr) / 1000, 1),) if lr else ()) if fs else 'text'
    if bp.get('vert') not in (None, 'horz'):
        o['vert'] = bp.get('vert')
    return o


def read_paras(txbody, th, rels, levels=None):
    """[(paragraph props, [(text, run props)])]; levels: inherited props per level (blank-template mode)."""
    out = []
    for p in txbody.findall(f'{{{A}}}p'):
        pp = ppr_props(kid(p, 'pPr'), th)
        inh = (levels or {}).get(pp.get('lvl', 0), {})
        inh_p = {k: v for k, v in inh.items() if k in PARA_KEYS}
        for a, b in (('sb', 'sbp'), ('sa', 'sap')):  # the paragraph's own spacing wins, in points or in %
            if a in pp or b in pp:
                inh_p.pop(a, None)
                inh_p.pop(b, None)
        pp = {**inh_p, **pp}
        base = {k: v for k, v in inh.items() if k not in PARA_KEYS}
        runs = []
        for c in p:
            n = ln(c)
            if n in ('r', 'fld'):
                t = kid(c, 't')
                ro = {**base, **rpr_props(kid(c, 'rPr'), th)}
                if n == 'fld' and c.get('type'):  # slide number, date ...
                    ro['fld'] = c.get('type')
                hl = kid(kid(c, 'rPr'), 'hlinkClick')
                if hl is not None and hl.get(f'{{{R}}}id') in rels:
                    ro['hl'] = rels[hl.get(f'{{{R}}}id')]
                txt = t.text if t is not None and t.text else ''
                if runs and runs[-1][1] == ro:
                    runs[-1] = (runs[-1][0] + txt, ro)
                elif txt:
                    runs.append((txt, ro))
            elif n == 'br':
                if runs:
                    runs[-1] = (runs[-1][0] + '\v', runs[-1][1])
                else:
                    runs.append(('\v', dict(base)))
        if not runs:
            end = kid(p, 'endParaRPr')
            if end is not None and end.get('sz'):
                pp['sz'] = num(int(end.get('sz')) / 100, 2)
        size = next((r[1]['sz'] for r in runs if 'sz' in r[1]), pp.get('sz', base.get('sz', 18)))
        for k in ('sb', 'sa'):
            if k + 'p' in pp:
                pp[k] = num(pp.pop(k + 'p') / 100 * size, 1)
        bc, bs = pp.pop('bulc', None), pp.pop('buls', None)
        if (bc or bs) and pp.get('bul') not in (None, ''):
            b = pp['bul']
            if isinstance(b, dict):
                pp['bul'] = {**b, **{k: v for k, v in (('color', bc), ('size', bs)) if v is not None}}
            else:
                ch, face = (b, None) if isinstance(b, str) else b
                pp['bul'] = {k: v for k, v in (('char', ch), ('font', face), ('color', bc), ('size', bs)) if v is not None}
        out.append((pp, runs))
    while len(out) > 1 and not out[-1][1] and not out[-1][0]:
        out.pop()  # trailing empty paragraphs
    return out


def factor(paras):
    """(shape-level kwargs, text argument): settings shared by every run/paragraph move to the shape."""
    runs = [r for _, rs in paras for r in rs]
    common = {}
    if runs:
        keys = set.intersection(*(set(o) for _, o in runs))
        common = {k: runs[0][1][k] for k in keys if all(o[k] == runs[0][1][k] for _, o in runs)}
    pcommon = {}
    if paras:
        keys = set.intersection(*(set(pp) for pp, _ in paras))
        pcommon = {k: paras[0][0][k] for k in keys if all(pp[k] == paras[0][0][k] for pp, _ in paras)}
    enc, simple = [], True
    for pp, rs in paras:
        pd = {k: v for k, v in pp.items() if k not in pcommon}
        rr = [(t, {k: v for k, v in o.items() if k not in common or o[k] != common[k]}) for t, o in rs]
        body = [t if not d else (t, d) for t, d in rr]
        if len(body) == 1 and isinstance(body[0], str):
            body = body[0]
        elif not body:
            body = ''
        if pd or not isinstance(body, str):
            simple = False
        enc.append({'t': body, **pd} if pd else body)
    kw = {**pcommon, **common}
    if simple:
        return kw, '\n'.join(enc)
    return kw, enc


def is_text_empty(paras):  # a no-break space is kept: it gives a cell or shape its line height
    return not any(t.strip(' \t\r\n\v\f') for _, rs in paras for t, _ in rs)


# ── code formatting ──────────────────────────────────────────────────────────
class Exact(float):
    """A number written in full (chart data), not rounded like positions and sizes."""


def lit(v):
    if isinstance(v, Raw):
        return str(v)
    if isinstance(v, Exact):
        return repr(float(v))
    if isinstance(v, float):
        return repr(num(v, 4))
    if isinstance(v, (list, tuple)):
        inner = ', '.join(lit(x) for x in v)
        return f'({inner},)' if isinstance(v, tuple) and len(v) == 1 else f'({inner})' if isinstance(v, tuple) \
            else f'[{inner}]'
    if isinstance(v, dict):
        return '{' + ', '.join(f'{lit(k)}: {lit(x)}' for k, x in v.items()) + '}'
    return repr(v)


ORDER = ('t', 'shape', 'fill', 'line', 'lw', 'dash', 'ends', 'adj', 'rot', 'flip', 'crop', 'pos', 'wrap', 'fit',
         'anchor', 'm', 'vert') + PARA_KEYS + ('b', 'i', 'u', 'sz', 'f', 'c', 'cap', 'spc', 'base', 'strike')


def tall(v, indent, width):
    """A long list/dict literal, one item per line; a long string as several adjacent strings."""
    one = lit(v)
    if isinstance(v, str) and not isinstance(v, Raw) and len(one) + indent > width and ' ' in v:
        size, parts, cur = width - indent - 8, [], ''
        for w in re.split(r'(?<= )', v):
            if cur and len(repr(cur + w)) > size:
                parts.append(cur)
                cur = ''
            cur += w
        pad = ' ' * (indent + 4)
        return '(\n' + '\n'.join(pad + repr(x) for x in parts + [cur]) + '\n' + ' ' * indent + ')'

    if len(one) + indent <= width or not isinstance(v, (list, dict)) or len(v) < 2:
        return one
    pad = ' ' * (indent + 4)
    items = [f'{lit(k)}: {lit(x)}' for k, x in v.items()] if isinstance(v, dict) else [lit(x) for x in v]
    o, c = ('{', '}') if isinstance(v, dict) else ('[', ']')
    return o + '\n' + ',\n'.join(pad + i for i in items) + ',\n' + ' ' * indent + c


def call(fn, args, kw, width=118, tail=()):
    kws = sorted(kw.items(), key=lambda t: (ORDER.index(t[0]) if t[0] in ORDER else 99, t[0]))
    parts = [tall(a, 4, width - 4) if not isinstance(a, Raw) else a for a in args] + \
            [f'{k}={tall(v, 4, width - 4 - len(k)) if not isinstance(v, Raw) else v}' for k, v in kws if v is not None] + list(tail)
    one = f'{fn}({", ".join(parts)})'
    if len(one) <= width and '\n' not in one:
        return [one]
    lines, cur = [], f'{fn}('
    for i, p in enumerate(parts):
        piece = p + (', ' if i < len(parts) - 1 else ')')
        if cur.strip() != f'{fn}(' and len(cur) + len(piece.split('\n')[0]) > width:
            lines.append(cur.rstrip())
            cur = ' ' * 4 + piece
        else:
            cur += piece
        if '\n' in cur:
            *done, cur = cur.split('\n')
            lines += done
    lines.append(cur.rstrip())
    return lines


class Raw(str):
    """Code that is written as is (a variable name, IMG['x'] ...)."""


class Call:
    """One helper call; rendered after shared styles and constants have been factored out."""

    def __init__(self, fn, args, kw, ref=None):
        self.fn, self.args, self.kw, self.style = fn, list(args), {k: v for k, v in kw.items() if v is not None}, None
        self.ref = ref  # a variable for the new shape, when animations or connectors refer to it

    def render(self, width=118):
        if self.fn == 'animate':
            return animate_code(self.args[1], self.kw.get('builds'), 4, width)
        args, kw = list(self.args), dict(self.kw)
        if 't' in kw and self.fn in ('box', 'ph'):
            if self.fn == 'ph' and len(args) == 2 or self.fn == 'box' and len(args) == 5:
                args.append(kw.pop('t'))
        if self.style:
            kw[f'**{self.style}'] = None
        lines = call(self.fn, args, {k: v for k, v in kw.items() if not k.startswith('**')}, width - (len(self.ref) + 3 if
                                                                                                    self.ref else 0),
                     tail=[k for k in kw if k.startswith('**')])
        if self.ref:
            lines[0] = f'{self.ref} = {lines[0]}'
        return lines


EFFECT_ORDER = ('shape', 'on', 'start', 'type', 'preset', 'sub', 'grp', 'delay', 'paras', 'chars', 'dur', 'accel',
                'decel', 'autorev', 'repeat', 'speed', 'restart', 'do')


def animate_code(effects, builds, indent, width):
    """animate(s, [...]) laid out one effect per entry, its steps packed below it."""
    pad = ' ' * indent
    out = ['animate(s, [']
    for e in effects:
        head = 'dict(' + ', '.join(f'{k}={lit(e[k])}' for k in EFFECT_ORDER if k in e and k != 'do') + ', do=['
        steps = [lit(st) for st in e.get('do', ())]
        lines, cur = [], pad + '    ' + head
        for i, st in enumerate(steps):
            piece = st + (', ' if i < len(steps) - 1 else '])')
            if len(cur) + len(piece) > width and cur.strip() != head:
                lines.append(cur.rstrip())
                cur = pad + '        '
            cur += piece
        if not steps:
            cur += '])'
        lines.append(cur.rstrip() + ',')
        out += [x[len(pad):] for x in lines]
    tail = '])' if not builds else '], builds=[' + ', '.join(
        'dict(' + ', '.join(f'{k}={lit(v)}' for k, v in b.items()) + ')' for b in builds) + '])'
    out.append(tail)
    return out


# ── the converter ────────────────────────────────────────────────────────────
@dataclass
class Result:
    code: str
    files: dict = field(default_factory=dict)
    slides: list = field(default_factory=list)
    skipped: list = field(default_factory=list)
    notes: list = field(default_factory=list)  # converted, but not exactly

    @property
    def lines(self):
        return self.code.count('\n') + 1


MEDIA = {'mp3': 'audio/mpeg', 'wav': 'audio/wav', 'wma': 'audio/x-ms-wma', 'm4a': 'audio/mp4', 'mp4': 'video/mp4',
         'm4v': 'video/mp4', 'mov': 'video/quicktime', 'wmv': 'video/x-ms-wmv', 'avi': 'video/x-msvideo',
         'mpg': 'video/mpeg', 'mpeg': 'video/mpeg', 'emf': 'image/x-emf', 'wmf': 'image/x-wmf', 'svg': 'image/svg+xml',
         'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'gif': 'image/gif', 'bin': 'application/vnd.openxmlformats-officedocument.oleObject',
         'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'rels':
         'application/vnd.openxmlformats-package.relationships+xml', 'xml': 'application/xml'}


def _dangling(name, b, parts):
    """Lists of slides / layouts / masters naming a relationship (rId) that is not there: those entries dropped."""
    folder, base = name.rsplit('/', 1)
    rels = parts.get(f'{folder}/_rels/{base}.rels', b'')
    ids = set(re.findall(rb'Id="([^"]+)"', rels))
    targets = dict(re.findall(rb'Id="([^"]+)"[^>]*Target="([^"]+)"', rels) +
                   [(i, t) for t, i in re.findall(rb'Target="([^"]+)"[^>]*Id="([^"]+)"', rels)])
    ok = {i for i in ids if targets.get(i, b'').startswith(b'http') or
          posixpath.normpath(posixpath.join(folder, targets.get(i, b'').decode())) in parts}
    pat = rb'<p:(sldLayoutId|sldId|sldMasterId|notesMasterId|handoutMasterId)\b[^>]*?r:id="([^"]+)"[^>]*/>'
    return re.sub(pat, lambda m: m[0] if m[2] in ok else b'', b)


MAIN_PRES = b'application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml'
OTHER_MAIN = {  # templates, slide shows and macro decks: read as an ordinary presentation
    b'application/vnd.openxmlformats-officedocument.presentationml.template.main+xml': 'a template (.potx)',
    b'application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml': 'a slide show (.ppsx)',
    b'application/vnd.ms-powerpoint.presentation.macroEnabled.main+xml': 'a deck with macros (.pptm)',
    b'application/vnd.ms-powerpoint.template.macroEnabled.main+xml': 'a template with macros (.potm)',
    b'application/vnd.ms-powerpoint.slideshow.macroEnabled.main+xml': 'a slide show with macros (.ppsm)'}
OLE2 = b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'  # old binary Office files (.ppt)
# a .ppt's CurrentUserAtom (record 0x0FF6, size 0x14) with the token PowerPoint writes when a password is set
ENCRYPTED_PPT = re.compile(rb'\x00\x00\xf6\x0f[\s\S]{4}\x14\x00\x00\x00\xdf\xc4\xd1\xf3')
_LEGACY = {}


def _soffice():
    import shutil
    found = shutil.which('soffice') or shutil.which('libreoffice')
    for p in ([] if found else [r'C:\Program Files\LibreOffice\program\soffice.exe',
                                r'C:\Program Files (x86)\LibreOffice\program\soffice.exe',
                                '/Applications/LibreOffice.app/Contents/MacOS/soffice']):
        if Path(p).exists():
            return p
    return found


def ole_kind(ole, part):
    """What an embedded object is ('Excel', 'MathType Equation' ...): its program, else the name its data gives."""
    if ole.get('progId'):
        return ole.get('progId').split('.')[0]
    rid = ole.get(f'{{{R}}}id')
    try:
        blob = part.related_part(rid).blob if rid else b''
    except (KeyError, AttributeError):
        return ''
    # the CompObj stream of the object's OLE container: header, class id, then the user-readable type name
    m = re.search(rb'\x01\x00\xfe\xff\x03\x0a\x00\x00\xff\xff\xff\xff[\s\S]{16}([\s\S]{4})', blob[:65536])
    n = int.from_bytes(m[1], 'little') if m else 0
    name = blob[m.end(): m.end() + n - 1].decode('latin-1', 'replace') if 1 < n < 80 else ''
    return name if re.fullmatch(r'[\w .()&-]+', name) else ''


def legacy_to_pptx(data):
    """An old .ppt (PowerPoint 97-2003) as .pptx bytes, saved by PowerPoint (Windows) or LibreOffice, whichever is
    installed; (bytes, what did it)."""
    import hashlib
    import subprocess
    import sys
    import tempfile
    key = hashlib.sha1(data).hexdigest()
    if key in _LEGACY:
        return _LEGACY[key]
    with tempfile.TemporaryDirectory(prefix='pptx2py_') as tmp:
        src, dst = Path(tmp) / 'deck.ppt', Path(tmp) / 'deck.pptx'
        src.write_bytes(data)
        how, tried = None, []
        if sys.platform.startswith('win'):  # PowerPoint itself, through its automation interface
            q = (lambda p: str(p).replace("'", "''"))
            ps = (f"$pp = New-Object -ComObject PowerPoint.Application; $p = $pp.Presentations.Open('{q(src)}', $true, "
                  f"$false, $false); $p.SaveAs('{q(dst)}', 24); $p.Close(); $pp.Quit()")
            try:
                r = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', ps], capture_output=True,
                                   timeout=300, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                how = 'PowerPoint' if dst.exists() else None
                if not how and b'PowerPoint.Application' not in r.stdout + r.stderr:  # installed, but it failed
                    tried.append('PowerPoint')
            except (OSError, subprocess.SubprocessError):
                pass
        exe = _soffice() if not dst.exists() else None
        if exe:
            try:
                subprocess.run([exe, '--headless', '--norestore', f'-env:UserInstallation={Path(tmp).as_uri()}/profile',
                                '--convert-to', 'pptx', '--outdir', tmp, str(src)], capture_output=True, timeout=300,
                               creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                how = 'LibreOffice' if dst.exists() else None
            except (OSError, subprocess.SubprocessError):
                pass
        if not dst.exists() and (exe or tried):
            raise ValueError(f'This is an old PowerPoint 97-2003 file (.ppt), which python-pptx cannot read, and '
                             f'{" and ".join(tried + (["LibreOffice"] if exe else []))} could not open it either (it may '
                             f'be damaged, or made by an unusual program). Open it in PowerPoint and save it as a '
                             f'PowerPoint Presentation (.pptx), then convert that.')
        if not dst.exists():
            raise ValueError('This is an old PowerPoint 97-2003 file (.ppt), which python-pptx cannot read. Open it in '
                             'PowerPoint and save it as a PowerPoint Presentation (.pptx), or install LibreOffice: '
                             'pptx2py then converts .ppt files by itself.')
        _LEGACY[key] = (dst.read_bytes(), how)
    return _LEGACY[key]


def deck_ext(data):
    """The file type of a deck's bytes: 'pptx', 'ppt', 'potx', 'pptm' ..."""
    if data[:8] == OLE2:
        return 'ppt'
    try:
        import zipfile
        ct = zipfile.ZipFile(io.BytesIO(data)).read('[Content_Types].xml')
    except Exception:  # noqa: BLE001  (damaged: repaired later)
        ct = b''
    return next((what.split('(')[-1].strip(').') for t, what in OTHER_MAIN.items() if t in ct), 'pptx')


def prepare(data):
    """(bytes python-pptx can open, [what was done]): old .ppt files converted, templates, slide shows and macro
    decks read as ordinary presentations (macros left out: a .pptx cannot carry them)."""
    fixes = []
    if data[:8] == OLE2 and ('EncryptedPackage'.encode('utf-16-le') in data or ENCRYPTED_PPT.search(data)):
        raise ValueError('This presentation is protected with a password, so it cannot be read. Open it in PowerPoint, '
                         'remove the password (File > Info > Protect Presentation > Encrypt with Password, clear it), '
                         'save, and convert again.')
    if data[:8] == OLE2:
        data, how = legacy_to_pptx(data)
        fixes.append(f'an old PowerPoint 97-2003 file (.ppt), converted to .pptx with {how} first')
    import zipfile
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        ct = z.read('[Content_Types].xml')
    except (zipfile.BadZipFile, KeyError):
        return data, fixes
    kinds = [what for t, what in OTHER_MAIN.items() if t in ct]
    vba = [n for n in z.namelist() if n.lower().endswith('vbaproject.bin') or n.lower().endswith('vbadata.xml')]
    if not kinds and not vba:
        return data, fixes
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as w:
        for info in z.infolist():
            if info.filename in vba or info.filename.endswith('/'):
                continue
            b = z.read(info.filename)
            if info.filename == '[Content_Types].xml':
                for t in OTHER_MAIN:
                    b = b.replace(t, MAIN_PRES)
                b = re.sub(rb'<Override[^>]*PartName="/[^"]*vba(Project\.bin|Data\.xml)"[^>]*/>', b'', b, flags=re.I)
                b = re.sub(rb'<Default[^>]*Extension="bin"[^>]*ContentType="application/vnd\.ms-office\.vbaProject"[^>]*/>',
                           b'', b)
            elif info.filename.endswith('.rels'):
                b = re.sub(rb'<Relationship[^>]*Target="[^"]*vba(Project\.bin|Data\.xml)"[^>]*/>', b'', b, flags=re.I)
            w.writestr(info, b)
    fixes += [f'{k}: read as a presentation' for k in kinds]
    if vba:
        fixes.append('its macros (VBA), left out (a .pptx cannot carry macros)')
    return out.getvalue(), fixes


def repair(data, deep=False):
    """(bytes python-pptx can open, [what was changed]). Strict Open XML is mapped to the usual format,
    files the package lists no type for (sounds, videos ...) get one; deep: lists naming missing parts are
    cleaned up."""
    import zipfile
    try:
        zin = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise ValueError('This is not a PowerPoint file, or it is damaged (it is not a .pptx package).') from None
    names = [n for n in zin.namelist() if not n.endswith('/')]
    if '[Content_Types].xml' not in names:
        raise ValueError('This file is damaged: it has no list of its parts ([Content_Types].xml).')
    damaged = []
    read = zin.read

    def lenient(name):  # a part failing its checksum: read as it is, and said
        try:
            return read(name)
        except Exception:  # noqa: BLE001  (bad checksum, broken compression ...)
            pass
        try:
            with zin.open(name) as f:
                f._expected_crc = None  # read past a wrong checksum
                b = f.read()
        except Exception:  # noqa: BLE001
            b = b''
        damaged.append(name)
        return b
    zin.read = lenient
    ct = zin.read('[Content_Types].xml')
    rels = zin.read('_rels/.rels') if '_rels/.rels' in names else b''
    strict = b'purl.oclc.org/ooxml' in rels
    have = set(re.findall(rb'Extension="([^"]+)"', ct, re.I))
    have = {e.lower() for e in have}
    over = {m.lower() for m in re.findall(rb'PartName="/?([^"]+)"', ct)}
    missing = sorted({n.rsplit('.', 1)[-1].lower() for n in names if n != '[Content_Types].xml' and '.' in n.rsplit('/', 1)[-1]
                      and n.encode().lower() not in over and n.rsplit('.', 1)[-1].lower().encode() not in have})
    if not strict and not missing and not deep:
        return data, []
    fixes, parts = [], {n: None for n in names}
    if deep:
        parts = {n: zin.read(n) for n in names}
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for info in zin.infolist():
            if info.filename.endswith('/'):
                continue
            b = zin.read(info.filename)
            if info.filename == '[Content_Types].xml' and missing:
                b = b.replace(b'</Types>', b''.join(b'<Default Extension="%s" ContentType="%s"/>' % (
                    e.encode(), MEDIA.get(e, 'application/octet-stream').encode()) for e in missing) + b'</Types>')
            if deep and re.fullmatch(r'ppt/(presentation|slideMasters/slideMaster\d+)\.xml', info.filename):
                nb = _dangling(info.filename, b, parts)
                if nb != b:
                    b = nb
                    fixes.append(f'{info.filename} named parts that are missing; they were left out')
            if strict and info.filename.endswith(('.xml', '.rels')):
                b = re.sub(rb'http://purl\.oclc\.org/ooxml/(\w+)/', rb'http://schemas.openxmlformats.org/\1/2006/', b)
                b = re.sub(rb'="(-?\d+(?:\.\d+)?)%"', lambda m: b'="%d"' % round(float(m[1]) * 1000), b)  # 50% -> 50000
            z.writestr(info.filename, b)
    if strict:
        fixes.append('the file is saved as Strict Open XML; it was read as an ordinary .pptx')
    if missing:
        fixes.append('the file did not list the type of its ' + ', '.join(f'.{e}' for e in missing) +
                     ' parts; they were given one')
    if damaged:
        fixes.append('the file is damaged (' + ', '.join(sorted(set(damaged))[:3]) + ' failed its checksum); read as '
                     'far as possible')
    return out.getvalue(), fixes


def layout_box(slide, phel):
    """(x, y, w, h) EMU of a placeholder with no counterpart on its layout: the layout's or master's placeholder
    of the same type."""
    if phel is None:
        return None
    typ = phel.get('type', 'body').replace('obj', 'body')
    lay = getattr(slide, 'slide_layout', None)
    if lay is None:  # a layout's or master's own placeholder
        return None
    for owner in (lay, lay.slide_master):
        for shp in owner.placeholders:
            if shp.width is not None and shp._element.find(f'.//{{{P}}}ph').get('type', 'body').replace('obj', 'body') == typ:
                return shp.left, shp.top, shp.width, shp.height
    return None


def _readable(prs):
    for m in prs.slide_masters:
        list(m.slide_layouts)


def open_deck(source):
    """A Presentation from a path or bytes, repaired when python-pptx could not open it as it is."""
    data = source if isinstance(source, bytes) else Path(source).read_bytes()
    data = prepare(data)[0]
    try:
        prs = Presentation(io.BytesIO(data))
        _readable(prs)
        return prs
    except Exception:  # noqa: BLE001
        return Presentation(io.BytesIO(repair(data, deep=True)[0]))


class Converter:
    def __init__(self, data, template=True, embed=False, notes=True, fx=True, name='deck', helpers='inline',
                 style='plain', extras=True, motion=True):
        self.ext = deck_ext(data)  # what the deck was: pptx, ppt, potx ...
        data, self.fixes = prepare(data)
        try:
            self.prs = Presentation(io.BytesIO(data))
            _readable(self.prs)
        except Exception as exc:  # noqa: BLE001
            data, more = repair(data, deep=True)
            self.fixes += more
            try:
                self.prs = Presentation(io.BytesIO(data))
            except Exception:  # noqa: BLE001
                raise ValueError(f'python-pptx cannot open this file ({exc}). Open it in PowerPoint and save it again '
                                 'as a PowerPoint Presentation (.pptx).') from None
        self.data = data
        self.th = self.base = Theme(self.prs.slide_masters[0])
        self.themes, self.layout_funcs = {}, {}
        self.template, self.embed, self.notes, self.fx = template, embed, notes, fx
        self.module = helpers == 'file' and not embed  # helpers imported from pptx_helpers.py
        self.style, self.extras = style, extras  # 'plain' python-pptx or 'compact'; extras: what python-pptx lacks
        self.motion = motion  # slide transitions and animations
        self.refs, self.ref_vars = set(), {}
        self.name = re.sub(r'\W+', '_', name).strip('_') or 'deck'
        self.images, self.used, self.skipped, self.approx = {}, set(), [], [f'file: {x}' for x in self.fixes]
        self.odd = set()  # pictures Pillow cannot read
        self.glue = []
        self.ngroup = 0

    # images ------------------------------------------------------------------
    def image(self, blob, ext, stem='img'):
        key = hashlib.sha1(blob).hexdigest()
        if key not in self.images:
            self.images[key] = (f'{stem}{sum(1 for n, _ in self.images.values() if n.startswith(stem)) + 1}.{ext}', blob)
            try:  # python-pptx's add_picture() takes only what Pillow reads
                from PIL import Image
                Image.open(io.BytesIO(blob))
            except Exception:  # noqa: BLE001  (PICT, HD Photo, EMF on some systems ...)
                self.odd.add(self.images[key][0])
        name = self.images[key][0]
        return Raw(f"IMG[{name.split('.')[0]!r}]") if self.embed else f'assets/{name}'

    # shapes -------------------------------------------------------------------
    def box_of(self, el, xf=None):
        """(x, y, w, h) in inches of an element, mapped through group transforms."""
        sppr = kid(el, 'spPr', P) if ln(el) != 'graphicFrame' else None
        x = kid(sppr if sppr is not None else el, 'xfrm', A if sppr is not None else P)
        if x is None and ln(el) == 'grpSp':
            x = kid(kid(el, 'grpSpPr', P), 'xfrm')
        off, ext = kid(x, 'off'), kid(x, 'ext')
        if off is None or ext is None:
            return None
        v = [int(off.get('x')), int(off.get('y')), int(ext.get('cx')), int(ext.get('cy'))]
        if xf:
            v = self.map(v, xf)
        return tuple(inch(a) for a in v)

    @staticmethod
    def map(v, xf):
        ox, oy, sx, sy, cx, cy = xf
        return [ox + (v[0] - cx) * sx, oy + (v[1] - cy) * sy, v[2] * sx, v[3] * sy]

    def rot_flip(self, el):
        sppr = el.find(f'{{{P}}}spPr')
        x = kid(sppr, 'xfrm')
        out = {}
        if x is not None:
            if x.get('rot'):
                out['rot'] = num(int(x.get('rot')) / 60000, 1)
            flip = ('h' if x.get('flipH') in ('1', 'true') else '') + ('v' if x.get('flipV') in ('1', 'true') else '')
            if flip:
                out['flip'] = flip
        return out

    def geometry(self, sppr):
        kw = {}
        pg, cg = kid(sppr, 'prstGeom'), kid(sppr, 'custGeom')
        if cg is not None:
            ext = kid(kid(sppr, 'xfrm'), 'ext')
            g = path_spec(cg, *((int(ext.get('cx', 0)), int(ext.get('cy', 0))) if ext is not None else (0, 0)))
            if g:
                kw['geom'] = g
            else:
                kw['shape'] = 'rect'
        elif pg is not None:
            kw['shape'] = pg.get('prst')
            gds = pg.findall(f'{{{A}}}avLst/{{{A}}}gd')
            vals = [int(re.sub(r'[^\d-]', '', g.get('fmla', '0')) or 0) for g in gds]
            names = [g.get('name') for g in gds]
            if vals and names == (['adj'] if len(vals) == 1 else [f'adj{i + 1}' for i in range(len(vals))]):
                kw['adj'] = tuple(vals)
        return kw

    def styled(self, el, kw):
        """Fill, line and effects of a shape: its own, else from its theme style."""
        sppr = kid(el, 'spPr', P)
        st = kid(el, 'style', P)
        refs = {ln(c): c for c in st} if st is not None else {}
        f = fill_spec(sppr, self.th, refs.get('fillRef'))
        if isinstance(f, tuple) and f[1] in self.part.rels:
            part = self.part.related_part(f[1])
            img = self.image(part.blob, part.partname.ext or 'png')
            if img is not None:
                kw['fill'] = ['img', img] + ([bool(f[2]), f[3]] if f[3] else [True] if f[2] else [])
        elif f is not None:
            kw['fill'] = f
        kw.update(line_spec(sppr, self.th, refs.get('lnRef')))
        if self.fx:
            e = effects(sppr, self.th, refs.get('effectRef'))
            if e:
                kw['fx'] = e
            d3 = three_d(sppr, self.th)
            if d3:
                kw['d3'] = d3
        self.link(el, kw)
        font_ref = refs.get('fontRef')
        inherited = {}
        if font_ref is not None:
            c = colour_of(font_ref, self.th)
            if c:
                inherited['c'] = c
            if font_ref.get('idx') == 'major':
                inherited['f'] = '+mj-lt'
        return inherited

    def text_kw(self, el, kw, kind, inherited=None, levels=None):
        """Frame settings + text argument of a shape. kind: 'box', 'shape' or 'ph' (what the helper creates)."""
        tb = kid(el, 'txBody', P)
        if tb is None:
            return None
        fr = body_props(kid(tb, 'bodyPr'), self.th)
        if levels and 'frame' in levels:
            fr = {**levels['frame'], **fr}
        if kind == 'box':  # python-pptx text boxes: wrap none + shape fits text
            fr['wrap'] = fr.get('wrap', True)
            if fr.get('wrap') is False:
                fr.pop('wrap')
            fr['fit'] = fr.get('fit', 'none')
            if fr['fit'] == 'shape':
                fr.pop('fit')
            if fr.get('anchor') == 't':
                fr.pop('anchor')
        elif kind == 'shape':  # python-pptx shapes: middle anchor
            fr['anchor'] = fr.get('anchor', 't')
            if fr['anchor'] == 'm':
                fr.pop('anchor')
            if fr.get('wrap') is True:
                fr.pop('wrap')
            if fr.get('fit') == 'none':
                fr.pop('fit')
        paras = read_paras(tb, self.th, self.rels, levels.get('levels') if levels else None)
        if fr.get('anchor', 't') == 't' or (kind == 'shape' and 'anchor' not in fr):
            while len(paras) > 1 and not paras[-1][1]:
                paras.pop()
        if inherited:
            paras = [(pp, [(t, {**inherited, **o}) for t, o in rs]) for pp, rs in paras]
        if is_text_empty(paras):
            return None
        common, t = factor(paras)
        kw.update(fr)
        kw.update(common)
        return t

    def emit_sp(self, el, parent, xf, out):
        nv = el.find(f'.//{{{P}}}nvPr')
        phel = kid(nv, 'ph', P)
        sppr = kid(el, 'spPr', P)
        if phel is not None and self.template and parent == 's' and not xf:
            idx = int(phel.get('idx', '0'))
            if idx in self.layout_ph and phel.get('type') not in ('dt', 'ftr', 'sldNum') and idx not in self.keep and \
                    self.same_kind(phel):
                kw = {}
                pos = self.box_of(el)
                if pos:
                    kw['pos'] = pos
                inherited = self.styled(el, kw)
                t = self.text_kw(el, kw, 'ph', inherited)
                self.keep.append(idx)
                ref = self.ref_for(el)
                if t is not None or kw or ref:
                    out.append(Call('ph', [Raw('s'), idx] + ([t] if t is not None else []), kw, ref))
                    self.used.add('ph')
                return
        pos = self.box_of(el, xf)
        if pos is None:
            pos = self.placeholder_pos(el)
            if pos is None:
                return self.skip(el, 'a placeholder with no position of its own and none on its layout, left out')
        txbox = kid(kid(el, 'nvSpPr', P), 'cNvSpPr', P)
        is_box = txbox is not None and txbox.get('txBox') in ('1', 'true')
        kw = self.geometry(sppr)
        tb = kid(el, 'txBody', P)
        if kw.get('shape') in LINE_PRESETS and (tb is None or not ''.join(tb.itertext()).strip()):
            return self.emit_cxn(el, parent, xf, out)  # a line drawn as a shape: a connector
        if is_box and kw.get('shape') == 'rect' and not kw.get('adj'):
            kw.pop('shape')
        kind = 'box' if 'shape' not in kw and 'geom' not in kw else 'shape'
        inherited = self.styled(el, kw)
        if kind == 'box' and kw.get('fill') == '':
            kw.pop('fill')  # text boxes start without fill
        kw.update(self.rot_flip(el))
        levels = self.inherited_levels(el) if phel is not None else self.own_levels(el)
        t = self.text_kw(el, kw, kind, inherited, levels)
        if phel is not None and t is None and kw.get('fill', '') == '' and kw.get('line', '') == '' and \
                not kw.get('fx') and not self.ref_for(el):
            return  # an empty placeholder shows nothing in a slide show
        if t is not None:
            kw = {'t': t, **kw}
        out.append(Call('box', [Raw(parent), *pos], kw, self.ref_for(el)))
        self.used.add('box')

    def same_kind(self, phel):
        """Whether a slide placeholder really is the layout's placeholder with its idx (a title is not a body)."""
        lay = self.layout_types.get(int(phel.get('idx', '0')))
        title = ('title', 'ctrTitle')
        return lay is not None and (phel.get('type', 'obj') in title) == (lay in title)

    def placeholder_pos(self, el):
        phel = el.find(f'.//{{{P}}}ph')
        if phel is None or not self.template or self.same_kind(phel):
            for shp in self.slide.shapes:
                if shp._element is el and shp.width is not None:
                    return tuple(inch(v) for v in (shp.left, shp.top, shp.width, shp.height))
        v = layout_box(self.slide, phel)
        return tuple(inch(x) for x in v) if v else None

    def emit_pic(self, el, parent, xf, out, ref=None, pos=None):
        pos = pos or self.box_of(el, xf) or self.placeholder_pos(el)
        blip = el.find(f'.//{{{A}}}blip')
        rid = blip.get(f'{{{R}}}embed') if blip is not None else None
        if pos is None or rid is None or rid not in self.part.rels:
            return self.skip(el, 'a picture whose image is missing from the file, left out')
        part = self.part.related_part(rid)
        ext = (part.partname.ext or 'png').lower()
        if ext in ('wmf', 'emf', 'svg', 'tif', 'tiff'):
            ext = ext  # python-pptx can place these; keep the original bytes
        kw = {}
        sr = el.find(f'.//{{{A}}}srcRect')
        if sr is not None and any(sr.get(k) for k in 'ltrb'):
            kw['crop'] = tuple(num(int(sr.get(k, 0)) / 100000, 5) for k in 'ltrb')
        sppr = kid(el, 'spPr', P)
        g = self.geometry(sppr)
        if g.get('shape', 'rect') != 'rect':
            kw['shape'] = g['shape']
        ls = line_spec(sppr, self.th)
        kw.update({k: v for k, v in ls.items() if k in ('line', 'lw')})
        back = fill_spec(sppr, self.th)
        if back and not isinstance(back, tuple):  # a fill behind the picture, seen through its clear parts
            kw['fill'] = back
        kw.update(self.rot_flip(el))
        if self.fx:
            e = effects(sppr, self.th)
            if e:
                kw['fx'] = e
        pfx = picture_fx(blip, self.th)
        if pfx:
            kw['pfx'] = pfx
        if self.fx:
            d3 = three_d(sppr, self.th)
            if d3:
                kw['d3'] = d3
        self.link(el, kw)
        img = self.image(part.blob, ext)
        if img is None:
            return self.skip(el, f'a .{ext} picture, left out (python-pptx cannot insert this image type)', out)
        if blip.find(f'.//{{{A}}}ext[@uri="{{96DAC541-7B7A-43D3-8B79-37D633B846F1}}"]') is not None:
            self.note(el, 'an SVG picture: the PNG copy saved with it is used (python-pptx inserts bitmap pictures)')
        nvpr = el.find(f'{{{P}}}nvPicPr/{{{P}}}nvPr')
        if nvpr is not None and self.media(el, nvpr, img, pos, parent, out, ref, kw.get('crop')):
            return
        out.append(Call('pic', [Raw(parent), img, *pos], kw, ref or self.ref_for(el)))
        self.used.add('pic')

    def media(self, el, nvpr, poster, pos, parent, out, ref, crop=None):
        """A video becomes add_movie() with its poster picture; a sound keeps its icon. True when handled."""
        vid, aud = kid(nvpr, 'videoFile'), kid(nvpr, 'audioFile')
        if vid is None and aud is None:
            return False
        if aud is not None:
            self.note(el, 'sound left out, its icon is kept (python-pptx cannot add sounds)')
            return False
        emb = nvpr.find(f'.//{{{P14}}}media')
        rid = emb.get(f'{{{R}}}embed') if emb is not None else None
        rid = rid if rid in self.part.rels else vid.get(f'{{{R}}}link')
        rel = self.part.rels.get(rid) if rid else None
        if rel is None or rel.is_external:
            self.note(el, 'linked video left out, its picture is kept (the video file is not inside the deck)')
            return False
        part = rel.target_part
        video = self.image(part.blob, (part.partname.ext or 'mp4').lower(), 'video')
        ext = (part.partname.ext or 'mp4').lower()
        mime = part.content_type if part.content_type.startswith('video/') and 'unknown' not in part.content_type \
            else MEDIA.get(ext, 'video/mp4')
        out.append(Call('movie', [Raw(parent), video, *pos], {'poster': poster, 'mime': mime, 'crop': crop},
                        ref or self.ref_for(el)))
        self.used.add('movie')
        return True

    def emit_cxn(self, el, parent, xf, out):
        pos = self.box_of(el, xf)
        if pos is None:
            return
        sppr = kid(el, 'spPr', P)
        kw = self.geometry(sppr)
        rf = self.rot_flip(el)
        if kw.get('shape') == 'lineInv':  # a line from bottom left to top right
            rf = {**rf, 'flip': rf.get('flip', '').replace('v', '') if 'v' in rf.get('flip', '') else rf.get('flip', '') + 'v'}
        x1, y1, x2, y2 = line_ends(pos, rf)
        if kw.get('shape') in ('line', 'lineInv', 'straightConnector1'):
            kw.pop('shape')
        kw.pop('geom', None)
        st = kid(el, 'style', P)
        refs = {ln(c): c for c in st} if st is not None else {}
        kw.update(line_spec(sppr, self.th, refs.get('lnRef')))
        out.append(Call('con', [Raw(parent), num(x1, 3), num(y1, 3), num(x2, 3), num(y2, 3)], kw, self.ref_for(el)))
        self.used.add('con')
        nvc = el.find(f'{{{P}}}nvCxnSpPr/{{{P}}}cNvCxnSpPr')
        if nvc is not None and (kid(nvc, 'stCxn') is not None or kid(nvc, 'endCxn') is not None):
            self.glue.append((el, (x1, y1, x2, y2)))

    def emit_grp(self, el, parent, xf, out, ref=None):
        x = kid(kid(el, 'grpSpPr', P), 'xfrm')
        if x is None:
            return self.walk(el, parent, xf, out)
        o, e, co, ce = (kid(x, t) for t in ('off', 'ext', 'chOff', 'chExt'))
        v = [int(o.get('x')), int(o.get('y')), int(e.get('cx')), int(e.get('cy'))]
        if xf:
            v = self.map(v, xf)
        sx = v[2] / int(ce.get('cx')) if ce is not None and int(ce.get('cx')) else 1
        sy = v[3] / int(ce.get('cy')) if ce is not None and int(ce.get('cy')) else 1
        nxf = (v[0], v[1], sx, sy, int(co.get('x')) if co is not None else 0, int(co.get('y')) if co is not None else 0)
        self.ngroup += 1
        var = ref or self.ref_for(el) or f'g{self.ngroup}'
        out.append(f'{var} = grp({parent})')
        self.used.add('grp')
        self.walk(el, var, nxf, out)
        rot = int(x.get('rot', 0)) / 60000  # a turned or flipped group: set once its shapes are in it
        flip = ('h' if x.get('flipH') in ('1', 'true') else '') + ('v' if x.get('flipV') in ('1', 'true') else '')
        if rot % 360 or flip:  # the point it turns about: the original box, not the one python-pptx fits
            out.append(Call('group_box', [Raw(var), *(inch(c) for c in v)], {}))
            self.used.add('group_box')
        if rot % 360:
            out.append(f'{var}.rotation = {lit(num(rot % 360, 2))}')
        if flip:
            out.append(Call('mirror', [Raw(var), flip], {}))
            self.used.add('mirror')

    def emit_frame(self, el, parent, xf, out):
        gd = el.find(f'.//{{{A}}}graphicData')
        uri = gd.get('uri', '') if gd is not None else ''
        pos = self.box_of(el, xf) or self.placeholder_pos(el)
        if pos is None:
            return self.skip(el, 'an object with no position, left out')
        if uri.endswith('/table'):
            return self.emit_table(el, gd, pos, out, self.ref_for(el), xf)
        if uri.endswith('/chart'):
            return self.emit_chart(el, parent, pos, out, self.ref_for(el))
        if uri.endswith('/diagram'):
            g = self.smartart(el, gd)
            if g is not None:
                return self.emit_grp(g, parent, xf, out, self.ref_for(el))
            parts = self.smartart_parts(gd) if self.style != 'plain' or self.extras else None
            if parts:
                self.note(el, 'SmartArt saved without its drawing: copied as it is with smartart() (python-pptx cannot '
                              'create SmartArt); PowerPoint lays it out when the deck opens')
                out.append(Call('smartart', [Raw(parent), self.image(parts, 'zip', 'smartart'), *pos], {},
                                self.ref_for(el)))
                self.used.add('smartart')
                return
            paras = self.smartart_text(gd)
            if paras:
                self.note(el, 'SmartArt saved without its drawing: its text is kept as a list in its place (python-pptx '
                              'cannot create SmartArt; open and save the deck in PowerPoint, then convert again for the '
                              'diagram itself)')
                out.append(Call('box', [Raw(parent), *pos], {'t': paras, 'wrap': True}, self.ref_for(el)))
                self.used.add('box')
                return
        ole = el.find(f'.//{{{P}}}oleObj')
        what = (f'an embedded {ole_kind(ole, self.part) + " " if ole_kind(ole, self.part) else ""}object (OLE)'
                if ole is not None else
                'an ActiveX control' if uri.endswith('/control') else f'a "{uri.rsplit("/", 1)[-1]}" object')
        fb = el.find(f'.//{{{P}}}pic')  # OLE objects and the like carry a picture fallback
        if fb is not None and fb.find(f'.//{{{A}}}blip') is not None:
            self.note(el, f'{what}: shown as its picture (python-pptx cannot create it)')
            return self.emit_pic(fb, parent, None, out, self.ref_for(el), None if self.box_of(fb) else pos)
        blob = self.vml_preview(ole.get('spid')) if ole is not None else None
        img = self.image(*blob[:2]) if blob else None
        if img is not None:
            self.note(el, f'{what}: shown as its picture (python-pptx cannot create it)')
            out.append(Call('pic', [Raw(parent), img, *pos], {}, self.ref_for(el)))
            self.used.add('pic')
            return
        if 'diagram' in uri:
            why = ('SmartArt without the drawing PowerPoint saves with it, left out (python-pptx cannot create SmartArt; '
                   'open and save the deck in PowerPoint, then convert again)')
        elif uri.endswith('/ole'):
            why = f'{what} without a preview picture, left out (python-pptx cannot create it)'
            if any('with LibreOffice' in f for f in self.fixes):
                why += '; LibreOffice dropped its picture reading the .ppt (save it as .pptx in PowerPoint to keep it)'
        else:
            why = f'a "{uri.rsplit("/", 1)[-1] or "unknown"}" object, left out (python-pptx cannot create it)'
        self.skip(el, why, out)

    def smartart(self, el, gd):
        """SmartArt as the shapes PowerPoint drew for it (saved beside the diagram data), in a group."""
        rels, ids = self.part.rels, gd[0] if len(gd) else None
        dm, rid = ids.get(f'{{{R}}}dm') if ids is not None else None, None
        if dm in rels:
            m = re.search(rb'dataModelExt[^>]*relId="([^"]+)"', self.part.related_part(dm).blob)
            rid = m.group(1).decode() if m else None
        if rid not in rels:
            return None
        drawing = self.part.related_part(rid)
        tree = copy.deepcopy(etree.fromstring(drawing.blob).find(f'{{{DSP}}}spTree'))
        if tree is None or not any(ln(c) in ('sp', 'grpSp', 'pic', 'cxnSp') for c in tree):
            return None  # no drawing saved (only PowerPoint saves one): nothing to draw from
        for blip in tree.iter(f'{{{A}}}blip'):  # pictures in the diagram: related to the slide, as its own are
            r = blip.get(f'{{{R}}}embed')
            if r in drawing.rels and not drawing.rels[r].is_external:
                blip.set(f'{{{R}}}embed', self.part.relate_to(drawing.rels[r].target_part, drawing.rels[r].reltype))
        for e in tree.iter():
            if isinstance(e.tag, str) and e.tag.startswith(f'{{{DSP}}}'):
                e.tag = f'{{{P}}}{ln(e)}'
        tree.tag = f'{{{P}}}grpSp'
        for sp in list(tree.iter(f'{{{P}}}sp')):
            tx, x, body = kid(sp, 'txXfrm', P), sp.find(f'{{{P}}}spPr/{{{A}}}xfrm'), sp.find(f'{{{P}}}txBody/{{{A}}}bodyPr')
            if tx is None or x is None or body is None:
                continue
            sp.remove(tx)
            (a, b), (c, d) = ([[int(kid(t, 'off').get(k)) for k in 'xy'], [int(kid(t, 'ext').get(k)) for k in ('cx', 'cy')]]
                              for t in (x, tx))
            ix, iy = text_inset(kid(sp, 'spPr', P), *b)  # where the shape itself puts text
            edge = {'lIns': c[0] - a[0] - ix, 'tIns': c[1] - a[1] - iy, 'rIns': a[0] + b[0] - c[0] - d[0] - ix,
                    'bIns': a[1] + b[1] - c[1] - d[1] - iy}
            if x.get('rot', '0') == tx.get('rot', '0') and min(edge.values()) > -1000:  # text inside: margins
                if max(abs(v) for v in edge.values()) < 1000:
                    continue
                for k, dv in edge.items():
                    body.set(k, str(max(0, round(int(body.get(k, 45720 if k in ('tIns', 'bIns') else 91440)) + dv))))
            else:  # text outside the shape: a text box of its own
                label = copy.deepcopy(sp)
                sp.remove(kid(sp, 'txBody', P))
                lx = label.find(f'{{{P}}}spPr/{{{A}}}xfrm')
                lx[:] = [copy.deepcopy(kid(tx, 'off')), copy.deepcopy(kid(tx, 'ext'))]
                for k in ('rot', 'flipH', 'flipV'):
                    lx.attrib.pop(k, None)
                if tx.get('rot'):
                    lx.set('rot', tx.get('rot'))
                spr = kid(label, 'spPr', P)
                spr[:] = [lx, etree.fromstring(f'<a:prstGeom xmlns:a="{A}" prst="rect"><a:avLst/></a:prstGeom>'),
                          etree.fromstring(f'<a:noFill xmlns:a="{A}"/>'),
                          etree.fromstring(f'<a:ln xmlns:a="{A}"><a:noFill/></a:ln>'),
                          etree.fromstring(f'<a:effectLst xmlns:a="{A}"/>')]
                sp.addnext(label)
        gp = kid(tree, 'grpSpPr', P)
        f = el.find(f'{{{P}}}xfrm')
        off, ext = kid(f, 'off'), kid(f, 'ext')
        gp[:] = [etree.fromstring(
            f'<a:xfrm xmlns:a="{A}"><a:off x="{off.get("x")}" y="{off.get("y")}"/><a:ext cx="{ext.get("cx")}" '
            f'cy="{ext.get("cy")}"/><a:chOff x="0" y="0"/><a:chExt cx="{ext.get("cx")}" cy="{ext.get("cy")}"/></a:xfrm>')]
        return tree

    def smartart_parts(self, gd):
        """A SmartArt's data, layout, style and colours as one .zip (for the smartart() extra); None when they are
        not all there or bring files of their own (pictures)."""
        import zipfile
        ids = gd[0] if len(gd) else None
        parts = {}
        for key, kind in (('dm', 'data'), ('lo', 'layout'), ('qs', 'quickStyle'), ('cs', 'colors')):
            rid = ids.get(f'{{{R}}}{key}') if ids is not None else None
            if rid not in self.part.rels:
                return None
            part = self.part.related_part(rid)
            if len(part.rels):
                return None
            parts[kind] = part.blob
        # the data's pointer to a saved drawing (there is none)
        parts['data'] = re.sub(rb'<(\w+:)?ext uri="http://schemas\.microsoft\.com/office/drawing/2008/diagram">'
                               rb'[\s\S]*?</(\w+:)?ext>', b'', parts['data'])
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
            for kind, blob in parts.items():
                z.writestr(zipfile.ZipInfo(f'{kind}.xml', (2000, 1, 1, 0, 0, 0)), blob, zipfile.ZIP_DEFLATED)
        return buf.getvalue()

    def smartart_text(self, gd):
        """The text of a SmartArt diagram as list paragraphs (level by depth), from its data model."""
        ids = gd[0] if len(gd) else None
        dm = ids.get(f'{{{R}}}dm') if ids is not None else None
        if dm not in self.part.rels:
            return None
        root = etree.fromstring(self.part.related_part(dm).blob)
        g = '{http://schemas.openxmlformats.org/drawingml/2006/diagram}'
        pts = {p.get('modelId'): p for p in root.iter(f'{g}pt')}
        kids = {}
        for c in root.iter(f'{g}cxn'):
            if c.get('type', 'parOf') == 'parOf':
                kids.setdefault(c.get('srcId'), []).append((int(c.get('srcOrd', 0)), c.get('destId')))
        doc = next((k for k, p in pts.items() if p.get('type') == 'doc'), None)
        paras, seen = [], set()

        def visit(mid, depth):
            for _, k in sorted(kids.get(mid, ())):
                p = pts.get(k)
                if p is None or k in seen or p.get('type', 'node') not in ('node', 'asst'):
                    continue
                seen.add(k)
                t = p.find(f'{g}t')
                text = '\v'.join(''.join(x.text or '' for x in q.iter(f'{{{A}}}t')) for q in t.findall(f'{{{A}}}p')) \
                    if t is not None else ''
                if text.strip():
                    paras.append({'t': text, 'lvl': depth} if depth else text)
                visit(k, depth + 1)
        visit(doc, 0)
        return paras or None

    def vml_preview(self, spid):
        """(blob, ext, (x, y, w, h) inches or None) of the preview image a legacy (VML) OLE object or ActiveX
        control shows."""
        if spid and spid.isdigit():
            spid = f'_x0000_s{spid}'
        for rel in self.part.rels.values():
            if rel.reltype.endswith('/vmlDrawing') and spid:
                vml = rel.target_part
                text = vml.blob.decode('utf-8', 'ignore')
                m = re.search(r'<v:shape[^>]*(?:o:spid|id)="%s".*?</v:shape>' % re.escape(spid), text, re.S)
                rid = re.search(r'o:relid="([^"]+)"', m.group(0)) if m else None
                if rid and rid.group(1) in vml.rels:
                    img = vml.related_part(rid.group(1))
                    st = dict(re.findall(r'(left|top|width|height):([-\d.]+)pt', m.group(0)))
                    box = tuple(num(float(st[k]) / 72, 3) for k in ('left', 'top', 'width', 'height')) \
                        if len(st) == 4 else None
                    return img.blob, img.partname.ext or 'png', box
        return None

    @staticmethod
    def label(el):
        """A shape's name for messages ('' for the slide itself)."""
        if el is None or ln(el) in ('sld', 'sldLayout', 'sldMaster'):
            return ''
        nv = el.find(f'.//{{{P}}}cNvPr')
        return (nv.get('name') or f'shape {nv.get("id")}') if nv is not None else ln(el)

    def skip(self, el, why, out=None):
        """Left out: said in the script header, where the shape was, and in the app."""
        label = self.label(el)
        self.skipped.append(f'slide {self.n}: {label}: {why}' if label else f'slide {self.n}: {why}')
        if out is not None:
            out.append(f'# left out{" " + repr(label) if label else ""}: {why}')

    # tables ----------------------------------------------------------------
    def emit_table(self, el, gd, pos, out, ref=None, xf=None):
        tbl = gd.find(f'{{{A}}}tbl')
        sx, sy = (xf[2], xf[3]) if xf else (1, 1)  # a table in a scaled group
        grid = [inch(int(g.get('w')) * sx) for g in tbl.findall(f'{{{A}}}tblGrid/{{{A}}}gridCol')]
        rows_el = tbl.findall(f'{{{A}}}tr')
        rh = [inch(int(r.get('h')) * sy) for r in rows_el]
        rows, styles, merge = [], {}, []
        for r, tr in enumerate(rows_el):
            row = []
            for c, tc in enumerate(tr.findall(f'{{{A}}}tc')):
                st = {}
                tcpr = kid(tc, 'tcPr')
                f = fill_spec(tcpr, self.th)
                if f is not None and not isinstance(f, tuple):
                    st['fill'] = f
                if tcpr is not None:
                    if tcpr.get('anchor') in ANCHOR:
                        st['anchor'] = ANCHOR[tcpr.get('anchor')]
                    if tcpr.get('vert') not in (None, 'horz'):
                        st['vert'] = tcpr.get('vert')
                    mar = [tcpr.get(a) for a in ('marL', 'marT', 'marR', 'marB')]
                    if any(m is not None for m in mar):
                        st['m'] = tuple(inch(m if m is not None else d) for m, d in
                                        zip(mar, (91440, 45720, 91440, 45720)))
                    bd = []
                    for sd in 'LRTB':
                        b = kid(tcpr, f'ln{sd}')
                        if b is None:
                            continue
                        fl = fill_spec(b, self.th)
                        w = num(int(b.get('w', '12700')) / 12700)
                        bd.append((sd, 0) if fl == '' or fl is None or w == 0 else (sd, w, fl if isinstance(fl, str)
                                                                                     else fl[2][0]))
                    if bd:
                        merged = {}
                        for b in bd:
                            merged.setdefault(b[1:], '')
                            merged[b[1:]] += b[0]
                        st['bd'] = tuple((sides, *spec) for spec, sides in merged.items())
                if (int(tc.get('gridSpan', '1')) > 1 or int(tc.get('rowSpan', '1')) > 1) and \
                        tc.get('hMerge') not in ('1', 'true') and tc.get('vMerge') not in ('1', 'true'):
                    merge.append((r, c, min(r + int(tc.get('rowSpan', '1')), len(rows_el)) - 1,
                                  min(c + int(tc.get('gridSpan', '1')), len(grid)) - 1))
                tb = kid(tc, 'txBody')
                txt = ''
                if tb is not None and not (tc.get('hMerge') or tc.get('vMerge')):
                    paras = read_paras(tb, self.th, self.rels)
                    if not is_text_empty(paras):
                        common, txt = factor(paras)
                        st.update(common)
                    elif paras and paras[0][0].get('sz'):  # an empty cell keeps the height of its empty line
                        txt = [{'t': '', 'sz': paras[0][0]['sz']}]
                row.append(txt)
                styles[(r, c)] = st
            row = row[:len(grid)] + [''] * (len(grid) - len(row))  # rows with a cell too few or too many
            for c in range(len(grid)):
                styles.setdefault((r, c), {})
            rows.append(row)
        styles = {k: v for k, v in styles.items() if k[1] < len(grid)}
        kw = {'cs': factor_cells(styles, len(rows), len(grid)) or None, 'merge': merge or None}
        tp = kid(tbl, 'tblPr')
        sid = kid(tp, 'tableStyleId')
        if sid is not None and sid.text and sid.text.strip() != '{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}':
            kw['style'] = sid.text.strip()
        elif sid is None or not (sid.text or '').strip():
            kw['style'] = '{2D5ABB26-0587-4C30-8999-92F81FD0307C}'  # no style: plain cells, as the original
        flags = ' '.join(a for a in ('firstRow', 'firstCol', 'lastRow', 'lastCol', 'bandRow', 'bandCol')
                         if tp is not None and tp.get(a) in ('1', 'true'))
        if flags != 'firstRow bandRow':
            kw['flags'] = flags
        out.append(Call('tbl', [Raw('s'), *pos, rows, grid, rh], kw, ref))
        self.used.add('tbl')

    # charts ----------------------------------------------------------------
    def emit_chart(self, el, parent, pos, out, ref=None):
        from .charts import read_chart
        try:
            kind, cats, series, opts, notes = read_chart(self.part, el, self.th)
        except Exception as exc:  # noqa: BLE001
            return self.skip(el, f'a chart that could not be read, left out ({type(exc).__name__}: {exc})', out)
        if kind is None:
            return self.skip(el, notes[0] if notes else 'a chart type python-pptx cannot create', out)
        if opts.get('d3') and self.style == 'plain' and not self.extras:  # 3-D needs the chart_3d() extra
            notes.append(f'a 3-D {kind.replace("_", " ").lower()} chart, drawn flat (python-pptx makes flat charts '
                         'only)')
        for x in notes:
            self.note(el, x)
        out.append(Call('chart', [Raw(parent), kind, *pos, cats, series], opts, ref))
        self.used.add('chart')

    # slides ----------------------------------------------------------------
    def walk(self, tree, parent, xf, out):
        for el in tree:
            n = ln(el)
            top = parent == 's' and xf is None and n != 'AlternateContent'
            at, kept, seen = len(out), len(self.keep), len(self.zseq)
            nv = el.find(f'.//{{{P}}}cNvPr') if n in ('sp', 'pic', 'cxnSp', 'grpSp', 'graphicFrame') else None
            if nv is not None and nv.get('hidden') in ('1', 'true'):  # hidden (Selection Pane): kept, and hidden
                if self.style == 'plain' and not self.extras:
                    self.skip(el, 'a hidden shape, left out (python-pptx cannot hide shapes)', out)
                    continue
                self.refs.add(nv.get('id'))
                self.emit(el, n, parent, xf, out)
                var = self.ref_vars.get(nv.get('id'))
                if var:
                    out.append(Call('hide', [Raw(var)], {}))
                    self.used.add('hide')
            else:
                self.emit(el, n, parent, xf, out)
            if not top or len(self.zseq) > seen:  # inside a group, or already noted shape by shape
                continue
            if len(self.keep) > kept:  # a layout placeholder, filled where python-pptx made it
                call = next((c for c in out[at:] if isinstance(c, Call) and c.fn == 'ph'), None)
                self.zseq.append(('ph', self.keep[-1], at, call, el))
            elif any(not isinstance(c, str) for c in out[at:]):  # a new shape, added on top of the others
                self.zseq.append(('new', None, at, None, el))

    def restack(self, slide, body):
        """python-pptx makes a slide's layout placeholders first, under every shape added later: a placeholder that
        the original has above other shapes is brought to the front where it comes in the slide's order."""
        keep = set(self.keep)
        now = [('ph', p.placeholder_format.idx) for p in slide.slide_layout.iter_cloneable_placeholders()
               if p.placeholder_format.idx in keep]
        done, moves = [], []
        for kind, idx, at, call, el in self.zseq:
            item = (kind, idx) if kind == 'ph' else ('new', len(done))
            if kind == 'ph' and (now[:len(done)] != done or len(now) <= len(done) or now[len(done)] != item):
                now.remove(item)
                now.append(item)
                moves.append((at, idx, call, el))
            elif kind != 'ph':
                now.append(item)
            done.append(item)
        for at, idx, call, el in sorted(moves, key=lambda m: -m[0]):
            if self.style == 'plain' and not self.extras:
                self.note(el, 'drawn under shapes it is above in the original (python-pptx makes placeholders first '
                              'and cannot change the stacking order)')
            elif call is not None:
                call.kw['front'] = True
            else:
                body.insert(at, Call('ph', [Raw('s'), idx], {'front': True}))
                self.used.add('ph')

    def emit(self, el, n, parent, xf, out):
        if n == 'sp':
            self.emit_sp(el, parent, xf, out)
        elif n == 'pic':
            self.emit_pic(el, parent, xf, out)
        elif n == 'cxnSp':
            self.emit_cxn(el, parent, xf, out)
        elif n == 'grpSp':
            self.emit_grp(el, parent, xf, out)
        elif n == 'graphicFrame':
            self.emit_frame(el, parent, xf, out)
        elif n == 'AlternateContent':
            alt = choose_alt(el)
            if alt is not None:
                if alt.get('_fallback'):
                    self.note(el, alt.get('_fallback') + ': python-pptx cannot create it, so the picture PowerPoint saved '
                                       'with it is used')
                self.walk(alt, parent, xf, out)
        elif n == 'contentPart':
            self.skip(el, 'ink (a pen drawing), left out (python-pptx cannot create ink)', out)

    def background(self, slide, out):
        owners = [slide] if self.template else [slide, slide.slide_layout, slide.slide_layout.slide_master]
        for owner in owners:
            bgel = owner._element.find(f'{{{P}}}cSld/{{{P}}}bg')
            if bgel is None:
                continue
            pr, ref = kid(bgel, 'bgPr', P), kid(bgel, 'bgRef', P)
            f = fill_spec(pr, self.th) if pr is not None else fill_spec(None, self.th, ref)
            if isinstance(f, tuple):
                master = owner if not hasattr(owner, 'slide_master') else owner.slide_master
                rels = owner.part.rels if pr is not None else next(  # a theme background style: the theme's picture
                    (r.target_part.rels for r in master.part.rels.values() if r.reltype.endswith('/theme')), {})
                if f[1] not in rels:
                    return
                part = rels[f[1]].target_part
                img = self.image(part.blob, part.partname.ext or 'png')
                if img is not None:
                    out.append(Call('bg', [Raw('s')], {'img': img, 'tile': True if f[2] else None,
                                                       'pfx': f[3] or None}))
            elif f is not None:
                out.append(Call('bg', [Raw('s'), f], {}))
            self.used.add('bg')
            return

    def layout_ref(self, slide):
        lay = slide.slide_layout
        masters = list(self.prs.slide_masters)
        for mi, m in enumerate(masters):
            lays = list(m.slide_layouts)
            for li, l_ in enumerate(lays):
                if l_ is lay or l_.part is lay.part:
                    names = [x.name for mm in masters for x in mm.slide_layouts]
                    if lay.name and names.count(lay.name) == 1:
                        return lay.name
                    return li if mi == 0 else (mi, li)
        return 0

    def slide_code(self, n, slide):
        self.n, self.slide, self.part = n, slide, slide.part
        master = slide.slide_layout.slide_master
        ovr = None if self.template else next((o.attrib for o in (  # a slide / layout colour map override
            x._element.find(f'{{{P}}}clrMapOvr/{{{A}}}overrideClrMapping') for x in (slide, slide.slide_layout))
            if o is not None), None)
        key = (id(master.part), tuple(sorted(ovr.items())) if ovr else ())
        if key not in self.themes:
            th = Theme(master)
            th.map.update(ovr or {})
            th.hexify = not self.template and ((th.colors, th.fonts, th.map) != (self.base.colors, self.base.fonts,
                                                                                 self.base.map) or
                                               self.style == 'plain' and not self.extras)  # no theme to point at
            th.remapped = not self.template and any(th.map.get(k) != v for k, v in SCHEME.items())
            self.themes[key] = th
        self.th = self.themes[key]
        self.rels = {r.rId: r.target_ref for r in slide.part.rels.values() if r.is_external}
        self.keep, self.ngroup = [], 0
        self.layout_ph = {p.placeholder_format.idx for p in slide.slide_layout.iter_cloneable_placeholders()} \
            if self.template else set()
        self.layout_types = {p.placeholder_format.idx: p._element.find(f'.//{{{P}}}ph').get('type', 'obj')
                             for p in slide.slide_layout.placeholders}
        body = []
        sld = slide._element
        self.trans = read_transition(sld) if self.motion else None
        self.timing = read_timing(sld) if self.motion else None
        self.refs, self.ref_vars = set(), {}
        for seq in (self.timing or {}).get('seqs', ()):
            self.refs |= {e['target']['spid'] for e in seq['effects']} | ({seq['trigger']} if seq['trigger'] else set())
        self.glue = []
        for cx in sld.iter(f'{{{P}}}cxnSp'):  # connectors glued to shapes: both get a variable
            nvc = cx.find(f'{{{P}}}nvCxnSpPr/{{{P}}}cNvCxnSpPr')
            ids = {e.get('id') for e in (kid(nvc, 'stCxn'), kid(nvc, 'endCxn')) if e is not None} if nvc is not None else ()
            if ids:
                self.refs |= ids | {cx.find(f'.//{{{P}}}cNvPr').get('id')}
        self.zseq = []  # top-level shapes in the order they are made (placeholders: where python-pptx made them)
        self.background(slide, body)
        if not self.template and slide._element.get('showMasterSp') not in ('0', 'false'):
            fn = self.layout_graphics(slide)
            if fn:
                body.append(f'{fn}(s)')
        self.walk(slide.shapes._spTree, 's', None, body)
        if self.template:
            self.restack(slide, body)
        self.glue_code(body)
        self.motion_code(body)
        ncm = sum(len(re.findall(rb'<(?:\w+:)?cm\b', r.target_part.blob)) for r in slide.part.rels.values()
                  if r.reltype.endswith('/comments') and not r.is_external)
        if ncm:
            self.skip(sld, f'{ncm} comment{"s" if ncm > 1 else ""}, left out (python-pptx cannot add comments)')
        for ctl in sld.find(f'{{{P}}}cSld').iterfind(f'.//{{{P}}}controls/{{{P}}}control'):  # legacy controls
            prev = self.vml_preview(ctl.get('spid'))
            img = self.image(*prev[:2]) if prev and prev[2] else None
            what = f'ActiveX control {ctl.get("name", "")!r}'
            if img is None:
                self.skip(sld, f'{what}, left out (python-pptx cannot create controls)', body)
                continue
            self.note(sld, f'{what}: shown as its picture (python-pptx cannot create controls)')
            body.append(Call('pic', [Raw('s'), img, *prev[2]], {}))
            self.used.add('pic')
        flags = {'hidden': True if slide._element.get('show') in ('0', 'false') else None,
                 'graphics': False if slide._element.get('showMasterSp') in ('0', 'false') and self.template else None}
        if self.template:
            kw = {'keep': sorted(set(self.keep))} if set(self.keep) != self.layout_ph else {}
            head = Call('add', [Raw('prs'), self.layout_ref(slide)], {**kw, **flags})
        else:
            head = Call('add', [Raw('prs'), 6], flags)
        self.used.add('add')
        if self.notes and slide.has_notes_slide:
            t = slide.notes_slide.notes_text_frame.text if slide.notes_slide.notes_text_frame else ''
            if t.strip():
                body.append(Call('notes', [Raw('s'), t.strip()], {}))
                self.used.add('notes')
        return n, head, body

    def glue_code(self, body):
        """Connectors stay attached to their shapes: begin_connect() when python-pptx's connection point is where
        the line already ends (top, left, bottom, right middle of a straight box), else glue()."""
        top = {c.find(f'.//{{{P}}}cNvPr').get('id'): c for c in self.slide.shapes._spTree
               if c.find(f'.//{{{P}}}cNvPr') is not None}
        for el, ends in self.glue:
            var = self.ref_vars.get(el.find(f'.//{{{P}}}cNvPr').get('id'))
            nvc = el.find(f'{{{P}}}nvCxnSpPr/{{{P}}}cNvCxnSpPr')
            kw, api = {}, []
            for end, tag, (px, py) in (('begin', 'stCxn', ends[:2]), ('end', 'endCxn', ends[2:])):
                e = kid(nvc, tag)
                tv = self.ref_vars.get(e.get('id')) if e is not None else None
                if tv is None:
                    continue
                idx = int(e.get('idx', 0))
                kw[end] = (Raw(tv), idx)
                t = top.get(e.get('id'))
                pos = self.box_of(t) if t is not None and ln(t) != 'grpSp' else None
                if pos and idx <= 3 and not self.rot_flip(t).get('rot'):
                    x, y, w, h = pos
                    cx, cy = ((x + w / 2, y), (x, y + h / 2), (x + w / 2, y + h), (x + w, y + h / 2))[idx]
                    if abs(cx - px) < 0.01 and abs(cy - py) < 0.01:
                        api.append(end)
            if var and kw:
                c = Call('glue', [Raw(var)], kw)
                c.api = tuple(api)
                body.append(c)
                self.used.add('glue')

    def link(self, el, kw):
        """A web link or a jump on clicking the shape."""
        h = el.find(f'.//{{{P}}}cNvPr/{{{A}}}hlinkClick')
        if h is None:
            return
        rid, action = h.get(f'{{{R}}}id'), h.get('action') or ''
        if kid(h, 'snd') is not None:
            self.note(el, 'the sound its click plays, left out (python-pptx cannot add sounds)')
        if rid and rid in self.rels:
            kw['link'] = self.rels[rid]
        elif action == 'ppaction://hlinksldjump' and rid in self.part.rels:
            target = self.part.rels[rid].target_part
            n = next((i for i, s in enumerate(self.prs.slides, 1) if s.part is target), None)
            if n in self.wanted:
                kw['goto'] = self.wanted.index(n) + 1  # its number in the rebuilt deck
                self.used.add('links')
            else:
                self.note(el, f'its click jump to slide {n} left out (that slide is not converted)')
        elif action.startswith('ppaction://hlinkshowjump?jump='):
            kw['jump'] = action.split('=', 1)[1]
        elif action in ('ppaction://media', 'ppaction://noaction'):
            pass  # play the video on click (add_movie() does that), or nothing at all
        elif action:
            what = action.replace('ppaction://', '').split('?')[0]
            what = {'macro': 'runs a macro', 'program': 'starts a program', 'ole': 'opens an embedded object',
                    'customshow': 'starts a custom show', 'hlinkfile': 'opens a file'}.get(what, f'does "{what}"')
            self.note(el, f'its click {what}; left out (python-pptx sets only links and jumps to slides)')

    def note(self, el, why):
        """Converted, but not exactly: said in the script header and the app."""
        label = self.label(el)
        self.approx.append(f'slide {self.n}: {label}: {why}' if label else f'slide {self.n}: {why}')

    def ref_for(self, el):
        """The variable name for a shape that animations or connectors refer to (else None)."""
        c = el.find(f'.//{{{P}}}cNvPr')
        spid = c.get('id') if c is not None else None
        if spid in self.refs:
            self.ref_vars[spid] = f'a{spid}'
            return f'a{spid}'
        return None

    def motion_code(self, body):
        """Slide transition and animations, as transition(s, ...) and animate(s, [...])."""
        tr = self.trans
        if tr and (tr['kind'] != 'none' or tr.get('after') is not None or tr.get('click') is False or 'dur' in tr):
            kw = dict(tr.get('opts', {}))
            kw.update({'speed': tr.get('speed'), 'duration': num(tr['dur'] / 1000, 3) if 'dur' in tr else None,
                       'click': False if tr.get('click') is False else None,
                       'after': num(tr['after'] / 1000, 3) if 'after' in tr else None})
            body.append(Call('transition', [Raw('s'), tr['kind']], kw))
            self.used.add('transition')
            if tr.get('sound'):
                self.skip(self.slide._element, 'the sound of the slide transition, left out (python-pptx cannot add sounds)')
        tm = self.timing
        if not tm:
            return
        for note in dict.fromkeys(tm['notes']):
            if 'playback settings' in note:
                if 'movie' in self.used:
                    self.note(self.slide._element, note)
            else:
                self.skip(self.slide._element, f'{note}, left out of the animations')
        effects, lost = [], 0
        for seq in tm['seqs']:
            trig = self.ref_vars.get(seq['trigger']) if seq['trigger'] else None
            if seq['trigger'] and not trig:
                lost += len(seq['effects'])
                continue
            for e in seq['effects']:
                var = self.ref_vars.get(e['target']['spid'])
                if not var:
                    lost += 1
                    continue
                d = {'shape': Raw(var)}
                if trig:
                    d['on'] = Raw(trig)
                d.update({('type' if k == 'class' else k): v for k, v in e.items() if k not in ('target',)})
                for k in ('paras', 'chars'):
                    if k in e['target']:
                        d[k] = e['target'][k]
                d['do'] = [{k: v for k, v in st.items() if not (('set' in st) and ((k == 'dur' and v == 1) or
                                                                                  (k == 'fill' and v == 'hold')))}
                           for st in e['do']]
                effects.append(d)
        if lost:
            self.skip(self.slide._element, f'{lost} animation effect{"s" if lost > 1 else ""} on shapes that were left '
                                           'out, left out too')
        builds = [{'shape': Raw(self.ref_vars[b['spid']]), **{k: v for k, v in b.items() if k != 'spid'}}
                  for b in tm['builds'] if b['spid'] in self.ref_vars]
        if effects:
            body.append(Call('animate', [Raw('s'), effects], {'builds': builds or None}))
            self.used.add('animate')

    def layout_graphics(self, slide):
        """Blank-template mode: the master's and the layout's own shapes (logos, bars ...), one function per layout."""
        lay = slide.slide_layout
        key = id(lay.part)
        if key not in self.layout_funcs:
            saved = self.part, self.rels
            out = []
            master_hidden = lay._element.get('showMasterSp') in ('0', 'false')
            for owner in ([] if master_hidden else [lay.slide_master]) + [lay]:
                self.part = owner.part
                self.rels = {r.rId: r.target_ref for r in owner.part.rels.values() if r.is_external}
                shapes = [el for el in owner.shapes._spTree if ln(el) in ('sp', 'pic', 'cxnSp', 'grpSp', 'graphicFrame')
                          and el.find(f'./*/{{{P}}}nvPr/{{{P}}}ph') is None]
                self.walk(shapes, 's', None, out)
            self.part, self.rels = saved
            self.layout_funcs[key] = (f'layout{len(self.layout_funcs) + 1}', out)
        name, out = self.layout_funcs[key]
        return name if out else None

    def own_levels(self, el):
        """Paragraph and run defaults from a shape's own list style (blank-template mode: on top of the deck's
        default text style, where it differs from python-pptx's)."""
        lst = kid(kid(el, 'txBody', P), 'lstStyle')
        base = {} if self.template else self.default_levels()
        if (lst is None or not len(lst)) and not base:
            return None
        levels = {}
        for lv in range(9):
            lp = kid(lst, f'lvl{lv + 1}pPr')
            d = {**ppr_props(lp, self.th), **rpr_props(kid(lp, 'defRPr'), self.th)} if lp is not None else {}
            d.pop('lvl', None)
            levels[lv] = {**base.get(lv, {}), **d}
        return {'levels': levels}

    def default_levels(self):
        if not hasattr(self, '_defaults'):
            def read(prs, th):
                st = prs.part._element.find(f'{{{P}}}defaultTextStyle')
                out = {}
                for lv in range(9):
                    lp = kid(st, f'lvl{lv + 1}pPr') if st is not None else None
                    d = {**ppr_props(lp, th), **rpr_props(kid(lp, 'defRPr'), th)} if lp is not None else {}
                    d.pop('lvl', None)
                    out[lv] = d
                return out
            blank = Presentation()
            mine, theirs = read(self.prs, self.base), read(blank, Theme(blank.slide_masters[0]))
            self._defaults = {lv: {k: v for k, v in mine[lv].items() if theirs[lv].get(k) != v and k != 'ml'}
                              for lv in mine}
            self._defaults = {lv: d for lv, d in self._defaults.items() if d}
        return self._defaults

    # what a placeholder inherits from its layout and master ------------------------------------------------
    def inherited_levels(self, el):
        phel = el.find(f'.//{{{P}}}ph')
        typ, idx = phel.get('type', 'body'), phel.get('idx', '0')
        lay = self.slide.slide_layout
        master = lay.slide_master
        chain, frames = [], []
        style = {'title': 'titleStyle', 'ctrTitle': 'titleStyle', 'body': 'bodyStyle', 'subTitle': 'bodyStyle',
                 'obj': 'bodyStyle'}.get(typ, 'otherStyle')
        tx = master._element.find(f'{{{P}}}txStyles/{{{P}}}{style}')
        if tx is not None:
            chain.append(tx)
        for owner in (master, lay):
            for sp in owner.shapes._spTree.iter(f'{{{P}}}sp'):
                p2 = sp.find(f'.//{{{P}}}ph')
                if p2 is None:
                    continue
                t2 = p2.get('type', 'body')
                same = t2 == typ or ({t2, typ} <= {'title', 'ctrTitle'}) or (owner is lay and p2.get('idx') == idx)
                if same:
                    tb = kid(sp, 'txBody', P)
                    if tb is not None and kid(tb, 'lstStyle') is not None:
                        chain.append(kid(tb, 'lstStyle'))
                    if tb is not None:
                        frames.append(body_props(kid(tb, 'bodyPr')))
                    break
        own = kid(kid(el, 'txBody', P), 'lstStyle')
        if own is not None:
            chain.append(own)
        levels = {}
        for lv in range(9):
            d = {}
            for st in chain:
                lp = kid(st, f'lvl{lv + 1}pPr')
                if lp is None:
                    continue
                d.update(ppr_props(lp, self.th))
                d.update(rpr_props(kid(lp, 'defRPr'), self.th))
            d.pop('lvl', None)
            levels[lv] = d
        fr = {}
        for f in frames:
            fr.update(f)
        return {'levels': levels, 'frame': fr}

    # assembling ----------------------------------------------------------------
    def run(self, slides=None):
        all_slides = list(self.prs.slides)
        wanted = [n for n in (slides or range(1, len(all_slides) + 1)) if 1 <= n <= len(all_slides)]
        self.wanted = wanted
        root = self.prs.part._element
        sect = root.find(f'.//{{{P14}}}sectionLst')
        if sect is not None and len(sect):
            self.approx.append(f'deck: {len(sect)} sections, left out (python-pptx cannot create sections; the slides '
                               'are all there, in order)')
        if root.find(f'{{{P}}}custShowLst') is not None:
            self.approx.append('deck: custom slide shows, left out (python-pptx cannot create them)')
        if not self.template and root.find(f'{{{P}}}embeddedFontLst') is not None:
            self.approx.append('deck: embedded fonts, left out with the template (they stay when you build on the '
                               'deck template)')
        blocks = []
        for n in wanted:
            try:
                blocks.append(self.slide_code(n, all_slides[n - 1]))
            except Exception as exc:  # noqa: BLE001  (a damaged slide: an empty one in its place)
                self.n = n
                self.skipped.append(f'slide {n}: the whole slide could not be read ({type(exc).__name__}: {exc}); '
                                    'an empty slide stands in for it')
                blocks.append((n, Call('add', [Raw('prs'), 6 if not self.template else 0], {}),
                               [f'# slide {n} could not be read, see the list at the top']))
        files = {}
        tname = f'{self.name}_template.pptx'
        if self.template:
            tpl = make_template(self.data)
            if self.embed:
                files['__template__'] = tpl
            else:
                files[tname] = tpl
        for name, blob in self.images.values():
            files[f'assets/{name}'] = blob
        if self.style == 'plain':
            from .plain import assemble as plain_code
            code = plain_code(self, blocks, wanted, tname, files)
        else:
            code = assemble(self, blocks, wanted, tname, files)
        if self.embed:
            files = {}
        return Result(code=code, files=files, slides=wanted, skipped=self.skipped, notes=self.approx)


def factor_cells(styles, nr, nc):
    """Cell styles shared by the whole table ('*'), a row ('r0') or a column ('c1'); the rest per cell."""
    keys = {k for st in styles.values() for k in st}
    out = {}

    def put(key, k, v):
        out.setdefault(key, {})[k] = v

    for k in sorted(keys):
        val = {rc: styles[rc].get(k) for rc in styles}
        eff = {}
        allv = [v for v in val.values()]
        if all(v is not None for v in allv):
            best = max(allv, key=lambda v: allv.count(repr(v)) if False else sum(1 for x in allv if x == v))
            if sum(1 for x in allv if x == best) * 2 >= len(allv):
                put('*', k, best)
                eff = {rc: best for rc in val}
        for r in range(nr):
            vs = [val.get((r, c)) for c in range(nc) if (r, c) in val]
            if vs and all(v is not None and v == vs[0] for v in vs) and any(eff.get((r, c)) != vs[0] for c in range(nc)):
                put(f'r{r}', k, vs[0])
                eff.update({(r, c): vs[0] for c in range(nc)})
        for c in range(nc):
            vs = [val.get((r, c)) for r in range(nr) if (r, c) in val]
            if len(vs) > 1 and all(v is not None and v == vs[0] for v in vs) and \
                    any(eff.get((r, c)) != vs[0] for r in range(nr)):
                put(f'c{c}', k, vs[0])
                eff.update({(r, c): vs[0] for r in range(nr)})
        for rc, v in val.items():
            if v is not None and eff.get(rc) != v:
                put(rc, k, v)
    return out


# ── the template and the script ──────────────────────────────────────────────
SUPPORTED_ALT = {'p14', 'p15', 'p159', 'v', 'o', 'w', 'wp14', 'p188'}
ALT_WHY = {'a14': 'an equation or Office 2010 text feature', 'cx1': 'an Office 2016 chart (waterfall, funnel, treemap ...)',
           'cx2': 'an Office 2016 chart', 'cx4': 'an Office 2016 chart', 'aink': 'ink', 'am3d': 'a 3D model',
           'psez': 'a zoom link'}


def choose_alt(el):
    """mc:AlternateContent: the Choice when it needs nothing pptx2py lacks, else the Fallback (marked)."""
    choice = next((c for c in el if ln(c) == 'Choice'), None)
    fallback = next((c for c in el if ln(c) == 'Fallback'), None)
    need = set((choice.get('Requires') or '').split()) if choice is not None else set()
    if choice is not None and need <= SUPPORTED_ALT:
        return choice
    if fallback is not None:
        why = next((ALT_WHY[n] for n in need if n in ALT_WHY), 'content that needs ' + ', '.join(sorted(need)))
        fallback.set('_fallback', why)
        return fallback
    return choice


LINE_PRESETS = {'line', 'lineInv', 'straightConnector1', *(f'{k}Connector{n}' for k in ('bent', 'curved') for n in range(2, 6))}


def line_ends(pos, rf):
    """Where a line starts and ends on the slide: its box, flipped, then turned about the box centre."""
    x, y, w, h = pos
    flip = rf.get('flip', '')
    x1, x2 = (x + w, x) if 'h' in flip else (x, x + w)
    y1, y2 = (y + h, y) if 'v' in flip else (y, y + h)
    r = math.radians(rf.get('rot', 0))
    if r:
        cx, cy = x + w / 2, y + h / 2
        x1, y1, x2, y2 = (cx + (px - cx) * math.cos(r) - (py - cy) * math.sin(r) if i == 0 else
                          cy + (px - cx) * math.sin(r) + (py - cy) * math.cos(r)
                          for px, py in ((x1, y1), (x2, y2)) for i in (0, 1))
    return tuple(num(v, 3) for v in (x1, y1, x2, y2))


def make_template(data):
    """The deck without its slides: masters, layouts, theme and fonts for the script to build on."""
    prs = Presentation(io.BytesIO(data))
    lst = prs.slides._sldIdLst
    for sid in list(lst):
        prs.part.drop_rel(sid.rId)
        lst.remove(sid)
    root = prs.part._element
    for ext in root.findall(f'{{{P}}}extLst'):  # sections and custom shows name the old slides
        root.remove(ext)
    for cs in root.findall(f'{{{P}}}custShowLst'):
        root.remove(cs)
    out = io.BytesIO()
    prs.save(out)
    return out.getvalue()


HELPERS_MISSING = 'pptx_helpers.py must be in the same folder as this script (pptx2py saves it there).'
# the folder of a script (its template and pictures are there); the current folder when run without a file (notebooks)
SCRIPT_HERE = "HERE = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()"
# python deck.py [out.pptx]; other arguments (an IDE's or notebook's) are ignored; says where the deck went
SCRIPT_MAIN = ['', '', "if __name__ == '__main__':",
               "    out = build(*[a for a in sys.argv[1:] if a.lower().endswith('.pptx')][:1])",
               "    print('Saved', os.path.abspath(out))"]


def report_lines(cv, width=118):
    """The script's list of what was left out, and of what is drawn another way."""
    import textwrap
    out = []
    for title, items in (('Left out (python-pptx cannot create these):', cv.skipped),
                         ('Converted, but not exactly like the original:',
                          [n for n in cv.approx if not n.startswith('all slides: ')])):
        if items:
            out.append('# ' + title)
            for s in items:
                out += textwrap.wrap(s, width, initial_indent='#   ', subsequent_indent='#       ')
    return out


def _runtime():
    src = RUNTIME.read_text(encoding='utf-8')
    tree = ast.parse(src)
    defs, imports = {}, {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.Assign)):
            name = node.name if isinstance(node, ast.FunctionDef) else node.targets[0].id
            defs[name] = ast.get_source_segment(src, node)
        elif isinstance(node, ast.ImportFrom):
            for a in node.names:
                imports[a.asname or a.name] = (node.module, a.name, a.asname)
        elif isinstance(node, ast.Import):
            for a in node.names:
                imports[a.asname or a.name] = (None, a.name, a.asname)
    return defs, imports


def _deps(code):
    """Global names a function (or assignment) reads: its own arguments and local variables left out."""
    tree = ast.parse(code)
    local = {a.arg for n in ast.walk(tree) if isinstance(n, ast.arguments)
             for a in n.args + n.kwonlyargs + n.posonlyargs + [x for x in (n.vararg, n.kwarg) if x]}
    local |= {n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)}
    top = tree.body[0]
    if isinstance(top, ast.Assign):  # a module constant: its own name is not a dependency
        local |= {t.id for t in top.targets if isinstance(t, ast.Name)}
    return {n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)} - local


def _names(code):
    return {n.id for n in ast.walk(ast.parse(code)) if isinstance(n, ast.Name)} | \
        {n.value.id for n in ast.walk(ast.parse(code)) if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name)}


STYLED = ('box', 'ph', 'pic', 'con')
NOT_STYLE = ('t', 'pos', 'crop', 'rot', 'flip', 'link', 'goto', 'jump')


def factor_styles(calls, min_gain=60):
    """Formatting shared by several shapes becomes a dict (ST1 = dict(...)) passed as **ST1; styles can extend
    each other (ST4 = dict(ST1, sz=14))."""
    items = {id(c): frozenset((k, repr(v)) for k, v in c.kw.items() if k not in NOT_STYLE) for c in calls
             if c.fn in STYLED}
    styles = []
    while True:
        groups = {}
        for c in calls:
            if c.fn in STYLED and len(items[id(c)]) >= 2:
                groups.setdefault(c.style, []).append(c)
        best, gain = None, min_gain
        for base, members in groups.items():
            uniq = {}
            for c in members:
                uniq.setdefault(items[id(c)], []).append(c)
            sets = sorted(uniq, key=lambda k: -len(uniq[k]))[:250]
            cands = set(sets)
            for i, x in enumerate(sets):
                for y in sets[i + 1:]:
                    if len(x & y) >= 2:
                        cands.add(x & y)
            for cand in cands:
                users = [c for c in members if cand <= items[id(c)]]
                size = sum(len(k) + len(v) + 2 for k, v in cand)
                g = (size - 8) * len(users) - size - 20
                if len(users) >= 2 and g > gain:
                    best, gain = (base, cand, users), g
        if best is None:
            break
        base, cand, users = best
        name = f'ST{len(styles) + 1}'
        styles.append((name, base, {k: users[0].kw[k] for k, _ in sorted(cand)}))
        for c in users:
            c.style = name
            for k, _ in cand:
                c.kw.pop(k)
            items[id(c)] = items[id(c)] - cand
    return styles


def factor_values(calls, styles, min_len=40):
    """Long values used more than once (effects, gradients ...) become constants."""
    counts = {}
    holders = [c.kw for c in calls] + [d for _, _, d in styles]
    for kw in holders:
        for k, v in kw.items():
            r = repr(v) if not isinstance(v, Raw) else str(v)
            if len(r) >= min_len:
                counts[(k, r)] = counts.get((k, r), 0) + 1
    names, consts = {}, []
    for (k, r), cnt in counts.items():
        if cnt >= 2 and (r not in [x for x in names]):
            base = {'fx': 'FX', 'fill': 'FILL', 'geom': 'GEOM'}.get(k, 'V')
            idx = sum(1 for nm, _ in consts if nm.startswith(base)) + 1
            names[r] = f'{base}{idx}'
            consts.append((names[r], next(v for kw in holders for kk, v in kw.items() if kk == k and (
                repr(v) if not isinstance(v, Raw) else str(v)) == r)))
    for kw in holders:
        for k, v in list(kw.items()):
            r = repr(v) if not isinstance(v, Raw) else str(v)
            if r in names:
                kw[k] = Raw(names[r])
    return consts


def assemble(cv, blocks, wanted, tname, files):
    defs, imports = _runtime()
    calls = [c for _, head, body in blocks for c in [head] + body if isinstance(c, Call)] + \
        [c for _, items in cv.layout_funcs.values() for c in items if isinstance(c, Call)]
    styles = factor_styles(calls)
    consts = factor_values(calls, styles)
    shared = [f'{name} = {tall(value, 0, 118)}' for name, value in consts]
    for name, base, kw in styles:
        shared += call(name + ' = dict', [Raw(base)] if base else [], kw)
    body = []
    for name, items in cv.layout_funcs.values():
        if items:
            body += [f'def {name}(s):'] + ['    ' + x for it in items
                                           for x in (it.render(114) if isinstance(it, Call) else [it])] + ['', '']
    for n, head, items in blocks:
        body += [f'def slide{n}(prs):'] + ['    ' + x for x in ['s = ' + head.render(110)[0]] + head.render(110)[1:]]
        for it in items:
            body += ['    ' + x for x in (it.render(114) if isinstance(it, Call) else [it])]
        body += ['', '']
    if cv.template:
        start = (["prs = Presentation(io.BytesIO(base64.b64decode(TEMPLATE)))"] if cv.embed else
                 [f"prs = Presentation(os.path.join(HERE, {tname!r}))"])
    else:
        sw, sh = cv.prs.slide_width, cv.prs.slide_height
        colors = {k: v for k, v in cv.base.colors.items() if k.startswith(('accent', 'dk', 'lt', 'hlink', 'folH'))}
        colors.update({std: cv.base.hex(slot) for slot, std in SCHEME.items()})  # bg1, tx1 ... as the deck maps them
        start = ['prs = Presentation()', f'prs.slide_width, prs.slide_height = {int(sw)}, {int(sh)}  # EMU: '
                 f'{inch(sw):g} x {inch(sh):g} in',
                 *Call('set_theme', [Raw('prs'), cv.base.fonts, colors], {}).render()]
        cv.used.add('set_theme')
    funcs = ', '.join(f'slide{n}' for n in wanted)
    main = ([f'def build(out={cv.name + "_rebuilt.pptx"!r}):', *['    ' + s for s in start],
             f'    for make in ({funcs}{"," if len(wanted) == 1 else ""}):', '        make(prs)'] +
            (['    links(prs)  # clicks that jump to another slide'] if 'links' in cv.used else []) +
            ['    prs.save(out)', '    return out'])
    run = SCRIPT_MAIN
    data_lines = []
    if cv.embed:
        if '__template__' in files:
            data_lines.append(f"TEMPLATE = {base64.b64encode(files['__template__']).decode()!r}")
        if cv.images:
            data_lines.append('IMG = {')
            data_lines += [f"    {name.split('.')[0]!r}: {base64.b64encode(blob).decode()!r},"
                           for name, blob in cv.images.values()]
            data_lines.append('}')
    # helpers used, with what they use in turn
    need, todo = [], sorted(cv.used)
    while todo:
        h = todo.pop()
        if h in need or h not in defs:
            continue
        need.append(h)
        todo += [n for n in _deps(defs[h]) if n in defs and n not in need]
    order = list(defs)
    helpers = [defs[h] for h in order if h in need]
    code_wo_imports = '\n'.join(helpers + shared + body + main + run + data_lines)
    used_names = _names(code_wo_imports) | {'sys'}
    if cv.template and not cv.embed:
        used_names |= {'os', 'HERE'}
    mods, plain = {}, []
    for name, (mod, orig, asname) in imports.items():
        if name in used_names:
            if mod is None:
                plain.append(f'import {orig}')
            else:
                mods.setdefault(mod, []).append(orig + (f' as {asname}' if asname else ''))
    helpers = [h for h in helpers if h != defs.get('HERE')]  # the script's own folder, not the helpers'
    if 'HERE' in used_names:
        helpers.insert(0, SCRIPT_HERE)
    imp = sorted(set(plain + ['import os', 'import sys'])) + \
        [f'from {m} import {", ".join(sorted(v))}' for m, v in sorted(mods.items())]
    if cv.module:  # the helpers stay in pptx_helpers.py, saved next to the script
        files['pptx_helpers.py'] = HELPERS.read_bytes()
        helpers = [SCRIPT_HERE] if 'HERE' in used_names else []
        imp = ['import os', 'import sys', '', 'try:', '    from pptx_helpers import *  # noqa: F403  (box, ph, pic, tbl ...)',
               'except ImportError:', f'    sys.exit({HELPERS_MISSING!r})']
    title = Path(cv.name).name
    skipped = report_lines(cv)
    head = [f'"""Rebuilds {title}.{cv.ext}{"" if cv.ext == "pptx" else " as a .pptx"} with python-pptx ({len(wanted)} slide{"s" if len(wanted) != 1 else ""}): '
            f'python {title}.py [out.pptx]', '',
            'Inches for positions, points for sizes. Colours: RRGGBB or theme (accent1, tx1 ...), +40 lighter, -25 darker,',
            '/50 = 50 % opaque. Text: "a\\nb" or [paragraph, ...] with runs (text, {format}).', '"""']
    parts = head + imp + [''] + skipped + ([''] if skipped else []) + \
        [h + '\n' for h in helpers] + ([''] + shared if shared else []) + ['', ''] + body + main + \
        (['', '', '# pictures and template, base64'] + data_lines if data_lines else []) + run
    code = '\n'.join(parts)
    code = re.sub(r'\n{3,}', '\n\n\n', code).rstrip() + '\n'
    return code


def convert(source, slides=None, template=True, embed=False, notes=True, fx=True, name=None, helpers='file',
            style='plain', extras=True, motion=True):
    """PowerPoint -> python-pptx code.
    source: path or bytes; slides: 1-based numbers or None for all;
    style: 'plain' (python-pptx statements) or 'compact' (short helper calls: box(), ph(), pic() ...);
    extras (plain): call pptx_helpers for what python-pptx has no command for (shadows, transparency ...),
        or leave those out;
    template: build on the deck's own masters/layouts (saved as <name>_template.pptx) or on a blank deck;
    embed: pictures and template inside the script; helpers (compact): 'file' (pptx_helpers.py) or 'inline'."""
    if isinstance(source, (str, Path)):
        data, name = Path(source).read_bytes(), name or Path(source).stem
    else:
        data = source
    return Converter(data, template, embed, notes, fx, name or 'deck', helpers, style, extras, motion).run(slides)


def outline(source):
    """[(number, title, shapes, hidden), ...] for picking slides."""
    prs = open_deck(source)
    out = []
    for n, s in enumerate(prs.slides, 1):
        texts = [sh.text_frame.text for sh in ([s.shapes.title] if s.shapes.title is not None else []) +
                 list(s.shapes) if sh.has_text_frame and sh.text_frame.text.strip().strip('0123456789')]
        title = ' '.join(texts[0].split())[:90] if texts else '(no text)'
        out.append((n, title, len(s.shapes), s._element.get('show') in ('0', 'false')))
    return out


def parse_slides(spec, count):
    """'1,3-5' -> [1, 3, 4, 5]."""
    out = []
    for part in (spec or '').replace(' ', '').split(','):
        if not part:
            continue
        a, _, b = part.partition('-')
        lo, hi = int(a), int(b or a)
        out += [n for n in range(lo, hi + 1) if 1 <= n <= count and n not in out]
    return out


def _hint(err, workdir):
    """What to do about the usual reasons a script cannot run."""
    if "No module named 'pptx'" in err:
        return '\n\npython-pptx is not installed for this Python. Install it with:  pip install python-pptx'
    if 'pptx_helpers' in err:
        return '\n\nThe code needs pptx_helpers.py next to it. Save the code with Save (.py or .zip), which writes it.'
    m = [x for x in re.findall(r"Package not found at '([^']+)'|No such file or directory: '([^']+)'", err)
         if '%s' not in x[0]]
    if m:
        return (f'\n\nThe file {Path(m[-1][0] or m[-1][1]).name} is not in {workdir}. The code needs the template and pictures '
                'it was saved with: open the .py from the folder it was saved in, or convert with "Embed pictures and '
                'template" for one self-contained file.')
    if 'cannot import name' in err and 'pptx' in err or "has no attribute" in err and 'pptx' in err:
        return '\n\nThis python-pptx is too old for the code. Update it with:  pip install -U python-pptx'
    return ''


def run_code(code, out, workdir=None, timeout=900):
    """Run a generated (or pasted) script in its own python process so it writes `out`; returns that path.
    The script runs in `workdir` (where its template and pictures are); pptx_helpers is importable."""
    import os
    import subprocess
    import sys
    import tempfile
    out = Path(out).resolve()
    workdir = Path(workdir or tempfile.mkdtemp(prefix='pptx2py_')).resolve()
    workdir.mkdir(parents=True, exist_ok=True)
    script = workdir / '_pptx2py_run.py'
    script.write_text(code, encoding='utf-8')
    before = {p: p.stat().st_mtime for p in workdir.glob('*.pptx')}
    env = dict(os.environ, PYTHONPATH=os.pathsep.join(filter(None, [str(HELPERS.parent), os.environ.get('PYTHONPATH')])),
               PYTHONIOENCODING='utf-8')
    try:
        r = subprocess.run([sys.executable, str(script), str(out)], cwd=workdir, env=env, capture_output=True,
                           text=True, encoding='utf-8', errors='replace', timeout=timeout,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    finally:
        script.unlink(missing_ok=True)
    if r.returncode:
        err = r.stderr.strip().replace(str(script), 'your code')
        raise RuntimeError('The code stopped with an error:\n' + '\n'.join(err.splitlines()[-12:]) + _hint(err, workdir))
    if not out.exists():  # a pasted script that saves under its own name
        new = [p for p in workdir.glob('*.pptx') if before.get(p) != p.stat().st_mtime and p != out
               and not p.name.endswith('_template.pptx')]
        if not new:
            raise RuntimeError('The code ran but saved no .pptx (call prs.save(...) or define build(out)).')
        out.write_bytes(max(new, key=lambda p: p.stat().st_mtime).read_bytes())
    return out


__all__ = ['convert', 'outline', 'make_template', 'parse_slides', 'run_code', 'open_deck', 'repair', 'Result', 'HELPERS']
