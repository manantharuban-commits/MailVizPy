"""Chart -> (type, categories, series, options). Options are only those that differ from the chart
python-pptx draws for the same type and data, so the generated call stays short."""
import re

from pptx import Presentation
from pptx.chart.data import BubbleChartData, CategoryChartData, XyChartData
from pptx.chart.plot import PlotTypeInspector
from pptx.chart.xmlwriter import ChartXmlWriter
from pptx.enum.chart import XL_CHART_TYPE
from pptx.util import Inches

from .convert import A, C, R, Exact, colour_of, fill_spec, kid, line_spec, ln, num


def _writable(m):
    try:
        ChartXmlWriter(m, [])
        return True
    except NotImplementedError:
        return False


WRITABLE = {m.name for m in XL_CHART_TYPE if _writable(m)}  # the chart types python-pptx can create
PLOT_NAMES = {'surfaceChart': 'a surface chart', 'surface3DChart': 'a 3-D surface chart', 'stockChart': 'a stock chart'}
LINE_LIKE = ('LINE', 'XY_', 'RADAR')


def flat(kind):
    """The chart type python-pptx can create closest to `kind` (3-D, cone, cylinder and pyramid charts drawn flat;
    pie-of-pie as a pie), or None."""
    if kind is None or kind in WRITABLE:
        return kind
    k = re.sub(r'^(THREE_D_|CONE_|CYLINDER_|PYRAMID_)', '', kind)
    k = re.sub(r'^COL(?=_|$)', 'COLUMN', k)
    k = {'COLUMN': 'COLUMN_CLUSTERED', 'BAR': 'BAR_CLUSTERED', 'PIE_OF_PIE': 'PIE', 'BAR_OF_PIE': 'PIE'}.get(k, k)
    return k if k in WRITABLE else None


def _pts(el):
    """Values of a c:numRef/c:numLit/c:strRef by point index."""
    if el is None:
        return {}
    out = {}
    for pt in el.iter(f'{{{C}}}pt'):
        v = kid(pt, 'v', C)
        if v is not None and v.text is not None:
            out[int(pt.get('idx'))] = v.text
    return out


def _num(s):
    try:
        f = float(s)
    except (TypeError, ValueError):
        return None
    return int(f) if f == int(f) and abs(f) < 1e15 else Exact(f'{f:.15g}')


def _sers(plots, kinds=None):
    """[(series element, chart type of its plot)] in the order the legend lists them (c:order); python-pptx numbers
    series in that order."""
    kinds = kinds or [None] * len(plots)
    out = [(s, k) for p, k in zip(plots, kinds) for s in p.findall(f'{{{C}}}ser')]
    return sorted(out, key=lambda t: int(kid(t[0], 'order', C).get('val', 0)) if kid(t[0], 'order', C) is not None else 0)


def _opts(cs, th, kind, n_series, kinds=None, n_cats=0):
    """The options the chart helper understands, read from chartSpace XML."""
    chart = kid(cs, 'chart', C)
    pa = kid(chart, 'plotArea', C)
    plots = [p for p in pa if ln(p).endswith('Chart')]
    plot = plots[0]
    kinds = kinds or [kind] * len(plots)
    sers = [s for s, _ in _sers(plots, kinds)]
    ser_line = [k.startswith(LINE_LIKE) for _, k in _sers(plots, kinds)]
    o = {}
    leg = kid(chart, 'legend', C)
    o['legend'] = (kid(leg, 'legendPos', C).get('val', 'r') if kid(leg, 'legendPos', C) is not None else 'r') \
        if leg is not None else False
    title = kid(chart, 'title', C)
    deleted = kid(chart, 'autoTitleDeleted', C)
    if title is not None:
        txt = ''.join(t.text or '' for t in title.iter(f'{{{A}}}t'))
        if not txt and n_series == 1:
            tx = sers[0].find(f'.//{{{C}}}tx//{{{C}}}v') if sers else None
            txt = tx.text if tx is not None else ''
        o['title'] = txt or 'Chart Title'  # what PowerPoint shows for a title with no text of its own
    else:
        o['title'] = False if (deleted is not None and deleted.get('val') in ('1', 'true')) or n_series > 1 \
            else 'auto'
    def on(d):
        return d is not None and any(x is not None and x.get('val') in ('1', 'true')
                                     for x in (kid(d, 'showVal', C), kid(d, 'showPercent', C)))
    own = [kid(s, 'dLbls', C) if kid(s, 'dLbls', C) is not None else kid(s.getparent(), 'dLbls', C) for s in sers]
    labelled = [i for i, d in enumerate(own) if on(d)]  # a series' own labels, else its plot's
    dl = own[labelled[0]] if labelled else None
    lb = {}
    if dl is not None:
        sv, sp = kid(dl, 'showVal', C), kid(dl, 'showPercent', C)
        on_v = sv is not None and sv.get('val') in ('1', 'true')
        on_p = sp is not None and sp.get('val') in ('1', 'true')
        if on_v or on_p:
            lb['on'] = 1
            if on_p:
                lb['pct'] = 1
            if not on_v:
                lb['val'] = 0
            pos = kid(dl, 'dLblPos', C)
            if pos is not None:
                lb['pos'] = pos.get('val')
            nf = kid(dl, 'numFmt', C)
            if nf is not None and nf.get('sourceLinked') in ('0', 'false'):
                lb['nf'] = nf.get('formatCode')
            d = dl.find(f'.//{{{A}}}defRPr')
            if d is not None and d.get('sz'):
                lb['sz'] = num(int(d.get('sz')) / 100, 2)
            if d is not None:
                c = colour_of(kid(d, 'solidFill'), th)
                if c:
                    lb['c'] = c
            if len(labelled) < len(sers) or len(plots) > 1:
                lb['series'] = labelled  # labels on these series only
    o['labels'] = lb or None
    cols = []
    for s, line_like in zip(sers, ser_line):
        sp = kid(s, 'spPr', C)
        target = kid(sp, 'ln') if line_like else sp
        c = None
        for f in target if target is not None else ():
            if ln(f) == 'solidFill':
                c = colour_of(f, th)
            elif ln(f) == 'gradFill':
                c = colour_of(f.find(f'.//{{{A}}}gs'), th)
        cols.append(c)
    st = kid(cs, 'style', C)
    if st is None or st.get('val') == '2':  # automatic colours go by series number: kept when it changes
        for i, s in enumerate(sers):
            idx = kid(s, 'idx', C)
            n = int(idx.get('val')) if idx is not None else i
            if cols[i] is None and n != i and n < 6 and kind and not kind.startswith(('PIE', 'DOUGHNUT')):
                cols[i] = f'accent{n + 1}'
    o['colors'] = cols if any(cols) else None
    allpts = {}
    for si, (s, line_like) in enumerate(zip(sers, ser_line)):
        if line_like:
            continue  # points of lines are markers: left to the chart style
        count = len(_pts(kid(s, 'val', C)) or _pts(kid(s, 'yVal', C)))
        pts = {}
        for dpt in s.findall(f'{{{C}}}dPt'):
            i = int(kid(dpt, 'idx', C).get('val'))
            c = colour_of(kid(kid(dpt, 'spPr', C), 'solidFill'), th)
            if c and i < max(count, n_cats):
                pts[i] = c
        if pts:
            allpts[si] = [pts.get(i) for i in range(max(pts) + 1)]
    o['pts'] = None if not allpts else allpts[0] if list(allpts) == [0] else allpts
    vary = kid(plot, 'varyColors', C)
    o['vary'] = vary is not None and vary.get('val', '1') in ('1', 'true')
    for key, tag in (('vtitle', 'valAx'), ('ctitle', 'catAx')):
        ax = next((a for a in pa if ln(a) == tag or (tag == 'catAx' and ln(a) == 'dateAx')), None)
        t = kid(ax, 'title', C) if ax is not None else None
        o[key] = ''.join(x.text or '' for x in t.iter(f'{{{A}}}t')) or None if t is not None else None
    g, ov = kid(plot, 'gapWidth', C), kid(plot, 'overlap', C)
    o['gap'] = int(g.get('val', 150)) if g is not None else (150 if ln(plot).startswith('bar') else None)
    o['overlap'] = int(ov.get('val', 0)) if ov is not None else (0 if ln(plot).startswith('bar') else None)
    va = next((a for a in pa if ln(a) == 'valAx'), None)
    ca = next((a for a in pa if ln(a) in ('catAx', 'dateAx')), None)
    if va is not None:
        o['grid'] = kid(va, 'majorGridlines', C) is not None
        d = kid(va, 'delete', C)
        o['vaxis'] = not (d is not None and d.get('val') in ('1', 'true'))
        sc = kid(va, 'scaling', C)
        for k, tag in (('vmin', 'min'), ('vmax', 'max')):
            e = kid(sc, tag, C)
            o[k] = _num(e.get('val')) if e is not None else None
    if ca is not None:
        d = kid(ca, 'delete', C)
        o['caxis'] = not (d is not None and d.get('val') in ('1', 'true'))
    nf = sers[0].find(f'.//{{{C}}}val//{{{C}}}formatCode') if sers else None
    o['nf'] = nf.text if nf is not None and nf.text and nf.text != 'General' else None
    tx = kid(cs, 'txPr', C)
    d = tx.find(f'.//{{{A}}}defRPr') if tx is not None else None
    o['sz'] = num(int(d.get('sz')) / 100, 2) if d is not None and d.get('sz') else 10  # 10 pt when unset
    st = kid(cs, 'style', C)
    o['style'] = int(st.get('val')) if st is not None else 2
    if line_like and sers:
        sm = kid(sers[0], 'smooth', C)
        o['smooth'] = sm is not None and sm.get('val') in ('1', 'true')
    for key, el in (('area', cs), ('plotfill', pa)):  # chart and plot area: fill and border
        sp = kid(el, 'spPr', C)
        f = fill_spec(sp, th) if sp is not None else None
        ls = line_spec(sp, th) if sp is not None else {}
        d = {k: v for k, v in (('fill', f if not isinstance(f, tuple) else None), ('line', ls.get('line')),
                               ('width', ls.get('lw'))) if v is not None}
        o[key] = d or None
    hole = cs.find(f'.//{{{C}}}holeSize')
    o['hole'] = int(hole.get('val')) if hole is not None else None
    return o


def _data(cs, xy, bubble):
    chart = kid(cs, 'chart', C)
    pa = kid(chart, 'plotArea', C)
    sers = [s for s, _ in _sers([p for p in pa if ln(p).endswith('Chart')])]
    names, cats, series = [], [], {}
    for i, s in enumerate(sers):
        tx = s.find(f'.//{{{C}}}tx//{{{C}}}v')
        name = tx.text if tx is not None and tx.text else f'Series {i + 1}'
        while name in names:
            name += ' '
        names.append(name)
        if xy:
            xs, ys = _pts(kid(s, 'xVal', C)), _pts(kid(s, 'yVal', C))
            bs = _pts(kid(s, 'bubbleSize', C)) if bubble else {}
            series[name] = [(_num(xs.get(k, k + 1)), _num(ys[k])) + ((_num(bs.get(k, 1)),) if bubble else ())
                            for k in sorted(ys)]
            continue
        cat, val = kid(s, 'cat', C), kid(s, 'val', C)
        if i == 0:
            lvl = cat.find(f'.//{{{C}}}lvl') if cat is not None else None
            cp = _pts(lvl if lvl is not None else cat)
            n = cat.find(f'.//{{{C}}}ptCount') if cat is not None else None
            count = int(n.get('val')) if n is not None else (max(cp) + 1 if cp else 0)
            cats = [cp.get(k, '') for k in range(count)]
            if all(_num(c) is not None for c in cats) and cats:
                cats = [_num(c) for c in cats]
            lvls = cat.findall(f'.//{{{C}}}lvl') if cat is not None else []
            if len(lvls) == 2:  # two-level categories: [(group, [category, ...]), ...]
                top = _pts(lvls[1])
                starts = sorted(top)
                if starts and starts[0] == 0:
                    ends = starts[1:] + [count]
                    groups = [(top[a], cats[a:b]) for a, b in zip(starts, ends)]
                    n_leaves = len(cats)
                    cats = groups
                    count = n_leaves
        vp = _pts(val)
        n = sum(len(g[1]) for g in cats) if cats and isinstance(cats[0], tuple) else len(cats)
        series[name] = [_num(vp.get(k)) for k in range(n or (max(vp) + 1 if vp else 0))]
    return cats, series


def set_categories(cd, cats):
    """Categories of chart data: a list, or two levels [(group, [category, ...]), ...]."""
    if cats and isinstance(cats[0], tuple):
        for group, leaves in cats:
            g = cd.add_category(group)
            for leaf in leaves:
                g.add_sub_category(leaf)
    else:
        cd.categories = cats


def _default_opts(kind, cats, series, th):
    prs = Presentation()
    s = prs.slides.add_slide(prs.slide_layouts[6])
    if kind.startswith(('XY_', 'BUBBLE')):
        cd = BubbleChartData() if kind.startswith('BUBBLE') else XyChartData()
        for name, pts in series.items():
            sr = cd.add_series(name)
            for p in pts:
                sr.add_data_point(*p)
    else:
        cd = CategoryChartData()
        set_categories(cd, cats)
        for name, vals in series.items():
            cd.add_series(name, vals)
    gf = s.shapes.add_chart(getattr(XL_CHART_TYPE, kind), 0, 0, Inches(4), Inches(3), cd)
    return _opts(gf.chart._chartSpace, th, kind, len(series))


def _three_d(el):
    """The chart type name of a 3-D plot python-pptx cannot read (bar3DChart ...), as its flat counterpart."""
    def val(tag, default):
        e = kid(el, tag, C)
        return e.get('val', default) if e is not None else default
    grouping = {'stacked': '_STACKED', 'percentStacked': '_STACKED_100'}.get(val('grouping', 'clustered'), '')
    tag = ln(el)
    if tag == 'bar3DChart':
        return ('BAR' if val('barDir', 'col') == 'bar' else 'COLUMN') + (grouping or '_CLUSTERED')
    if tag == 'area3DChart':
        return 'AREA' + grouping
    if tag == 'line3DChart':
        return 'LINE'
    if tag == 'pie3DChart':
        return 'PIE'
    return None


def _plots(chart):
    """[(plot element, chart type name or None, 3-D)] of a chart, in drawing order."""
    from pptx.chart.plot import PlotFactory
    out = []
    for el in kid(kid(chart._chartSpace, 'chart', C), 'plotArea', C):
        if not ln(el).endswith('Chart'):
            continue
        try:
            k = PlotTypeInspector.chart_type(PlotFactory(el, chart)).name
        except Exception:  # noqa: BLE001
            if ln(el) == 'ofPieChart':
                t = kid(el, 'ofPieType', C)
                out.append((el, 'BAR_OF_PIE' if t is not None and t.get('val') == 'bar' else 'PIE_OF_PIE', False))
                continue
            k = _three_d(el)
            if k:
                out.append((el, k, True))
                continue
        out.append((el, k, '3D' in ln(el)))
    return out


def read_chart(slide_part, gf, th):
    """(kind, categories, series, options, notes); kind None when python-pptx cannot create the chart (notes say
    why)."""
    ref = gf.find(f'.//{{{C}}}chart')
    part = slide_part.related_part(ref.get(f'{{{R}}}id'))
    chart = part.chart
    plots3 = _plots(chart)
    plots = [(el, k) for el, k, _ in plots3]
    if not plots:
        return None, None, None, None, ['a chart with no data series, left out (python-pptx makes charts from their data)']
    notes = []
    kinds = [flat(k) for _, k in plots]
    for (el, k, d3), f in zip(plots3, kinds):
        if f is None:
            what = PLOT_NAMES.get(ln(el), f'a {k or ln(el)} chart')
            return None, None, None, None, [f'{what}, left out (python-pptx cannot create this chart type)']
        if f != k or d3:
            notes.append(f'a 3-D {f.replace("_", " ").lower()} chart, drawn flat (python-pptx makes flat charts only)'
                         if d3 or k.startswith('THREE_D') else
                         f'a {k.replace("_", " ").lower()} chart, drawn as {f.replace("_", " ").lower()} '
                         '(python-pptx cannot create this chart type)')
    kind = kinds[0]
    cs = chart._chartSpace
    xy, bubble = kind.startswith(('XY_', 'BUBBLE')), kind.startswith('BUBBLE')
    combo = []
    pa = cs.find(f'.//{{{C}}}plotArea')
    vals = {a.find(f'{{{C}}}axId').get('val') for a in pa if ln(a) == 'valAx'}
    main_ax = [a.get('val') for a in plots[0][0].findall(f'{{{C}}}axId')]
    order = [s for s, _ in _sers([el for el, _ in plots])]
    for i, (el, _) in enumerate(plots):
        mine = [order.index(s) for s in el.findall(f'{{{C}}}ser')]
        if i:
            ax = [a.get('val') for a in el.findall(f'{{{C}}}axId')]
            other_xy = kinds[i].startswith(('XY_', 'BUBBLE'))
            if xy or other_xy or kind.startswith(('PIE', 'DOUGHNUT')) or kinds[i].startswith(('PIE', 'DOUGHNUT')):
                notes.append(f'its {kinds[i].replace("_", " ").lower()} part drawn as {kind.replace("_", " ").lower()} '
                             '(these chart types cannot be combined)')
            else:
                second = bool(set(ax) & vals) and not set(ax) & set(main_ax) & vals
                if kinds[i] != kind or second:
                    combo.append((kinds[i], sorted(mine), second))
    cats, series = _data(cs, xy, bubble)
    if not series:
        return None, None, None, None, ['a chart with no data series, left out (python-pptx makes charts from their data)']
    n_cats = sum(len(g[1]) for g in cats) if cats and isinstance(cats[0], tuple) else len(cats)
    mine = _opts(cs, th, kind, len(series), kinds, n_cats)
    try:
        base = _default_opts(kind, cats, series, th)
    except Exception:  # noqa: BLE001
        base = {}
    opts = {k: v for k, v in mine.items() if v != base.get(k) and not (v is None and k not in base)}
    if opts.get('title') == 'auto':
        opts.pop('title')
    lb = opts.get('labels')
    if lb:
        lb = {k: v for k, v in lb.items() if k != 'on'}
        opts['labels'] = lb or True
    elif 'labels' in opts and not lb and base.get('labels'):
        opts['labels'] = None  # python-pptx draws none either way
    for k in [k for k, v in opts.items() if v is None]:
        opts.pop(k)
    if combo:
        opts['combo'] = combo
    return kind, cats, series, opts, notes


__all__ = ['read_chart']
