"""Compare a rebuilt deck with the original, shape by shape: position, size, rotation, text, paragraph alignment,
character formatting, fills and lines, pictures, tables, charts, slide transitions and animations.
No rendering and no PowerPoint needed.

    report = compare('deck.pptx', 'deck_rebuilt.pptx')
    print(report.text())
"""
import hashlib
import math
import re
from dataclasses import dataclass, field


from .anim import read_timing, read_transition, summary
from .convert import COLOUR_MODS, NEUTRAL, A, C, P, R, Converter, Theme, _hls_mods, choose_alt, kid, layout_box, LINE_PRESETS, line_ends, ln, open_deck

EMU = 914400
TOL = 0.02  # inches: about two pixels on a 96-dpi screen
TEXT_KEYS = ('sz', 'b', 'i', 'u', 'strike', 'cap', 'spc', 'baseline')
PARA_ATTRS = ('algn', 'lvl', 'marL', 'indent')


@dataclass
class Issue:
    slide: int
    level: str          # 'error' (looks different), 'listed' (a difference the converter reported) or 'note' (minor)
    shape: str
    message: str

    def __str__(self):
        return f'slide {self.slide}: {self.shape}: {self.message}' if self.shape else f'slide {self.slide}: {self.message}'


@dataclass
class Report:
    slides: int = 0
    shapes: int = 0
    matched: int = 0
    issues: list = field(default_factory=list)

    @property
    def errors(self):
        return [i for i in self.issues if i.level == 'error']

    def text(self):
        e = len(self.errors)
        listed = sum(1 for i in self.issues if i.level == 'listed')
        notes = sum(1 for i in self.issues if i.level == 'note')
        head = (f'{self.slides} slides, {self.shapes} shapes compared: {self.matched} found in place; '
                f'{e} difference{"s" if e != 1 else ""}'
                + (f', {listed} more the converter already listed as not convertible' if listed else '')
                + (f', {notes} note{"s" if notes != 1 else ""}' if notes else '') + '.')
        return '\n'.join([head] + [f'  {"!" if i.level == "error" else "~" if i.level == "listed" else "-"} {i}'
                                    for i in self.issues])


# ── what a shape is, read straight from the XML ──────────────────────────────────────────────────────────────
def _box(el):
    if ln(el) == 'graphicFrame':
        x = kid(el, 'xfrm', P)
    elif ln(el) == 'grpSp':
        x = el.find(f'{{{P}}}grpSpPr/{{{A}}}xfrm')
    else:
        x = el.find(f'{{{P}}}spPr/{{{A}}}xfrm')
    if x is None or kid(x, 'off') is None or kid(x, 'ext') is None:
        return None, x
    o, e = kid(x, 'off'), kid(x, 'ext')
    return [int(o.get('x')), int(o.get('y')), int(e.get('cx')), int(e.get('cy'))], x


def _map(v, xf):
    ox, oy, sx, sy, cx, cy = xf
    return [ox + (v[0] - cx) * sx, oy + (v[1] - cy) * sy, v[2] * sx, v[3] * sy]


NUMS = {}  # original slide number -> rebuilt slide number (set per comparison)
TH = {'theme': None}  # the theme colours are resolved with (set per slide)
PRESET = {'black': '000000', 'white': 'FFFFFF', 'red': 'FF0000', 'green': '008000', 'blue': '0000FF',
          'yellow': 'FFFF00', 'gray': '808080', 'grey': '808080'}


def _colour(el):
    """A colour as resolved RGB ('RRGGBB') with its transparency, so 'accent1' and '4F81BD' compare equal."""
    for c in el.iter() if el is not None else ():
        n = ln(c)
        if n in ('srgbClr', 'schemeClr', 'prstClr', 'sysClr', 'scrgbClr'):
            base = (c.get('lastClr') if n == 'sysClr' else c.get('val', '').upper() if n == 'srgbClr' else
                    PRESET.get(c.get('val'), '808080') if n == 'prstClr' else
                    ''.join(f'{round(int(c.get(k, 0)) / 100000 * 255):02X}' for k in 'rgb') if n == 'scrgbClr' else
                    TH['theme'].hex(c.get('val')) if TH['theme'] else c.get('val'))
            mods = [(ln(m), int(m.get('val', '0'))) for m in c]
            alpha = next((v for k, v in mods if k == 'alpha'), 100000)
            mods = [(k, v) for k, v in mods if k in COLOUR_MODS and NEUTRAL.get(k) != v]
            try:
                rgb = _hls_mods(base, mods) if mods else base
            except (ValueError, TypeError):
                rgb = base
            return (rgb, round(alpha / 1000))
    return None


def _fill(parent):
    for c in parent if parent is not None else ():
        n = ln(c)
        if n == 'noFill':
            return ('none',)
        if n == 'solidFill':
            return ('solid', _colour(c))
        if n == 'gradFill':
            return ('gradient', len(c.findall(f'.//{{{A}}}gs')))
        if n == 'pattFill':
            return ('pattern', c.get('prst', 'pct5'))
        if n == 'blipFill':
            return ('picture',)
    return None


DEFAULTS = {'cap': 'none', 'strike': 'noStrike', 'u': 'none', 'baseline': '0', 'spc': '0', 'lvl': '0', 'marL': '0',
            'indent': '0'}


def _clean(d):
    return {k: v for k, v in d.items() if DEFAULTS.get(k) != v}


def _text(tb):
    paras = []
    for p in tb.findall(f'{{{A}}}p'):
        ppr = kid(p, 'pPr')
        pa = _clean({a: ppr.get(a) for a in PARA_ATTRS if ppr is not None and ppr.get(a) is not None})
        runs = []
        for c in p:
            if ln(c) in ('r', 'fld'):
                rpr = kid(c, 'rPr')
                k = _clean({a: rpr.get(a) for a in TEXT_KEYS if rpr is not None and rpr.get(a) is not None})
                lat = kid(rpr, 'latin')
                if lat is not None:
                    k['font'] = lat.get('typeface')
                sf = kid(rpr, 'solidFill')
                if sf is not None:
                    k['color'] = _colour(sf)
                t = kid(c, 't')
                runs.append(((t.text or '') if t is not None else '', k))
            elif ln(c) == 'br':
                runs.append(('\v', {}))
        paras.append((pa, runs))
    while paras and not ''.join(t for _, rs in paras[-1:] for t, _ in rs).strip():
        paras.pop()
    return paras


def _record(el, box, slide_part):
    n = ln(el)
    nv = el.find(f'.//{{{P}}}cNvPr')
    rec = {'el': el, 'name': nv.get('name', '') if nv is not None else '', 'spid': nv.get('id') if nv is not None else None,
           'box': box, 'kind': 'shape'}
    ph = el.find(f'.//{{{P}}}nvPr/{{{P}}}ph')
    if ph is not None:
        rec['ph'] = (ph.get('type', 'body'), ph.get('idx', '0'))
    h = nv.find(f'{{{A}}}hlinkClick') if nv is not None else None
    if h is not None:
        rid, action = h.get(f'{{{R}}}id'), h.get('action') or ''
        rel = slide_part.rels.get(rid) if rid else None
        if action == 'ppaction://hlinksldjump' and rel is not None and not rel.is_external:
            slides = slide_part.package.presentation_part.presentation.slides
            rec['click'] = ('slide', next((i for i, s in enumerate(slides, 1) if s.part is rel.target_part), None))
        elif rel is not None and rel.is_external:
            rec['click'] = ('url', rel.target_ref)
        elif action and action != 'ppaction://noaction':
            rec['click'] = ('action', action)
    xf = _box(el)[1]
    rec['rot'] = int(xf.get('rot', 0)) / 60000 if xf is not None else 0
    rec['flip'] = (xf.get('flipH') in ('1', 'true') if xf is not None else False,
                   xf.get('flipV') in ('1', 'true') if xf is not None else False)
    sppr = kid(el, 'spPr', P)
    if n == 'pic':
        rec['kind'] = 'picture'
        blip = el.find(f'.//{{{A}}}blip')
        rid = blip.get(f'{{{R}}}embed') if blip is not None else None
        if rid and rid in slide_part.rels:
            rec['image'] = hashlib.sha1(slide_part.related_part(rid).blob).hexdigest()[:12]
        sr = el.find(f'.//{{{A}}}srcRect')
        rec['crop'] = tuple(round(int(sr.get(k, 0)) / 1000) for k in 'ltrb') if sr is not None else (0, 0, 0, 0)
    elif n == 'cxnSp':
        rec['kind'] = 'line'
    elif n == 'graphicFrame':
        gd = el.find(f'.//{{{A}}}graphicData')
        uri = gd.get('uri', '') if gd is not None else ''
        if uri.endswith('/table'):
            rec['kind'] = 'table'
            if box:  # a table is as big as its rows and columns, whatever its frame says
                hs = [int(tr.get('h', 0)) for tr in gd.iter(f'{{{A}}}tr')]
                ws = [int(g.get('w', 0)) for g in gd.iter(f'{{{A}}}gridCol')]
                k = (box[3] / (int(kid(el, 'xfrm', P).find(f'{{{A}}}ext').get('cy')) / EMU)) if box[3] else 1
                rec['box'] = [box[0], box[1], sum(ws) / EMU * k if ws else box[2], sum(hs) / EMU * k if hs else box[3]]
            rec['cells'] = [[''.join(t.text or '' for t in tc.iter(f'{{{A}}}t'))  # cells merged into another: hidden
                             if tc.get('hMerge') not in ('1', 'true') and tc.get('vMerge') not in ('1', 'true') else ''
                             for tc in tr.findall(f'{{{A}}}tc')] for tr in gd.iter(f'{{{A}}}tr')]
        elif uri.endswith('/chart'):
            rec['kind'] = 'chart'
            ref = gd.find(f'{{{C}}}chart')
            rid = ref.get(f'{{{R}}}id') if ref is not None else None
            if rid in slide_part.rels:
                cs = slide_part.related_part(rid).chart._chartSpace
                plots = [ln(p) for p in cs.find(f'.//{{{C}}}plotArea') if ln(p).endswith('Chart')]
                sers = cs.findall(f'.//{{{C}}}ser')
                vals = [[v.text for v in s.findall(f'{{{C}}}val//{{{C}}}v') + s.findall(f'{{{C}}}yVal//{{{C}}}v')]
                        for s in sers]
                rec['chart'] = (tuple(plots), len(sers), tuple(tuple(_num(x) for x in v) for v in vals))
        else:
            rec['kind'] = 'object'
    if sppr is not None:
        rec['fill'] = _fill(sppr)
        lnel = kid(sppr, 'ln')
        if lnel is not None and (_fill(lnel) is not None or lnel.get('w')):
            rec['line'] = (_fill(lnel), lnel.get('w'))
        pg = kid(sppr, 'prstGeom')
        rec['geom'] = pg.get('prst') if pg is not None else 'custom' if kid(sppr, 'custGeom') is not None else None
        tb = kid(el, 'txBody', P)
        if n == 'sp' and rec['geom'] in LINE_PRESETS and (tb is None or not ''.join(tb.itertext()).strip()):
            rec['kind'] = 'line'  # a line drawn as a shape
            if rec['geom'] == 'lineInv':  # from bottom left to top right
                rec['flip'] = (rec['flip'][0], not rec['flip'][1])
    tb = kid(el, 'txBody', P)
    if tb is not None:
        rec['paras'] = _text(tb)
        rec['text'] = '\n'.join(''.join(t for t, _ in rs) for _, rs in rec['paras'])
        bp = kid(tb, 'bodyPr')
        rec['body'] = {a: bp.get(a) for a in ('anchor', 'wrap', 'vert', 'lIns', 'tIns', 'rIns', 'bIns')
                       if bp is not None and bp.get(a) is not None}
        if rec['kind'] == 'shape' and rec['text'].strip():
            rec['kind'] = 'text'
    return rec


def _num(v):
    try:
        return round(float(v), 6)
    except (TypeError, ValueError):
        return v


def _turn(rec, turns):
    """A shape inside turned or flipped groups: where it ends up, innermost group first."""
    if not turns or not rec['box']:
        return
    x, y, w, h = rec['box']
    cx, cy, rot, (fh, fv) = x + w / 2, y + h / 2, rec['rot'], rec['flip']
    for gx, gy, grot, gfh, gfv in reversed(turns):
        if gfh:
            cx, rot, fh = 2 * gx - cx, -rot, not fh
        if gfv:
            cy, rot, fv = 2 * gy - cy, -rot, not fv
        if grot:
            a = math.radians(grot)
            cx, cy = (gx + (cx - gx) * math.cos(a) - (cy - gy) * math.sin(a),
                      gy + (cx - gx) * math.sin(a) + (cy - gy) * math.cos(a))
            rot += grot
    rec['box'], rec['rot'], rec['flip'] = [cx - w / 2, cy - h / 2, w, h], rot % 360, (fh, fv)


def leaves(slide, cv=None):
    """Every visible shape of a slide with its place on the slide (groups opened, SmartArt as its drawn shapes)."""
    out = []
    top = {id(sh._element): sh for sh in slide.shapes}

    def walk(tree, xf, turns=()):
        for el in tree:
            n = ln(el)
            if n == 'AlternateContent':
                alt = choose_alt(el)
                if alt is not None:
                    walk(alt, xf, turns)
                continue
            if n not in ('sp', 'pic', 'cxnSp', 'grpSp', 'graphicFrame'):
                continue
            nv = el.find(f'.//{{{P}}}cNvPr')
            if nv is not None and nv.get('hidden') in ('1', 'true'):
                continue
            v, x = _box(el)
            if v is None and id(el) in top and top[id(el)].width is not None:
                sh = top[id(el)]
                v = [sh.left, sh.top, sh.width, sh.height]
            if v is None and n == 'sp':
                v = layout_box(slide, el.find(f'.//{{{P}}}ph'))
                v = list(v) if v else None
            if v is not None and xf:
                v = _map(v, xf)
            if n == 'grpSp':
                if x is None or v is None:
                    walk(el, xf)
                    continue
                co, ce = kid(x, 'chOff'), kid(x, 'chExt')
                sx = v[2] / int(ce.get('cx')) if ce is not None and int(ce.get('cx')) else 1
                sy = v[3] / int(ce.get('cy')) if ce is not None and int(ce.get('cy')) else 1
                grot, gfh, gfv = int(x.get('rot', 0)) / 60000, x.get('flipH') in ('1', 'true'), x.get('flipV') in ('1', 'true')
                more = ((((v[0] + v[2] / 2) / EMU, (v[1] + v[3] / 2) / EMU, grot, gfh, gfv),)
                        if grot or gfh or gfv else ())
                walk(el, (v[0], v[1], sx, sy, int(co.get('x')) if co is not None else 0,
                          int(co.get('y')) if co is not None else 0), turns + more)
                continue
            if n == 'graphicFrame' and cv is not None:
                gd = el.find(f'.//{{{A}}}graphicData')
                if gd is not None and gd.get('uri', '').endswith('/diagram'):
                    cv.part = slide.part
                    g = cv.smartart(el, gd)
                    if g is not None:
                        walk([g], xf, turns)
                        continue
                fb = el.find(f'.//{{{P}}}pic')
                if fb is not None and gd is not None and not gd.get('uri', '').endswith(('/table', '/chart')):
                    rec = _record(fb, [b / EMU for b in v] if v else None, slide.part)
                    rec['spid'] = nv.get('id') if nv is not None else rec['spid']
                    _turn(rec, turns)
                    out.append(rec)
                    continue
            rec = _record(el, [b / EMU for b in v] if v else None, slide.part)
            box = el.find(f'{{{P}}}nvSpPr/{{{P}}}cNvSpPr')
            if (rec.get('ph') or (box is not None and box.get('txBox') in ('1', 'true'))) and \
                    not rec.get('text', '').strip() and rec['kind'] in ('shape', 'text') and \
                    rec.get('fill') in (None, ('none',)) and rec.get('line', (None,))[0] in (None, ('none',)):
                continue  # an empty placeholder or text box shows nothing in a slide show
            _turn(rec, turns)
            out.append(rec)
    walk(slide.shapes._spTree, None)
    return out


# ── comparing ─────────────────────────────────────────────────────────────────────────────────────────────────
FAMILY = {'text': 'text', 'shape': 'shape', 'picture': 'picture', 'object': 'picture', 'line': 'line',
          'table': 'table', 'chart': 'chart'}


def _ends(d):
    return line_ends(d['box'], {'rot': d['rot'], 'flip': ('h' if d['flip'][0] else '') + ('v' if d['flip'][1] else '')})


def _score(a, b):
    if FAMILY[a['kind']] != FAMILY[b['kind']] and {a['kind'], b['kind']} != {'text', 'shape'}:
        return None
    if a['box'] is None or b['box'] is None:
        return 1 if a.get('text') == b.get('text') else None
    if a['kind'] == b['kind'] == 'line':
        return sum(abs(x - y) for x, y in zip(_ends(a), _ends(b)))
    d = sum(abs(x - y) for x, y in zip(a['box'], b['box']))
    if a.get('text', '').strip() != b.get('text', '').strip():
        d += 3
    return d


def _label(r):
    t = (r.get('text') or '').strip().replace('\n', ' ').replace('\v', ' ')
    what = {'text': 'text', 'shape': 'shape', 'picture': 'picture', 'object': 'object', 'line': 'line',
            'table': 'table', 'chart': 'chart'}[r['kind']]
    return f"{what} '{r['name']}'" + (f' ("{t[:30]}{"…" if len(t) > 30 else ""}")' if t else '')


def _chars(paras):
    """Per character: its explicit formatting (so runs split or merged differently still compare)."""
    out = []
    for pa, runs in paras:
        for t, k in runs:
            out += [k] * len(t)
        out.append(None)
    return out


def compare_shape(n, o, r, issues, template):
    lab = _label(o)
    ob, rb = o['box'], r['box']
    if o['kind'] == 'line' and r['kind'] == 'line' and ob and rb:  # a line: where its two ends are
        eo, er = _ends(o), _ends(r)
        if max(abs(a - b) for a, b in zip(eo, er)) > TOL:
            issues.append(Issue(n, 'error', lab, f'runs from ({er[0]:g}, {er[1]:g}) to ({er[2]:g}, {er[3]:g}) in instead '
                                                 f'of ({eo[0]:g}, {eo[1]:g}) to ({eo[2]:g}, {eo[3]:g})'))
        ob = rb = None
    elif ob and rb:
        dx, dy, dw, dh = (rb[i] - ob[i] for i in range(4))
        if abs(dx) > TOL or abs(dy) > TOL:
            issues.append(Issue(n, 'error', lab, 'moved ' + ', '.join(
                f'{abs(v):.2f} in {d}' for v, d in ((dx, 'right' if dx > 0 else 'left'), (dy, 'down' if dy > 0 else 'up'))
                if abs(v) > TOL)))
        if abs(dw) > TOL or abs(dh) > TOL:
            issues.append(Issue(n, 'error', lab, f'size {rb[2]:.2f} x {rb[3]:.2f} in instead of {ob[2]:.2f} x {ob[3]:.2f}'))
    if o['kind'] != 'line' and abs((r['rot'] - o['rot'] + 180) % 360 - 180) > 0.5:
        issues.append(Issue(n, 'error', lab, f'rotated {r["rot"]:g}° instead of {o["rot"]:g}°'))
    if r['flip'] != o['flip'] and o['kind'] != 'line':
        issues.append(Issue(n, 'error', lab, 'flipped differently'))
    ot, rt = (o.get('text') or '').strip(), (r.get('text') or '').strip()
    if ot != rt and ot.upper() == rt:
        if not any(k.get('cap') == 'all' for _, rs in o.get('paras', ()) for _, k in rs):
            issues.append(Issue(n, 'note', lab, 'written in capitals, as the original shows it through its style'))
        ot = rt  # capitals written out instead of the all-caps setting
    if ot != rt:
        i = next((k for k in range(min(len(ot), len(rt))) if ot[k] != rt[k]), min(len(ot), len(rt)))
        issues.append(Issue(n, 'error', lab, f'text differs at "{ot[max(0, i - 10):i + 20]}" -> "{rt[max(0, i - 10):i + 20]}"'))
        return
    if o.get('paras') and r.get('paras') and template:
        for k, (op, rp) in enumerate(zip(o['paras'], r['paras'])):
            for a, v in op[0].items():
                if rp[0].get(a) != v and not (a in ('marL', 'indent') and abs(int(rp[0].get(a) or 0) - int(v)) < 1500):
                    what = {'algn': 'alignment', 'lvl': 'outline level', 'marL': 'left indent', 'indent': 'first-line indent'}[a]
                    issues.append(Issue(n, 'error', lab, f'paragraph {k + 1}: {what} {rp[0].get(a)} instead of {v}'))
        oc, rc = _chars(o['paras']), _chars(r['paras'])
        for i, (a, b) in enumerate(zip(oc, rc)):
            if a and b is not None:
                diff = [k for k, v in a.items() if b.get(k) != v and not (k == 'color' and _same_colour(v, b.get(k)))
                        and not (k == 'cap' and v == 'all')]
                if diff:
                    txt = o['text'].replace('\n', '')
                    issues.append(Issue(n, 'error', lab, f'character formatting differs ({", ".join(diff)}) near "'
                                                         f'{txt[max(0, i - 5):i + 15]}"'))
                    break
    if template:
        for key, what in (('fill', 'fill'), ('line', 'outline')):
            ov, rv = o.get(key), r.get(key)
            if key == 'fill' and (o['kind'] == 'line' or o['kind'] == 'picture' and ov == ('none',) and rv is None):
                continue  # lines and pictures have no fill either way
            if ov is None:
                continue  # inherited from the shape's theme style: compared on screen, not here
            if ov != rv and not (key == 'fill' and ov[0] == 'solid' and rv and rv[0] == 'solid' and
                                                    _same_colour(ov[1], rv[1])):
                if not (key == 'line' and rv and _same_line(ov, rv)):
                    issues.append(Issue(n, 'error', lab, f'{what} {_desc(rv)} instead of {_desc(ov)}'))
    if o['kind'] == 'picture' and r['kind'] == 'picture':
        if o.get('image') and r.get('image') and o['image'] != r['image']:
            issues.append(Issue(n, 'error', lab, 'shows a different picture'))
        if any(abs(a - b) > 1 for a, b in zip(o.get('crop', ()), r.get('crop', ()))):
            issues.append(Issue(n, 'error', lab, f'cropped {r["crop"]} % instead of {o["crop"]} %'))
    oc = o.get('click')
    if oc and oc[0] == 'slide':  # the target's number in the rebuilt deck
        oc = ('slide', NUMS[oc[1]]) if oc[1] in NUMS else ('missing', f'slide {oc[1]} of the original, not converted')
    og, rg = o.get('geom'), r.get('geom')
    if o['kind'] in ('shape', 'text') and og and rg and og != rg and 'custom' not in (og, rg):
        issues.append(Issue(n, 'error', lab, f'outline {rg} instead of {og}'))
    rc = r.get('click')
    if oc != rc:
        def where(c):
            return 'nowhere' if not c else f'slide {c[1]}' if c[0] == 'slide' else str(c[1])
        issues.append(Issue(n, 'error', lab, f'a click goes to {where(rc)} instead of {where(oc)}'))
    if o['kind'] == 'table' and o.get('cells') != r.get('cells'):
        issues.append(Issue(n, 'error', lab, 'table cells differ'))
    if o['kind'] == 'chart' and o.get('chart') and r.get('chart'):
        if o['chart'][0] != r['chart'][0]:
            issues.append(Issue(n, 'error', lab, f'chart type {"/".join(r["chart"][0])} instead of {"/".join(o["chart"][0])}'))
        elif o['chart'][1:] != r['chart'][1:]:
            issues.append(Issue(n, 'error', lab, 'chart data differs'))


def _same_colour(a, b):
    if a == b:
        return True
    try:
        return bool(a and b) and abs(a[1] - b[1]) <= 2 and all(abs(int(a[0][i:i + 2], 16) - int(b[0][i:i + 2], 16)) <= 4
                                                             for i in (0, 2, 4))
    except (ValueError, TypeError):
        return False


def _same_line(a, b):
    if a[0] == ('none',) and b[0] == ('none',):
        return True  # no line: its width does not matter
    if a[1] == '0' and b[1] is None:  # width 0 (hairline): python-pptx writes no width for 0
        a = (a[0], None)
    return (a[0] is None or a[0] == b[0] or (b[0] and a[0][0] == b[0][0] == 'solid' and _same_colour(a[0][1], b[0][1]))) and \
        (a[1] is None or b[1] is not None and abs(int(a[1]) - int(b[1])) < 200)


def _desc(v):
    if v is None:
        return 'unset'
    if isinstance(v[0], tuple) or v[0] is None:
        return f'{_desc(v[0])}, width {v[1]}'
    return v[0] + (f' {v[1][0]}' if len(v) > 1 and isinstance(v[1], tuple) and v[1] else
                   f' {v[1]}' if len(v) > 1 and v[1] is not None else '')


def compare_slide(n, so, sr, template, cv_o, cv_r, report):
    issues = report.issues
    TH['theme'] = Theme(so.slide_layout.slide_master)
    lo = leaves(so, cv_o)
    if not template and so._element.get('showMasterSp') not in ('0', 'false'):  # the master's and layout's own
        lay = so.slide_layout                                                       # shapes are drawn on the slide
        owners = ([] if lay._element.get('showMasterSp') in ('0', 'false') else [lay.slide_master]) + [lay]
        lo = [r for o in owners for r in leaves(o, cv_o) if not r.get('ph')] + lo
    TH['theme'] = Theme(sr.slide_layout.slide_master)
    lr = leaves(sr, cv_r)
    report.shapes += len(lo)
    used, pairs = set(), []
    for o in lo:
        best, bs = None, None
        for j, r in enumerate(lr):
            if j in used:
                continue
            s = _score(o, r)
            if s is not None and (bs is None or s < bs):
                best, bs = j, s
        if best is not None and bs < 4.5:
            used.add(best)
            pairs.append((o, lr[best]))
        else:
            issues.append(Issue(n, 'error', _label(o), 'missing from the rebuilt slide'))
    for j, r in enumerate(lr):
        if j not in used:
            issues.append(Issue(n, 'error', _label(r), 'is extra on the rebuilt slide'))
    report.matched += len(pairs)
    for o, r in pairs:
        compare_shape(n, o, r, issues, template)
    order = [lr.index(r) for _, r in pairs]
    if any(a > b for a, b in zip(order, order[1:])):
        issues.append(Issue(n, 'note', '', 'some shapes are stacked in a different order'))
    if template and so.slide_layout.name != sr.slide_layout.name:
        issues.append(Issue(n, 'error', '', f'layout "{sr.slide_layout.name}" instead of "{so.slide_layout.name}"'))
    if (so._element.get('show') in ('0', 'false')) != (sr._element.get('show') in ('0', 'false')):
        issues.append(Issue(n, 'error', '', 'hidden / shown differs'))
    to, tr = read_transition(so._element), read_transition(sr._element)
    clean = (lambda t: {k: v for k, v in (t or {}).items() if k != 'sound' and not (k == 'kind' and v == 'none')
                        and not (t.get('kind') == 'none' and k in ('speed', 'dur'))})
    if clean(to) != clean(tr):
        issues.append(Issue(n, 'error', '', f'slide transition {tr} instead of {to}'))
    elif to and to.get('sound'):
        issues.append(Issue(n, 'note', '', 'transition sound left out'))
    spid = {o['spid']: r['spid'] for o, r in pairs}
    ao, ar = read_timing(so._element), read_timing(sr._element)
    so_, sr_ = summary(ao, spid), summary(ar, {r['spid']: r['spid'] for _, r in pairs})
    if so_ != sr_:
        miss = len([x for x in so_ if x not in sr_])
        issues.append(Issue(n, 'error', '', f'animations differ: {len(sr_)} effects instead of {len(so_)}'
                                            + (f', {miss} not matching' if miss else '')))
    no = so.notes_slide.notes_text_frame.text.strip() if so.has_notes_slide and so.notes_slide.notes_text_frame else ''
    nr = sr.notes_slide.notes_text_frame.text.strip() if sr.has_notes_slide and sr.notes_slide.notes_text_frame else ''
    if no != nr:
        issues.append(Issue(n, 'error', '', 'speaker notes differ'))


def _listed(rep, known):
    """Differences the converter already reported (left out, or drawn another way) are marked 'listed'."""
    known = list(known or ())
    for i in rep.issues:
        if i.level != 'error':
            continue
        m = re.search(r"'(.*?)'", i.shape)
        head = f'slide {i.slide}: '
        mine = [k[len(head):] for k in known if k.startswith(head)]
        if any((m and k.startswith(m[1] + ': ')) or (not i.shape and word in i.message and word in k)
               for k in mine for word in ('animation', 'transition')) or \
                (i.shape.startswith('picture') and 'extra' in i.message and any('ActiveX control' in k for k in mine)) or \
                (i.shape.startswith('text') and 'extra' in i.message and any('SmartArt saved without' in k for k in mine)):
            i.level = 'listed'


def compare(original, rebuilt, slides=None, template=True, known=None):
    """Report the differences between an original deck and its rebuilt copy. slides: the original's slide numbers
    that were converted (in order); template: whether the rebuilt deck kept the original's template; known: the
    converter's messages (Result.skipped + Result.notes), so differences it already reported are marked."""
    def load(x):
        return open_deck(x)
    po, pr = load(original), load(rebuilt)
    data_o = original if isinstance(original, bytes) else open(original, 'rb').read()
    data_r = rebuilt if isinstance(rebuilt, bytes) else open(rebuilt, 'rb').read()
    cv_o, cv_r = Converter(data_o), Converter(data_r)
    so = list(po.slides)
    nums = slides or list(range(1, len(so) + 1))
    sr = list(pr.slides)
    rep = Report(slides=len(nums))
    NUMS.clear()
    NUMS.update({n: k for k, n in enumerate(nums, 1)})
    if len(sr) != len(nums):
        rep.issues.append(Issue(0, 'error', '', f'{len(sr)} slides instead of {len(nums)}'))
    if (po.slide_width, po.slide_height) != (pr.slide_width, pr.slide_height):
        rep.issues.append(Issue(0, 'error', '', 'slide size differs'))
    for k, (n, s2) in enumerate(zip(nums, sr)):
        compare_slide(n, so[n - 1], s2, template, cv_o, cv_r, rep)
    _listed(rep, known)
    return rep
