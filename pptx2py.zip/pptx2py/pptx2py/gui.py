"""Desktop app: python -m pptx2py (needs PySide6: pip install PySide6)."""
import sys


def main(deck=None):
    try:
        import PySide6  # noqa: F401
    except ImportError:
        sys.exit('The desktop app needs PySide6:  pip install PySide6\n'
                 '(The command line works without it: python -m pptx2py deck.pptx)')
    from .app import main as run
    return run(deck)


if __name__ == '__main__':
    main(*sys.argv[1:2])
