"""Builds specimen.pptx: one old-fashioned example of every component kind.

The style gallery renders these slides in every style so you can compare designs side by side.
    python samples/make_specimen.py            # writes samples/specimen.pptx
"""
import io
import math
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.util import Inches, Pt

# slide number of each gallery kind in the specimen deck
SPECIMEN_SLIDES = {'chart': 1, 'heatmap': 2, 'table': 3, 'card': 4, 'shape': 5, 'flow': 6, 'picture': 7,
                   'title': 8, 'text': 8, 'background': 8}
OLD_BLUE, OLD_RED, OLD_GREEN = RGBColor(0x1F, 0x49, 0x7D), RGBColor(0xC0, 0x50, 0x4D), RGBColor(0x9B, 0xBB, 0x59)


def _photo(w=900, h=600):
    """A synthetic landscape photo (sky gradient, sun, layered hills)."""
    img = Image.new('RGB', (w, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / h
        d.line([(0, y), (w, y)], fill=(int(255 - 120 * t), int(190 - 60 * t), int(140 + 60 * t)))
    d.ellipse([w * 0.62, h * 0.18, w * 0.78, h * 0.42], fill=(255, 236, 190))
    for k, (col, base, amp) in enumerate([((94, 84, 142), 0.62, 0.10), ((58, 64, 110), 0.72, 0.08),
                                          ((30, 38, 70), 0.84, 0.06)]):
        pts = [(x, h * base - h * amp * math.sin(x / w * math.pi * (2 + k) + k)) for x in range(0, w + 10, 10)]
        d.polygon(pts + [(w, h), (0, h)], fill=col)
    img = img.filter(ImageFilter.GaussianBlur(0.6))
    buf = io.BytesIO()
    img.save(buf, 'JPEG', quality=88)
    buf.seek(0)
    return buf


def _title(slide, text):
    t = slide.shapes.title
    t.text = text
    for p in t.text_frame.paragraphs:
        for r in p.runs:
            r.font.color.rgb = OLD_BLUE
            r.font.name = 'Times New Roman'
            r.font.bold = True
    return t


def build():
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    title_only = prs.slide_layouts[5]

    # 1 charts: clustered column + pie
    s = prs.slides.add_slide(title_only)
    _title(s, 'Revenue by Quarter')
    cd = CategoryChartData()
    cd.categories = ['Q1', 'Q2', 'Q3', 'Q4']
    cd.add_series('North', (12.1, 14.3, 13.8, 16.2))
    cd.add_series('South', (9.4, 10.2, 11.9, 12.5))
    cd.add_series('West', (7.2, 8.8, 9.1, 10.4))
    ch = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.6), Inches(1.6), Inches(7.6), Inches(5.4), cd).chart
    ch.has_legend, ch.legend.position, ch.legend.include_in_layout = True, XL_LEGEND_POSITION.RIGHT, False
    ch.value_axis.has_major_gridlines = True
    pd = CategoryChartData()
    pd.categories = ['Us', 'Rival A', 'Rival B', 'Others']
    pd.add_series('Share', (38, 27, 21, 14))
    pie = s.shapes.add_chart(XL_CHART_TYPE.PIE, Inches(8.5), Inches(1.6), Inches(4.3), Inches(5.4), pd).chart
    pie.has_legend, pie.legend.position = True, XL_LEGEND_POSITION.BOTTOM
    pie.plots[0].has_data_labels = True

    # 2 heatmap: numeric table
    s = prs.slides.add_slide(title_only)
    _title(s, 'Weekly Sign-ups by Region')
    days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    data = [('North', [42, 55, 61, 58, 72, 31, 24]), ('South', [35, 38, 44, 51, 49, 22, 18]),
            ('East', [58, 63, 70, 76, 81, 40, 33]), ('West', [21, 26, 30, 28, 35, 15, 12]),
            ('Central', [47, 50, 53, 66, 69, 37, 29]), ('Online', [80, 84, 88, 91, 95, 74, 68])]
    tbl = s.shapes.add_table(len(data) + 1, 8, Inches(0.8), Inches(1.7), Inches(11.7), Inches(4.9)).table
    tbl.cell(0, 0).text = 'Region'
    for j, dname in enumerate(days, 1):
        tbl.cell(0, j).text = dname
    for i, (reg, vals) in enumerate(data, 1):
        tbl.cell(i, 0).text = reg
        for j, v in enumerate(vals, 1):
            tbl.cell(i, j).text = str(v)

    # 3 table: text + numbers + total
    s = prs.slides.add_slide(title_only)
    _title(s, 'Regional Results')
    rows = [('Region', 'Lead', 'Revenue', 'Growth', 'Margin'), ('North', 'A. Rao', '$56.4M', '11%', '18%'),
            ('South', 'M. Chen', '$44.0M', '14%', '16%'), ('East', 'J. Diaz', '$38.2M', '9%', '17%'),
            ('West', 'S. Iyer', '$35.5M', '7%', '15%'), ('Total', '', '$174.1M', '11%', '17%')]
    tbl = s.shapes.add_table(len(rows), 5, Inches(0.8), Inches(1.7), Inches(11.7), Inches(4.6)).table
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            tbl.cell(i, j).text = v

    # 4 cards: KPI boxes with dated bevels/gradients
    s = prs.slides.add_slide(title_only)
    _title(s, 'Key Highlights')
    kpis = [('$4.2M', 'Revenue this quarter', '+16.1% vs last quarter'),
            ('1,204', 'New customers', '+8.4% vs last quarter'),
            ('98%', 'Customer retention', '−0.6% vs last quarter'),
            ('3', 'New offices', 'Opened in Q3')]
    for k, (num, lab, note) in enumerate(kpis):
        box = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.6 + k * 3.1), Inches(2.0), Inches(2.85), Inches(2.5))
        box.fill.gradient()
        box.fill.gradient_stops[0].color.rgb = RGBColor(0x4F, 0x81, 0xBD)
        box.fill.gradient_stops[1].color.rgb = RGBColor(0x1F, 0x49, 0x7D)
        box.line.color.rgb = RGBColor(0x38, 0x5D, 0x8A)
        tf = box.text_frame
        tf.text = num
        tf.paragraphs[0].runs[0].font.size = Pt(36)
        tf.paragraphs[0].runs[0].font.bold = True
        for line, size in ((lab, 16), (note, 12)):
            p = tf.add_paragraph()
            p.text = line
            p.runs[0].font.size = Pt(size)

    # 5 shapes: chevron process + call-out arrows
    s = prs.slides.add_slide(title_only)
    _title(s, 'Our Approach')
    for k, txt in enumerate(['Discover', 'Design', 'Build', 'Launch']):
        sh = s.shapes.add_shape(MSO_SHAPE.CHEVRON if k else MSO_SHAPE.PENTAGON, Inches(0.8 + k * 3.0), Inches(2.2),
                                Inches(3.1), Inches(1.4))
        sh.fill.solid()
        sh.fill.fore_color.rgb = [OLD_BLUE, OLD_RED, OLD_GREEN, RGBColor(0x80, 0x64, 0xA2)][k]
        sh.text_frame.text = txt
        sh.text_frame.paragraphs[0].runs[0].font.size = Pt(20)
    for k, txt in enumerate(['Faster delivery', 'Lower cost', 'Happier users']):
        sh = s.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(1.2 + k * 3.9), Inches(4.5), Inches(3.4), Inches(1.3))
        sh.fill.solid()
        sh.fill.fore_color.rgb = RGBColor(0xF7, 0x96, 0x46)
        sh.text_frame.text = txt

    # 6 flowchart
    s = prs.slides.add_slide(title_only)
    _title(s, 'Order Approval Process')
    spec = [(MSO_SHAPE.FLOWCHART_TERMINATOR, 'Request'), (MSO_SHAPE.FLOWCHART_PROCESS, 'Review'),
            (MSO_SHAPE.FLOWCHART_DECISION, 'Approved?'), (MSO_SHAPE.FLOWCHART_PROCESS, 'Ship'),
            (MSO_SHAPE.FLOWCHART_TERMINATOR, 'Close')]
    nodes = []
    for k, (shape, txt) in enumerate(spec):
        w = 2.1 if shape != MSO_SHAPE.FLOWCHART_DECISION else 2.2
        n = s.shapes.add_shape(shape, Inches(0.5 + k * 2.55), Inches(3.0), Inches(w), Inches(1.3))
        n.fill.solid()
        n.fill.fore_color.rgb = RGBColor(0xFF, 0xD9, 0x66)
        n.line.color.rgb = RGBColor(0x7F, 0x60, 0x00)
        n.text_frame.text = txt
        r = n.text_frame.paragraphs[0].runs[0]
        r.font.color.rgb, r.font.size = RGBColor(0, 0, 0), Pt(16)
        nodes.append(n)
    for a, b in zip(nodes, nodes[1:]):
        c = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, 0, 0, 0, 0)
        c.begin_connect(a, 3)
        c.end_connect(b, 1)
        c.line.color.rgb = RGBColor(0, 0, 0)
        ln = c.line._get_or_add_ln()
        from lxml import etree
        ln.append(etree.fromstring('<a:tailEnd xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
                                   'type="triangle"/>'))
    back = s.shapes.add_shape(MSO_SHAPE.FLOWCHART_PROCESS, Inches(5.6), Inches(5.3), Inches(2.1), Inches(1.0))
    back.fill.solid()
    back.fill.fore_color.rgb = RGBColor(0xFF, 0xD9, 0x66)
    back.text_frame.text = 'Rework'
    back.text_frame.paragraphs[0].runs[0].font.color.rgb = RGBColor(0, 0, 0)
    c = s.shapes.add_connector(MSO_CONNECTOR.ELBOW, 0, 0, 0, 0)
    c.begin_connect(nodes[2], 2)
    c.end_connect(back, 3)
    c.line.color.rgb = RGBColor(0, 0, 0)

    # 7 pictures
    s = prs.slides.add_slide(title_only)
    _title(s, 'Where We Work')
    pic = s.shapes.add_picture(_photo(), Inches(0.8), Inches(1.7), Inches(7.2), Inches(4.8))
    pic.line.color.rgb, pic.line.width = RGBColor(0, 0, 0), Pt(3)
    s.shapes.add_picture(_photo(600, 600), Inches(8.6), Inches(1.7), Inches(4.0), Inches(4.0))

    # 8 title + body text (also used for backgrounds)
    s = prs.slides.add_slide(prs.slide_layouts[1])
    _title(s, 'Quarterly Business Review')
    body = s.placeholders[1].text_frame
    body.text = 'Revenue grew 18% year over year'
    for line, lvl in [('All four regions beat their targets', 1), ('Customer retention reached 98%', 0),
                      ('Two new offices opened in Q3', 0), ('Hiring plan approved for 2025', 1)]:
        p = body.add_paragraph()
        p.text, p.level = line, lvl
    for p in body.paragraphs:
        for r in p.runs:
            r.font.name, r.font.color.rgb = 'Times New Roman', RGBColor(0x40, 0x40, 0x40)
    return prs


if __name__ == '__main__':
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name('specimen.pptx')
    build().save(out)
    print(out)
