"""Build a deliberately dated 'classic corporate' deck to test modernising conversion.

Old-school traits: Office-2007 colours, Times/Comic Sans/Arial Black type, bevelled 3-D
gradient boxes with heavy black outlines, charts with borders + major/minor gridlines +
legend on the right, fully boxed tables, thick black flowchart arrows, framed clip-art-ish
picture, drop-shadowed WordArt-like titles.

    python samples/make_old_deck.py samples/old_deck.pptx
"""
import io
import sys

from PIL import Image, ImageDraw
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.oxml import parse_xml
from pptx.util import Inches, Pt

NS = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"')
NAVY, RED, GREEN, GOLD, BLACK = (RGBColor(0x1F, 0x49, 0x7D), RGBColor(0xC0, 0x50, 0x4D), RGBColor(0x9B, 0xBB, 0x59),
                                 RGBColor(0xF7, 0x96, 0x46), RGBColor(0, 0, 0))


def el(xml):
    return parse_xml(f'<w {NS}>{xml}</w>')[0]


def old_title(shape, text, size=36):
    shape.text_frame.text = text
    r = shape.text_frame.paragraphs[0].runs[0]
    r.font.name, r.font.size, r.font.bold = 'Arial Black', Pt(size), True
    r.font.color.rgb = NAVY
    rpr = r._r.get_or_add_rPr()
    rpr.append(el('<a:effectLst><a:outerShdw blurRad="38100" dist="38100" dir="2700000" algn="tl">'
                  '<a:srgbClr val="808080"><a:alpha val="60000"/></a:srgbClr></a:outerShdw></a:effectLst>'))


def bevel_box(shape, top, bottom):
    shape.fill.gradient()
    shape.fill.gradient_angle = 90
    shape.fill.gradient_stops[0].color.rgb = top
    shape.fill.gradient_stops[1].color.rgb = bottom
    shape.line.color.rgb = BLACK
    shape.line.width = Pt(2.25)
    sp = shape._element.spPr
    sp.append(el('<a:effectLst><a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0">'
                 '<a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw></a:effectLst>'))
    sp.append(el('<a:scene3d><a:camera prst="orthographicFront"/><a:lightRig rig="threePt" dir="t"/></a:scene3d>'))
    sp.append(el('<a:sp3d><a:bevelT w="63500" h="25400"/></a:sp3d>'))


def runs(shape, font, size, color, bold=False):
    for p in shape.text_frame.paragraphs:
        for r in p.runs:
            r.font.name, r.font.size, r.font.bold = font, Pt(size), bold
            r.font.color.rgb = color


def old_chart(gf, minor=True):
    cs = gf.chart._chartSpace
    cs.append(el('<c:spPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>'
                 '<a:ln w="25400"><a:solidFill><a:srgbClr val="000000"/></a:solidFill></a:ln></c:spPr>'))
    pa = cs.find('.//{http://schemas.openxmlformats.org/drawingml/2006/chart}plotArea')
    for ax in pa:
        if ax.tag.endswith('valAx'):
            delete = ax.find('{http://schemas.openxmlformats.org/drawingml/2006/chart}delete')
            delete.addnext(el('<c:majorGridlines><c:spPr><a:ln w="9525"><a:solidFill><a:srgbClr val="808080"/>'
                              '</a:solidFill></a:ln></c:spPr></c:majorGridlines>'))
            if minor:
                ax.find('{http://schemas.openxmlformats.org/drawingml/2006/chart}majorGridlines').addnext(
                    el('<c:minorGridlines><c:spPr><a:ln w="3175"><a:solidFill><a:srgbClr val="C0C0C0"/>'
                       '</a:solidFill><a:prstDash val="dash"/></a:ln></c:spPr></c:minorGridlines>'))
    pa.append(el('<c:spPr><a:solidFill><a:srgbClr val="EAEAEA"/></a:solidFill>'
                 '<a:ln w="9525"><a:solidFill><a:srgbClr val="808080"/></a:solidFill></a:ln></c:spPr>'))


def clipart():
    img = Image.new('RGB', (600, 400), (255, 255, 204))
    d = ImageDraw.Draw(img)
    d.rectangle([60, 220, 540, 360], fill=(102, 153, 51))
    d.polygon([(150, 220), (300, 90), (450, 220)], fill=(204, 51, 51))
    d.rectangle([200, 220, 400, 340], fill=(255, 204, 102), outline=(0, 0, 0), width=4)
    d.rectangle([275, 270, 325, 340], fill=(102, 51, 0))
    d.ellipse([470, 30, 560, 120], fill=(255, 220, 0), outline=(255, 153, 0), width=6)
    buf = io.BytesIO()
    img.save(buf, 'PNG')
    buf.seek(0)
    return buf


def build(path):
    prs = Presentation()  # 4:3, like the old days
    L = prs.slide_layouts

    s = prs.slides.add_slide(L[0])
    old_title(s.shapes.title, 'ANNUAL SALES REVIEW 2009', 40)
    s.placeholders[1].text = 'Prepared by the Regional Sales Department'
    runs(s.placeholders[1], 'Times New Roman', 24, BLACK, True)

    s = prs.slides.add_slide(L[5])
    old_title(s.shapes.title, 'Key Highlights')
    for i, (txt, top, bot) in enumerate((('Sales up 12%', RGBColor(0x9D, 0xC3, 0xE6), NAVY),
                                         ('3 new offices', RGBColor(0xE6, 0xB9, 0xB8), RED),
                                         ('98% retention', RGBColor(0xD7, 0xE4, 0xBD), GREEN))):
        b = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.5 + i * 3.05), Inches(2.2), Inches(2.8), Inches(2.0))
        bevel_box(b, top, bot)
        b.text_frame.text = txt
        b.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        runs(b, 'Comic Sans MS', 22, RGBColor(255, 255, 255), True)
    note = s.shapes.add_textbox(Inches(0.5), Inches(4.8), Inches(9), Inches(1.6))
    note.text_frame.word_wrap = True
    note.text_frame.text = 'Strong performance across all regions.'
    p = note.text_frame.add_paragraph()
    p.text = 'Targets for 2010 have been raised accordingly.'
    runs(note, 'Times New Roman', 20, BLACK)

    s = prs.slides.add_slide(L[5])
    old_title(s.shapes.title, 'Quarterly Revenue ($M)')
    cd = CategoryChartData()
    cd.categories = ['Q1', 'Q2', 'Q3', 'Q4']
    cd.add_series('North', (12.1, 14.3, 13.8, 16.2))
    cd.add_series('South', (9.4, 10.2, 11.9, 12.5))
    cd.add_series('West', (7.2, 8.8, 9.1, 10.4))
    gf = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.4), Inches(1.5), Inches(9.2), Inches(5.6), cd)
    gf.chart.has_legend = True
    gf.chart.legend.position = XL_LEGEND_POSITION.RIGHT
    gf.chart.has_title = True
    gf.chart.chart_title.text_frame.text = 'Revenue by Region'
    for ser, col in zip(gf.chart.plots[0].series, (NAVY, RED, GREEN)):
        ser.format.fill.solid()
        ser.format.fill.fore_color.rgb = col
        ser.format.line.color.rgb = BLACK
    old_chart(gf)

    s = prs.slides.add_slide(L[5])
    old_title(s.shapes.title, 'Market Share')
    cd = CategoryChartData()
    cd.categories = ['Us', 'Competitor A', 'Competitor B', 'Others']
    cd.add_series('Share', (0.38, 0.27, 0.21, 0.14))
    gf = s.shapes.add_chart(XL_CHART_TYPE.PIE, Inches(0.4), Inches(1.5), Inches(4.6), Inches(5.2), cd)
    gf.chart.has_legend = True
    gf.chart.legend.position = XL_LEGEND_POSITION.RIGHT
    gf.chart.plots[0].has_data_labels = True
    gf.chart.plots[0].data_labels.number_format = '0%'
    gf.chart.plots[0].data_labels.number_format_is_linked = False
    old_chart(gf, minor=False)
    cd2 = CategoryChartData()
    cd2.categories = ['2005', '2006', '2007', '2008', '2009']
    cd2.add_series('Customers (k)', (41, 47, 52, 58, 66))
    g2 = s.shapes.add_chart(XL_CHART_TYPE.LINE_MARKERS, Inches(5.1), Inches(1.5), Inches(4.5), Inches(5.2), cd2)
    g2.chart.has_legend = True
    g2.chart.legend.position = XL_LEGEND_POSITION.RIGHT
    old_chart(g2)

    s = prs.slides.add_slide(L[5])
    old_title(s.shapes.title, 'Regional Results')
    data = [('Region', 'Revenue', 'Growth', 'Margin'), ('North', '$56.4M', '11%', '18%'),
            ('South', '$44.0M', '14%', '16%'), ('West', '$35.5M', '9%', '15%'), ('Total', '$135.9M', '12%', '17%')]
    t = s.shapes.add_table(5, 4, Inches(0.6), Inches(1.8), Inches(8.8), Inches(3.4)).table
    for ri, row in enumerate(data):
        for ci, v in enumerate(row):
            c = t.cell(ri, ci)
            c.text = v
            r = c.text_frame.paragraphs[0].runs[0]
            r.font.name, r.font.size, r.font.bold = 'Times New Roman', Pt(18), ri in (0, 4)
            r.font.color.rgb = RGBColor(255, 255, 255) if ri == 0 else BLACK
            c.fill.solid()
            c.fill.fore_color.rgb = NAVY if ri == 0 else RGBColor(0xFF, 0xFF, 0xCC) if ri == 4 else RGBColor(255, 255, 255)
            tcPr = c._tc.get_or_add_tcPr()
            for side in ('lnL', 'lnR', 'lnT', 'lnB'):
                tcPr.insert(0 if side == 'lnL' else len([x for x in tcPr if x.tag.split('}')[1].startswith('ln')]),
                            el(f'<a:{side} w="25400"><a:solidFill><a:srgbClr val="000000"/></a:solidFill></a:{side}>'))

    s = prs.slides.add_slide(L[5])
    old_title(s.shapes.title, 'Order Approval Process')
    labels = [('Request', MSO_SHAPE.FLOWCHART_TERMINATOR), ('Review', MSO_SHAPE.FLOWCHART_PROCESS),
              ('Approved?', MSO_SHAPE.FLOWCHART_DECISION), ('Ship', MSO_SHAPE.FLOWCHART_PROCESS),
              ('Close', MSO_SHAPE.FLOWCHART_TERMINATOR)]
    nodes = []
    for i, (lbl, kind) in enumerate(labels):
        n = s.shapes.add_shape(kind, Inches(0.2 + i * 1.95), Inches(3.0), Inches(1.6), Inches(1.1))
        bevel_box(n, RGBColor(0xFF, 0xFF, 0x99), GOLD)
        n.text_frame.text = lbl
        runs(n, 'Arial', 14, BLACK, True)
        nodes.append(n)
    for a, b in zip(nodes, nodes[1:]):
        c = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, 0, 0, 0, 0)
        c.begin_connect(a, 3)
        c.end_connect(b, 1)
        c.line.color.rgb = BLACK
        c.line.width = Pt(3)
        c.line._get_or_add_ln().append(el('<a:tailEnd type="stealth" w="lg" len="lg"/>'))
    pic = s.shapes.add_picture(clipart(), Inches(7.2), Inches(4.9), Inches(2.4), Inches(1.6))
    pic.line.color.rgb = BLACK
    pic.line.width = Pt(4)

    prs.save(path)
    print('saved', path)


if __name__ == '__main__':
    build(sys.argv[1] if len(sys.argv) > 1 else 'old_deck.pptx')
