"""Build a feature-rich sample deck used to test PPTX → Python conversion.

Covers: mixed fonts/sizes/colours, bullets, hyperlinks, internal slide jumps,
flowchart shapes + elbow/straight connectors, gradients, shadows, rotation,
groups, pictures with crop, bar/line/pie/doughnut charts, styled tables,
slide backgrounds, transitions (incl. a PowerPoint 2010 p14 transition inside
mc:AlternateContent), entrance/emphasis animations, notes and a hidden slide.

    python samples/make_sample.py samples/sample_deck.pptx
"""
import io
import sys

from lxml import etree
from PIL import Image, ImageDraw
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.enum.dml import MSO_THEME_COLOR
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml import parse_xml
from pptx.util import Emu, Inches, Pt

NS = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
      'xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main"')

INK = RGBColor(0x14, 0x1B, 0x2D)
TEAL = RGBColor(0x0E, 0xA5, 0x9B)
CORAL = RGBColor(0xF2, 0x6B, 0x5B)
AMBER = RGBColor(0xF5, 0xA6, 0x23)
SLATE = RGBColor(0x5B, 0x67, 0x7A)


def _el(xml):
    return parse_xml(xml.replace('<root>', f'<root {NS}>'))[0]


def set_transition(slide, xml):
    sld = slide._element
    node = _el(f'<root>{xml}</root>')
    # transition must follow clrMapOvr, precede timing
    timing = sld.find('{http://schemas.openxmlformats.org/presentationml/2006/main}timing')
    if timing is not None:
        timing.addprevious(node)
    else:
        sld.append(node)


def set_animations(slide, effects):
    """effects: list of (spid, presetClass, presetID, filter_or_None, trigger)"""
    ctn = [3]

    def nid():
        ctn[0] += 1
        return ctn[0]

    pars = []
    for spid, pclass, pid, flt, trig in effects:
        outer, mid, inner, setid, efid = nid(), nid(), nid(), nid(), nid()
        node = 'clickEffect' if trig == 'click' else 'withEffect'
        behaviours = ''
        if pclass == 'entr':
            behaviours += (f'<p:set><p:cBhvr><p:cTn id="{setid}" dur="1" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst></p:cTn>'
                           f'<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl><p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst></p:cBhvr>'
                           f'<p:to><p:strVal val="visible"/></p:to></p:set>')
            if flt:
                behaviours += (f'<p:animEffect transition="in" filter="{flt}"><p:cBhvr><p:cTn id="{efid}" dur="600"/>'
                               f'<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl></p:cBhvr></p:animEffect>')
        else:  # emphasis: grow/shrink
            behaviours += (f'<p:animScale><p:cBhvr><p:cTn id="{efid}" dur="500" autoRev="1" fill="hold"/>'
                           f'<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl></p:cBhvr><p:by x="120000" y="120000"/></p:animScale>')
        pars.append(
            f'<p:par><p:cTn id="{outer}" fill="hold"><p:stCondLst><p:cond delay="indefinite"/></p:stCondLst><p:childTnLst>'
            f'<p:par><p:cTn id="{mid}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>'
            f'<p:par><p:cTn id="{inner}" presetID="{pid}" presetClass="{pclass}" presetSubtype="0" fill="hold" nodeType="{node}">'
            f'<p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>{behaviours}</p:childTnLst></p:cTn></p:par>'
            f'</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>')
    xml = ('<p:timing><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst>'
           '<p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>'
           + ''.join(pars) +
           '</p:childTnLst></p:cTn><p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst>'
           '<p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq>'
           '</p:childTnLst></p:cTn></p:par></p:tnLst></p:timing>')
    slide._element.append(_el(f'<root>{xml}</root>'))


def make_image(w=800, h=500):
    img = Image.new('RGB', (w, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / h
        d.line([(0, y), (w, y)], fill=(int(14 + 200 * t), int(165 - 60 * t), int(155 - 40 * t)))
    for i in range(9):
        d.ellipse([60 + i * 80, 120 + (i % 3) * 70, 160 + i * 80, 220 + (i % 3) * 70],
                  outline=(255, 255, 255), width=4)
    d.rectangle([40, 40, w - 40, h - 40], outline=(255, 255, 255), width=3)
    buf = io.BytesIO()
    img.save(buf, 'PNG')
    buf.seek(0)
    return buf


def style_run(run, size, color=None, bold=None, italic=None, font=None, theme=None):
    run.font.size = Pt(size)
    if font:
        run.font.name = font
    if bold is not None:
        run.font.bold = bold
    if italic is not None:
        run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color
    if theme is not None:
        run.font.color.theme_color = theme


def build(path):
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    layouts = prs.slide_layouts

    # ── 1 · Title slide ─────────────────────────────────────────────
    s = prs.slides.add_slide(layouts[0])
    bg = s.background.fill
    bg.gradient()
    bg.gradient_angle = 45
    bg.gradient_stops[0].color.rgb = RGBColor(0x0B, 0x12, 0x20)
    bg.gradient_stops[1].color.rgb = RGBColor(0x12, 0x3A, 0x4A)
    t = s.shapes.title
    t.text_frame.text = 'Quarterly Business Review'
    style_run(t.text_frame.paragraphs[0].runs[0], 54, RGBColor(255, 255, 255), True, font='Georgia')
    sub = s.placeholders[1]
    p = sub.text_frame.paragraphs[0]
    r = p.add_run(); r.text = 'FY26 · Q3 '
    style_run(r, 24, TEAL, True, font='Segoe UI')
    r = p.add_run(); r.text = 'Operations & Growth'
    style_run(r, 24, RGBColor(0xCF, 0xD8, 0xE3), italic=True, font='Segoe UI Light')
    set_transition(s, '<p:transition spd="slow"><p:fade/></p:transition>')
    s.notes_slide.notes_text_frame.text = 'Open with the headline number. Pause after the title.'

    # ── 2 · Rich text ───────────────────────────────────────────────
    s = prs.slides.add_slide(layouts[5])  # title only
    s.shapes.title.text = 'What changed this quarter'
    style_run(s.shapes.title.text_frame.paragraphs[0].runs[0], 36, INK, True, font='Georgia')
    tb = s.shapes.add_textbox(Inches(0.8), Inches(1.7), Inches(7.2), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    items = [
        ('Revenue grew ', '18%', ' year over year', TEAL),
        ('Churn fell to ', '2.1%', ', lowest on record', CORAL),
        ('Three new regions ', 'live', ' — APAC, LATAM, MEA', AMBER),
    ]
    for i, (a, b, c, col) in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.space_after = Pt(14)
        p.line_spacing = 1.15
        pPr = p._p.get_or_add_pPr()
        pPr.set('marL', '342900'); pPr.set('indent', '-342900')
        pPr.append(_el('<root><a:buClr><a:srgbClr val="%s"/></a:buClr></root>' % str(col)))
        pPr.append(_el('<root><a:buFont typeface="Arial"/></root>'))
        pPr.append(_el('<root><a:buChar char="&#8226;"/></root>'))
        for txt, size, color, bold in ((a, 22, SLATE, False), (b, 26, col, True), (c, 22, SLATE, False)):
            r = p.add_run(); r.text = txt
            style_run(r, size, color, bold, font='Calibri')
    p = tf.add_paragraph()
    r = p.add_run(); r.text = 'Full report: '
    style_run(r, 16, SLATE, font='Calibri')
    r = p.add_run(); r.text = 'example.com/qbr'
    style_run(r, 16, TEAL, font='Consolas')
    r.hyperlink.address = 'https://example.com/qbr'
    rPr = r._r.get_or_add_rPr(); rPr.set('spc', '120')
    # rotated callout with shadow
    call = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(8.8), Inches(2.0), Inches(3.6), Inches(2.4))
    call.rotation = -4
    call.adjustments[0] = 0.18
    call.fill.solid(); call.fill.fore_color.rgb = AMBER
    call.line.fill.background()
    call.text_frame.text = 'Record\nquarter'
    for para in call.text_frame.paragraphs:
        para.alignment = PP_ALIGN.CENTER
        style_run(para.runs[0], 32, INK, True, font='Trebuchet MS')
    call.text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    call._element.spPr.append(_el(
        '<root><a:effectLst><a:outerShdw blurRad="190500" dist="76200" dir="5400000" algn="t" rotWithShape="0">'
        '<a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw></a:effectLst></root>'))
    set_transition(s, '<p:transition spd="med"><p:push dir="u"/></p:transition>')
    set_animations(s, [(tb.shape_id, 'entr', 2, None, 'click'),
                       (call.shape_id, 'entr', 10, 'fade', 'click'),
                       (call.shape_id, 'emph', 6, None, 'with')])

    # ── 3 · Flowchart ───────────────────────────────────────────────
    s = prs.slides.add_slide(layouts[5])
    s.shapes.title.text = 'Order processing flow'
    steps = [(MSO_SHAPE.FLOWCHART_TERMINATOR, 'Start', TEAL),
             (MSO_SHAPE.FLOWCHART_PROCESS, 'Validate order', SLATE),
             (MSO_SHAPE.FLOWCHART_DECISION, 'In stock?', AMBER),
             (MSO_SHAPE.FLOWCHART_PROCESS, 'Ship', SLATE),
             (MSO_SHAPE.FLOWCHART_TERMINATOR, 'Done', TEAL)]
    nodes = []
    for i, (kind, label, col) in enumerate(steps):
        sh = s.shapes.add_shape(kind, Inches(0.6 + i * 2.55), Inches(3.0), Inches(2.0), Inches(1.2))
        sh.fill.gradient(); sh.fill.gradient_angle = 90
        sh.fill.gradient_stops[0].color.rgb = col
        sh.fill.gradient_stops[1].color.rgb = RGBColor(min(col[0] + 60, 255), min(col[1] + 60, 255), min(col[2] + 60, 255))
        sh.line.color.rgb = RGBColor(255, 255, 255); sh.line.width = Pt(1.5)
        sh.text_frame.text = label
        style_run(sh.text_frame.paragraphs[0].runs[0], 16, RGBColor(255, 255, 255), True, font='Segoe UI')
        sh.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        nodes.append(sh)
    for a, b in zip(nodes, nodes[1:]):
        c = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, 0, 0, 0, 0)
        c.begin_connect(a, 3); c.end_connect(b, 1)
        c.line.color.rgb = INK; c.line.width = Pt(2)
        c.line._get_or_add_ln().append(_el('<root><a:tailEnd type="triangle" w="med" len="med"/></root>'))
    back = s.shapes.add_shape(MSO_SHAPE.FLOWCHART_PROCESS, Inches(5.7), Inches(5.3), Inches(2.0), Inches(0.9))
    back.fill.solid(); back.fill.fore_color.theme_color = MSO_THEME_COLOR.ACCENT_2
    back.text_frame.text = 'Back-order'
    style_run(back.text_frame.paragraphs[0].runs[0], 14, RGBColor(255, 255, 255), font='Segoe UI')
    el = s.shapes.add_connector(MSO_CONNECTOR.ELBOW, 0, 0, 0, 0)
    el.begin_connect(nodes[2], 2); el.end_connect(back, 0)
    el.line.color.rgb = CORAL; el.line.width = Pt(2); el.line.dash_style = 4  # dash
    set_transition(s, '<mc:AlternateContent><mc:Choice Requires="p14"><p:transition spd="slow" p14:dur="2000">'
                      '<p14:vortex dir="r"/></p:transition></mc:Choice><mc:Fallback><p:transition spd="slow"><p:fade/>'
                      '</p:transition></mc:Fallback></mc:AlternateContent>')
    set_animations(s, [(n.shape_id, 'entr', 10, 'fade', 'click' if i == 0 else 'with') for i, n in enumerate(nodes)])

    # ── 4 · Charts ──────────────────────────────────────────────────
    s = prs.slides.add_slide(layouts[5])
    s.shapes.title.text = 'Performance at a glance'
    cd = CategoryChartData()
    cd.categories = ['Q1', 'Q2', 'Q3', 'Q4']
    cd.add_series('2025', (4.2, 4.8, 5.1, 5.9))
    cd.add_series('2026', (5.0, 5.6, 6.3, 7.1))
    g = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.5), Inches(1.6), Inches(6.2), Inches(2.8), cd)
    ch = g.chart
    ch.has_legend = True; ch.legend.position = XL_LEGEND_POSITION.BOTTOM; ch.legend.include_in_layout = False
    for ser, col in zip(ch.plots[0].series, (SLATE, TEAL)):
        ser.format.fill.solid(); ser.format.fill.fore_color.rgb = col
    ch.plots[0].gap_width = 60
    cd2 = CategoryChartData()
    cd2.categories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
    cd2.add_series('Active users (k)', (12, 15, 14, 19, 23, 27))
    g2 = s.shapes.add_chart(XL_CHART_TYPE.LINE_MARKERS, Inches(6.9), Inches(1.6), Inches(6.0), Inches(2.8), cd2)
    g2.chart.has_legend = False
    g2.chart.plots[0].series[0].format.line.color.rgb = CORAL
    g2.chart.plots[0].series[0].format.line.width = Pt(3)
    cd3 = CategoryChartData()
    cd3.categories = ['Enterprise', 'SMB', 'Consumer']
    cd3.add_series('Mix', (0.55, 0.30, 0.15))
    g3 = s.shapes.add_chart(XL_CHART_TYPE.PIE, Inches(0.5), Inches(4.6), Inches(6.2), Inches(2.7), cd3)
    g3.chart.plots[0].has_data_labels = True
    g3.chart.plots[0].data_labels.number_format = '0%'
    g3.chart.plots[0].data_labels.number_format_is_linked = False
    g4 = s.shapes.add_chart(XL_CHART_TYPE.DOUGHNUT, Inches(6.9), Inches(4.6), Inches(6.0), Inches(2.7), cd3)
    g4.chart.has_title = True
    g4.chart.chart_title.text_frame.text = 'Revenue mix'
    set_transition(s, '<p:transition spd="med"><p:wipe dir="r"/></p:transition>')

    # ── 5 · Table + picture + group ─────────────────────────────────
    s = prs.slides.add_slide(layouts[5])
    s.shapes.title.text = 'Regional scorecard'
    rows = [('Region', 'Revenue', 'Growth', 'NPS'), ('APAC', '$4.1M', '+22%', '61'),
            ('EMEA', '$3.6M', '+14%', '57'), ('Americas', '$5.3M', '+11%', '64')]
    tbl_sh = s.shapes.add_table(len(rows), 4, Inches(0.6), Inches(1.7), Inches(6.6), Inches(2.6))
    tbl = tbl_sh.table
    tbl.columns[0].width = Inches(2.1)
    for ri, row in enumerate(rows):
        for ci, val in enumerate(row):
            cell = tbl.cell(ri, ci)
            cell.text = val
            run = cell.text_frame.paragraphs[0].runs[0]
            style_run(run, 16 if ri else 15, RGBColor(255, 255, 255) if ri == 0 else INK, ri == 0, font='Segoe UI')
            if ci:
                cell.text_frame.paragraphs[0].alignment = PP_ALIGN.RIGHT
            if ri == 0:
                cell.fill.solid(); cell.fill.fore_color.rgb = INK
            elif ci == 2:
                cell.fill.solid(); cell.fill.fore_color.rgb = RGBColor(0xDF, 0xF5, 0xF2)
    tbl.cell(3, 0).merge(tbl.cell(3, 0))
    pic = s.shapes.add_picture(make_image(), Inches(7.6), Inches(1.7), Inches(5.2), Inches(3.0))
    pic.crop_left = 0.05; pic.crop_right = 0.05
    pic.line.color.rgb = INK; pic.line.width = Pt(2)
    grp = s.shapes.add_group_shape()
    for i, (lbl, col) in enumerate((('Plan', TEAL), ('Build', AMBER), ('Measure', CORAL))):
        chev = grp.shapes.add_shape(MSO_SHAPE.CHEVRON, Inches(0.6 + i * 2.3), Inches(5.2), Inches(2.4), Inches(1.0))
        chev.fill.solid(); chev.fill.fore_color.rgb = col; chev.line.fill.background()
        chev.text_frame.text = lbl
        style_run(chev.text_frame.paragraphs[0].runs[0], 18, RGBColor(255, 255, 255), True, font='Segoe UI Semibold')
    grp.name = 'Process chevrons'
    jump = s.shapes.add_shape(MSO_SHAPE.ACTION_BUTTON_HOME, Inches(12.3), Inches(6.6), Inches(0.6), Inches(0.6))
    jump.click_action.target_slide = prs.slides[0]
    set_transition(s, '<p:transition spd="fast"><p:cover dir="l"/></p:transition>')

    # ── 6 · Hidden appendix ─────────────────────────────────────────
    s = prs.slides.add_slide(layouts[1])
    s.shapes.title.text = 'Appendix (hidden)'
    body = s.placeholders[1].text_frame
    body.text = 'Methodology'
    for lvl, txt in ((1, 'Revenue recognised on delivery'), (1, 'NPS from 1,240 responses'), (2, 'Margin of error ±3%')):
        p = body.add_paragraph(); p.text = txt; p.level = lvl
    s._element.set('show', '0')

    prs.save(path)
    print('saved', path)


if __name__ == '__main__':
    build(sys.argv[1] if len(sys.argv) > 1 else 'sample_deck.pptx')
