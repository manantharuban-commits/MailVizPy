"""Command line for PPTX Studio.

  python cli.py deck.pptx                          # editable code in ./deck_code/
  python cli.py deck.pptx --mode exact --single    # one self-contained .py
  python cli.py deck.pptx --look fresh             # modernise with a look first, then generate code
  python cli.py deck.pptx --look finance --deck-only # just write the modern deck
  python cli.py deck.pptx --look cobalt --restyle chart=bold,table=striped --chart-type bar
  python cli.py deck.pptx --brand DB0011 --font segoe          # palette from one brand colour
  python cli.py deck.pptx --verify                 # also run + compare (+ render if LibreOffice is present)
  python cli.py deck.pptx --designs my_designs.json --restyle heatmap=my:brand-heat   # your own designs
  python cli.py --capture sample.pptx 3:7 --name "Brand heat"   # save a design copied from slide 3, shape 7
  python cli.py --looks                            # list looks and font pairs
  python cli.py --styles                           # list component styles (and your saved designs)
"""
import argparse
import json
import re
import shutil
import sys
from pathlib import Path

from converter import custom, looks, restyle, themes
from converter.design import prepare
from converter.codegen import generate


def main(argv=None):
    ap = argparse.ArgumentParser(description='Convert a PowerPoint deck into Python (python-pptx) code.')
    ap.add_argument('pptx', nargs='?')
    ap.add_argument('-o', '--out', help='output folder (default: <deck>_code)')
    ap.add_argument('--mode', choices=['editable', 'exact'], default='editable')
    ap.add_argument('--single', action='store_true', help='embed assets in one .py file')
    ap.add_argument('--no-notes', action='store_true')
    ap.add_argument('--look', help='one-click look: palette, font pair and component styles (see --looks)')
    ap.add_argument('--brand', help='build a fresh palette from one hex colour, e.g. 3355FF')
    ap.add_argument('--font', help='font pair id (see --looks)')
    ap.add_argument('--title-accent', help='hex colour for the title accent bar only, e.g. DB0011')
    ap.add_argument('--theme', help='palette from a JSON file {"colors": {...}, "fonts": {...}} (or a look id)')
    ap.add_argument('--restyle', help='component styles, e.g. chart=bold,table=striped,card=accent-top,'
                                      'flow=chip,picture=shadow,title=accent-bar,text=airy,background=glow')
    ap.add_argument('--designs', help='your own designs (an exported my_designs.json), used as style my:<id>; '
                                      'designs saved in the app are found without it')
    ap.add_argument('--capture', nargs=2, metavar=('SAMPLE', 'SLIDE:SHAPE'),
                    help='copy a design from a component of a sample deck and save it (see --styles for ids)')
    ap.add_argument('--name', help='name for --capture')
    ap.add_argument('--kind', help='design kind for --capture (e.g. heatmap or table for a table)')
    ap.add_argument('--chart-type', help='switch every chart: column, bar, stacked, line, area, pie, doughnut')
    ap.add_argument('--recolor', choices=['smart', 'exact', 'theme'], default='smart')
    ap.add_argument('--refont', choices=['all', 'matching', 'theme'])
    ap.add_argument('--deck-only', action='store_true', help='write the modern deck and stop (no code)')
    ap.add_argument('--verify', action='store_true', help='run the generated script and compare with the source')
    ap.add_argument('--looks', action='store_true', help='list looks and font pairs')
    ap.add_argument('--themes', action='store_true', help=argparse.SUPPRESS)
    ap.add_argument('--styles', action='store_true', help='list component styles')
    a = ap.parse_args(argv)

    if a.looks or a.themes:
        print('Looks')
        for lk in looks.LOOKS:
            print(f"  {lk['id']:10s} {lk['name']:14s} "
                  f"{looks.FONT_BY_ID[lk['font']]['name']:16s} {lk['desc']}")
        print('Font pairs')
        for f in looks.FONT_PAIRS:
            print(f"  {f['id']:10s} {f['major']} / {f['minor']}  ({f['note']})")
        return 0
    if a.capture:
        sample, ref = a.capture
        if not re.fullmatch(r'\d+:(\d+|bg)', ref):
            ap.error('SLIDE:SHAPE looks like 3:7 (shape id 7 on slide 3) or 3:bg for the background')
        res = custom.capture(Path(sample).read_bytes(), int(ref.split(':')[0]), ref, a.kind)
        d = custom.save({'kind': res['kind'], 'base': res['base'], 'params': res['params'], 'source': 'sample',
                         'name': a.name or f"{res['kind'].title()} from {Path(sample).stem}",
                         'sample': {'name': Path(sample).name, 'slide': int(ref.split(':')[0]), 'cid': ref}})
        print(f"saved my:{d['id']}  ({d['kind']}: {', '.join(res['notes'])})  in {custom.store_path()}")
        return 0
    if a.styles:
        for kind, styles in restyle.STYLES.items():
            print(f"{kind:11s} " + ', '.join(i for i, _, _ in styles))
        mine = custom.load()
        if mine:
            print('your designs')
            for d in mine.values():
                print(f"  {d['kind']:10s} my:{d['id']:28s} {d['name']}")
        print('chart_type  ' + ', '.join(i for i, _ in restyle.CHART_TYPES))
        return 0
    if not a.pptx:
        ap.error('give a .pptx file')
    src = Path(a.pptx)
    data = src.read_bytes()
    stem = re.sub(r'[^0-9A-Za-z]+', '_', src.stem).strip('_').lower() or 'deck'
    out = Path(a.out or f'{stem}_code')

    design = {}
    if a.look:
        if a.look not in looks.LOOK_BY_ID:
            ap.error(f'unknown look {a.look!r}; see --looks')
        design['look'] = a.look
    if a.brand:
        design['palette'], design['palette_name'] = themes.harmonize(a.brand), f'Brand {a.brand.upper()}'
        design.setdefault('look', 'fresh')
    if a.theme:
        if a.theme in looks.LOOK_BY_ID:
            design.setdefault('look', a.theme)
        else:
            spec = json.loads(Path(a.theme).read_text())
            design['palette'], design['palette_name'] = spec['colors'], spec.get('name', 'Custom')
            if spec.get('fonts'):
                design['fonts'] = spec['fonts']
    if a.font:
        if a.font not in looks.FONT_BY_ID:
            ap.error(f'unknown font pair {a.font!r}; see --looks')
        design['font'] = a.font
    if a.title_accent:
        design['title_accent'] = a.title_accent.strip('#').upper()
    if a.restyle or a.chart_type:
        plan = restyle.parse_cli(a.restyle)
        design['kinds'] = plan['kinds']
        if plan.get('look'):
            design.setdefault('look', plan['look'])
        if a.chart_type:
            design['kinds'].setdefault('chart', {})['chart_type'] = a.chart_type
    if a.designs:
        obj = json.loads(Path(a.designs).read_text(encoding='utf-8'))
        design['custom'] = {d['id']: d for d in (obj.get('designs') if isinstance(obj, dict) else obj) or []
                            if isinstance(d, dict) and d.get('id')}
    design['recolor'] = a.recolor
    if a.refont:
        design['refont'] = a.refont
    if len(design) > 1:
        data, tsum, rs = prepare(data, design)
        out.mkdir(parents=True, exist_ok=True)
        (out / f'{stem}_modern.pptx').write_bytes(data)
        if tsum:
            print(f"palette {tsum['to']['name']}: {tsum['recoloured']} colours, {tsum['refonted']} font references updated")
        if rs:
            print('restyle ' + ', '.join(f'{v} {k}' for k, v in rs['restyled'].items()))
            for s_ in rs['skipped']:
                print('note   ', s_)
        print(f"deck    {out / (stem + '_modern.pptx')}")
        if a.deck_only:
            return 0
    elif a.deck_only:
        ap.error('--deck-only needs a design: --look, --brand, --font, --restyle …')

    res = generate(data, mode=a.mode, asset_mode='inline' if a.single else 'folder', module_name=stem,
                   source_name=src.name, notes=not a.no_notes)
    out.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(out / 'assets', ignore_errors=True)
    (out / f'{stem}.py').write_text(res.code, encoding='utf-8')
    for name, blob in res.assets.items():
        p = out / 'assets' / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(blob)
    (out / 'requirements.txt').write_text('python-pptx>=1.0\nlxml\n')
    r = res.report
    print(f"code   {out / (stem + '.py')}  ({res.code.count(chr(10)):,} lines, {r['stats']['slides']} slides)")
    print(f"shapes {r['api_shapes']} via API ({r['patches']} exact patches), {r['xml_shapes']} as exact XML")
    print(f"check  {r['identical']}/{r['items']} slide elements rebuild identically ({r['fidelity']:.1%})")
    for w in r['warnings']:
        print('note  ', w)

    if a.verify:
        from converter.verify import verify
        rep, rebuilt = verify(data, res.code, res.assets, out / '_verify', stem)
        (out / f'{stem}_rebuilt.pptx').write_bytes(rebuilt)
        s = rep['structural']
        print(f"verify structure {s['identical']}/{s['items']} identical, media {s['media']['rebuilt']}/{s['media']['source']}")
        if rep.get('visual'):
            worst = min(rep['visual'], key=lambda v: v['similarity'])
            print(f"verify pixels    lowest match {worst['similarity']:.2%} (slide {worst['slide']})")
        shutil.rmtree(out / '_verify', ignore_errors=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
