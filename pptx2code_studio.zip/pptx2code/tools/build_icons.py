"""Build converter/icons_data.json from Bootstrap Icons (MIT, https://icons.getbootstrap.com).

Each icon becomes native DrawingML geometry (a:custGeom paths in a 16000 x 16000 box), so icons in
the deck are crisp vector shapes coloured by the theme, not pictures.

    npm pack bootstrap-icons@1.11.3 && tar xzf bootstrap-icons-1.11.3.tgz
    pip install svgpathtools
    python tools/build_icons.py package/icons
"""
import json
import math
import re
import sys
from pathlib import Path

from lxml import etree
from svgpathtools import Arc, CubicBezier, Line, QuadraticBezier, parse_path

CURATED = [
    # money
    'currency-dollar', 'currency-rupee', 'currency-euro', 'currency-pound', 'currency-yen', 'cash-stack', 'cash-coin',
    'coin', 'wallet2', 'piggy-bank', 'bank', 'credit-card', 'receipt', 'percent', 'calculator',
    # growth and data
    'graph-up-arrow', 'graph-down-arrow', 'graph-up', 'bar-chart-line', 'bar-chart', 'pie-chart', 'activity',
    'speedometer2', 'clipboard-data', 'arrow-up-right-circle', 'arrow-down-right-circle', 'bullseye', 'funnel',
    # people
    'people', 'person', 'person-check', 'person-plus', 'person-badge', 'emoji-smile', 'hand-thumbs-up', 'heart',
    'chat-dots', 'star', 'award', 'trophy', 'patch-check', 'mortarboard',
    # commerce and places
    'cart3', 'bag', 'bag-check', 'box-seam', 'truck', 'shop', 'tags', 'basket', 'building', 'buildings', 'house',
    'globe2', 'geo-alt', 'map', 'briefcase',
    # time and operations
    'clock', 'calendar3', 'calendar-check', 'hourglass-split', 'stopwatch', 'alarm', 'arrow-repeat', 'check2-circle',
    'shield-check', 'lightning-charge', 'rocket-takeoff', 'flag', 'lightbulb', 'gear', 'tools', 'cpu', 'cloud',
    'database', 'server', 'laptop', 'phone', 'envelope', 'megaphone', 'bell', 'layers', 'diagram-3', 'puzzle',
    'search', 'bookmark-star', 'stars', 'fire', 'gem', 'recycle', 'droplet', 'sun', 'tree', 'heart-pulse',
    'hospital', 'capsule', 'airplane', 'car-front', 'wifi', 'boxes', 'kanban', 'list-check', 'file-earmark-text',
]
S = 1000  # 16 svg units -> 16000 path units


def _shape_to_d(el):
    tag = etree.QName(el).localname
    g = lambda k, d=0: float(el.get(k, d))  # noqa: E731
    if tag == 'path':
        return el.get('d')
    if tag == 'circle':
        cx, cy, r = g('cx'), g('cy'), g('r')
        return f'M{cx - r} {cy}a{r} {r} 0 1 0 {2 * r} 0a{r} {r} 0 1 0 {-2 * r} 0Z'
    if tag == 'ellipse':
        cx, cy, rx, ry = g('cx'), g('cy'), g('rx'), g('ry')
        return f'M{cx - rx} {cy}a{rx} {ry} 0 1 0 {2 * rx} 0a{rx} {ry} 0 1 0 {-2 * rx} 0Z'
    if tag == 'rect':
        x, y, w, h = g('x'), g('y'), g('width'), g('height')
        rx = float(el.get('rx', el.get('ry', 0)))
        if not rx:
            return f'M{x} {y}h{w}v{h}h{-w}Z'
        return (f'M{x + rx} {y}h{w - 2 * rx}a{rx} {rx} 0 0 1 {rx} {rx}v{h - 2 * rx}a{rx} {rx} 0 0 1 {-rx} {rx}'
                f'h{-(w - 2 * rx)}a{rx} {rx} 0 0 1 {-rx} {-rx}v{-(h - 2 * rx)}a{rx} {rx} 0 0 1 {rx} {-rx}Z')
    return None


def _pt(z):
    return f'<a:pt x="{round(z.real * S)}" y="{round(z.imag * S)}"/>'


def _arc_cubics(arc):
    """Split an arc into <=90° pieces and approximate each with a cubic (Hermite)."""
    n = max(1, math.ceil(abs(arc.delta) / 90))
    out = []
    for k in range(n):
        t0, t1 = k / n, (k + 1) / n
        p0, p3 = arc.point(t0), arc.point(t1)
        d0, d1 = arc.derivative(t0), arc.derivative(t1)
        h = (t1 - t0)
        # tangent length for a circular arc piece: 4/3 tan(theta/4) scaled by speed
        theta = math.radians(abs(arc.delta)) * h
        kk = 4 / 3 * math.tan(theta / 4) / (theta if theta else 1)
        p1 = p0 + d0 * h * kk
        p2 = p3 - d1 * h * kk
        out.append((p1, p2, p3))
    return out


def path_xml(d):
    p = parse_path(d)
    cmds = []
    for sub in p.continuous_subpaths():
        if not len(sub):
            continue
        cmds.append(f'<a:moveTo>{_pt(sub[0].start)}</a:moveTo>')
        for seg in sub:
            if isinstance(seg, Line):
                cmds.append(f'<a:lnTo>{_pt(seg.end)}</a:lnTo>')
            elif isinstance(seg, QuadraticBezier):
                cmds.append(f'<a:quadBezTo>{_pt(seg.control)}{_pt(seg.end)}</a:quadBezTo>')
            elif isinstance(seg, CubicBezier):
                cmds.append(f'<a:cubicBezTo>{_pt(seg.control1)}{_pt(seg.control2)}{_pt(seg.end)}</a:cubicBezTo>')
            elif isinstance(seg, Arc):
                for p1, p2, p3 in _arc_cubics(seg):
                    cmds.append(f'<a:cubicBezTo>{_pt(p1)}{_pt(p2)}{_pt(p3)}</a:cubicBezTo>')
        cmds.append('<a:close/>')  # filled icons: every sub-path is a closed region
    return ''.join(cmds)


def convert(svg_file):
    root = etree.parse(str(svg_file)).getroot()
    paths = []
    for el in root.iter():
        if not isinstance(el.tag, str):
            continue
        d = _shape_to_d(el)
        if d:
            body = path_xml(d)
            if body:
                paths.append(f'<a:path w="{16 * S}" h="{16 * S}" stroke="0">{body}</a:path>')
    return ''.join(paths)


def main(icon_dir):
    icon_dir = Path(icon_dir)
    out = {}
    for name in CURATED:
        for variant in (name, name + '-fill'):
            f = icon_dir / f'{variant}.svg'
            if f.exists():
                out[variant] = convert(f)
    target = Path(__file__).resolve().parents[1] / 'converter' / 'icons_data.json'
    target.write_text(json.dumps({'source': 'Bootstrap Icons 1.11.3, MIT licence, https://icons.getbootstrap.com',
                                  'icons': out}, separators=(',', ':')))
    missing = [n for n in CURATED if n not in out]
    print(f'{len(out)} icons -> {target} ({target.stat().st_size // 1024} KB)', 'missing:', missing)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'package/icons')
