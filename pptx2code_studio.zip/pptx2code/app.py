"""PPTX→Code Studio — local web app.

    pip install -r requirements.txt
    python app.py            # then open http://127.0.0.1:8765
"""
import hashlib
import io
import json
import re
import shutil
import threading
import time
import traceback
import uuid
import zipfile
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_file, send_from_directory

from converter import custom, looks, restyle, themes
from converter.design import custom_ids, gallery_designs, prepare
from converter.codegen import generate
from converter.inspect_deck import inventory
from converter.verify import render, render_many, soffice, structural, run_generated, visual

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'workspace'
WORK.mkdir(exist_ok=True)
app = Flask(__name__, static_folder=str(ROOT / 'static'), static_url_path='/static')
app.config['MAX_CONTENT_LENGTH'] = 300 * 1024 * 1024

TASKS = {}
LOCK = threading.Lock()


# ── helpers ──────────────────────────────────────────────────────────────────
def job_dir(job):
    if not re.fullmatch(r'[0-9a-f]{12}', job or ''):
        abort(404)
    d = WORK / job
    if not d.exists():
        abort(404)
    return d


def meta(job, **update):
    p = job_dir(job) / 'meta.json'
    m = json.loads(p.read_text()) if p.exists() else {}
    if update:
        m.update(update)
        p.write_text(json.dumps(m, indent=1))
    return m


def task(fn, *args):
    tid = uuid.uuid4().hex[:12]
    TASKS[tid] = {'state': 'running', 'started': time.time()}

    def run():
        try:
            TASKS[tid].update(state='done', result=fn(*args))
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            TASKS[tid].update(state='error', error=f'{type(exc).__name__}: {exc}')

    threading.Thread(target=run, daemon=True).start()
    return tid


def highlight(code):
    """Per-line HTML so the UI can number lines and jump to slides."""
    try:
        from pygments import highlight as _hl
        from pygments.formatters import HtmlFormatter
        from pygments.lexers import PythonLexer
        html = _hl(code, PythonLexer(), HtmlFormatter(nowrap=True))
        return html.split('\n')
    except ImportError:
        import html as _h
        return [_h.escape(line) for line in code.split('\n')]


RENDER_SLOTS = threading.Semaphore(2)  # at most two LibreOffice renders at once


def _key(obj):
    return hashlib.sha1(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:16]


# ── pages ────────────────────────────────────────────────────────────────────
@app.get('/')
def index():
    return send_from_directory(ROOT / 'static', 'index.html')


@app.get('/api/info')
def info():
    return jsonify({'render': bool(soffice()), 'restyle': restyle.catalogue(), **looks.catalogue()})


@app.get('/api/harmonize')
def harmonize():
    base = request.args.get('color', '3355FF').strip('#')
    if not re.fullmatch(r'[0-9A-Fa-f]{6}', base):
        return jsonify(error='Use a 6-digit hex colour.'), 400
    return jsonify(colors=themes.harmonize(base, request.args.get('dark') == '1'))


@app.post('/api/upload')
def upload():
    f = request.files.get('file')
    if not f or not f.filename.lower().endswith(('.pptx', '.pptm', '.potx')):
        return jsonify(error='Choose a .pptx file.'), 400
    data = f.read()
    job = uuid.uuid4().hex[:12]
    d = WORK / job
    d.mkdir()
    (d / 'source.pptx').write_bytes(data)
    try:
        inv = inventory(data)
    except Exception as exc:  # noqa: BLE001
        shutil.rmtree(d, ignore_errors=True)
        return jsonify(error=f'This file could not be read as a PowerPoint deck ({exc}).'), 400
    stem = re.sub(r'[^0-9A-Za-z]+', '_', Path(f.filename).stem).strip('_').lower() or 'deck'
    meta(job, name=f.filename, stem=stem, created=time.time())
    (d / 'inventory.json').write_text(json.dumps(inv))
    thumbs = task(lambda: [p.name for p in render(data, d / 'thumbs', 'slide', dpi=50)])
    return jsonify(job=job, name=f.filename, inventory=inv, components=restyle.detect(data), thumbs_task=thumbs)


@app.get('/api/task/<tid>')
def task_status(tid):
    t = TASKS.get(tid)
    if not t:
        abort(404)
    return jsonify({k: v for k, v in t.items() if k != 'started'})


@app.get('/api/job/<job>/file/<path:name>')
def job_file(job, name):
    d = job_dir(job).resolve()
    p = (d / name).resolve()
    if d not in p.parents or not p.is_file():
        abort(404)
    return send_file(p)


def _slide_design(design, n):
    """The part of a design that matters for slide n (so unrelated item edits keep the cache warm)."""
    if not design:
        return None
    d = dict(design)
    d['items'] = {k: v for k, v in (design.get('items') or {}).items() if k.startswith(f'{n}:')}
    d.pop('apply', None)
    return d


@app.post('/api/job/<job>/preview')
def preview(job):
    """Render one slide, as designed and as it was. Synchronous: ~1-2 s with LibreOffice."""
    d = job_dir(job)
    body = request.get_json(force=True)
    n = int(body.get('slide', 1))
    design = _slide_design(body.get('design'), n)
    if not soffice():
        return jsonify(error='Live previews need LibreOffice; downloads still work.'), 400
    out = d / 'preview'
    out.mkdir(exist_ok=True)
    src = (d / 'source.pptx').read_bytes()
    t0 = time.time()
    before = out / f'orig{n}-1.png'
    key = _key({'n': n, 'design': design})
    after = out / f'd{key}-1.png'
    summary = None
    with RENDER_SLOTS:
        decks = []
        if not before.exists():
            decks.append((f'orig{n}', restyle.single_slide(src, n)))
        if design and not after.exists():
            data, tsum, rsum = prepare(src, design, n)
            decks.append((f'd{key}', data))
            summary = {'restyled': (rsum or {}).get('restyled', {}), 'theme': bool(tsum)}
            (out / f'd{key}.json').write_text(json.dumps(summary))
        if decks:
            render_many(decks, out, dpi=120)
    if design and summary is None and (out / f'd{key}.json').exists():
        summary = json.loads((out / f'd{key}.json').read_text())
    return jsonify(before=f'preview/{before.name}', after=f'preview/{after.name}' if design and after.exists() else None,
                   summary=summary, ms=int((time.time() - t0) * 1000))


@app.post('/api/job/<job>/looks')
def looks_preview(job):
    """Slide n rendered in every look (one LibreOffice start-up for all of them)."""
    d = job_dir(job)
    body = request.get_json(force=True)
    n = int(body.get('slide', 1))
    out = d / 'looks'

    def work():
        src = (d / 'source.pptx').read_bytes()
        todo = []
        for lk in looks.LOOKS:
            if not (out / f'{n}-{lk["id"]}-1.png').exists():
                data, _, _ = prepare(src, {'look': lk['id']}, n)
                todo.append((f'{n}-{lk["id"]}', data))
        if todo:
            with RENDER_SLOTS:
                render_many(todo, out, dpi=56)
        return {lk['id']: f'looks/{n}-{lk["id"]}-1.png' for lk in looks.LOOKS
                if (out / f'{n}-{lk["id"]}-1.png').exists()}

    return jsonify(task=task(work))


SPECIMEN = ROOT / 'samples' / 'specimen.pptx'


def _fs(sid):
    """A style id that is safe in a file name ('my:brand-heat' -> 'my_brand-heat')."""
    return re.sub(r'[^0-9A-Za-z_-]', '_', sid)


def _specimen():
    if not SPECIMEN.exists():
        from samples.make_specimen import build
        build().save(SPECIMEN)
    from samples.make_specimen import SPECIMEN_SLIDES
    return SPECIMEN, SPECIMEN_SLIDES


@app.post('/api/job/<job>/gallery')
def gallery(job):
    """Every style of one component kind, rendered on the specimen slide or on the user's own slide."""
    d = job_dir(job)
    body = request.get_json(force=True)
    kind = body.get('kind')
    if kind not in restyle.STYLES:
        return jsonify(error='Unknown component kind.'), 400
    source = body.get('source', 'sample')
    design = body.get('design') or {}
    if source == 'slide':
        n, src_path = int(body.get('slide', 1)), d / 'source.pptx'
    else:
        spec, slides = _specimen()
        n, src_path = slides[kind], spec
    ctx_design = {k: v for k, v in design.items() if k != 'items'}
    key = _key({'k': kind, 's': source, 'n': n, 'd': ctx_design})
    out = d / 'gallery'

    def work():
        src = src_path.read_bytes()
        todo = []
        for sid, dz in gallery_designs(design, kind, (design.get('kinds') or {}).get('chart', {}).get('chart_type')):
            if not (out / f'{key}-{_fs(sid)}-1.png').exists():
                data, _, _ = prepare(src, dz, n)
                todo.append((f'{key}-{_fs(sid)}', data))
        if todo:
            with RENDER_SLOTS:
                render_many(todo, out, dpi=64)
        ids = ['keep'] + [x[0] for x in restyle.STYLES[kind]] + custom_ids(design, kind)
        return {'slide': n, 'source': source, 'styles': {sid: f'gallery/{key}-{_fs(sid)}-1.png' for sid in ids
                                                         if (out / f'{key}-{_fs(sid)}-1.png').exists()}}

    return jsonify(task=task(work))


@app.post('/api/job/<job>/render-design')
def render_design(job):
    """Apply the design to the whole deck, save it for download and render every slide."""
    d = job_dir(job)
    design = request.get_json(force=True).get('design')

    def work():
        data, tsum, rsum = prepare((d / 'source.pptx').read_bytes(), design)
        (d / 'designed.pptx').write_bytes(data)
        tag = uuid.uuid4().hex[:6]
        shutil.rmtree(d / 'designed', ignore_errors=True)
        with RENDER_SLOTS:
            files = render(data, d / 'designed', f'd{tag}', dpi=56)
        return {'files': [f'designed/{p.name}' for p in files], 'summary': rsum, 'theme': tsum}

    return jsonify(task=task(work))


@app.post('/api/job/<job>/export-design')
def export_design(job):
    """Apply the design to the whole deck (no rendering) so it can be downloaded straight away."""
    d = job_dir(job)
    data, tsum, rsum = prepare((d / 'source.pptx').read_bytes(), request.get_json(force=True).get('design'))
    (d / 'designed.pptx').write_bytes(data)
    return jsonify(url=f'/api/job/{job}/download/designed', summary=rsum)


@app.post('/api/job/<job>/convert')
def convert(job):
    d = job_dir(job)
    opts = request.get_json(force=True)
    m = meta(job)

    def work():
        t0 = time.time()
        src = (d / 'source.pptx').read_bytes()
        data, summary, rsum = prepare(src, opts.get('design') if opts.get('use_design') else None)
        (d / 'input.pptx').write_bytes(data)
        module = re.sub(r'\W+', '_', opts.get('module') or m.get('stem') or 'deck')
        res = generate(data, mode=opts.get('mode', 'editable'), asset_mode=opts.get('assets', 'folder'),
                       module_name=module, source_name=m.get('name', 'deck.pptx'), notes=opts.get('notes', True))
        out = d / 'output'
        shutil.rmtree(out, ignore_errors=True)
        (out / 'assets').mkdir(parents=True)
        (out / f'{module}.py').write_text(res.code, encoding='utf-8')
        for name, blob in res.assets.items():
            p = out / 'assets' / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(blob)
        if not res.assets:
            shutil.rmtree(out / 'assets')
        meta(job, module=module, converted=time.time(), options=opts)
        rep = res.report
        rep['seconds'] = round(time.time() - t0, 2)
        rep['theme_summary'] = summary
        rep['restyle_summary'] = rsum
        rep['lines'] = res.code.count('\n')
        rep['bytes'] = len(res.code.encode())
        rep['asset_bytes'] = sum(len(b) for b in res.assets.values())
        (d / 'report.json').write_text(json.dumps(rep, default=str))
        slide_lines = {}
        for i, line in enumerate(res.code.split('\n'), 1):
            mm = re.match(r'def slide_(\d+)\(', line)
            if mm:
                slide_lines[int(mm.group(1))] = i
        return {'report': rep, 'html': highlight(res.code), 'slide_lines': slide_lines, 'module': module}

    return jsonify(task=task(work))


@app.post('/api/job/<job>/verify')
def verify_job(job):
    d = job_dir(job)
    m = meta(job)
    if not (d / 'output').exists():
        return jsonify(error='Generate the code first.'), 400

    def work():
        module = m['module']
        code = (d / 'output' / f'{module}.py').read_text(encoding='utf-8')
        assets = {}
        adir = d / 'output' / 'assets'
        if adir.exists():
            for p in adir.rglob('*'):
                if p.is_file():
                    assets[str(p.relative_to(adir)).replace('\\', '/')] = p.read_bytes()
        src = (d / 'input.pptx').read_bytes()
        shutil.rmtree(d / 'verify', ignore_errors=True)
        out, log = run_generated(code, assets, d / 'verify' / 'run', module)
        (d / 'rebuilt.pptx').write_bytes(out)
        rep = {'structural': structural(src, out), 'log': log[-400:]}
        if soffice():
            a = render(src, d / 'verify' / 'render', 'source', dpi=50)
            b = render(out, d / 'verify' / 'render', 'rebuilt', dpi=50)
            rep['visual'] = visual(a, b)
            rep['source'] = [f'verify/render/{p.name}' for p in a]
            rep['rebuilt'] = [f'verify/render/{p.name}' for p in b]
        return rep

    return jsonify(task=task(work))


@app.get('/api/job/<job>/download/<kind>')
def download(job, kind):
    d = job_dir(job)
    m = meta(job)
    module = m.get('module', 'deck')
    if kind == 'zip':
        out = d / 'output'
        if not out.exists():
            abort(404)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
            for p in out.rglob('*'):
                if p.is_file():
                    z.write(p, f'{module}/{p.relative_to(out)}')
            z.writestr(f'{module}/requirements.txt', 'python-pptx>=1.0\nlxml\n')
            z.writestr(f'{module}/README.md', _readme(module, m))
        buf.seek(0)
        return send_file(buf, as_attachment=True, download_name=f'{module}_code.zip', mimetype='application/zip')
    files = {'py': (d / 'output' / f'{module}.py', f'{module}.py'),
             'designed': (d / 'designed.pptx', f'{m.get("stem", module)}_modern.pptx'),
             'rebuilt': (d / 'rebuilt.pptx', f'{module}_rebuilt.pptx')}
    if kind not in files or not files[kind][0].exists():
        abort(404)
    return send_file(files[kind][0], as_attachment=True, download_name=files[kind][1])


# ── your own designs ─────────────────────────────────────────────────────────
@app.get('/api/designs')
def designs_list():
    return jsonify(designs=list(custom.load().values()), schema=custom.schema(),
                   path=str(custom.store_path()))


@app.post('/api/designs')
def designs_save():
    try:
        return jsonify(design=custom.save(request.get_json(force=True) or {}))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400


@app.delete('/api/designs/<did>')
def designs_delete(did):
    return jsonify(deleted=custom.delete(did))


@app.get('/api/designs/export')
def designs_export():
    ids = [i for i in request.args.get('ids', '').split(',') if i]
    buf = io.BytesIO(json.dumps(custom.export(ids or None), indent=1).encode())
    return send_file(buf, as_attachment=True, download_name='my_designs.json', mimetype='application/json')


@app.post('/api/designs/import')
def designs_import():
    f = request.files.get('file')
    try:
        obj = json.loads(f.read().decode('utf-8')) if f else request.get_json(force=True)
        saved = custom.import_(obj)
    except (ValueError, UnicodeDecodeError) as exc:
        return jsonify(error=f'Not a designs file ({exc}).'), 400
    return jsonify(imported=len(saved), designs=list(custom.load().values()))


@app.post('/api/designs/capture')
def designs_capture():
    """Read a design off a component of an uploaded deck (the open deck or a sample deck)."""
    body = request.get_json(force=True)
    d = job_dir(body.get('job'))
    try:
        res = custom.capture((d / 'source.pptx').read_bytes(), int(body.get('slide', 1)), body.get('cid', ''),
                             body.get('kind') or None, bool(body.get('follow_theme')))
    except (ValueError, IndexError) as exc:
        return jsonify(error=str(exc)), 400
    res['sample'] = {'job': body.get('job'), 'slide': int(body.get('slide', 1)), 'cid': body.get('cid'),
                     'name': meta(body.get('job')).get('name')}
    return jsonify(res)


@app.post('/api/job/<job>/design-preview')
def design_preview(job):
    """One slide with a design being built: on the sample slide, the user's slide, or the sample it copies."""
    d = job_dir(job)
    body = request.get_json(force=True)
    kind = body.get('kind')
    if kind not in custom.FIELDS:
        return jsonify(error='Unknown component kind.'), 400
    if not soffice():
        return jsonify(error='Live previews need LibreOffice.'), 400
    source = body.get('source', 'sample')
    if source == 'slide':
        src_path, n = d / 'source.pptx', int(body.get('slide', 1))
    elif source == 'capture':
        src_path, n = job_dir(body.get('sample_job')) / 'source.pptx', int(body.get('sample_slide', 1))
    else:
        spec, slides = _specimen()
        src_path, n = spec, slides['table' if kind == 'table' else kind]
    draft = body.get('draft') or {}
    design = dict(body.get('design') or {})
    design.pop('items', None)
    design['custom'] = {**(design.get('custom') or {}), '__draft': {**draft, 'kind': kind}}
    kinds = {k: dict(v) for k, v in (design.get('kinds') or {}).items()}
    kinds[kind] = {**kinds.get(kind, {}), 'style': 'my:__draft'}
    kinds[kind].pop('icons', None)
    kinds[kind].pop('legend', None)
    if kind == 'table':
        kinds['heatmap'] = {'style': 'keep'}
    if source == 'capture':  # compare like with like: only this component kind changes on the sample
        design = {'kinds': {kind: kinds[kind], **({'heatmap': {'style': 'keep'}} if kind == 'table' else {})},
                  'custom': design['custom']}
    else:
        design['kinds'] = kinds
    out = d / 'designer'
    out.mkdir(exist_ok=True)
    key = _key({'s': source, 'n': n, 'src': str(src_path), 'd': design})
    png = out / f'p{key}-1.png'
    before = out / f'b{_key({"src": str(src_path), "n": n})}-1.png'
    t0 = time.time()
    with RENDER_SLOTS:
        todo = []
        if not png.exists():
            data, _, _ = prepare(src_path.read_bytes(), design, n)
            todo.append((png.name[:-6], data))
        if source == 'capture' and not before.exists():
            todo.append((before.name[:-6], restyle.single_slide(src_path.read_bytes(), n)))
        if todo:
            render_many(todo, out, dpi=110)
    return jsonify(after=f'designer/{png.name}', before=f'designer/{before.name}' if source == 'capture' else None,
                   ms=int((time.time() - t0) * 1000))


def _readme(module, m):
    rep = {}
    try:
        rep = json.loads((job_dir_from_meta(m) / 'report.json').read_text())
    except Exception:  # noqa: BLE001
        pass
    return f"""# {module}

Python source that rebuilds **{m.get('name', 'the deck')}** with python-pptx.

```
pip install -r requirements.txt
python {module}.py            # writes {module}_rebuilt.pptx
python {module}.py out.pptx   # or choose the output path
```

Keep the `assets/` folder next to the script (single-file builds embed everything).

* Each slide is a function `slide_NN(prs)`; edit text, fonts, colours, positions or chart data there.
* `_run(p, 'text', size=24, bold=True, color='0EA59B', font='Segoe UI')` adds formatted text.
* Charts are built from `CategoryChartData` etc.; `_chart_style(...)` restores the original styling.
* Lines starting with `_sync(...)` restore details python-pptx has no API for (effects, 3-D, exact theme tints).
* Transitions and animations are kept verbatim in `_transition(...)` / `_timing(...)`.

Mode: {rep.get('mode', m.get('options', {}).get('mode', ''))}
"""


def job_dir_from_meta(m):
    for p in WORK.iterdir():
        mp = p / 'meta.json'
        if mp.exists() and json.loads(mp.read_text()).get('created') == m.get('created'):
            return p
    raise FileNotFoundError


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description='PPTX→Code Studio')
    ap.add_argument('--host', default='127.0.0.1')
    ap.add_argument('--port', type=int, default=8765)
    a = ap.parse_args()
    print(f'PPTX→Code Studio on http://{a.host}:{a.port}')
    app.run(host=a.host, port=a.port, threaded=True, debug=False)
