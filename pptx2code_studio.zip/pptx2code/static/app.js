/* PPTX Studio – front end (no build step, no framework). */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const KIND_ORDER = ['chart', 'heatmap', 'table', 'card', 'flow', 'shape', 'picture', 'title', 'text', 'background'];
const ICON = {
  chart: '<path d="M4 16.5V10M8.5 16.5V5.5M13 16.5v-4.5M17 16.5V8"/>',
  table: '<rect x="3.5" y="4.5" width="13" height="11" rx="2"/><path d="M3.5 8.5h13M8.5 8.5v7M12.5 8.5v7"/>',
  heatmap: '<rect x="3.5" y="3.5" width="5.5" height="5.5" rx="1.2"/><rect x="11" y="3.5" width="5.5" height="5.5" rx="1.2" fill="currentColor"/><rect x="3.5" y="11" width="5.5" height="5.5" rx="1.2" fill="currentColor" fill-opacity=".45"/><rect x="11" y="11" width="5.5" height="5.5" rx="1.2"/>',
  card: '<rect x="3.5" y="4.5" width="13" height="11" rx="2.6"/><path d="M6.5 8.5h5M6.5 11.5h7"/>',
  shape: '<path d="M10 3.5l6 3.5v6l-6 3.5-6-3.5V7z"/>',
  flow: '<rect x="2.5" y="7" width="5.5" height="6" rx="1.6"/><rect x="12" y="7" width="5.5" height="6" rx="1.6"/><path d="M8 10h4"/>',
  picture: '<rect x="3.5" y="4.5" width="13" height="11" rx="2"/><path d="M3.5 13.5l3.8-3.6 3 2.7 2.1-1.8 4.1 3.4"/><circle cx="12.6" cy="8" r="1.2"/>',
  title: '<path d="M5 5.5h10M10 5.5v10"/>',
  text: '<path d="M4 6h12M4 10h12M4 14h8"/>',
  background: '<rect x="3.5" y="4.5" width="13" height="11" rx="2"/><path d="M10.5 4.5c0 4 2.5 6.5 6 6.5"/>',
};
const ACCENTS = [1, 2, 3, 4, 5, 6].map(i => 'accent' + i);
const NOUN = { chart: ['chart', 'charts'], heatmap: ['heatmap', 'heatmaps'], table: ['table', 'tables'], card: ['card', 'cards'], shape: ['shape', 'shapes'],
  flow: ['flowchart part', 'flowchart parts'], picture: ['picture', 'pictures'], title: ['title', 'titles'],
  text: ['text block', 'text blocks'], background: ['background', 'backgrounds'] };
const counted = (restyled, skipBg) => Object.entries(restyled || {}).filter(([k]) => !(skipBg && k === 'background'))
  .map(([k, v]) => `${v} ${(NOUN[k] || [k, k])[v === 1 ? 0 : 1]}`).join(', ');

const state = {
  job: null, inv: null, thumbs: [], selected: 1, components: [],
  looks: [], fonts: [], catalogue: null, render: false,
  design: blankDesign(),
  report: null, lines: [], slideLines: {},
  lookShots: {}, previewCache: {}, previewSeq: 0, deck: null, view: 'design',
  my: [], schema: null, builder: null,
};
function blankDesign() {
  return { look: null, palette: null, paletteName: null, font: null, kinds: {}, items: {}, titleAccent: undefined };
}

/* ── utilities ─────────────────────────────────────────────── */
function esc(s) { return String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function toast(msg, error = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast show' + (error ? ' error' : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.className = 'toast'), error ? 6000 : 2800);
}
async function api(url, opts = {}) {
  if (opts.json !== undefined) {
    opts = { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(opts.json) };
  }
  const r = await fetch(url, opts);
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error(j.error || `Request failed (${r.status})`);
  return j;
}
async function waitTask(id) {
  for (;;) {
    const t = await api(`/api/task/${id}`);
    if (t.state === 'done') return t.result;
    if (t.state === 'error') throw new Error(t.error);
    await new Promise(r => setTimeout(r, 600));
  }
}
function busy(btn, on) { btn.classList.toggle('busy', on); btn.disabled = on; }
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
const clean = t => String(t ?? '').replace(/[\x0b\r\n]+/g, ' ').replace(/\s{2,}/g, ' ').trim();
const fileUrl = name => `/api/job/${state.job}/file/${name}`;
const pct = v => (v * 100).toFixed(v >= 0.9995 ? 0 : 1) + '%';
const icon = k => `<svg viewBox="0 0 20 20">${ICON[k] || ''}</svg>`;
let uid = 0;

/* ── interface light / dark ────────────────────────────────── */
(function initMode() {
  const saved = (() => { try { return localStorage.getItem('pptx-studio-mode'); } catch { return null; } })();
  const dark = saved ? saved === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  $('#btn-mode').onclick = () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('pptx-studio-mode', next); } catch { /* private mode */ }
  };
})();

/* ── design model ──────────────────────────────────────────── */
const lookById = id => state.looks.find(l => l.id === id);
const fontById = id => state.fonts.find(f => f.id === id);
function curLook() { return lookById(state.design.look); }
function effColors() {
  return state.design.palette || curLook()?.colors || state.inv?.theme?.colors || state.looks[0]?.colors;
}
function effDark() { return false; }  // light designs only
function effFont() {
  const f = fontById(state.design.font || curLook()?.font);
  return f || (state.inv ? { name: 'Deck fonts', major: state.inv.theme.fonts.major, minor: state.inv.theme.fonts.minor } : state.fonts[0]);
}
function effTitleAccent() {
  const d = state.design;
  return d.titleAccent !== undefined ? d.titleAccent : (curLook()?.title_accent || null);
}
function lookKind(lk, kind) {  // a look's setting for a kind: 'clean' or {style, container, icons}
  const v = lk?.kinds?.[kind];
  return v == null ? {} : typeof v === 'string' ? { style: v } : v;
}
function kindOption(kind, key, fallback) {
  const o = state.design.kinds[kind];
  if (o && o[key] && o[key] !== 'inherit') return o[key];
  return lookKind(curLook(), kind)[key] || fallback;
}
function kindStyle(kind) { return kindOption(kind, 'style', 'keep'); }
function designActive() {
  const d = state.design;
  return !!(d.look || d.palette || d.font || d.titleAccent !== undefined ||
    Object.values(d.kinds).some(k => Object.values(k).some(v => v && v !== 'inherit')) ||
    Object.values(d.items).some(k => Object.values(k).some(v => v && v !== 'inherit')));
}
function payload() {
  if (!designActive()) return null;
  const d = state.design;
  const p = { look: d.look, palette: d.palette, palette_name: d.paletteName, font: d.font,
    kinds: d.kinds, items: d.items, colour: 'auto', recolor: $('#opt-recolor').value, refont: $('#opt-refont').value };
  if (d.titleAccent !== undefined) p.title_accent = d.titleAccent;
  if (state.my.length) p.custom = customMap();
  return p;
}
function customMap() {
  return Object.fromEntries(state.my.map(d => [d.id, { kind: d.kind, base: d.base, name: d.name, params: d.params }]));
}
function galleryDesign() {  // the current design, always with your own designs (the gallery shows them too)
  const p = payload() || {};
  if (state.my.length) p.custom = customMap();
  return p;
}
const payloadKey = () => JSON.stringify(payload());
function designSummary() {
  if (!designActive()) return 'Original design';
  const parts = [];
  parts.push(curLook() ? curLook().name : 'Custom');
  if (state.design.palette) parts.push(state.design.paletteName || 'custom palette');
  parts.push(effFont().name);
  const n = Object.values(state.design.items).filter(o => Object.values(o).some(v => v && v !== 'inherit')).length;
  if (n) parts.push(`${n} item override${n > 1 ? 's' : ''}`);
  return parts.join(' · ');
}

/* ── mini dashboards drawn in a look's palette ─────────────── */
function lighten(hex, f) {
  const n = parseInt(hex, 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  const m = c => Math.round(c + (255 - c) * f);
  return '#' + [m(r), m(g), m(b)].map(c => c.toString(16).padStart(2, '0')).join('');
}
function tones(c) {
  const h = x => '#' + x;
  return { page: h(c.lt1), ink: h(c.dk1), ink2: h(c.dk2), surf: h(c.lt2), canvas: lighten(c.lt2, .4),
    hair: 'rgba(15,23,42,.10)', grid: 'rgba(15,23,42,.08)', A: i => h(c['accent' + i]), tint: i => lighten(c['accent' + i], .86) };
}
function fontStack(f) { return `'${f}', 'Inter', 'Segoe UI', system-ui, sans-serif`; }
function bgSvg(style, t, id, w, h) {
  const base = style === 'canvas' ? t.canvas : t.page;
  if (style === 'glow') {
    return `<defs><radialGradient id="${id}g" cx="1" cy="0" r="1.1"><stop offset="0" stop-color="${t.A(1)}" stop-opacity=".2"/><stop offset=".6" stop-color="${t.A(1)}" stop-opacity="0"/></radialGradient></defs>
      <rect width="${w}" height="${h}" fill="${base}"/><rect width="${w}" height="${h}" fill="url(#${id}g)"/>`;
  }
  return `<rect width="${w}" height="${h}" fill="${base}"/>`;
}
const DOTS = ['M8 3v10M5.5 5.5h4a1.5 1.5 0 0 1 0 3h-3a1.5 1.5 0 0 0 0 3h4', 'M3 12l3.5-4 2.5 2.5L13 5', 'M4 8a4 4 0 1 1 1.2 2.9M4 12V9h3'];
function kpiSvg(style, t, x, y, w, h, i, id, label, value) {
  let card = '', ink = t.ink, mut = t.ink2, chipFill = t.tint(i), iconCol = t.A(i), chipStroke = '';
  const r = 3.2, white = `fill="#fff" stroke="${t.hair}" stroke-width=".5" filter="url(#${id}sh)"`;
  if (['kpi', 'kpi-side', 'kpi-corner', 'kpi-accent', 'kpi-bar', 'kpi-circle'].includes(style)) card = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" ${white}/>`;
  if (style === 'kpi-accent') card += `<rect x="${x + 2.5}" y="${y + .6}" width="${w - 5}" height="1.1" rx=".55" fill="${t.A(i)}"/>`;
  if (style === 'kpi-bar') card += `<rect x="${x + 2.2}" y="${y + 3}" width="1.2" height="${h - 6}" rx=".6" fill="${t.A(i)}"/>`;
  if (style === 'kpi-tint') { card = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${lighten(t.A(i).slice(1), .92)}"/>`; chipFill = '#fff'; }
  if (style === 'kpi-soft') { card = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="#fff"/>`; chipFill = t.A(i); iconCol = '#fff'; }
  if (style === 'kpi-float') { card = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="#fff" filter="url(#${id}sf)"/>`; chipFill = t.A(i); iconCol = '#fff'; }
  if (style === 'kpi-outline') { card = `<rect x="${x + .3}" y="${y + .3}" width="${w - .6}" height="${h - .6}" rx="${r}" fill="#fff" stroke="rgba(15,23,42,.2)" stroke-width=".6"/>`; chipFill = 'none'; chipStroke = `stroke="${t.A(i)}" stroke-width=".6"`; }
  if (style === 'kpi-solid' || style === 'kpi-gradient') {
    const fill = style === 'kpi-solid' ? t.A(i) : `url(#${id}gr${i})`;
    card = (style === 'kpi-gradient' ? `<defs><linearGradient id="${id}gr${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${t.A(i)}"/><stop offset="1" stop-color="${t.A(i % 6 + 1)}"/></linearGradient></defs>` : '') +
      `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${fill}"/>`;
    ink = '#fff'; mut = 'rgba(255,255,255,.85)'; chipFill = 'rgba(255,255,255,.25)'; iconCol = '#fff';
  }
  if (style === 'kpi-header') { card = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" ${white}/>`; ink = t.A(i); }
  if (style === 'kpi-tile' || style === 'kpi-hero' || (style === 'kpi-spotlight' && i === 2)) {
    const a = style === 'kpi-spotlight' ? t.A(2) : t.A(i);
    card = `<defs><linearGradient id="${id}tl${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${style === 'kpi-tile' ? t.A(i % 6 + 1) : a}"/></linearGradient></defs>` +
      `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${style === 'kpi-hero' ? 1.6 : r}" fill="url(#${id}tl${i})"/>`;
    ink = '#fff'; mut = 'rgba(255,255,255,.85)'; chipFill = 'rgba(255,255,255,.22)'; iconCol = '#fff';
  }
  if (style === 'kpi-strip' && i > 1) card = `<line x1="${x - 2.5}" x2="${x - 2.5}" y1="${y + 4}" y2="${y + h - 4}" stroke="${t.hair}" stroke-width=".5"/>`;
  if (style === 'kpi-strip') { chipFill = t.A(i); iconCol = '#fff'; }
  const plain = style === 'kpi-light' || (style === 'kpi-spotlight' && i !== 2) || style === 'kpi-tile';
  const side = style === 'kpi-side' || style === 'kpi-strip', centre = style === 'kpi-circle' || style === 'kpi-tile',
    corner = style === 'kpi-corner' || style === 'kpi-hero', head = style === 'kpi-header';
  const c = 6, pad = 3 + (style === 'kpi-bar' ? 2 : 0);
  const cx = side ? x + pad : corner ? x + w - pad - c : centre ? x + (w - c) / 2 : x + pad, cy = side ? y + (h - c) / 2 : y + 3;
  const chip = style === 'kpi-minimal' || plain ? '' : `<rect x="${cx}" y="${cy}" width="${c}" height="${c}" rx="${centre || head || corner ? c / 2 : 1.6}" fill="${chipFill}" ${chipStroke}/>`;
  const icon = plain ? '' : `<path d="${DOTS[(i - 1) % 3]}" transform="translate(${cx + c * .18} ${cy + c * .18}) scale(${c * .64 / 16})" fill="none" stroke="${iconCol}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`;
  const tx = side ? cx + c + 2.5 : centre ? x + w / 2 : head ? cx + c + 1.8 : x + pad, anchor = centre ? 'middle' : 'start';
  const ty = side ? y + h / 2 - 1 : corner ? y + 5.5 : head ? cy + c * .68 : y + 13;
  const vx = head ? x + pad : tx, vy = head ? y + h - 4 : ty + 5.6;
  const weight = style === 'kpi-light' || style === 'kpi-spotlight' ? 300 : 700;
  return card + chip + icon + `<text x="${tx}" y="${ty}" font-size="2.6" fill="${mut}" text-anchor="${anchor}">${label}</text>
    <text x="${vx}" y="${vy}" font-size="${style === 'kpi-hero' ? 6.6 : 5.6}" font-weight="${weight}" fill="${ink}" text-anchor="${anchor}" letter-spacing="-.15">${value}</text>`;
}
function chartBars(style, t, px, py, pw, ph) {
  let s = [1, 2, 3].map(k => `<line x1="${px}" x2="${px + pw}" y1="${py + k * ph / 4}" y2="${py + k * ph / 4}" stroke="${t.grid}" stroke-width=".4" stroke-dasharray="1 1"/>`).join('');
  const vals = [.5, .74, .6, .92, .68, .82];
  if (style === 'smooth' || style === 'slim') {
    const pts = vals.map((v, i) => [px + i * pw / 5, py + ph - v * ph]);
    const path = pts.reduce((a, [X, Y], i) => i ? a + ` C ${pts[i - 1][0] + pw / 10} ${pts[i - 1][1]}, ${X - pw / 10} ${Y}, ${X} ${Y}` : `M ${X} ${Y}`, '');
    return s + `<path d="${path} L ${px + pw} ${py + ph} L ${px} ${py + ph} Z" fill="${t.A(1)}" opacity=".14"/><path d="${path}" fill="none" stroke="${t.A(1)}" stroke-width="1.1" stroke-linecap="round"/>`;
  }
  const slot = pw / vals.length, top = vals.indexOf(Math.max(...vals));
  vals.forEach((v, i) => {
    const bw = slot * .5, bx = px + i * slot + slot * .25, bh = v * ph;
    let col = t.A(1 + (i % 2));
    if (style === 'highlight') col = i === top ? t.A(1) : 'rgba(15,23,42,.13)';
    if (style === 'mono') col = i % 2 ? lighten(t.A(1).slice(1), .45) : t.A(1);
    if (style === 'gradient') col = `url(#gb)`;
    s += `<rect x="${bx}" y="${py + ph - bh}" width="${bw}" height="${bh}" rx=".8" fill="${col}"/>`;
  });
  return s;
}
function lookSvg(lk) {
  const t = tones(lk.colors);
  const id = 'k' + uid++;
  const card = lookKind(lk, 'card').style || 'kpi', chart = lookKind(lk, 'chart'), bg = lookKind(lk, 'background').style;
  const f = fontById(lk.font) || { major: 'Inter' };
  const ta = lk.title_accent ? '#' + lk.title_accent : t.A(1);
  const box = chart.container || 'card';
  const flat = box === 'tint' || box === 'grey';
  const cont = box === 'none' ? '' : `<rect x="12" y="50" width="136" height="32" rx="3" fill="${box === 'tint' ? t.tint(1) : box === 'grey' ? '#eef0f4' : '#fff'}" ${box === 'float' ? `filter="url(#${id}sf)"` : flat ? '' : `stroke="${box === 'outline' ? 'rgba(15,23,42,.2)' : t.hair}" stroke-width=".5" ${box === 'outline' ? '' : `filter="url(#${id}sh)"`}`}/>` +
    (box === 'accent' ? `<rect x="14.5" y="50.6" width="131" height="1.1" rx=".55" fill="${t.A(1)}"/>` : '') +
    (box === 'badge' ? `<rect x="15.5" y="52.6" width="5" height="5" rx="1.3" fill="${t.A(1)}"/>` : '') +
    `<text x="${box === 'centered' ? 80 : box === 'badge' ? 22.5 : 16}" y="56.5" font-size="${box === 'grey' ? 2.6 : 3.2}" font-weight="700" fill="${t.ink}" text-anchor="${box === 'centered' ? 'middle' : 'start'}" letter-spacing="${box === 'grey' ? '.3' : '0'}">${box === 'grey' ? 'REVENUE BY QUARTER' : 'Revenue by quarter'}</text>` +
    (box === 'header' ? `<line x1="12" x2="148" y1="58.6" y2="58.6" stroke="${t.hair}" stroke-width=".4"/>` : '');
  const strip = card === 'kpi-strip' ? `<rect x="9" y="25" width="142" height="20" rx="3" fill="#fff" stroke="${t.hair}" stroke-width=".5" filter="url(#${id}sh)"/>` : '';
  return `<svg viewBox="0 0 160 90" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" font-family="${esc(fontStack(f.major))}">
    <defs><filter id="${id}sh" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy=".5" stdDeviation=".7" flood-color="#0f172a" flood-opacity=".09"/></filter>
      <filter id="${id}sf" x="-30%" y="-30%" width="160%" height="190%"><feDropShadow dx="0" dy="1.6" stdDeviation="2.4" flood-color="#0f172a" flood-opacity=".12"/></filter>
      <linearGradient id="gb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${t.A(1)}"/><stop offset="1" stop-color="${t.tint(1)}"/></linearGradient></defs>
    ${bgSvg(bg, t, id, 160, 90)}
    <text x="12" y="16" font-size="8.4" font-weight="700" fill="${t.ink}" letter-spacing="-.25">Quarterly results</text>
    ${lookKind(lk, 'title').style === 'accent-bar' ? `<rect x="12" y="19.2" width="10" height="1.6" rx=".8" fill="${ta}"/>` : ''}
    ${strip}
    ${kpiSvg(card, t, 12, 25, 42, 20, 1, id, 'Revenue', '$4.2M')}
    ${kpiSvg(card, t, 59, 25, 42, 20, 2, id, 'Growth', '+24%')}
    ${kpiSvg(card, t, 106, 25, 42, 20, 3, id, 'Retention', '98%')}
    ${cont}
    ${chartBars(chart.style, t, 18, 61, 124, 18)}
  </svg>`;
}

/* ── boot ──────────────────────────────────────────────────── */
loadDesigns();
api('/api/info').then(j => {
  Object.assign(state, { looks: j.looks, fonts: j.fonts, catalogue: j.restyle, render: j.render });
  $('#showcase').innerHTML = state.looks.map(lk => `<figure>${lookSvg(lk)}<figcaption>${esc(lk.name)}<span>${esc(fontById(lk.font)?.name || '')}</span></figcaption></figure>`).join('');
}).catch(() => toast('Could not reach the local server.', true));
$('#views').classList.add('locked');

/* ── views ─────────────────────────────────────────────────── */
function showView(name) {
  state.view = name;
  if (name !== 'design' && state.gallery) closeGallery();
  $$('#views button').forEach(b => b.setAttribute('aria-selected', b.dataset.view === name));
  $$('.view').forEach(v => (v.hidden = v.id !== `view-${name}`));
  $('#insp-design').hidden = name !== 'design';
  $('#insp-export').hidden = name === 'design';
  if (name !== 'design') renderExportNote();
  if (name === 'design') { requestPreview(); requestLooks(); }
}
$('#views').addEventListener('click', e => { const b = e.target.closest('button'); if (b) showView(b.dataset.view); });

/* ── upload ────────────────────────────────────────────────── */
const drop = $('#drop');
['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', e => e.dataTransfer.files[0] && upload(e.dataTransfer.files[0]));
$('#file').addEventListener('change', e => e.target.files[0] && upload(e.target.files[0]));
$('#file2').addEventListener('change', e => e.target.files[0] && upload(e.target.files[0]));
document.body.addEventListener('dragover', e => e.preventDefault());
document.body.addEventListener('drop', e => { e.preventDefault(); if (e.dataTransfer.files[0]) upload(e.dataTransfer.files[0]); });

async function upload(file) {
  const fd = new FormData();
  fd.append('file', file);
  drop.classList.add('loading');
  $('#drop-title').textContent = `Reading ${file.name}…`;
  toast(`Reading ${file.name}…`);
  try {
    const j = await api('/api/upload', { method: 'POST', body: fd });
    if (state.gallery) closeGallery();
    state.galleryCache = {};
    Object.assign(state, {
      job: j.job, inv: j.inventory, components: j.components || [], thumbs: [], selected: 1,
      design: blankDesign(), report: null, lines: [], slideLines: {}, lookShots: {}, previewCache: {}, deck: null,
    });
    document.documentElement.style.setProperty('--ratio', `${j.inventory.size.width_in} / ${j.inventory.size.height_in}`);
    $('#welcome').hidden = true;
    $('#studio').hidden = false;
    $('#views').classList.remove('locked');
    $('#btn-generate').disabled = false;
    $('#deck-chip').hidden = false;
    $('#deck-chip').innerHTML = `<span class="ppt">P</span><b>${esc(j.name)}</b><span>${j.inventory.slide_count} slides</span>`;
    $('#brand').value = '#' + (j.inventory.theme.colors.accent1 || '4F46E5').toLowerCase();
    $('#brand-hex').textContent = $('#brand').value.toUpperCase();
    resetOutputs();
    renderInspector();
    renderStrip();
    showView('design');
    selectSlide(1);
    if (j.thumbs_task) {
      waitTask(j.thumbs_task).then(files => {
        state.thumbs = files.map(f => fileUrl(`thumbs/${f}`));
        renderStrip();
      }).catch(() => toast('Previews need LibreOffice; conversion still works without them.'));
    }
  } catch (err) {
    toast(err.message, true);
  } finally {
    drop.classList.remove('loading');
    $('#drop-title').textContent = 'Drop a PowerPoint file';
    $('#file').value = ''; $('#file2').value = '';
  }
}

function resetOutputs() {
  $('#code').innerHTML = '<div class="empty">Choose your code style on the right, then press <b>Generate code</b>.</div>';
  $('#code-sub').textContent = 'Generate code to see it here';
  $('#report').hidden = true; $('#report-empty').hidden = false;
  $('#verify').innerHTML = '<div class="empty">Generate code first, then run it here.</div>';
  ['#dl-py', '#dl-zip', '#dl-rebuilt'].forEach(s => $(s).classList.add('disabled'));
  $('#btn-copy').disabled = true; $('#btn-verify').disabled = true;
  $('#export-results').hidden = true;
  $('#deck-grid').innerHTML = '';
}

/* ── slide strip ───────────────────────────────────────────── */
function shapeModes(n) {
  const s = state.report?.slides?.[n - 1];
  return s ? s.shapes.map(x => (x.mode === 'xml' ? 'xml' : x.patches ? 'patched' : 'api')) : null;
}
function stripImage(i) {
  if (state.deck && state.deck.key === payloadKey() && state.deck.files[i]) return fileUrl(state.deck.files[i]);
  return state.thumbs[i];
}
function renderStrip() {
  if (!state.inv) return;
  $('#strip').innerHTML = state.inv.slides.map(s => {
    const img = stripImage(s.index - 1);
    const modes = shapeModes(s.index);
    return `<button class="thumb" data-n="${s.index}" aria-current="${s.index === state.selected}" title="${esc(clean(s.title) || 'Slide ' + s.index)}">
      <span class="n">${s.index}</span>
      <span class="frame">${img ? `<img src="${img}" alt="Slide ${s.index}" loading="lazy">` : `<em>${esc(s.title || s.layout)}</em>`}
        ${s.hidden ? '<span class="hidden-tag">hidden</span>' : ''}</span>
      ${modes ? `<span class="modebar">${modes.map(m => `<i class="${m}"></i>`).join('')}</span>` : ''}
    </button>`;
  }).join('');
}
$('#strip').addEventListener('click', e => {
  const b = e.target.closest('.thumb');
  if (!b) return;
  selectSlide(+b.dataset.n);
  if (state.view === 'code') jumpToSlide(+b.dataset.n);
});
$('#prev').onclick = () => selectSlide(Math.max(1, state.selected - 1));
$('#next').onclick = () => selectSlide(Math.min(state.inv.slide_count, state.selected + 1));
document.addEventListener('keydown', e => {
  if (!state.inv || state.view !== 'design' || e.target.closest('input, select, textarea, .handle')) return;
  if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); $('#prev').click(); }
  if (e.key === 'ArrowRight' || e.key === 'PageDown') { e.preventDefault(); $('#next').click(); }
});

function selectSlide(n) {
  state.selected = n;
  $$('.thumb').forEach(t => t.setAttribute('aria-current', +t.dataset.n === n));
  $(`.thumb[data-n="${n}"]`)?.scrollIntoView({ block: 'nearest' });
  const s = state.inv.slides[n - 1];
  $('#slide-title').textContent = clean(s.title) || `Slide ${n}`;
  $('#slide-sub').textContent = `Slide ${n} of ${state.inv.slide_count} · ${s.layout}${s.hidden ? ' · hidden' : ''}`;
  renderSlideMeta(n);
  renderItems();
  if (state.gallery) {
    if (state.gallery.source === 'slide' && !slideHasKind(state.gallery.kind)) state.gallery.source = 'sample';
    renderGallery(); requestGallery();
  }
  if (state.view === 'design') { requestPreview(); requestLooks(); }
}

function renderSlideMeta(n) {
  const s = state.inv.slides[n - 1];
  const rep = state.report?.slides?.[n - 1];
  const modeOf = {};
  (rep?.shapes || []).forEach(x => (modeOf[x.id] = x));
  const shapes = s.shapes.map(sh => {
    const r = modeOf[sh.id];
    const chip = r ? (r.mode === 'xml' ? `<span class="chip xml" title="${esc(r.reason)}">exact XML</span>`
      : r.patches ? `<span class="chip patched">API + patch</span>` : '<span class="chip api">API</span>')
      : `<span class="chip kind">${esc(sh.kind.split(':')[0])}</span>`;
    const detail = [sh.kind.replace('autoshape:', ''), sh.text && `“${sh.text}”`, sh.fonts.join(', '), sh.sizes.length ? sh.sizes.join('/') + ' pt' : ''].filter(Boolean).join(' · ');
    return `<li style="padding-left:${sh.depth * 12}px"><div><span class="nm">${esc(sh.name || 'Shape ' + sh.id)}</span><span class="sub">${esc(detail)}</span></div>${chip}</li>`;
  }).join('');
  const anims = s.animations.map(a => `<li><span class="when">${esc(a.trigger)}</span><span>${esc(a.cls)}: <b>${esc(a.effect)}</b> on ${esc(a.target)}${a.duration_ms ? ` (${a.duration_ms / 1000}s)` : ''}</span></li>`).join('');
  $('#slide-meta').innerHTML = `
    <div class="card"><h5>Shapes (${s.shapes.length})</h5><ul class="shape-list">${shapes || '<li>No shapes</li>'}</ul></div>
    <div class="card"><h5>Motion</h5><ul class="timeline"><li><span class="when">Transition</span><span>${esc(s.transition_text || 'None')}</span></li>
      ${anims || '<li><span class="when">Animations</span><span>None</span></li>'}</ul>
      ${s.notes ? `<h5 style="margin-top:14px">Speaker notes</h5><p class="notes">${esc(s.notes)}</p>` : ''}</div>`;
}

/* ── inspector: looks, palette, fonts, components ──────────── */
function renderInspector() {
  renderLooks(); renderPalette(); renderFonts(); renderKinds();
  $('#design-sum').textContent = designSummary();
  $('#title-accent-on').checked = !!effTitleAccent();
  if (effTitleAccent()) $('#title-accent').value = '#' + effTitleAccent().toLowerCase();
}
function renderLooks() {
  $('#look-grid').innerHTML = state.looks.map(lk => `
    <button class="look" data-id="${lk.id}" aria-pressed="${state.design.look === lk.id}" title="${esc(lk.desc)}">
      <span class="pic">${lookSvg(lk)}</span>
      <span class="nm">${esc(lk.name)}<small>${esc((lk.tags || [])[1] || 'light')}</small></span>
      <span class="sub">${esc(fontById(lk.font)?.name || '')} · ${esc(lk.desc)}</span>
    </button>`).join('');
}
function renderPalette() {
  const c = effColors();
  const names = { dk1: 'Ink', lt1: 'Page', dk2: 'Ink 2', lt2: 'Surface' };
  $('#palette').innerHTML = ACCENTS.map(s => `<label class="sw" style="background:#${c[s]}" title="${s.replace('accent', 'Accent ')} #${c[s]}"><input type="color" data-slot="${s}" value="#${c[s].toLowerCase()}"></label>`).join('') +
    ['dk1', 'dk2', 'lt2', 'lt1'].map(s => `<label class="sw n" style="background:#${c[s]};grid-column:span ${s === 'lt1' || s === 'dk1' ? 2 : 1}" title="${names[s]} #${c[s]}"><input type="color" data-slot="${s}" value="#${c[s].toLowerCase()}"></label>`).join('') +
    `<span class="lbl">${esc(state.design.palette ? (state.design.paletteName || 'Custom') + ' palette' : curLook() ? curLook().name + ' palette' : 'Current deck palette')} · click a swatch to change it</span>`;
}
function renderFonts() {
  const cur = state.design.font;
  const def = curLook() ? fontById(curLook().font) : null;
  $('#fonts').innerHTML = `<button class="font inherit" data-id="" aria-pressed="${!cur}"><span class="aa">Auto</span>
      <span><b>${def ? `Look's pair: ${esc(def.name)}` : 'Keep the deck fonts'}</b><span>${def ? esc(def.note) : esc(state.inv ? state.inv.theme.fonts.major + ' / ' + state.inv.theme.fonts.minor : '')}</span></span></button>` +
    state.fonts.map(f => `<button class="font" data-id="${f.id}" aria-pressed="${cur === f.id}">
      <span class="aa" style="font-family:${esc(fontStack(f.major))}">Aa</span><span><b>${esc(f.name)}</b><span>${esc(f.note)}</span></span></button>`).join('');
}
const GO = '<svg viewBox="0 0 20 20"><path d="M7.5 4.5L13 10l-5.5 5.5"/></svg>';
function kindsPresent() {
  const byKind = {};
  state.components.forEach(c => {
    byKind[c.kind] = (byKind[c.kind] || 0) + 1;
    if (c.kind === 'table' && c.numeric) byKind.heatmap = (byKind.heatmap || 0) + 1;
  });
  return byKind;
}
function styleName(kind, id) {
  if (id === 'keep') return 'Keep original';
  if (String(id).startsWith('my:')) return state.my.find(d => 'my:' + d.id === id)?.name || 'My design';
  return state.catalogue.styles[kind]?.find(s => s.id === id)?.name || id;
}
function renderKinds() {
  if (!state.catalogue) return;
  const byKind = kindsPresent();
  const cat = state.catalogue;
  $('#comp-count').textContent = `${state.components.filter(c => c.kind !== 'background').length} found`;
  $('#kinds').innerHTML = KIND_ORDER.filter(k => byKind[k] && cat.styles[k]).map(kind => {
    const n = kind === 'background' ? state.inv.slide_count : byKind[kind];
    const ct = kind === 'chart' && (state.design.kinds.chart?.chart_type || 'keep') !== 'keep'
      ? ` · as ${esc(cat.chart_types.find(t => t.id === state.design.kinds.chart.chart_type)?.name || '')}` : '';
    return `<button class="krow${state.gallery?.kind === kind ? ' open' : ''}" data-kind="${kind}">
      <span class="ico">${icon(kind)}</span>
      <span><b>${esc(cat.kinds[kind])} <span class="muted" style="font-weight:500">· ${n}</span></b>
        <span class="cur">Style: <i>${esc(kind === 'heatmap' && kindStyle(kind) === 'keep' ? 'Same as tables' : styleName(kind, kindStyle(kind)))}</i>${ct}${kind === 'chart' && cat.legends
          ? ` · ${esc((cat.legends.find(c => c.id === kindOption('chart', 'legend', 'chips')) || {}).name || '')}` : ''}${['chart', 'table', 'heatmap'].includes(kind) && !(kind === 'heatmap' && kindStyle(kind) === 'keep')
          ? ` · ${esc((cat.containers.find(c => c.id === kindOption(kind, 'container', 'none')) || {}).name || '')}` : ''}${kind === 'card'
          ? ` · ${esc((cat.icon_modes.find(c => c.id === kindOption('card', 'icons', 'auto')) || {}).name || '')}` : ''}</span></span>
      <span class="go">${cat.styles[kind].length}${mineOf(kind).length ? ` + ${mineOf(kind).length}` : ''} designs ${GO}</span></button>`;
  }).join('');
}
$('#kinds').addEventListener('click', e => {
  const b = e.target.closest('.krow');
  if (b) openGallery(b.dataset.kind);
});

/* ── style gallery ─────────────────────────────────────────── */
function slideHasKind(kind, n = state.selected) {
  return state.components.some(c => c.slide === n && (kind === 'heatmap' ? c.kind === 'table' && c.numeric : c.kind === kind));
}
function openGallery(kind) {
  const src = slideHasKind(kind) ? 'slide' : 'sample';
  state.gallery = { kind, source: state.gallery?.kind === kind ? state.gallery.source : src };
  if (state.gallery.source === 'slide' && !slideHasKind(kind)) state.gallery.source = 'sample';
  $('#gallery').hidden = false;
  renderKinds();
  renderGallery();
  requestGallery();
}
function closeGallery() {
  state.gallery = null;
  $('#gallery').hidden = true;
  renderKinds();
}
$('#gal-close').onclick = closeGallery;
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (!$('#cpop').hidden) closeCpop();
  else if (state.builder) closeBuilder();
  else if (state.gallery) closeGallery();
});
$('#gal-source').addEventListener('click', e => {
  const b = e.target.closest('button');
  if (!b || b.disabled || !state.gallery) return;
  state.gallery.source = b.dataset.v;
  renderGallery();
  requestGallery();
});
function setKindOption(kind, key, value) {
  const k = state.design.kinds[kind] || (state.design.kinds[kind] = {});
  if (!k.style) k.style = kindStyle(kind);
  k[key] = value;
  if (!state.design.look && !state.design.palette) state.design.look = null;
  designChanged();
}
$('#gal-box').addEventListener('change', e => setKindOption(state.gallery.kind, 'container', e.target.value));
$('#gal-icons').addEventListener('change', e => setKindOption('card', 'icons', e.target.value));
$('#gal-legend').addEventListener('change', e => setKindOption('chart', 'legend', e.target.value));
$('#gal-type').addEventListener('change', e => {
  const k = state.design.kinds.chart || (state.design.kinds.chart = {});
  k.chart_type = e.target.value;
  designChanged();
});
function galleryKey() {
  const g = state.gallery, p = galleryDesign();
  const ctx = { ...p, items: undefined, kinds: { ...(p.kinds || {}) } };
  const mine = { ...(ctx.kinds[g.kind] || {}) };
  delete mine.style;
  ctx.kinds[g.kind] = mine;  // the gallery varies the style only; container, icons and type stay part of the key
  return JSON.stringify([g.kind, g.source, g.source === 'slide' ? state.selected : 0, ctx]);
}
state.galleryCache = {};
const styles_count = kind => state.catalogue.styles[kind].length + 1;
function renderGallery() {
  const g = state.gallery;
  if (!g) return;
  const cat = state.catalogue, kind = g.kind;
  const has = slideHasKind(kind);
  $('#gal-ico').innerHTML = icon(kind);
  $('#gal-name').textContent = `${cat.kinds[kind]} · ${cat.styles[kind].length + mineOf(kind).length} designs`;
  const loading0 = !state.galleryCache[galleryKey()] && state.render;
  $('#gal-status').innerHTML = loading0 ? `<span class="spinner"></span>Rendering ${styles_count(kind)} designs…` : '';
  $('#gal-sub').textContent = `Shown ${g.source === 'slide' ? `on your slide ${state.selected}` : 'on a sample slide'} in ${curLook() ? curLook().name : 'your current'} colours · click one to apply it to every ${(NOUN[kind] || [kind])[0]} in the deck`;
  $$('#gal-source button').forEach(b => {
    b.setAttribute('aria-checked', b.dataset.v === g.source);
    if (b.dataset.v === 'slide') { b.disabled = !has; b.textContent = has ? `My slide ${state.selected}` : 'My slide (none here)'; }
  });
  $('#gal-type-wrap').hidden = kind !== 'chart';
  if (kind === 'chart') {
    const ct = state.design.kinds.chart?.chart_type || 'keep';
    $('#gal-type').innerHTML = cat.chart_types.map(t => `<option value="${t.id}"${t.id === ct ? ' selected' : ''}>${esc(t.name)}</option>`).join('');
  }
  const boxKind = ['chart', 'table', 'heatmap'].includes(kind);
  $('#gal-box-wrap').hidden = !boxKind;
  if (boxKind) {
    const cur = kindOption(kind, 'container', 'none');
    $('#gal-box').innerHTML = cat.containers.map(c => `<option value="${c.id}"${c.id === cur ? ' selected' : ''}>${esc(c.name)}</option>`).join('');
  }
  const customCur = kindStyle(kind).startsWith('my:');  // a design of your own brings its own icons and legend
  $('#gal-legend-wrap').hidden = kind !== 'chart' || !cat.legends || customCur;
  if (kind === 'chart' && cat.legends) {
    const cur = kindOption('chart', 'legend', 'chips');
    $('#gal-legend').innerHTML = cat.legends.map(c => `<option value="${c.id}"${c.id === cur ? ' selected' : ''}>${esc(c.name)}</option>`).join('');
  }
  $('#gal-icons-wrap').hidden = kind !== 'card' || customCur;
  if (kind === 'card') {
    const cur = kindOption('card', 'icons', 'auto');
    $('#gal-icons').innerHTML = cat.icon_modes.map(c => `<option value="${c.id}"${c.id === cur ? ' selected' : ''}>${esc(c.name)}</option>`).join('');
  }
  const shots = state.galleryCache[galleryKey()];
  const loading = !shots && state.render;
  const cur = kindStyle(kind);
  const styles = [kind === 'heatmap' ? { id: 'keep', name: 'Same as tables', desc: 'Number tables use the table design' }
    : { id: 'keep', name: 'Keep original', desc: 'Leave this component as designed' }, ...cat.styles[kind]];
  $('#gal-grid').innerHTML = styles.map((st, i) => {
    const src = shots?.[st.id];
    return `<button class="gcard" data-style="${st.id}" aria-pressed="${st.id === cur}" title="${esc(st.desc)}">
      <span class="pic${loading ? ' loading' : ''}">${src ? `<img src="${fileUrl(src)}" alt="${esc(st.name)}" loading="lazy">` : ''}</span>
      <span class="cap"><b><em class="num">${i || '0'}</em>${esc(st.name)}${lookKind(curLook(), kind).style === st.id ? '<small>look default</small>' : ''}</b><span>${esc(st.desc)}</span></span></button>`;
  }).join('') + mySection(kind, shots, loading, cur) +
    (!state.render ? '<div class="empty gal-empty">Previews need LibreOffice on this machine; you can still pick a design by name.</div>' : '');
  const ratio = g.source === 'slide' ? getComputedStyle(document.documentElement).getPropertyValue('--ratio') : '16 / 9';
  $('#gal-grid').style.setProperty('--gal-ratio', ratio);
}
async function requestGallery() {
  const g = state.gallery;
  if (!g || !state.render) return;
  const key = galleryKey();
  if (state.galleryCache[key]) { renderGallery(); return; }
  if (state.galleryPending === key) return;
  state.galleryPending = key;
  try {
    const { task } = await api(`/api/job/${state.job}/gallery`, { json: { kind: g.kind, source: g.source, slide: state.selected, design: galleryDesign() } });
    const r = await waitTask(task);
    state.galleryCache[key] = r.styles;
  } catch (err) { toast(err.message, true); state.galleryCache[key] = {}; }
  finally { if (state.galleryPending === key) state.galleryPending = null; }
  if (state.gallery && galleryKey() === key) renderGallery();
}
$('#gal-grid').addEventListener('click', e => {
  if (!state.gallery) return;
  const act = e.target.closest('[data-act]');
  if (act) { e.stopPropagation(); myAction(act.dataset.act, act.dataset.id); return; }
  if (e.target.closest('[data-my="import"]')) { $('#my-import').click(); return; }
  if (e.target.closest('[data-create]')) { openBuilder(state.gallery.kind); return; }
  const b = e.target.closest('.gcard[data-style]');
  if (!b) return;
  const kind = state.gallery.kind;
  const k = state.design.kinds[kind] || (state.design.kinds[kind] = {});
  k.style = b.dataset.style;
  if (!state.design.look && !designActive()) state.design.look = null;
  designChanged();
  toast(`${styleName(kind, b.dataset.style)} applied to every ${(NOUN[kind] || [kind])[0]}`);
});

function designChanged({ inspector = true } = {}) {
  if (inspector) renderInspector(); else $('#design-sum').textContent = designSummary();
  if (state.gallery) { renderGallery(); requestGallery(); }
  renderItems();
  renderStrip();
  schedulePreview();
  renderExportNote();
}
$('#look-grid').addEventListener('click', e => {
  const b = e.target.closest('.look');
  if (!b) return;
  applyLook(b.dataset.id);
});
function applyLook(id) {
  const d = state.design;
  if (d.look === id && !d.palette && !d.font && !Object.keys(d.kinds).length) return;
  Object.assign(d, { look: id, palette: null, paletteName: null, font: null, kinds: {}, titleAccent: undefined });
  designChanged();
  renderFilmstrip();
  toast(`${lookById(id).name} applied to every slide`);
}
$('#palette').addEventListener('input', debounce(e => {
  const i = e.target.closest('input[data-slot]');
  if (!i) return;
  state.design.palette = { ...effColors(), [i.dataset.slot]: i.value.slice(1).toUpperCase() };
  state.design.paletteName = 'Custom';
  designChanged();
}, 250));
$('#brand').addEventListener('input', e => ($('#brand-hex').textContent = e.target.value.toUpperCase()));
$('#btn-harmonize').onclick = () => harmonizeBrand();
async function harmonizeBrand(quiet) {
  try {
    const j = await api(`/api/harmonize?color=${$('#brand').value.slice(1)}&dark=0`);
    state.design.palette = j.colors;
    state.design.paletteName = 'Brand';
    if (!state.design.look) state.design.look = 'fresh';
    designChanged();
    if (!quiet) toast('Palette built from your brand colour');
  } catch (err) { toast(err.message, true); }
}
$('#title-accent-on').addEventListener('change', e => {
  state.design.titleAccent = e.target.checked ? $('#title-accent').value.slice(1).toUpperCase() : null;
  if (e.target.checked && kindStyle('title') !== 'accent-bar') state.design.kinds.title = { style: 'accent-bar' };
  designChanged();
});
$('#title-accent').addEventListener('input', debounce(e => {
  $('#title-accent-on').checked = true;
  state.design.titleAccent = e.target.value.slice(1).toUpperCase();
  if (kindStyle('title') !== 'accent-bar') state.design.kinds.title = { style: 'accent-bar' };
  designChanged();
}, 250));
['#opt-recolor', '#opt-refont'].forEach(s => $(s).addEventListener('change', () => designChanged({ inspector: false })));
$('#fonts').addEventListener('click', e => {
  const b = e.target.closest('.font');
  if (!b) return;
  state.design.font = b.dataset.id || null;
  designChanged();
});
$('#kinds').addEventListener('click', e => {
  const b = e.target.closest('.sty');
  if (!b) return;
  const k = state.design.kinds[b.dataset.kind] || (state.design.kinds[b.dataset.kind] = {});
  k.style = b.dataset.style;
  designChanged();
});
$('#kinds').addEventListener('change', e => {
  if (e.target.id !== 'chart-type') return;
  const k = state.design.kinds.chart || (state.design.kinds.chart = {});
  k.chart_type = e.target.value;
  designChanged();
});
$('#btn-reset').onclick = () => {
  state.design = blankDesign();
  designChanged();
  renderFilmstrip();
  toast('Back to the original design');
};

/* ── on this slide: per-component overrides ────────────────── */
function renderItems() {
  if (!state.inv || !state.catalogue) return;
  const n = state.selected;
  const all = state.components.filter(c => c.slide === n && c.kind !== 'background');
  const items = all.filter(c => c.detail !== 'connector');
  const links = all.length - items.length;
  const cat = state.catalogue;
  $('#items').innerHTML = (items.length ? items.map(it => {
    const o = state.design.items[it.id] || {};
    const heat = it.kind === 'table' && it.numeric && kindStyle('heatmap') !== 'keep';
    const inherited = heat ? kindStyle('heatmap') : kindStyle(it.kind);
    const inhName = inherited === 'keep' ? 'Keep' : styleName(heat ? 'heatmap' : it.kind, inherited);
    const optList = list => list.map(s => `<option value="${s.id}"${o.style === s.id ? ' selected' : ''}>${esc(s.name)}</option>`).join('');
    const mine = (it.kind === 'table' ? [...mineOf('table'), ...(it.numeric ? mineOf('heatmap') : [])] : mineOf(it.kind))
      .map(d => ({ id: 'my:' + d.id, name: d.name }));
    const opts = [`<option value="inherit">Deck: ${esc(inhName)}</option>`, `<option value="keep"${o.style === 'keep' ? ' selected' : ''}>Keep original</option>`,
      it.kind === 'table' && it.numeric ? `<optgroup label="Tables">${optList(cat.styles.table)}</optgroup><optgroup label="Heatmaps">${optList(cat.styles.heatmap)}</optgroup>`
        : optList(cat.styles[it.kind]), mine.length ? `<optgroup label="My designs">${optList(mine)}</optgroup>` : ''].join('');
    const changed = Object.values(o).some(v => v && v !== 'inherit' && v !== 'auto');
    let typeSel = it.kind === 'chart' ? `<select data-item="${it.id}" data-field="chart_type" aria-label="Chart type">
      <option value="inherit">Type: as deck</option>${cat.chart_types.filter(t => t.id !== 'keep').map(t => `<option value="${t.id}"${o.chart_type === t.id ? ' selected' : ''}>${esc(t.name)}</option>`).join('')}</select>` : '';
    if (it.kind === 'chart' || it.kind === 'table') typeSel += `<select data-item="${it.id}" data-field="container" aria-label="Container">
      <option value="inherit">Container: as deck</option>${cat.containers.map(c => `<option value="${c.id}"${o.container === c.id ? ' selected' : ''}>${esc(c.name)}</option>`).join('')}</select>`;
    if (it.kind === 'card') typeSel += `<select data-item="${it.id}" data-field="icon" aria-label="Icon">
      ${cat.icons.map(n => `<option value="${n}"${(o.icon || 'auto') === n ? ' selected' : ''}>${n === 'auto' ? 'Icon: automatic' : 'Icon: ' + esc(n.replace(/-/g, ' '))}</option>`).join('')}<option value="none"${o.icon === 'none' ? ' selected' : ''}>No icon</option></select>`;
    return `<div class="item${changed ? ' changed' : ''}"><span class="ico">${icon(it.kind)}</span>
      <span class="txt"><b>${esc(clean(it.detail && it.kind !== 'picture' ? it.detail : it.name))}</b><span>${esc(cat.kinds[it.kind].replace(/s$/, ''))}${it.kind === 'chart' && it.chart_type ? ' · ' + esc(it.chart_type) : ''} · ${esc(it.name)}</span></span>
      <span style="display:flex;flex-direction:column;gap:4px"><select data-item="${it.id}" data-field="style" aria-label="Style">${opts}</select>${typeSel}</span></div>`;
  }).join('') : '<div class="none">Nothing to restyle on this slide.</div>') +
    (links ? `<div class="none">+ ${links} connector${links > 1 ? 's' : ''}: they follow the flowchart style, keeping their arrow directions.</div>` : '');
}
$('#items').addEventListener('change', e => {
  const s = e.target.closest('select[data-item]');
  if (!s) return;
  const o = state.design.items[s.dataset.item] || (state.design.items[s.dataset.item] = {});
  o[s.dataset.field] = s.value;
  if (Object.values(o).every(v => !v || v === 'inherit' || v === 'auto')) delete state.design.items[s.dataset.item];
  designChanged({ inspector: false });
});

/* ── live preview of the current slide ─────────────────────── */
const stage = $('#stage');
function setCompare(mode) {
  stage.dataset.mode = mode;
  $$('#seg-compare button').forEach(b => b.setAttribute('aria-checked', b.dataset.v === mode));
}
$('#seg-compare').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setCompare(b.dataset.v); });
function loadImg(img, src) {
  return new Promise(res => {
    if (!src) { img.removeAttribute('src'); res(); return; }
    if (img.getAttribute('src') === src) { res(); return; }
    const pre = new Image();
    pre.onload = pre.onerror = () => { img.src = src; res(); };
    pre.src = src;
  });
}
function status(text, spin) {
  const el = $('#stage-status');
  el.innerHTML = (spin ? '<span class="spinner"></span>' : '') + esc(text);
  el.classList.toggle('show', !!text);
  clearTimeout(status._t);
  if (text && !spin) status._t = setTimeout(() => el.classList.remove('show'), 2200);
}
const schedulePreview = debounce(() => requestPreview(), 320);
async function requestPreview() {
  if (!state.job || state.view !== 'design') return;
  const n = state.selected, p = payload();
  const key = n + '|' + JSON.stringify(p);
  const seq = ++state.previewSeq;
  const active = !!p;
  stage.classList.toggle('single', !active);
  $('#seg-compare').querySelectorAll('button').forEach(b => (b.disabled = !active));
  const cached = state.previewCache[key];
  if (cached) { await show(cached); return; }
  if (!state.render) { $('#stage-empty').textContent = 'Live previews need LibreOffice on this machine.'; $('#stage-empty').hidden = false; return; }
  stage.classList.toggle('loading', active);
  if (!$('#img-before').getAttribute('src')) { $('#stage-empty').hidden = false; $('#stage-empty').textContent = 'Rendering slide…'; }
  status(active ? 'Rendering with the new design…' : 'Rendering slide…', true);
  try {
    const r = await api(`/api/job/${state.job}/preview`, { json: { slide: n, design: p } });
    const res = { before: fileUrl(r.before), after: r.after ? fileUrl(r.after) : null, summary: r.summary, ms: r.ms };
    state.previewCache[key] = res;
    if (seq === state.previewSeq) await show(res, true);
  } catch (err) {
    if (seq === state.previewSeq) { status(''); stage.classList.remove('loading'); toast(err.message, true); }
  }
  async function show(res, fresh) {
    await Promise.all([loadImg($('#img-before'), res.before), loadImg($('#img-after'), res.after)]);
    if (seq !== state.previewSeq) return;
    $('#stage-empty').hidden = true;
    stage.classList.remove('loading');
    if (fresh && res.after) {
      const sum = counted(res.summary?.restyled, true);
      status(`Updated in ${(res.ms / 1000).toFixed(1)}s${sum ? ' · ' + sum : ''}`);
    } else status('');
  }
}
/* compare handle */
(function initHandle() {
  let drag = false;
  const setPos = x => {
    const r = stage.getBoundingClientRect();
    const v = Math.max(0, Math.min(100, ((x - r.left) / r.width) * 100));
    stage.style.setProperty('--pos', v + '%');
    $('#handle').setAttribute('aria-valuenow', Math.round(v));
  };
  stage.addEventListener('pointerdown', e => {
    if (stage.dataset.mode !== 'split' || stage.classList.contains('single')) return;
    drag = true; stage.setPointerCapture(e.pointerId); setPos(e.clientX);
  });
  stage.addEventListener('pointermove', e => drag && setPos(e.clientX));
  stage.addEventListener('pointerup', () => (drag = false));
  $('#handle').addEventListener('keydown', e => {
    const cur = parseFloat(getComputedStyle(stage).getPropertyValue('--pos')) || 50;
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
      e.preventDefault();
      const v = Math.max(0, Math.min(100, cur + (e.key === 'ArrowLeft' ? -5 : 5)));
      stage.style.setProperty('--pos', v + '%');
      $('#handle').setAttribute('aria-valuenow', v);
    }
  });
})();

/* ── this slide in every look ──────────────────────────────── */
function renderFilmstrip() {
  if (!state.inv) return;
  const shots = state.lookShots[state.selected] || {};
  const pending = state.lookShots[state.selected] === undefined || state.lookShots[state.selected] === 'pending';
  $('#filmstrip').innerHTML = state.looks.map(lk => {
    const src = shots[lk.id];
    return `<button class="shot" data-id="${lk.id}" aria-pressed="${state.design.look === lk.id}" title="${esc(lk.desc)}">
      <span class="pic${!src && pending && state.render ? ' loading' : ''}">${src ? `<img src="${fileUrl(src)}" alt="Slide in ${esc(lk.name)}">` : lookSvg(lk)}</span>
      <span class="cap">${esc(lk.name)}<span class="sw">${[1, 2, 3, 4].map(i => `<i style="background:#${lk.colors['accent' + i]}"></i>`).join('')}</span></span></button>`;
  }).join('');
}
$('#filmstrip').addEventListener('click', e => { const b = e.target.closest('.shot'); if (b) applyLook(b.dataset.id); });
async function requestLooks() {
  const n = state.selected;
  renderFilmstrip();
  if (!state.render || state.lookShots[n] !== undefined) return;
  state.lookShots[n] = 'pending';
  renderFilmstrip();
  try {
    const { task } = await api(`/api/job/${state.job}/looks`, { json: { slide: n } });
    state.lookShots[n] = await waitTask(task);
  } catch { state.lookShots[n] = {}; }
  if (state.selected === n) renderFilmstrip();
}

/* ── all slides ────────────────────────────────────────────── */
$('#seg-scope').addEventListener('click', e => {
  const b = e.target.closest('button');
  if (!b) return;
  setScope(b.dataset.v);
});
function setScope(v) {
  $$('#seg-scope button').forEach(x => x.setAttribute('aria-checked', x.dataset.v === v));
  $('#scope-slide').hidden = v !== 'slide';
  $('#scope-deck').hidden = v !== 'deck';
  $('#seg-compare').style.visibility = v === 'slide' ? '' : 'hidden';
  if (v === 'deck') {
    if (!state.deck || state.deck.key !== payloadKey()) renderAll();
    else drawDeck();
  }
}
$('#btn-all').onclick = () => { showView('design'); setScope('deck'); };
$('#btn-render-all').onclick = () => renderAll();
async function renderAll() {
  if (!designActive()) { $('#deck-note').textContent = 'Pick a look (or change a component) to see the whole deck redesigned.'; $('#deck-grid').innerHTML = ''; return; }
  const btn = $('#btn-render-all');
  busy(btn, true);
  const key = payloadKey();
  $('#deck-note').textContent = 'Applying the design to every slide and rendering…';
  $('#deck-grid').innerHTML = state.inv.slides.map(s => `<figure class="deck-card"><div class="pic">${state.thumbs[s.index - 1] ? `<img src="${state.thumbs[s.index - 1]}" alt="" style="opacity:.35;filter:blur(1px)">` : ''}</div><figcaption><b>Slide ${s.index}</b></figcaption></figure>`).join('');
  try {
    const { task } = await api(`/api/job/${state.job}/render-design`, { json: { design: payload() } });
    const r = await waitTask(task);
    state.deck = { key, files: r.files, summary: r.summary };
    drawDeck();
    renderStrip();
  } catch (err) { $('#deck-note').textContent = err.message; toast(err.message, true); } finally { busy(btn, false); }
}
function drawDeck() {
  const d = state.deck, sm = d.summary || { restyled: {} };
  $('#deck-note').textContent = `${designSummary()}: restyled ${counted(sm.restyled) || 'nothing'}. Hover a slide to see the original; click it to open it.`;
  $('#deck-grid').innerHTML = d.files.length ? d.files.map((f, i) => `
    <figure class="deck-card" data-n="${i + 1}"><div class="pic"><img src="${fileUrl(f)}" alt="Slide ${i + 1} redesigned" loading="lazy">
      ${state.thumbs[i] ? `<img class="b" src="${state.thumbs[i]}" alt="Slide ${i + 1} original" loading="lazy">` : ''}</div>
      <figcaption><b>Slide ${i + 1}</b><span>${esc(clean(state.inv.slides[i]?.title))}</span></figcaption></figure>`).join('')
    : '<div class="empty">The redesigned deck is ready to download; previews need LibreOffice.</div>';
}
$('#deck-grid').addEventListener('click', e => {
  const f = e.target.closest('.deck-card[data-n]');
  if (!f) return;
  setScope('slide');
  selectSlide(+f.dataset.n);
});
$('#btn-download-deck').onclick = async () => {
  if (!designActive()) { toast('Pick a look or change a component first.', true); return; }
  const btn = $('#btn-download-deck');
  busy(btn, true);
  try {
    const r = await api(`/api/job/${state.job}/export-design`, { json: { design: payload() } });
    window.location.href = r.url;
    toast('Modern deck downloaded');
  } catch (err) { toast(err.message, true); } finally { busy(btn, false); }
};

/* ── export settings ───────────────────────────────────────── */
function segValue(id) { return $(`#${id} [aria-checked="true"]`).dataset.v; }
['#choice-mode', '#seg-assets'].forEach(sel => $(sel).addEventListener('click', e => {
  const b = e.target.closest('button');
  if (!b) return;
  $$('button', $(sel)).forEach(x => x.setAttribute('aria-checked', x === b));
}));
$('#use-design').addEventListener('change', renderExportNote);
function renderExportNote() {
  const on = designActive() && $('#use-design').checked;
  $('#export-design-note').innerHTML = !designActive() ? 'The code rebuilds the deck exactly as uploaded. Pick a look in Design to modernise it first.'
    : on ? `<b>${esc(designSummary())}</b> is applied before conversion, so the code builds the modern deck. Switch this off in Design to convert the original.`
      : `A design is set up (${esc(designSummary())}) but switched off for code generation.`;
}

/* ── generate ──────────────────────────────────────────────── */
$('#btn-generate').onclick = async () => {
  const btn = $('#btn-generate');
  busy(btn, true);
  try {
    const opts = { mode: segValue('choice-mode'), assets: segValue('seg-assets'), notes: $('#opt-notes').checked,
      design: payload(), use_design: $('#use-design').checked && designActive() };
    const { task } = await api(`/api/job/${state.job}/convert`, { json: opts });
    const r = await waitTask(task);
    Object.assign(state, { report: r.report, lines: r.html, slideLines: r.slide_lines, module: r.module });
    renderCode(); renderReport(); renderStrip(); renderSlideMeta(state.selected);
    $('#dl-py').href = `/api/job/${state.job}/download/py`;
    $('#dl-zip').href = `/api/job/${state.job}/download/zip`;
    ['#dl-py', '#dl-zip'].forEach(s => $(s).classList.remove('disabled'));
    $('#btn-copy').disabled = false; $('#btn-verify').disabled = false;
    $('#verify').innerHTML = '<div class="empty">Run the script to compare the rebuilt deck with its input.</div>';
    const rep = r.report;
    $('#mini-stats').innerHTML = `<div class="${rep.fidelity >= .9995 ? 'good' : ''}"><b>${pct(rep.fidelity)}</b><span>elements identical</span></div>
      <div><b>${rep.lines.toLocaleString()}</b><span>lines of Python</span></div><div><b>${rep.seconds}s</b><span>to generate</span></div>
      <div><b>${rep.restyle_summary ? rep.restyle_summary.total : 0}</b><span>components modernised</span></div>`;
    $('#export-results').hidden = false;
    showView('code');
    jumpToSlide(state.selected);
    toast(`Generated ${rep.lines.toLocaleString()} lines in ${rep.seconds}s · self-check ${pct(rep.fidelity)} identical`);
  } catch (err) { toast(err.message, true); } finally { busy(btn, false); }
};

/* ── code view ─────────────────────────────────────────────── */
function renderCode() {
  const starts = new Set(Object.values(state.slideLines));
  const rows = state.lines.map((html, i) => `<tr id="L${i + 1}"${starts.has(i + 1) ? ' class="slide-start"' : ''}><td class="ln">${i + 1}</td><td>${html || ' '}</td></tr>`);
  $('#code').innerHTML = `<table>${rows.join('')}</table>`;
  $('#code-sub').textContent = `${state.module}.py · ${state.report.lines.toLocaleString()} lines · click a slide to jump to its function`;
}
function jumpToSlide(n) {
  const ln = state.slideLines[n];
  const row = ln && document.getElementById('L' + ln);
  if (!row) return;
  const box = $('#code');
  box.scrollTop = row.offsetTop - 8;
  row.classList.add('flash');
  setTimeout(() => row.classList.remove('flash'), 1400);
}
$('#btn-copy').onclick = async () => {
  const text = $$('#code td:not(.ln)').map(td => td.textContent).join('\n');
  try { await navigator.clipboard.writeText(text); toast('Code copied'); } catch { toast('Copy is blocked here; use the download instead.', true); }
};
let findHits = [], findIdx = -1;
$('#code-find').addEventListener('input', debounce(runFind, 200));
$('#code-find').addEventListener('keydown', e => {
  if (e.key === 'Enter' && findHits.length) { e.preventDefault(); stepFind(e.shiftKey ? -1 : 1); }
});
function runFind() {
  const q = $('#code-find').value;
  $$('#code mark').forEach(m => m.replaceWith(...m.childNodes));
  findHits = []; findIdx = -1;
  if (q.length < 2) { $('#find-count').textContent = ''; return; }
  const rx = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  for (const td of $$('#code td:not(.ln)')) {
    if (!rx.test(td.textContent)) continue;
    const walker = document.createTreeWalker(td, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      const txt = node.nodeValue; let m, last = 0, found = false; const frag = document.createDocumentFragment();
      rx.lastIndex = 0;
      while ((m = rx.exec(txt))) {
        found = true;
        frag.append(txt.slice(last, m.index));
        const mk = document.createElement('mark'); mk.textContent = m[0]; frag.append(mk); findHits.push(mk);
        last = m.index + m[0].length;
      }
      if (found) { frag.append(txt.slice(last)); node.replaceWith(frag); }
    }
    if (findHits.length > 2000) break;
  }
  $('#find-count').textContent = findHits.length ? `${findHits.length} found` : 'No matches';
  if (findHits.length) stepFind(1);
}
function stepFind(d) {
  if (findIdx >= 0) findHits[findIdx].classList.remove('cur');
  findIdx = (findIdx + d + findHits.length) % findHits.length;
  const m = findHits[findIdx]; m.classList.add('cur'); m.scrollIntoView({ block: 'center' });
  $('#find-count').textContent = `${findIdx + 1} of ${findHits.length}`;
}

/* ── fidelity report ───────────────────────────────────────── */
function ring(value) {
  const r = 54, c = 2 * Math.PI * r, off = c * (1 - value);
  const col = value >= 0.9995 ? 'var(--mint)' : value > 0.97 ? 'var(--amber)' : 'var(--danger)';
  return `<svg class="ring" viewBox="0 0 132 132" role="img" aria-label="${pct(value)} identical">
    <circle cx="66" cy="66" r="${r}" fill="none" stroke="var(--sunk)" stroke-width="11"/>
    <circle cx="66" cy="66" r="${r}" fill="none" stroke="${col}" stroke-width="11" stroke-linecap="round"
      stroke-dasharray="${c}" stroke-dashoffset="${off}" transform="rotate(-90 66 66)"/>
    <text x="66" y="69" text-anchor="middle">${pct(value)}</text><text class="lab" x="66" y="87" text-anchor="middle">identical</text></svg>`;
}
function renderReport() {
  const r = state.report, st = r.stats;
  const patched = r.slides.reduce((a, s) => a + s.shapes.filter(x => x.mode === 'api' && x.patches).length, 0);
  const api_ = r.api_shapes - patched;
  const reasons = Object.entries(r.xml_reasons).map(([k, v]) => `<li>${v} shape${v > 1 ? 's' : ''}: ${esc(k)}</li>`).join('');
  const rs = r.restyle_summary, ts = r.theme_summary;
  $('#report-empty').hidden = true;
  $('#report').hidden = false;
  $('#report').innerHTML = `
    <div class="score">${ring(r.fidelity)}
      <div><h3>${r.identical} of ${r.items} slide elements rebuild identically</h3>
      <p>The generator ran its own code, rebuilt the deck and compared every shape, background, transition and animation tree with ${rs || ts ? 'the redesigned deck' : 'your file'}. ${r.rounds} build round${r.rounds > 1 ? 's' : ''}, ${r.seconds}s, ${r.lines.toLocaleString()} lines.</p></div></div>
    <div class="kpis">
      <div class="kpi api"><b>${api_}</b><span>Shapes written with the API</span></div>
      <div class="kpi patched"><b>${patched}</b><span>API shapes with exact patches</span></div>
      <div class="kpi xml"><b>${r.xml_shapes}</b><span>Shapes kept as exact XML</span></div>
      <div class="kpi"><b>${st.charts}</b><span>Charts</span></div>
      <div class="kpi"><b>${st.transitions}</b><span>Transitions</span></div>
      <div class="kpi"><b>${st.animations}</b><span>Animation effects</span></div>
    </div>
    ${rs ? `<p class="hint">Modernised before conversion: ${esc(counted(rs.restyled))}${ts ? `, with the ${esc(ts.to.name)} palette (${ts.recoloured} colours and ${ts.refonted} font references updated)` : ''}.</p>` : ts ? `<p class="hint">Palette “${esc(ts.to.name)}” applied before conversion: ${ts.recoloured} colours and ${ts.refonted} font references updated.</p>` : ''}
    <h3 class="section-title">By slide</h3>
    <div class="legend"><span><i style="background:var(--accent)"></i>API</span><span><i style="background:var(--amber)"></i>API + exact patch</span><span><i style="background:var(--violet)"></i>Exact XML</span></div>
    <table class="grid"><thead><tr><th>#</th><th>Slide</th><th class="num">Shapes</th><th>Code mix</th><th class="num">Patches</th><th>Transition</th><th class="num">Animations</th><th>Rebuild</th></tr></thead><tbody>
    ${r.slides.map(s => {
      const p = s.shapes.filter(x => x.mode === 'api' && x.patches).length, a = s.api_shapes - p, x = s.xml_shapes, tot = Math.max(1, a + p + x);
      return `<tr><td>${s.slide}</td><td>${esc(clean(s.title) || '—')}</td><td class="num">${s.shapes.length}</td>
        <td><span class="bar-mix"><i style="width:${a / tot * 100}%"></i><i class="patched" style="width:${p / tot * 100}%"></i><i class="xml" style="width:${x / tot * 100}%"></i></span></td>
        <td class="num">${s.patches}</td><td>${esc(s.transition || '—')}</td><td class="num">${s.animations.length}</td>
        <td>${s.differences.length ? `<span class="warn">${s.differences.length} different</span>` : '<span class="ok">identical</span>'}</td></tr>`;
    }).join('')}</tbody></table>
    ${reasons ? `<h3 class="section-title">Why some shapes are exact XML</h3><ul class="reasons">${reasons}</ul>` : ''}
    ${r.warnings.length ? `<h3 class="section-title">Notes</h3><ul class="reasons">${r.warnings.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}`;
}

/* ── verify ────────────────────────────────────────────────── */
$('#btn-verify').onclick = async () => {
  const btn = $('#btn-verify');
  busy(btn, true);
  $('#verify').innerHTML = '<div class="empty">Running the script and rendering both decks…</div>';
  try {
    const { task } = await api(`/api/job/${state.job}/verify`, { method: 'POST' });
    const r = await waitTask(task);
    const s = r.structural, vis = r.visual || [];
    const minSim = vis.length ? Math.min(...vis.map(v => v.similarity)) : null;
    $('#dl-rebuilt').href = `/api/job/${state.job}/download/rebuilt`;
    $('#dl-rebuilt').classList.remove('disabled');
    const allSame = s.identical === s.items;
    const input = state.report?.restyle_summary || state.report?.theme_summary ? 'redesigned input' : 'input deck';
    $('#verify').innerHTML = `
      <div class="summary-line">
        <span class="pill ${allSame ? 'good' : 'bad'}">Structure <b>${s.identical}/${s.items}</b> identical</span>
        <span class="pill ${s.slide_count[0] === s.slide_count[1] ? 'good' : 'bad'}">Slides <b>${s.slide_count[1]}/${s.slide_count[0]}</b></span>
        <span class="pill ${s.media.missing ? 'bad' : 'good'}">Media <b>${s.media.rebuilt}/${s.media.source}</b></span>
        ${minSim !== null ? `<span class="pill ${minSim > 0.999 ? 'good' : ''}">Lowest pixel match <b>${pct(minSim)}</b></span>` : ''}
      </div>
      <div class="compare">${(r.source || []).map((src, i) => {
        const v = vis[i], d = s.slides[i];
        return `<div class="pair"><figure><img src="${fileUrl(src)}" alt="Input slide ${i + 1}" loading="lazy"><figcaption>Slide ${i + 1} · ${input}</figcaption></figure>
          <figure><img src="${fileUrl(r.rebuilt[i])}" alt="Rebuilt slide ${i + 1}" loading="lazy"><figcaption>Slide ${i + 1} · rebuilt from code</figcaption></figure>
          <div class="verdict"><b class="${v && v.similarity > 0.999 ? 'ok' : ''}">${v ? pct(v.similarity) : '–'}</b>pixel match<br>${d && !d.differences.length ? '<span class="ok">XML identical</span>' : `<span class="warn">${d ? d.differences.length : '?'} XML differences</span>`}</div></div>`;
      }).join('') || s.slides.map(d => `<div class="pill">Slide ${d.slide}: ${d.differences.length ? d.differences.join(', ') : 'identical'}</div>`).join('')}</div>`;
  } catch (err) {
    $('#verify').innerHTML = `<div class="empty">${esc(err.message)}</div>`;
    toast('Verification failed; see the message in Verify.', true);
  } finally { busy(btn, false); }
};

/* ── your own designs ───────────────────────────────────────── */
const PEN = '<path d="M12.6 4.4l3 3L8.2 14.8H5.2v-3z"/>';
const DUP = '<rect x="7" y="7" width="9" height="9" rx="1.8"/><path d="M4 12.5V5.6A1.6 1.6 0 0 1 5.6 4h6.9"/>';
const BIN = '<path d="M4.5 6h11M8 6V4.5h4V6M6.2 6l.7 9.5h6.2l.7-9.5"/>';
const PLUS = '<path d="M10 4.5v11M4.5 10h11"/>';
const svgIcon = p => `<svg viewBox="0 0 20 20">${p}</svg>`;
const mineOf = kind => state.my.filter(d => d.kind === kind);
const CAP_KINDS = { heatmap: ['table'], table: ['table'], chart: ['chart'], card: ['card', 'shape'], shape: ['shape', 'card'],
  flow: ['flow'], picture: ['picture'], title: ['title'], text: ['text'], background: ['background'] };

async function loadDesigns() {
  try {
    const j = await api('/api/designs');
    state.my = j.designs || [];
    state.schema = j.schema;
  } catch { state.my = []; }
  if (state.inv) { renderKinds(); renderItems(); }
}

/* colour tokens: 'accent1', 'accent1@15' (tint), 'accent1@-30' (shade), '1F4FD8', 'auto' */
const TOKEN_RX = /^(?:(accent[1-6]|tx[12]|bg[12])|([0-9A-Fa-f]{6}))(?:@(-?\d{1,2}))?$/;
const SLOT = { tx1: 'dk1', bg1: 'lt1', tx2: 'dk2', bg2: 'lt2' };
function hexToHsl(hex) {
  const n = parseInt(hex, 16), r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
  if (mx === mn) return [0, 0, l];
  const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
  const h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [h / 6, s, l];
}
function hslToHex(h, s, l) {
  const f = (p, q, t) => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
  let r = l, g = l, b = l;
  if (s) { const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q; r = f(p, q, h + 1 / 3); g = f(p, q, h); b = f(p, q, h - 1 / 3); }
  return [r, g, b].map(x => Math.round(x * 255).toString(16).padStart(2, '0')).join('').toUpperCase();
}
function lumMod(hex, mod, off) { const [h, s, l] = hexToHsl(hex); return hslToHex(h, s, Math.min(1, l * mod / 100 + off / 100)); }
function tokHex(t) {
  const m = TOKEN_RX.exec(t || '');
  if (!m) return '#CBD5E1';
  const c = effColors() || {};
  let hex = m[2] ? m[2].toUpperCase() : (c[SLOT[m[1]] || m[1]] || '888888');
  if (m[3]) { const n = +m[3]; hex = n > 0 ? lumMod(hex, n, 100 - n) : lumMod(hex, 100 + n, 0); }
  return '#' + hex;
}
function tokName(t) {
  if (t === 'auto') return 'Automatic';
  const m = TOKEN_RX.exec(t || '');
  if (!m) return t;
  const mod = m[3] ? (+m[3] > 0 ? ` · ${m[3]}% tint` : ` · ${-m[3]}% darker`) : '';
  if (m[2]) return '#' + m[2].toUpperCase() + mod;
  return ({ tx1: 'Text', tx2: 'Text 2', bg1: 'Page', bg2: 'Surface' }[m[1]] || 'Accent ' + m[1].slice(-1)) + mod;
}

/* gallery section */
function describeDesign(d) {
  if (d.desc) return d.desc;
  if (d.sample?.name) return `Copied from ${d.sample.name}, slide ${d.sample.slide}`;
  return `Based on ${styleName(d.kind, d.base)}`;
}
function mySection(kind, shots, loading, cur) {
  if (!state.schema) return '';
  const mine = mineOf(kind), noun = (NOUN[kind] || [kind])[0];
  return `<div class="gal-mine-head"><h3>My designs</h3><span class="muted">${mine.length ? `${mine.length} saved · hover one to edit it`
      : `Build your own ${noun} design, or copy one from your own slides`}</span><span class="sp"></span>
      <button class="btn small quiet" data-my="import">Import…</button>${state.my.length ? '<a class="btn small quiet" href="/api/designs/export">Export all</a>' : ''}</div>
    <button class="gcard create" data-create="1" title="Create your own ${noun} design"><span class="pic"><span class="plus"><i>${svgIcon(PLUS)}</i>Create your own ${noun}
      <small>Start from any design above, or copy one from a slide</small></span></span>
      <span class="cap"><b>New design</b><span>Your colours, spacing, borders and sizes</span></span></button>` +
    mine.map(d => {
      const sid = 'my:' + d.id, src = shots?.[sid];
      return `<button class="gcard" data-style="${sid}" aria-pressed="${cur === sid}" title="${esc(d.name)}">
        <span class="pic${loading ? ' loading' : ''}">${src ? `<img src="${fileUrl(src)}" alt="${esc(d.name)}" loading="lazy">` : ''}</span>
        <span class="acts"><span data-act="edit" data-id="${d.id}" title="Edit">${svgIcon(PEN)}</span><span data-act="dup" data-id="${d.id}" title="Duplicate">${svgIcon(DUP)}</span><span class="del" data-act="del" data-id="${d.id}" title="Delete">${svgIcon(BIN)}</span></span>
        <span class="cap"><b>${esc(d.name)}<span class="mine">Mine</span></b><span>${esc(describeDesign(d))}</span></span></button>`;
    }).join('');
}
function myAction(act, id) {
  const d = state.my.find(x => x.id === id);
  if (!d) return;
  if (act === 'edit') openBuilder(d.kind, d);
  else if (act === 'dup') openBuilder(d.kind, d, { copy: true });
  else if (act === 'del') deleteDesign(d);
}
async function deleteDesign(d) {
  if (!confirm(`Delete “${d.name}”? Components using it go back to the deck design.`)) return;
  try {
    await fetch(`/api/designs/${encodeURIComponent(d.id)}`, { method: 'DELETE' });
    state.my = state.my.filter(x => x.id !== d.id);
    const sid = 'my:' + d.id;
    Object.values(state.design.kinds).forEach(k => { if (k.style === sid) delete k.style; });
    Object.entries(state.design.items).forEach(([key, o]) => { if (o.style === sid) { delete o.style; if (!Object.keys(o).length) delete state.design.items[key]; } });
    designChanged();
    toast(`“${d.name}” deleted`);
  } catch (err) { toast(err.message, true); }
}
$('#my-import').addEventListener('change', async e => {
  const f = e.target.files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append('file', f);
  try {
    const j = await api('/api/designs/import', { method: 'POST', body: fd });
    state.my = j.designs;
    designChanged();
    toast(`${j.imported} design${j.imported === 1 ? '' : 's'} imported`);
  } catch (err) { toast(err.message, true); }
  e.target.value = '';
});

/* the builder */
function openBuilder(kind, from = null, opts = {}) {
  const sch = state.schema;
  if (!sch || !state.job) { toast('Open a deck first.'); return; }
  const cur = kindStyle(kind);
  const base = from?.base || (sch.bases[kind].includes(cur) ? cur : sch.bases[kind][0]);
  const noun = (NOUN[kind] || [kind])[0];
  state.builder = {
    kind, base, id: opts.copy ? null : from?.id || null,
    params: JSON.parse(JSON.stringify(from?.params || sch.defaults[kind][base])),
    name: from ? (opts.copy ? `${from.name} copy` : from.name) : `My ${noun} ${mineOf(kind).length + 1}`,
    desc: from?.desc || '', sample: from?.sample || null, note: null,
    source: slideHasKind(kind) ? 'slide' : 'sample', cache: {}, seq: 0, capOpen: false,
    cap: { src: 'deck', job: state.job, comps: state.components, count: state.inv.slide_count, thumbs: state.thumbs,
      name: $('#deck-chip b')?.textContent || 'This deck', slide: null, ratio: null },
  };
  if (state.builder.sample) state.builder.source = 'capture';
  $$('#b-shots img').forEach(img => img.removeAttribute('src'));  // no stale preview from the last design
  $('#b-shot-before').hidden = true;
  $('#b-shots').classList.remove('two');
  $('#b-status').textContent = '';
  $('#builder').hidden = false;
  renderBuilder();
  requestBuilderPreview();
}
function closeBuilder() {
  state.builder = null;
  $('#builder').hidden = true;
  closeCpop();
}
$('#b-cancel').onclick = closeBuilder;
$('#b-save').onclick = () => saveBuilder(false);
$('#b-saveas').onclick = () => saveBuilder(true);
$('#b-name').addEventListener('input', e => { if (state.builder) state.builder.name = e.target.value; });

function renderBuilder() {
  const b = state.builder;
  if (!b) return;
  const sch = state.schema, cat = state.catalogue, noun = (NOUN[b.kind] || [b.kind])[0];
  $('#b-ico').innerHTML = icon(b.kind);
  $('#b-eyebrow').textContent = `${b.id ? 'Edit your' : 'New'} ${noun} design`;
  $('#b-name').value = b.name;
  $('#b-saveas').hidden = !b.id;
  $('#b-save').lastChild.textContent = b.id ? 'Save changes' : 'Save design';
  const has = slideHasKind(b.kind);
  $$('#b-source button').forEach(x => {
    x.setAttribute('aria-checked', x.dataset.v === b.source);
    if (x.dataset.v === 'slide') { x.disabled = !has; x.textContent = has ? `My slide ${state.selected}` : 'My slide (none here)'; }
    if (x.dataset.v === 'capture') x.hidden = !b.sample?.job;
  });
  $('#b-hint').textContent = b.source === 'capture' ? 'Your sample on the left, rebuilt with your design on the right.'
    : 'Every change re-renders the slide.';
  $('#b-base').innerHTML = sch.bases[b.kind].map(id => `<option value="${id}"${id === b.base ? ' selected' : ''}>${esc(styleName(b.kind, id))}</option>`).join('');
  const note = $('#b-note');
  note.hidden = !b.note;
  if (b.note) note.innerHTML = b.note;
  renderCapture();
  renderFields();
  const ratio = b.source === 'slide' ? getComputedStyle(document.documentElement).getPropertyValue('--ratio')
    : b.source === 'capture' ? (b.sample?.ratio || '16 / 9') : '16 / 9';
  $('#builder').style.setProperty('--b-ratio', ratio);
}
function fieldVisible(f, P) {
  if (!f.when) return true;
  return Object.entries(f.when).every(([k, c]) => Array.isArray(c) ? c.includes(P[k]) : c === '>0' ? +P[k] > 0 : true);
}
function fmtRange(f, v) {
  if (+v === 0 && f.zero) return f.zero;
  const n = +v, s = Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0$/, '');
  return s + (f.unit ? (f.unit === '%' || f.unit === '°' ? f.unit : ' ' + f.unit) : '');
}
function swatchStyle(list) {
  if (!list.length) return '';
  if (list.length === 1) return tokHex(list[0]);
  return `linear-gradient(90deg, ${list.map((t, i) => `${tokHex(t)} ${Math.round(i / (list.length - 1) * 100)}%`).join(', ')})`;
}
function fieldHtml(f, v) {
  const help = f.help ? `<small>${esc(f.help)}</small>` : '';
  if (f.type === 'select') {
    return `<label class="bf"><span>${esc(f.label)}</span><select data-k="${f.key}">${f.options.map(o => `<option value="${o.id}"${o.id === v ? ' selected' : ''}>${esc(o.name)}</option>`).join('')}</select>${help}</label>`;
  }
  if (f.type === 'range') {
    return `<label class="bf"><span>${esc(f.label)}<em data-v="${f.key}">${esc(fmtRange(f, v))}</em></span><input type="range" data-k="${f.key}" min="${f.min}" max="${f.max}" step="${f.step}" value="${v}">${help}</label>`;
  }
  if (f.type === 'toggle') {
    return `<label class="bf tog"><input type="checkbox" data-k="${f.key}"${v ? ' checked' : ''}><span>${esc(f.label)}</span></label>`;
  }
  if (f.type === 'colour') {
    return `<div class="bf"><span>${esc(f.label)}</span><button class="sw-btn" data-colour="${f.key}"><i class="${v === 'auto' ? 'auto' : ''}" style="${v === 'auto' ? '' : `background:${tokHex(v)}`}"></i><b>${esc(tokName(v))}</b>${v !== 'auto' && TOKEN_RX.exec(v)?.[1] ? '<span>theme</span>' : ''}</button>${help}</div>`;
  }
  const list = v || [];  // palette / ramp
  const presets = f.type === 'ramp' ? `<div class="presets">${state.schema.ramps.map(r => `<button data-ramp="${r.id}" title="${esc(r.name)}" style="background:${r.stops.length ? swatchStyle(r.stops) : `linear-gradient(90deg, ${tokHex('accent1@10')}, ${tokHex('accent1')}, ${tokHex('accent1@-25')})`}"></button>`).join('')}</div>` : '';
  const bar = f.type === 'ramp' ? `<div class="ramp-bar" style="background:${list.length ? swatchStyle(list) : `linear-gradient(90deg, ${tokHex('accent1@10')}, ${tokHex('accent1')}, ${tokHex('accent1@-25')})`}"></div>` : '';
  return `<div class="bf"><span>${esc(f.label)}${list.length ? `<em><a href="#" data-clear="${f.key}">${f.type === 'ramp' ? 'Use brand shades' : 'Use deck colours'}</a></em>` : ''}</span>${bar}
    <div class="chips">${list.length ? list.map((t, i) => `<button class="chip-sw" data-list="${f.key}" data-i="${i}" title="${esc(tokName(t))}" style="background:${tokHex(t)}"></button>`).join('')
      : `<span class="deck">${f.type === 'ramp' ? 'Shades of the brand colour' : 'Deck colours'}</span>`}${list.length < 8 ? `<button class="chip-add" data-add="${f.key}" title="Add a colour">+</button>` : ''}</div>${presets}${help}</div>`;
}
function renderFields() {
  const b = state.builder;
  const fields = state.schema.fields[b.kind];
  const groups = [];
  fields.forEach(f => {
    if (!fieldVisible(f, b.params)) return;
    let g = groups.find(x => x.name === f.group);
    if (!g) groups.push(g = { name: f.group, html: [] });
    g.html.push(fieldHtml(f, b.params[f.key]));
  });
  $('#b-fields').innerHTML = groups.map(g => `<div class="b-group"><h4>${esc(g.name)}</h4>${g.html.join('')}</div>`).join('');
}
const builderPreview = debounce(() => requestBuilderPreview(), 420);
function setParam(k, v, rerender = true) {
  const b = state.builder;
  if (!b) return;
  b.params[k] = v;
  if (rerender) renderFields();
  builderPreview();
}
$('#b-fields').addEventListener('input', e => {
  const el = e.target.closest('[data-k]');
  if (!el || el.type !== 'range') return;
  const f = state.schema.fields[state.builder.kind].find(x => x.key === el.dataset.k);
  const v = +el.value;
  const em = $(`em[data-v="${f.key}"]`);
  if (em) em.textContent = fmtRange(f, v);
  setParam(f.key, v, false);
});
$('#b-fields').addEventListener('change', e => {
  const el = e.target.closest('[data-k]');
  if (!el) return;
  setParam(el.dataset.k, el.type === 'checkbox' ? el.checked : el.type === 'range' ? +el.value : el.value);
});
$('#b-fields').addEventListener('click', e => {
  const b = state.builder;
  const clear = e.target.closest('[data-clear]');
  if (clear) { e.preventDefault(); setParam(clear.dataset.clear, []); return; }
  const preset = e.target.closest('[data-ramp]');
  if (preset) { setParam('ramp', [...(state.schema.ramps.find(r => r.id === preset.dataset.ramp)?.stops || [])]); return; }
  const one = e.target.closest('[data-colour]');
  if (one) {
    const f = state.schema.fields[b.kind].find(x => x.key === one.dataset.colour);
    openCpop(one, b.params[f.key], { auto: !!f.auto, onPick: t => setParam(f.key, t) });
    return;
  }
  const chip = e.target.closest('.chip-sw');
  if (chip) {
    const key = chip.dataset.list, i = +chip.dataset.i;
    openCpop(chip, b.params[key][i], { remove: true, onPick: t => {
      const list = [...b.params[key]];
      if (t === null) list.splice(i, 1); else list[i] = t;
      setParam(key, list);
    } });
    return;
  }
  const add = e.target.closest('[data-add]');
  if (add) {
    const key = add.dataset.add, list = b.params[key] || [];
    openCpop(add, list.length ? list[list.length - 1] : 'accent1', { onPick: t => setParam(key, [...list, t]) });
  }
});
$('#b-base').addEventListener('change', e => {
  const b = state.builder;
  b.base = e.target.value;
  b.params = JSON.parse(JSON.stringify(state.schema.defaults[b.kind][b.base]));
  b.note = null;
  renderBuilder();
  requestBuilderPreview();
});
$('#b-source').addEventListener('click', e => {
  const x = e.target.closest('button');
  if (!x || x.disabled || !state.builder) return;
  state.builder.source = x.dataset.v;
  renderBuilder();
  requestBuilderPreview();
});
async function requestBuilderPreview() {
  const b = state.builder;
  if (!b || !state.render) {
    if (b && !state.render) $('#b-status').textContent = 'Previews need LibreOffice; you can still save the design.';
    return;
  }
  const body = { kind: b.kind, source: b.source, slide: state.selected, sample_job: b.sample?.job, sample_slide: b.sample?.slide,
    draft: { kind: b.kind, base: b.base, params: b.params }, design: galleryDesign() };
  const key = JSON.stringify(body);
  if (b.cache[key]) { showBuilderShots(b.cache[key]); return; }
  const seq = ++b.seq;
  $('#b-status').innerHTML = '<span class="spinner"></span>Rendering…';
  $$('#b-shots .frame').forEach(f => f.classList.add('loading'));
  try {
    const j = await api(`/api/job/${state.job}/design-preview`, { json: body });
    b.cache[key] = j;
    if (state.builder === b && seq === b.seq) showBuilderShots(j);
  } catch (err) {
    if (state.builder === b && seq === b.seq) {
      $('#b-status').textContent = '';
      $$('#b-shots .frame').forEach(f => f.classList.remove('loading'));
      if (b.source === 'capture') { b.source = 'sample'; renderBuilder(); requestBuilderPreview(); }
      toast(err.message, true);
    }
  }
}
function showBuilderShots(j) {
  const before = $('#b-shot-before'), two = !!j.before;
  before.hidden = !two;
  $('#b-shots').classList.toggle('two', two);
  $('#b-after-cap').textContent = two ? 'Rebuilt with your design' : 'With your design';
  const tasks = [loadImg($('#b-shot-after img'), fileUrl(j.after))];
  if (two) tasks.push(loadImg($('#b-shot-before img'), fileUrl(j.before)));
  Promise.all(tasks).then(() => {
    $$('#b-shots .frame').forEach(f => f.classList.remove('loading'));
    $('#b-status').textContent = j.ms > 50 ? `Rendered in ${(j.ms / 1000).toFixed(1)} s` : '';
  });
}
async function saveBuilder(asNew) {
  const b = state.builder;
  if (!b) return;
  const name = ($('#b-name').value || b.name).trim() || 'My design';
  busy($('#b-save'), true);
  try {
    const j = await api('/api/designs', { json: { id: asNew ? null : b.id, kind: b.kind, base: b.base, name, desc: b.desc,
      params: b.params, source: b.sample ? 'sample' : 'builder', sample: b.sample } });
    const d = j.design;
    const i = state.my.findIndex(x => x.id === d.id);
    if (i >= 0) state.my[i] = d; else state.my.push(d);
    const k = state.design.kinds[b.kind] || (state.design.kinds[b.kind] = {});
    k.style = 'my:' + d.id;
    const noun = (NOUN[b.kind] || [b.kind])[1];
    closeBuilder();
    if (state.gallery?.kind !== d.kind) openGallery(d.kind);
    designChanged();
    toast(`“${d.name}” saved and applied to every ${noun.replace(/s$/, '')}${d.kind === 'heatmap' ? ' (number tables)' : ''}`);
  } catch (err) { toast(err.message, true); }
  finally { busy($('#b-save'), false); }
}

/* colour picker */
const CP_COLS = ['accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6', 'tx1'];
const CP_ROWS = [12, 30, 60, 0, -25, -50];
function openCpop(anchor, current, { auto = false, remove = false, onPick }) {
  const pop = $('#cpop');
  const cur = current && current !== 'auto' ? current : null;
  const btn = t => `<button data-tok="${t}" class="${t === cur ? 'sel' : ''}" title="${esc(tokName(t))}" style="background:${tokHex(t)}"></button>`;
  const neutrals = ['bg1', 'bg2', 'bg2@60', 'tx1@20', 'tx1@50', 'tx1@75', 'tx2'];
  const hex = (cur ? tokHex(cur) : '#4F46E5').slice(1);
  pop.innerHTML = `<h5>Theme colours · follow the palette</h5>
    <div class="cp-grid">${CP_ROWS.map(n => CP_COLS.map(c => btn(n ? `${c}@${n}` : c)).join('')).join('')}${neutrals.map(btn).join('')}</div>
    <h5>Exact colour</h5>
    <div class="cp-row"><input type="color" value="#${hex}" aria-label="Pick a colour"><input type="text" value="#${hex}" maxlength="7" aria-label="Hex colour"><button class="btn small" data-hex>Use</button></div>
    ${auto || remove ? `<div class="cp-row">${auto ? '<button class="btn small quiet" data-auto>Automatic</button>' : ''}${remove ? '<button class="btn small quiet" data-remove>Remove this colour</button>' : ''}</div>` : ''}`;
  pop.hidden = false;
  const r = anchor.getBoundingClientRect(), h = pop.offsetHeight;
  pop.style.left = Math.max(8, Math.min(r.left, innerWidth - 282)) + 'px';
  pop.style.top = (r.bottom + 6 + h > innerHeight ? Math.max(8, r.top - h - 6) : r.bottom + 6) + 'px';
  state.cpop = { onPick, anchor };
  const color = $('input[type="color"]', pop), text = $('input[type="text"]', pop);
  color.addEventListener('input', () => (text.value = color.value.toUpperCase()));
}
function closeCpop() { $('#cpop').hidden = true; state.cpop = null; }
$('#cpop').addEventListener('click', e => {
  const c = state.cpop;
  if (!c) return;
  const tokB = e.target.closest('[data-tok]');
  let pick;
  if (tokB) pick = tokB.dataset.tok;
  else if (e.target.closest('[data-auto]')) pick = 'auto';
  else if (e.target.closest('[data-remove]')) pick = null;
  else if (e.target.closest('[data-hex]')) {
    const v = $('#cpop input[type="text"]').value.replace('#', '').trim();
    if (!/^[0-9A-Fa-f]{6}$/.test(v)) { toast('Use a 6-digit hex colour, like #1F4FD8.', true); return; }
    pick = v.toUpperCase();
  } else return;
  closeCpop();
  c.onPick(pick);
});
document.addEventListener('mousedown', e => {
  if (!$('#cpop').hidden && !e.target.closest('#cpop') && !(state.cpop && state.cpop.anchor.contains(e.target))) closeCpop();
});

/* copy a design from a slide */
$('#b-copy-btn').onclick = () => {
  const b = state.builder;
  b.capOpen = !b.capOpen;
  renderCapture();
};
function renderCapture() {
  const b = state.builder, c = b.cap;
  $('#b-capture').hidden = !b.capOpen;
  if (!b.capOpen) return;
  $$('#b-cap-src button').forEach(x => x.setAttribute('aria-checked', x.dataset.v === c.src));
  const want = CAP_KINDS[b.kind];
  const comps = (c.comps || []).filter(x => want.includes(x.kind) && x.detail !== 'connector');
  $('#b-cap-deck').textContent = c.loading ? `Reading ${c.name}…` : comps.length
    ? `${c.name}: ${comps.length} ${comps.length === 1 ? 'component' : 'components'} you can copy. Choose a slide.`
    : `${c.name}: nothing of this kind to copy here.`;
  if (c.slide == null || !comps.some(x => x.slide === c.slide)) c.slide = comps[0]?.slide ?? null;
  const n = c.count || 0;
  $('#b-cap-slides').innerHTML = Array.from({ length: n }, (_, i) => i + 1).map(k => {
    const ok = comps.some(x => x.slide === k);
    return `<button data-n="${k}" aria-pressed="${c.slide === k}"${ok ? '' : ' disabled'} title="Slide ${k}">${c.thumbs?.[k - 1] ? `<img src="${c.thumbs[k - 1]}" alt="">` : ''}<em>${k}</em></button>`;
  }).join('');
  const here = comps.filter(x => x.slide === c.slide);
  $('#b-cap-comps').innerHTML = here.length ? here.map(x => `<button data-cid="${x.id}" data-slide="${x.slide}" title="${esc(x.name)}">${icon(x.kind === 'table' && b.kind === 'heatmap' ? 'heatmap' : x.kind)}<span>${esc(capLabel(x))}</span></button>`).join('')
    : '<span class="none">Pick a slide above.</span>';
}
function capLabel(x) {
  if (x.kind === 'background') return 'Slide background';
  if (x.kind === 'table') return `${x.name} · ${x.detail}`;
  if (x.kind === 'chart') return `${x.name}${x.detail ? ' · ' + x.detail : ''}`;
  return clean(x.detail && x.kind !== 'picture' ? x.detail : x.name);
}
$('#b-cap-src').addEventListener('click', e => {
  const x = e.target.closest('button');
  if (!x || !state.builder) return;
  if (x.dataset.v === 'file') { $('#b-cap-file').click(); return; }
  Object.assign(state.builder.cap, { src: 'deck', job: state.job, comps: state.components, count: state.inv.slide_count,
    thumbs: state.thumbs, name: $('#deck-chip b')?.textContent || 'This deck', slide: null, ratio: null });
  renderCapture();
});
$('#b-cap-file').addEventListener('change', async e => {
  const f = e.target.files[0];
  e.target.value = '';
  const b = state.builder;
  if (!f || !b) return;
  Object.assign(b.cap, { src: 'file', loading: true, name: f.name, comps: [], count: 0, thumbs: [], slide: null });
  renderCapture();
  const fd = new FormData();
  fd.append('file', f);
  try {
    const j = await api('/api/upload', { method: 'POST', body: fd });
    Object.assign(b.cap, { job: j.job, comps: j.components || [], count: j.inventory.slide_count, loading: false,
      ratio: `${j.inventory.size.width_in} / ${j.inventory.size.height_in}` });
    renderCapture();
    if (j.thumbs_task) {
      waitTask(j.thumbs_task).then(files => {
        b.cap.thumbs = files.map(x => `/api/job/${j.job}/file/thumbs/${x}`);
        if (state.builder === b) renderCapture();
      }).catch(() => {});
    }
  } catch (err) { b.cap.loading = false; renderCapture(); toast(err.message, true); }
});
$('#b-cap-slides').addEventListener('click', e => {
  const x = e.target.closest('button[data-n]');
  if (!x || x.disabled || !state.builder) return;
  state.builder.cap.slide = +x.dataset.n;
  renderCapture();
});
$('#b-cap-comps').addEventListener('click', async e => {
  const x = e.target.closest('button[data-cid]');
  const b = state.builder;
  if (!x || !b) return;
  x.classList.add('busy');
  try {
    const r = await api('/api/designs/capture', { json: { job: b.cap.job, slide: +x.dataset.slide, cid: x.dataset.cid,
      kind: b.kind, follow_theme: $('#b-follow').checked } });
    b.base = r.base;
    b.params = r.params;
    b.sample = { ...r.sample, ratio: b.cap.ratio || getComputedStyle(document.documentElement).getPropertyValue('--ratio') };
    b.source = 'capture';
    b.capOpen = false;
    const what = x.querySelector('span').textContent;
    b.note = `<b>Copied from “${esc(what)}”</b> on slide ${r.sample.slide} of ${esc(r.sample.name || 'your deck')}: ${esc((r.notes || []).join(', ') || 'settings read')}. Fine-tune anything below.`;
    if (!b.id && /^My /.test(b.name)) b.name = `${(state.catalogue.kinds[b.kind] || '').replace(/s$/, '')} from ${(r.sample.name || 'my deck').replace(/\.pptx?$/i, '')}`;
    renderBuilder();
    requestBuilderPreview();
  } catch (err) { toast(err.message, true); }
  finally { x.classList.remove('busy'); }
});
