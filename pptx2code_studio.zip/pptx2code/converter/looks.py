"""Fresh design system: palettes, font pairs and one-click Looks.

Palette roles (12 theme slots)
  lt1  page          – the slide background in light looks
  dk1  ink           – body text in light looks / the page in dark looks
  lt2  surface       – cards, panels, table header fills (light looks)
  dk2  ink-2         – secondary text (light) / surface (dark looks)
  accent1…6          – vivid, evenly bright data colours; accent1 is the brand colour
  hlink / folHlink   – links

Components only ever reference roles (bg1, bg2, tx1, accentN), so a Look changes the
whole deck coherently and still flips correctly between light and dark.
"""

FONT_PAIRS = [
    {'id': 'aptos', 'light': 'Aptos Light', 'name': 'Aptos', 'major': 'Aptos Display', 'minor': 'Aptos',
     'note': 'Microsoft 365 default – crisp and current'},
    {'id': 'segoe', 'light': 'Segoe UI Light', 'name': 'Segoe UI', 'major': 'Segoe UI Semibold', 'minor': 'Segoe UI',
     'note': 'Built into every Windows PC'},
    {'id': 'inter', 'light': 'Inter Light', 'name': 'Inter', 'major': 'Inter', 'minor': 'Inter',
     'note': 'Free Google font, product-UI feel (install it)'},
    {'id': 'poppins', 'light': 'Poppins Light', 'name': 'Poppins + Inter', 'major': 'Poppins', 'minor': 'Inter',
     'note': 'Geometric headings, friendly (install both)'},
    {'id': 'manrope', 'light': 'Manrope Light', 'name': 'Manrope', 'major': 'Manrope', 'minor': 'Manrope',
     'note': 'Free, modern grotesk (install it)'},
    {'id': 'helvetica', 'light': 'Helvetica Neue Light', 'name': 'Helvetica Neue', 'major': 'Helvetica Neue', 'minor': 'Helvetica Neue',
     'note': 'Mac standard'},
]
FONT_BY_ID = {f['id']: f for f in FONT_PAIRS}


def _p(dk1, lt1, dk2, lt2, a, hl=None, fhl=None):
    return dict(dk1=dk1, lt1=lt1, dk2=dk2, lt2=lt2, **{f'accent{i + 1}': c for i, c in enumerate(a)},
                hlink=hl or a[0], folHlink=fhl or a[5])


def _k(chart, container, card, table, background, title='modern', flow='pill', shape='soft', picture='rounded',
       text='modern', icons='auto', table_box=None, legend='chips', heatmap=None):
    k = dict(chart={'style': chart, 'container': container, 'legend': legend},
             table={'style': table, 'container': table_box or container},
             card={'style': card, 'icons': icons}, shape=shape, flow=flow, picture=picture, title=title, text=text,
             background=background)
    if heatmap:
        k['heatmap'] = {'style': heatmap, 'container': table_box or container}
    return k


LOOKS = [
    {'id': 'fresh', 'name': 'Fresh Indigo', 'dark': False, 'font': 'aptos', 'tags': ['light', 'dashboard'],
     'desc': 'Light slate canvas, white cards, solid icon chips, indigo with cyan and amber',
     'colors': _p('0F172A', 'FFFFFF', '475569', 'F1F5F9',
                  ['4F46E5', '06B6D4', 'F59E0B', '10B981', 'EC4899', '8B5CF6']),
     'kinds': _k('clean', 'header', 'kpi', 'soft', 'canvas')},
    {'id': 'finance', 'name': 'Finance Teal', 'dark': False, 'font': 'segoe', 'tags': ['light', 'finance'],
     'desc': 'Mint-grey page, icon-header KPI cards with coloured figures, teal and green',
     'colors': _p('2F3B45', 'FFFFFF', '5B6B76', 'E6F0F0',
                  ['3BB0BC', '3DBE8B', '5C7E99', 'E5B63A', '8B6CD9', 'EF7A5C']),
     'kinds': _k('clean', 'badge', 'kpi-header', 'soft', 'canvas', title='editorial', icons='circle')},
    {'id': 'analytics', 'name': 'Analytics', 'dark': False, 'font': 'segoe', 'tags': ['light', 'analytics'],
     'desc': 'Navy and orange: thin big numbers with one highlighted KPI, smooth lines',
     'colors': _p('2B2766', 'FFFFFF', '6B6F80', 'F2F2F4',
                  ['3A3584', 'F5A11C', '2ECC9A', '7CCFE6', 'F05A6B', '8B5CF6']),
     'kinds': _k('smooth', 'grey', 'kpi-spotlight', 'clean', 'white', title='editorial', table_box='grey')},
    {'id': 'navy', 'name': 'Navy Sky', 'dark': False, 'font': 'segoe', 'tags': ['light', 'finance'],
     'desc': 'Navy and sky blue, large-radius cards with centred titles, side icons',
     'colors': _p('0E2F4F', 'FFFFFF', '4B6075', 'EDEFF2',
                  ['123E68', '2AA3DE', '7CC7EE', '0EA5A0', 'F59E0B', 'E05263']),
     'kinds': _k('clean', 'centered', 'kpi-side', 'clean', 'canvas', icons='bare', flow='chip')},
    {'id': 'electric', 'name': 'Electric', 'dark': False, 'font': 'segoe', 'tags': ['light', 'project'],
     'desc': 'Electric blue and violet, lavender KPI cards, smooth curves',
     'colors': _p('1B1748', 'FFFFFF', '55536E', 'EFEFF4',
                  ['3D2BF5', '8B2CF5', '22C1D6', 'F59E0B', 'EC4899', '10B981']),
     'kinds': _k('smooth', 'card', 'kpi-tint', 'soft', 'canvas', icons='soft', flow='solid', shape='gradient')},
    {'id': 'vivid', 'name': 'Vivid Tiles', 'dark': False, 'font': 'segoe', 'tags': ['light', 'sales'],
     'desc': 'Gradient KPI tiles in blue, teal, orange and green, clean chart cards',
     'colors': _p('1F2937', 'FFFFFF', '5B6472', 'F1F2F4',
                  ['4A6CF7', '22C1D6', 'F5A623', '52C41A', '1FBF8F', 'A855F7']),
     'kinds': _k('clean', 'header', 'kpi-tile', 'soft', 'canvas')},
    {'id': 'cobalt', 'name': 'Cobalt', 'dark': False, 'font': 'segoe', 'tags': ['light', 'people'],
     'desc': 'Cobalt, green and orange: KPI strip with colour icon chips, grey panels',
     'colors': _p('1F2937', 'FFFFFF', '4B5563', 'F2F2F3',
                  ['1F4FD8', '2EBFAE', 'F28A3C', '7C4DFF', '3DBB61', '2EBFCF']),
     'kinds': _k('clean', 'grey', 'kpi-strip', 'clean', 'white', icons='solid', heatmap='heat-mono')},
    {'id': 'royal', 'name': 'Royal Numbers', 'dark': False, 'font': 'segoe', 'tags': ['light', 'bold'],
     'desc': 'Royal blue, teal and plum tiles with big figures and outline icons',
     'colors': _p('1E293B', 'FFFFFF', '475569', 'F3F4F6',
                  ['1F5BB8', '25B4B8', '7B4A7E', 'F59E0B', '10B981', 'E4562E']),
     'kinds': _k('bold', 'grey', 'kpi-hero', 'blocks', 'white', title='modern', flow='typed', table_box='grey')},
    {'id': 'mint', 'name': 'Mint', 'dark': False, 'font': 'aptos', 'tags': ['light', 'calm'],
     'desc': 'Emerald and sky, accent-line cards on a soft glow',
     'colors': _p('0B1F1A', 'FFFFFF', '3F5F56', 'ECFDF5',
                  ['10B981', '0EA5E9', 'F97316', '6366F1', 'F43F5E', '14B8A6']),
     'kinds': _k('smooth', 'accent', 'kpi-accent', 'soft', 'glow', title='accent-bar', icons='soft')},
    {'id': 'sunset', 'name': 'Sunset', 'dark': False, 'font': 'poppins', 'tags': ['light', 'vivid'],
     'desc': 'Orange, pink and violet gradient KPIs, fading bars',
     'colors': _p('1F1235', 'FFFFFF', '5B4B75', 'FFF7ED',
                  ['F97316', 'EC4899', '8B5CF6', 'FACC15', '06B6D4', '22C55E']),
     'kinds': _k('fade', 'card', 'kpi-gradient', 'accent', 'canvas', title='accent-bar', flow='solid',
                 shape='solid')},
    {'id': 'graphite', 'name': 'Graphite', 'dark': False, 'font': 'inter', 'tags': ['light', 'consulting'],
     'desc': 'Monochrome with one electric-blue highlight, outline cards',
     'colors': _p('111111', 'FFFFFF', '52525B', 'F4F4F5',
                  ['2563EB', '18181B', '71717A', 'A1A1AA', 'D4D4D8', 'F59E0B']),
     'kinds': _k('highlight', 'outline', 'kpi-outline', 'minimal', 'white', flow='chip', shape='outline')},
    {'id': 'house-red', 'name': 'House Red', 'dark': False, 'font': 'segoe', 'tags': ['light', 'brand'],
     'desc': 'Neutral and calm; #DB0011 only on the title bar',
     'colors': _p('1A1D23', 'FFFFFF', '4B5260', 'F4F5F7',
                  ['2563EB', '0D9488', '7C3AED', 'F59E0B', '0891B2', '64748B']),
     'title_accent': 'DB0011',
     'kinds': _k('highlight', 'header', 'kpi-bar', 'clean', 'canvas', title='accent-bar', flow='chip')},
]
LOOK_BY_ID = {lk['id']: lk for lk in LOOKS}
# looks retired in the redesign map to their nearest successor, so saved settings keep working
for _old, _new in (('sky', 'navy'), ('ocean', 'navy'), ('coral', 'sunset'), ('lavender', 'electric'),
                   ('teal', 'finance')):
    LOOK_BY_ID.setdefault(_old, LOOK_BY_ID[_new])


def presets():
    """Theme presets derived from the looks (used by the Theme panel and the CLI)."""
    out = {}
    for lk in LOOKS:
        f = FONT_BY_ID[lk['font']]
        out[lk['id']] = {'name': lk['name'], 'dark': lk['dark'], 'colors': lk['colors'],
                         'fonts': {'major': f['major'], 'minor': f['minor']}}
    return out


def catalogue():
    return {'looks': LOOKS, 'fonts': FONT_PAIRS}
