"""PPTX → Python code generator.

Two modes
  editable – python-pptx API calls + small helpers (fonts, sizes, colours, bullets,
             tables, chart data, connectors …). Anything the API cannot express is
             restored with targeted exact patches found by rebuilding and diffing.
  exact    – every shape is written as its original OOXML (lossless, less readable).

In both modes slide backgrounds, transitions, animations (timing tree), hidden
state, notes, links between slides, sections and custom shows are reproduced, and
the generator rebuilds the deck itself and diffs it against the source before it
returns, so the code it hands back is checked, not hoped-for.
"""
import datetime as _dt
import io
import keyword
import re
import sys
import traceback
from dataclasses import dataclass, field
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE, MSO_CONNECTOR
from pptx.parts.image import Image as PptxImage

from . import describe as D
from .diff import diff, merge_ops
from .ooxml import (A_NS, C_NS, NS, P_NS, R_NS, RT_NAMES, NsRegistry, canon, child, children, fmt_len,
                    fmt_num, local, make_resolver, py_str, snippet)

RUNTIME_PATH = Path(__file__).with_name('runtime.py')
SKIP_RELS = {'http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout',
             'http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide'}
CONNECTORS = {'straightConnector1': 'STRAIGHT', 'bentConnector3': 'ELBOW', 'curvedConnector3': 'CURVE'}
IND = '    '


# ═══ data model ══════════════════════════════════════════════════════════════
@dataclass
class ShapeEmit:
    el: object                  # source element
    sid: str
    name: str
    kind: str
    var: str
    mode: str = 'api'           # 'api' | 'xml'
    lines: list = field(default_factory=list)
    children: list = field(default_factory=list)
    ops: dict = field(default_factory=dict)
    chart: dict = None          # chart info when built via API
    ph_cloned: bool = True      # placeholder comes from the layout (else created with _new_ph)
    reason: str = ''            # why xml mode was chosen


@dataclass
class SlideEmit:
    index: int
    src: object                 # source slide
    shapes: list = field(default_factory=list)
    extras: dict = field(default_factory=dict)
    notes_xml: bool = False
    tree_props: bool = False
    fallback: bool = False


@dataclass
class Result:
    code: str
    assets: dict
    report: dict
    module_name: str


# ═══ helpers ═════════════════════════════════════════════════════════════════
def _slug(name, used):
    s = re.sub(r'[^0-9a-zA-Z]+', '_', name or 'shape').strip('_').lower() or 'shape'
    if s[0].isdigit():
        s = 'sh_' + s
    if keyword.iskeyword(s) or s in {'slide', 'prs', 'p', 'tbl', 'cd', 'cell', 'C', 'F', 'G', 'Pct', 'RT',
                                     'gf', 'grp', 'c'}:
        s += '_'
    base, n = s, 2
    while s in used:
        s = f'{base}_{n}'
        n += 1
    used.add(s)
    return s


def _ident_kw(k):
    return k.isidentifier() and not keyword.iskeyword(k)


def _attr_items(el):
    """Plain (non-namespaced) attributes; None if any attribute can't be a keyword argument."""
    out = []
    for k, v in el.attrib.items():
        if k.startswith('{') or not _ident_kw(k):
            return None
        out.append((k, v))
    return out


def _numstr(v):
    try:
        f = float(v)
        return fmt_num(f) if re.fullmatch(r'-?\d+(\.\d+)?', v) else repr(v)
    except ValueError:
        return repr(v)


# ── colours / fills / lines → expressions ────────────────────────────────────
def color_expr(el):
    if el is None:
        return None
    tag = local(el)
    mods = []
    for m in el:
        if not isinstance(m.tag, str) or set(m.attrib) - {'val'} or len(m):
            return None
        mods.append((local(m), m.get('val')))
    if tag == 'srgbClr':
        val = el.get('val').upper()
    elif tag == 'schemeClr':
        val = el.get('val')
        if re.fullmatch(r'[0-9A-Fa-f]{6}', val):
            return None
    elif tag == 'sysClr':
        val = 'sys:' + el.get('val')
        if el.get('lastClr'):
            mods.append(('lastClr', repr(el.get('lastClr'))))
    elif tag == 'prstClr':
        val = 'prst:' + el.get('val')
    else:
        return None
    if not mods:
        return repr(val)
    if len({k for k, _ in mods}) != len(mods):
        return None
    return 'C(%r%s)' % (val, ''.join(f', {k}={v if k == "lastClr" else _numstr(v)}' for k, v in mods))


def fill_expr(el):
    tag = local(el)
    if tag == 'noFill':
        return "'none'"
    if tag == 'solidFill':
        return color_expr(el[0]) if len(el) == 1 else None
    if tag == 'gradFill':
        gs = child(el, 'gsLst')
        if gs is None:
            return None
        stops = []
        for g in gs:
            if len(g) != 1:
                return None
            c = color_expr(g[0])
            if c is None:
                return None
            stops.append(f"({g.get('pos')}, {c})")
        args = [f"stops=[{', '.join(stops)}]"]
        known = {'gsLst'}
        lin, path, tile = child(el, 'lin'), child(el, 'path'), child(el, 'tileRect')
        if lin is not None:
            known.add('lin')
            if set(lin.attrib) - {'ang', 'scaled'}:
                return None
            if lin.get('ang') is not None:
                args.append(f"angle={fmt_num(int(lin.get('ang')) / 60000)}")
            if lin.get('scaled') is not None:
                args.append(f"scaled={lin.get('scaled')}")
        if path is not None:
            known.add('path')
            ftr = child(path, 'fillToRect')
            if ftr is not None:
                attrs = ' '.join(f'{k}="{v}"' for k, v in ftr.attrib.items())
                args.append(f"path=({path.get('path')!r}, {attrs!r})")
            else:
                args.append(f"path={path.get('path')!r}")
        if tile is not None and tile.attrib:
            known.add('tileRect')
            args.append('tile=%r' % ' '.join(f'{k}="{v}"' for k, v in tile.attrib.items()))
        if {local(c) for c in el} - known:
            return None
        for a in ('flip', 'rotWithShape'):
            if el.get(a) is not None:
                args.append(f'{a}={el.get(a)!r}')
        if set(el.attrib) - {'flip', 'rotWithShape'}:
            return None
        return f"G({', '.join(args)})"
    return None


FILL_TAGS = ('noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill')


def effects_expr(el):
    """a:effectLst → "'none'" | "Shadow(...)" | None."""
    if el.attrib:
        return None
    if not len(el):
        return "'none'"
    if len(el) != 1 or local(el[0]) != 'outerShdw' or len(el[0]) != 1:
        return None
    sh = el[0]
    col = color_expr(sh[0])
    if col is None or not all(_ident_kw(k) for k in sh.attrib):
        return None
    return 'Shadow(' + ', '.join([col] + [f'{k}={_numstr(v)}' for k, v in sh.attrib.items()]) + ')'


def style_kwargs(st):
    kw = []
    for tag, key in (('lnRef', 'line'), ('fillRef', 'fill'), ('effectRef', 'effect'), ('fontRef', 'font')):
        r = child(st, tag)
        if r is None or set(r.attrib) != {'idx'} or len(r) > 1:
            return None
        idx = r.get('idx')
        idx_s = repr(idx) if tag == 'fontRef' else idx
        if len(r):
            col = color_expr(r[0])
            if col is None:
                return None
            kw.append(f'{key}=({idx_s}, {col})')
        else:
            kw.append(f'{key}={idx_s}')
    return kw


def line_kwargs(ln):
    kw = []
    if ln.get('w') is not None:
        kw.append(f"width={fmt_num(int(ln.get('w')) / 12700)}")
    for a in ('cap', 'cmpd', 'algn'):
        if ln.get(a) is not None:
            kw.append(f'{a}={ln.get(a)!r}')
    for c in ln:
        t = local(c)
        if t == 'noFill':
            kw.append('none=True')
        elif t in ('solidFill', 'gradFill'):
            e = fill_expr(c)
            if e:
                kw.append(f'color={e}')
        elif t == 'prstDash':
            kw.append(f"dash={c.get('val')!r}")
        elif t in ('round', 'bevel'):
            kw.append(f'join={t!r}')
        elif t == 'miter':
            kw.append("join='miter'")
        elif t in ('headEnd', 'tailEnd'):
            items = dict(c.attrib)
            key = 'head' if t == 'headEnd' else 'tail'
            if list(items) == ['type']:
                kw.append(f"{key}={items['type']!r}")
            else:
                kw.append(f'{key}=dict(' + ', '.join(f'{k}={v!r}' for k, v in items.items()) + ')')
        elif t == 'miter' and c.get('lim') != '800000':
            pass
    return kw


# ── text → helper calls ──────────────────────────────────────────────────────
def rpr_kwargs(rpr, rels):
    if rpr is None:
        return []
    kw = []
    attrs = _attr_items(rpr) or []
    for k, v in attrs:
        if k == 'sz':
            kw.append(f'size={fmt_num(int(v) / 100)}')
        elif k in ('b', 'i'):
            kw.append(f"{'bold' if k == 'b' else 'italic'}={v not in ('0', 'false')}")
        elif k == 'u':
            kw.append(f'underline={v!r}')
        elif k == 'strike':
            kw.append(f'strike={v!r}')
        else:
            kw.append(f'{k}={v!r}')
    for c in rpr:
        t = local(c)
        if t == 'ln':
            if len(c) == 1 and local(c[0]) == 'noFill' and not c.attrib:
                kw.append("outline='none'")
            elif len(c) == 1 and local(c[0]) == 'solidFill' and set(c.attrib) <= {'w'}:
                e = fill_expr(c[0])
                if e:
                    kw.append(f"outline=({e}, {fmt_num(int(c.get('w')) / 12700)})" if c.get('w') else f'outline={e}')
        elif t == 'effectLst':
            e = effects_expr(c)
            if e:
                kw.append(f'effects={e}')
        elif t in FILL_TAGS:
            e = fill_expr(c)
            if e:
                kw.append(f'color={e}')
        elif t == 'highlight' and len(c) == 1:
            e = color_expr(c[0])
            if e:
                kw.append(f'highlight={e}')
        elif t in ('latin', 'ea', 'cs', 'sym'):
            face = c.get('typeface')
            extra = {k: v for k, v in c.attrib.items() if k != 'typeface'}
            key = 'font' if t == 'latin' else t
            if face is None:
                continue
            if extra and all(_ident_kw(k) for k in extra):
                kw.append(f'{key}=F({face!r}, ' + ', '.join(f'{k}={v!r}' for k, v in extra.items()) + ')')
            elif not extra:
                kw.append(f'{key}={face!r}')
        elif t == 'hlinkClick':
            rid = c.get(f'{{{R_NS}}}id')
            spec = rels.get(rid)
            if spec and spec[0] == 'ext' and not len(c) and set(c.attrib) == {f'{{{R_NS}}}id'}:
                kw.append(f'link={spec[2]!r}')
    return kw


def ppr_kwargs(ppr):
    if ppr is None:
        return []
    kw = []
    for k, v in (_attr_items(ppr) or []):
        if k == 'algn':
            kw.append(f'align={v!r}')
        elif k == 'lvl':
            kw.append(f'level={v}')
        elif k in ('marL', 'indent'):
            kw.append(f'{k}={fmt_len(v)}' if re.fullmatch(r'-?\d+', v) and int(v) >= 0 else f'{k}={v!r}')
        else:
            kw.append(f'{k}={v!r}')
    for c in ppr:
        t = local(c)
        if t in ('lnSpc', 'spcBef', 'spcAft') and len(c) == 1:
            key = {'lnSpc': 'line_spacing', 'spcBef': 'space_before', 'spcAft': 'space_after'}[t]
            s = c[0]
            if local(s) == 'spcPct':
                kw.append(f"{key}=Pct({fmt_num(int(s.get('val')) / 1000)})")
            elif local(s) == 'spcPts':
                kw.append(f"{key}=Pt({fmt_num(int(s.get('val')) / 100)})")
        elif t == 'buClr' and len(c) == 1:
            e = color_expr(c[0])
            if e:
                kw.append(f'bullet_color={e}')
        elif t == 'buClrTx':
            kw.append("bullet_color='text'")
        elif t == 'buSzTx':
            kw.append("bullet_size='text'")
        elif t == 'buFontTx':
            kw.append("bullet_font='text'")
        elif t == 'buSzPts':
            kw.append(f"bullet_size=Pt({fmt_num(int(c.get('val')) / 100)})")
        elif t == 'tabLst':
            tabs = []
            for tab in c:
                if set(tab.attrib) - {'pos', 'algn'} or tab.get('pos') is None:
                    tabs = None
                    break
                tabs.append(f"({fmt_len(tab.get('pos'))}, {tab.get('algn', 'l')!r})")
            if tabs is not None:
                kw.append(f"tabs=[{', '.join(tabs)}]")
        elif t == 'buSzPct':
            kw.append(f"bullet_size={fmt_num(int(c.get('val')) / 1000)}")
        elif t == 'defRPr':
            kw.append('default_run=dict(' + ', '.join(rpr_kwargs(c, {})) + ')')
        elif t == 'buFont' and c.get('typeface'):
            extra = {k: v for k, v in c.attrib.items() if k != 'typeface'}
            if extra:
                kw.append(f"bullet_font=F({c.get('typeface')!r}, " + ', '.join(f'{k}={v!r}' for k, v in extra.items()) + ')')
            else:
                kw.append(f"bullet_font={c.get('typeface')!r}")
        elif t == 'buNone':
            kw.append('no_bullet=True')
        elif t == 'buAutoNum':
            kw.append(f"autonum={c.get('type')!r}")
            if c.get('startAt'):
                kw.append(f"start_at={c.get('startAt')}")
        elif t == 'buChar':
            kw.append(f"bullet={c.get('char')!r}")
    return kw


INSET_ATTRS = {'lIns', 'tIns', 'rIns', 'bIns'}


def bodypr_kwargs(bp):
    kw = []
    for k, v in (_attr_items(bp) or []):
        if k in INSET_ATTRS and re.fullmatch(r'\d+', v):
            kw.append(f'{k}={fmt_len(v)}')
        else:
            kw.append(f'{k}={v!r}')
    for c in bp:
        t = local(c)
        if t == 'spAutoFit':
            kw.append("autofit='shape'")
        elif t == 'noAutofit':
            kw.append("autofit='none'")
        elif t == 'normAutofit':
            kw.append("autofit='normal'")
            if c.get('fontScale'):
                kw.append(f"font_scale={c.get('fontScale')}")
            if c.get('lnSpcReduction'):
                kw.append(f"line_reduction={c.get('lnSpcReduction')}")
    return kw


def call(fn, *args, kw=(), width=104):
    parts = [*args, *kw]
    s = f"{fn}({', '.join(parts)})"
    if len(s) <= width + 8:
        return [s]
    out, line = [f'{fn}('], IND
    for p in parts:
        if len(line) + len(p) + 2 > width and line.strip():
            out.append(line.rstrip())
            line = IND
        line += p + ', '
    out.append(line.rstrip().rstrip(','))
    out.append(')')
    return out


def emit_text(target, txBody, rels):
    """Lines that rebuild a text body through the text helpers."""
    lines = []
    bp = child(txBody, 'bodyPr')
    if bp is not None and (bp.attrib or len(bp)):
        lines += call('_frame', target, kw=bodypr_kwargs(bp))
    paras = children(txBody, 'p')
    for i, p in enumerate(paras):
        ppr = child(p, 'pPr')
        kids = [c for c in p if isinstance(c.tag, str) and local(c) != 'pPr']
        var = 'p' if kids else None
        head = call('_para', target, str(i), kw=ppr_kwargs(ppr))
        if var:
            head[0] = 'p = ' + head[0]
        lines += head
        for c in kids:
            t = local(c)
            rk = rpr_kwargs(child(c, 'rPr') if t != 'endParaRPr' else c, rels)
            if t == 'r':
                tx = child(c, 't')
                lines += call('_run', 'p', repr(tx.text or '' if tx is not None else ''), kw=rk)
            elif t == 'br':
                lines += call('_br', 'p', kw=rk)
            elif t == 'fld':
                tx = child(c, 't')
                fp = child(c, 'pPr')
                if fp is not None:
                    rk = rk + ['para=dict(' + ', '.join(ppr_kwargs(fp)) + ')']
                lines += call('_field', 'p', repr(c.get('type')), repr(c.get('id')),
                              repr(tx.text or '' if tx is not None else ''), kw=rk)
            elif t == 'endParaRPr':
                lines += call('_end', 'p', kw=rk)
    return lines


# ═══ generator ═══════════════════════════════════════════════════════════════
class Generator:
    def __init__(self, data, mode='editable', asset_mode='folder', module_name='deck', notes=True,
                 max_rounds=5, log=None):
        self.data = data
        self.mode = mode
        self.asset_mode = asset_mode
        self.module_name = re.sub(r'\W+', '_', module_name).strip('_') or 'deck'
        self.notes = notes
        self.max_rounds = max_rounds
        self.log = log or (lambda *a: None)
        self.ns = NsRegistry()
        self.assets = {}
        self.parts = {}      # key -> info dict
        self.warnings = []

    # ── package bookkeeping ──────────────────────────────────────────────────
    def build_template(self):
        prs = Presentation(io.BytesIO(self.data))
        pres = prs.part._element
        lst = prs.slides._sldIdLst
        index = {prs.part.related_part(s.rId): i + 1 for i, s in enumerate(lst)}
        self.slide_ids = [int(s.get('id')) for s in lst]
        self.custom_shows = []
        csl = pres.find('{%s}custShowLst' % P_NS)
        if csl is not None:
            for show in csl:
                nums = []
                for sld in show.iter('{%s}sld' % P_NS):
                    part = prs.part.related_part(sld.get(f'{{{R_NS}}}id'))
                    nums.append(index.get(part))
                self.custom_shows.append((show.get('name'), int(show.get('id')), [n for n in nums if n]))
            for sld in csl.iter('{%s}sld' % P_NS):
                sld.attrib.pop(f'{{{R_NS}}}id', None)
            pres.remove(csl)
        for s in list(lst):
            prs.part.drop_rel(s.rId)
            lst.remove(s)
        out = io.BytesIO()
        prs.save(out)
        self.assets['template.pptx'] = out.getvalue()

    def asset_name(self, partname):
        name = str(partname).lstrip('/')
        return name[4:] if name.startswith('ppt/') else name

    def register(self, part):
        key = str(part.partname)
        if key in self.parts:
            return key
        info = {'ct': part.content_type, 'file': self.asset_name(key), 'rels': {}}
        self.parts[key] = info
        self.assets[info['file']] = part.blob
        for rid, rel in sorted(part.rels.items(), key=lambda kv: _rid_num(kv[0])):
            info['rels'][rid] = self.rel_spec(rel)
        return key

    def rel_spec(self, rel):
        if rel.is_external:
            return ('ext', rel.reltype, rel.target_ref)
        tgt = rel.target_part
        if tgt in self.slide_index:
            return ('slide', rel.reltype, self.slide_index[tgt])
        if tgt in self.layout_index:
            m, l = self.layout_index[tgt]
            return ('layout', rel.reltype, m, l)
        return ('part', rel.reltype, self.register(tgt))

    # ── shapes ───────────────────────────────────────────────────────────────
    def make_shape(self, el, used, rels, layout_ph):
        name, sid = D.shape_name(el)
        kind = D.shape_kind(el)
        se = ShapeEmit(el=el, sid=sid, name=name, kind=kind, var=_slug(name, used))
        tag = local(el)
        if self.mode == 'exact' or sid is None:
            se.mode, se.reason = 'xml', 'exact mode' if self.mode == 'exact' else 'no shape id'
        elif tag == 'grpSp':
            for c in el:
                if local(c) in ('sp', 'pic', 'cxnSp', 'grpSp', 'graphicFrame', 'contentPart', 'AlternateContent'):
                    se.children.append(self.make_shape(c, used, rels, layout_ph))
        elif tag == 'sp':
            ph = el.find('.//{%s}ph' % P_NS)
            if ph is not None:
                idx = int(ph.get('idx', '0'))
                ltype = layout_ph.get(idx)
                se.ph_cloned = ph.get('type') not in ('dt', 'ftr', 'sldNum') and idx in layout_ph and \
                    (ltype != 'pic' or ph.get('type') == 'pic')
            elif child(child(el, 'spPr'), 'xfrm') is None:
                se.mode, se.reason = 'xml', 'shape without position'
        elif tag == 'pic':
            ph = el.find('.//{%s}ph' % P_NS)
            if ph is not None and layout_ph.get(int(ph.get('idx', '0'))) != 'pic':
                se.mode, se.reason = 'xml', 'picture in a non-picture placeholder'
            elif se.kind in ('video', 'audio'):
                se.mode, se.reason = 'xml', 'media'
            else:
                blip = el.find('.//{%s}blip' % A_NS)
                rid = blip.get(f'{{{R_NS}}}embed') if blip is not None else None
                spec = rels.get(rid)
                ok = False
                if spec and spec[0] == 'part':
                    try:
                        PptxImage.from_blob(self.assets[self.parts[spec[2]]['file']])
                        ok = ph is not None or child(child(el, 'spPr'), 'xfrm') is not None
                    except Exception:
                        ok = False
                if not ok:
                    se.mode, se.reason = 'xml', 'image format/position not supported by add_picture'
        elif tag == 'cxnSp':
            sp = child(el, 'spPr')
            if sp is None or child(sp, 'xfrm') is None or child(sp, 'prstGeom') is None:
                se.mode, se.reason = 'xml', 'connector geometry'
        elif tag == 'graphicFrame':
            if el.find('.//{%s}ph' % P_NS) is not None:
                se.mode, se.reason = 'xml', 'graphic placeholder'
            elif kind == 'table':
                pass
            elif kind == 'chart':
                se.chart = self.chart_info(el, rels)
                if se.chart is None:
                    se.mode, se.reason = 'xml', 'chart type/data layout not supported by chart-data API'
            else:
                se.mode, se.reason = 'xml', f'{kind} has no python-pptx API'
        else:
            se.mode, se.reason = 'xml', f'{kind} has no python-pptx API'
        return se

    # ── charts ───────────────────────────────────────────────────────────────
    def chart_info(self, gf, rels):
        cref = gf.find('.//{%s}chart' % C_NS)
        if cref is None:
            return None
        spec = rels.get(cref.get(f'{{{R_NS}}}id'))
        if not spec or spec[0] != 'part':
            return None
        part = self.part_obj.get(spec[2])
        if part is None:
            return None
        try:
            from pptx.chart.chart import Chart
            ctype = Chart(part._element, part).chart_type
        except Exception:
            return None
        cs = part._element
        plot_area = cs.find('.//{%s}plotArea' % C_NS)
        plots = [c for c in plot_area if local(c).endswith('Chart')]
        sers = []
        for pl in plots:
            sers += [c for c in pl if local(c) == 'ser']
        sers.sort(key=lambda s: int(child(s, 'order').get('val')) if child(s, 'order') is not None else 0)
        kinds = {local(p) for p in plots}
        if not sers or kinds & {'stockChart', 'surfaceChart', 'surface3DChart', 'ofPieChart'}:
            return None
        family = 'xy' if kinds == {'scatterChart'} else 'bubble' if kinds == {'bubbleChart'} else 'cat'
        if family == 'cat' and kinds & {'scatterChart', 'bubbleChart'}:
            return None

        def cache(el):
            if el is None:
                return None, None
            ref = el[0] if len(el) else None
            if ref is None:
                return None, None
            if local(ref) in ('strRef', 'numRef'):
                c = child(ref, 'strCache') if child(ref, 'strCache') is not None else child(ref, 'numCache')
            elif local(ref) in ('strLit', 'numLit'):
                c = ref
            else:
                return 'bad', None
            if c is None:
                return [], None
            n = int(child(c, 'ptCount').get('val')) if child(c, 'ptCount') is not None else 0
            vals = [None] * n
            for pt in children(c, 'pt'):
                v = child(pt, 'v')
                i = int(pt.get('idx'))
                if i < n and v is not None:
                    vals[i] = v.text
            fc = child(c, 'formatCode')
            kind = 'num' if local(ref).startswith('num') else 'str'
            return (kind, vals), (fc.text if fc is not None else None)

        def name_of(s):
            tx = child(s, 'tx')
            if tx is None:
                return ''
            for v in tx.iter('{%s}v' % C_NS):
                return v.text or ''
            return ''

        def nums(vals):
            out = []
            for v in vals:
                if v is None:
                    out.append(None)
                elif re.fullmatch(r'-?\d+', v.strip()):
                    out.append(int(v))
                else:
                    out.append(float(v))
            return out

        info = {'type': ctype.name, 'family': family, 'part': spec[2], 'series': []}
        if family == 'cat':
            cats, cat_fmt = cache(child(sers[0], 'cat'))
            if cats == 'bad' or (cats and cats[0] == 'num'):
                return None
            categories = [c if c is not None else '' for c in cats[1]] if cats else []
            info['categories'] = categories
            for s in sers:
                c2, _ = cache(child(s, 'cat'))
                if c2 and c2 != 'bad' and [x if x is not None else '' for x in c2[1]] != categories:
                    return None
                vals, fmt = cache(child(s, 'val'))
                if vals is None or vals == 'bad' or vals[0] != 'num':
                    return None
                if len(vals[1]) != len(categories):
                    return None
                info['series'].append((name_of(s), nums(vals[1]), fmt))
        else:
            for s in sers:
                xs, _ = cache(child(s, 'xVal'))
                ys, fmt = cache(child(s, 'yVal'))
                if not xs or not ys or xs == 'bad' or ys == 'bad' or xs[0] != 'num' or ys[0] != 'num':
                    return None
                pts = list(zip(nums(xs[1]), nums(ys[1])))
                if family == 'bubble':
                    bs, _ = cache(child(s, 'bubbleSize'))
                    if not bs or bs == 'bad':
                        return None
                    pts = [(x, y, b) for (x, y), b in zip(pts, nums(bs[1]))]
                info['series'].append((name_of(s), pts, fmt))
        fmts = {f for _, _, f in info['series']}
        info['number_format'] = info['series'][0][2] if len(fmts) == 1 else None
        rels_extra = {rid: s for rid, s in self.parts[spec[2]]['rels'].items()
                      if s[1] != 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/package'}
        info['rels'] = rels_extra
        return info

    def chart_lines(self, se, container, x):
        ci = se.chart
        lines = []
        fmt = ci['number_format']
        if ci['family'] == 'cat':
            lines.append(f"cd = CategoryChartData({'number_format=%r' % fmt if fmt else ''})")
            lines.append(f"cd.categories = {ci['categories']!r}")
            for name, vals, f in ci['series']:
                extra = f', number_format={f!r}' if f and f != fmt else ''
                lines.append(f'cd.add_series({name!r}, {tuple(vals)!r}{extra})')
        else:
            cls = 'XyChartData' if ci['family'] == 'xy' else 'BubbleChartData'
            lines.append(f"cd = {cls}({'number_format=%r' % fmt if fmt else ''})")
            for name, pts, f in ci['series']:
                extra = f', number_format={f!r}' if f and f != fmt else ''
                lines.append(f's = cd.add_series({name!r}{extra})')
                for pt in pts:
                    lines.append(f's.add_data_point({", ".join(repr(v) for v in pt)})')
        lines.append(f"{se.var} = {container}.shapes.add_chart(XL_CHART_TYPE.{ci['type']}, {x}, cd)")
        return lines

    # ── API code for one shape ───────────────────────────────────────────────
    def api_lines(self, se, container, rels):
        el, v = se.el, se.var
        tag = local(el)
        L = []
        if tag == 'sp':
            sp = child(el, 'spPr')
            xf = child(sp, 'xfrm')
            ph = el.find('.//{%s}ph' % P_NS)
            is_box = False
            if ph is not None:
                if se.ph_cloned:
                    L.append(f"{v} = _ph({container}, {int(ph.get('idx', '0'))})")
                else:
                    args = [repr(ph.get('type')), ph.get('idx', 'None')]
                    extra = [f'{k}={val!r}' for k, val in ph.attrib.items() if k not in ('type', 'idx')]
                    L += [f'{v} = ' + '\n'.join(call('_new_ph', container, *args, kw=extra))]
                L.append(f'_place({container}, {v}, {se.sid}, {se.name!r}{self.place_extra(el)})')
                if xf is not None:
                    L += self.xfrm_lines(v, xf, set_pos=True)
            else:
                off, ext = child(xf, 'off'), child(xf, 'ext')
                pos = ', '.join(fmt_len(n) for n in (off.get('x'), off.get('y'), ext.get('cx'), ext.get('cy')))
                is_box = child(child(el, 'nvSpPr'), 'cNvSpPr') is not None and \
                    child(child(el, 'nvSpPr'), 'cNvSpPr').get('txBox') == '1'
                geom = child(sp, 'prstGeom')
                prst = geom.get('prst') if geom is not None else 'rect'
                if is_box:
                    L.append(f'{v} = {container}.shapes.add_textbox({pos})')
                else:
                    try:
                        enum = MSO_AUTO_SHAPE_TYPE.from_xml(prst).name
                    except Exception:
                        enum = None
                    L.append(f"{v} = {container}.shapes.add_shape(MSO_SHAPE.{enum or 'RECTANGLE'}, {pos})")
                    if enum is None and geom is not None:
                        L.append(f'_geom({v}, {prst!r})')
                L.append(f'_place({container}, {v}, {se.sid}, {se.name!r}{self.place_extra(el)})')
                L += self.xfrm_lines(v, xf)
                if is_box and not any(local(c) in FILL_TAGS for c in sp):
                    L.append(f'_fill({v}, None)')
                if geom is not None:
                    L += self.adj_lines(v, geom)
            L += self.spPr_style_lines(v, sp)
            L += self.locks_lines(se)
            L += self.style_lines(se, api_adds_style=(ph is None and not is_box))
            body = child(el, 'txBody')
            if body is None:
                L.append(f'_no_text({v})')
            else:
                L += emit_text(v, body, rels)
        elif tag == 'pic':
            sp = child(el, 'spPr')
            xf = child(sp, 'xfrm')
            off, ext = (child(xf, 'off'), child(xf, 'ext')) if xf is not None else (None, None)
            pos = ', '.join(fmt_len(n) for n in (off.get('x'), off.get('y'), ext.get('cx'), ext.get('cy'))) \
                if off is not None else ''
            blip = el.find('.//{%s}blip' % A_NS)
            spec = rels[blip.get(f'{{{R_NS}}}embed')]
            ph = el.find('.//{%s}ph' % P_NS)
            img = f"_stream({self.parts[spec[2]]['file']!r})"
            if ph is not None:
                L.append(f"{v} = _ph({container}, {int(ph.get('idx', '0'))}).insert_picture({img})")
                L.append(f'_place({container}, {v}, {se.sid}, {se.name!r}{self.place_extra(el)})')
                L += self.xfrm_lines(v, xf, set_pos=True)
            else:
                L.append(f"{v} = {container}.shapes.add_picture({img}, {pos})")
                L.append(f'_place({container}, {v}, {se.sid}, {se.name!r}{self.place_extra(el)})')
                L += self.xfrm_lines(v, xf)
            src = el.find('.//{%s}srcRect' % A_NS)
            if src is not None:
                for a, nm in (('l', 'left'), ('t', 'top'), ('r', 'right'), ('b', 'bottom')):
                    if src.get(a):
                        L.append(f'{v}.crop_{nm} = {fmt_num(int(src.get(a)) / 100000)}')
            geom = child(sp, 'prstGeom')
            if geom is not None and geom.get('prst') != 'rect':
                L.append(f"_geom({v}, {geom.get('prst')!r})")
            L += self.spPr_style_lines(v, sp)
            L += self.locks_lines(se)
            L += self.style_lines(se, api_adds_style=False)
        elif tag == 'cxnSp':
            sp = child(el, 'spPr')
            xf = child(sp, 'xfrm')
            off, ext = child(xf, 'off'), child(xf, 'ext')
            x, y, cx, cy = (int(off.get('x')), int(off.get('y')), int(ext.get('cx')), int(ext.get('cy')))
            fh, fv = xf.get('flipH') == '1', xf.get('flipV') == '1'
            bx, by = (x + cx if fh else x), (y + cy if fv else y)
            ex, ey = (x if fh else x + cx), (y if fv else y + cy)
            prst = child(sp, 'prstGeom').get('prst')
            kind = CONNECTORS.get(prst, 'ELBOW' if 'bent' in prst else 'CURVE' if 'curved' in prst else 'STRAIGHT')
            L.append(f'{v} = {container}.shapes.add_connector(MSO_CONNECTOR.{kind}, '
                     f'{fmt_len(bx)}, {fmt_len(by)}, {fmt_len(ex)}, {fmt_len(ey)})')
            if prst not in CONNECTORS:
                L.append(f'_geom({v}, {prst!r})')
            if (fh and not bx > ex) or (fv and not by > ey):
                L.append(f'_flip({v}, h={fh and not bx > ex}, v={fv and not by > ey})')
            L.append(f'_place({container}, {v}, {se.sid}, {se.name!r}{self.place_extra(el)})')
            if xf.get('rot'):
                L.append(f"{v}.rotation = {fmt_num(int(xf.get('rot')) / 60000)}")
            L += self.adj_lines(v, child(sp, 'prstGeom'))
            c = el.find('.//{%s}cNvCxnSpPr' % P_NS)
            st, en = (c.find('{%s}stCxn' % A_NS), c.find('{%s}endCxn' % A_NS)) if c is not None else (None, None)
            if st is not None or en is not None:
                kw = []
                if st is not None:
                    kw.append(f"begin=({st.get('id')}, {st.get('idx')})")
                if en is not None:
                    kw.append(f"end=({en.get('id')}, {en.get('idx')})")
                L += call('_connect', v, kw=kw)
            L += self.spPr_style_lines(v, sp)
            L += self.locks_lines(se)
            L += self.style_lines(se, api_adds_style=True)
        elif tag == 'grpSp':
            L.append(f'{v} = {container}.shapes.add_group_shape()')
            L.append(f'_place({container}, {v}, {se.sid}, {se.name!r}{self.place_extra(el)})')
            L += self.locks_lines(se)
        elif tag == 'graphicFrame':
            xf = child(el, 'xfrm')
            off, ext = child(xf, 'off'), child(xf, 'ext')
            pos = ', '.join(fmt_len(n) for n in (off.get('x'), off.get('y'), ext.get('cx'), ext.get('cy')))
            if se.kind == 'table':
                L += self.table_lines(se, container, pos, rels)
            else:
                L += self.chart_lines(se, container, pos)
                L.append(f'_place({container}, {v}, {se.sid}, {se.name!r}{self.place_extra(el)})')
                L += self.locks_lines(se)
                ci = se.chart
                rel_arg = f", rels={ci['rels']!r}" if ci['rels'] else ''
                L.append(f"_chart_style({v}, {self.parts[ci['part']]['file']!r}, cd{rel_arg})"
                         f"  # exact formatting; data stays editable above")
        return L

    def place_extra(self, el):
        cnv = next((c for c in el.iter() if local(c) == 'cNvPr'), None)
        out = ''
        for k in ('descr', 'title', 'hidden'):
            if cnv is not None and cnv.get(k) is not None:
                out += f', {k}={cnv.get(k)!r}'
        if cnv is not None:
            cid = cnv.find('.//{%s}creationId' % NS['a16'])
            if cid is not None and len(cnv) == 1:
                out += f", cid={cid.get('id')!r}"
        return out

    def xfrm_lines(self, v, xf, set_pos=False):
        L = []
        if xf is None:
            return L
        if set_pos:
            off, ext = child(xf, 'off'), child(xf, 'ext')
            if off is not None and ext is not None:
                L.append(f"{v}.left, {v}.top = {fmt_len(off.get('x'))}, {fmt_len(off.get('y'))}")
                L.append(f"{v}.width, {v}.height = {fmt_len(ext.get('cx'))}, {fmt_len(ext.get('cy'))}")
        if xf.get('rot'):
            L.append(f"{v}.rotation = {fmt_num(int(xf.get('rot')) / 60000)}")
        if xf.get('flipH') == '1' or xf.get('flipV') == '1':
            L.append(f"_flip({v}, h={xf.get('flipH') == '1'}, v={xf.get('flipV') == '1'})")
        return L

    def adj_lines(self, v, geom):
        av = child(geom, 'avLst') if geom is not None else None
        if av is None or not len(av):
            return []
        kw = []
        for gd in av:
            m = re.fullmatch(r'val (-?\d+)', gd.get('fmla', ''))
            if not m or not _ident_kw(gd.get('name', '')):
                return []
            kw.append(f"{gd.get('name')}={m.group(1)}")
        return call('_adj', v, kw=kw)

    def spPr_style_lines(self, v, sp):
        L = []
        if sp is None:
            return L
        for c in sp:
            t = local(c)
            if t in FILL_TAGS:
                e = fill_expr(c)
                if e:
                    L.append(f'_fill({v}, {e})')
            elif t == 'ln':
                kw = line_kwargs(c)
                L += call('_line', v, kw=kw)
            elif t == 'effectLst':
                e = effects_expr(c)
                if e:
                    L.append(f'_effects({v}, {e})')
        return L

    def style_lines(self, se, api_adds_style):
        st = child(se.el, 'style')
        if st is None:
            return [f'_style({se.var})  # no theme style'] if api_adds_style else []
        kw = style_kwargs(st)
        return call('_style', se.var, kw=kw) if kw is not None else []

    def locks_lines(self, se):
        nv = se.el[0]
        cnv = nv[1] if len(nv) > 1 else None
        if cnv is None:
            return []
        lk = next((c for c in cnv if local(c).endswith('Locks')), None)
        if lk is None or len(lk) or not all(_ident_kw(k) for k in lk.attrib):
            return []
        return call('_locks', se.var, kw=[f'{k}={v!r}' for k, v in lk.attrib.items()])

    def table_lines(self, se, container, pos, rels):
        el, v = se.el, se.var
        tbl = el.find('.//{%s}tbl' % A_NS)
        grid = [int(g.get('w')) for g in child(tbl, 'tblGrid')]
        rows = children(tbl, 'tr')
        L = [f'{v} = {container}.shapes.add_table({len(rows)}, {len(grid)}, {pos})',
             f'_place({container}, {v}, {se.sid}, {se.name!r}{self.place_extra(el)})',
             f'tbl = {v}.table'] + self.locks_lines(se)
        tp = child(tbl, 'tblPr')
        if tp is not None:
            sid = child(tp, 'tableStyleId')
            flags = [f'{k}={val}' for k, val in (_attr_items(tp) or [])]
            args = [repr(sid.text)] if sid is not None else []
            comment = f'  # {D.TABLE_STYLES[sid.text]}' if sid is not None and sid.text in D.TABLE_STYLES else ''
            ln = call('_table_style', 'tbl', *args, kw=flags)
            ln[-1] += comment
            L += ln
        L.append('for i, w in enumerate((' + ', '.join(fmt_len(w) for w in grid) + (',' if len(grid) == 1 else '') + ')):')
        L.append(f'{IND}tbl.columns[i].width = w')
        L.append('for i, h in enumerate((' + ', '.join(fmt_len(r.get('h')) for r in rows) + (',' if len(rows) == 1 else '') + ')):')
        L.append(f'{IND}tbl.rows[i].height = h')
        for ri, tr in enumerate(rows):
            for ci, tc in enumerate(children(tr, 'tc')):
                gs, rs = int(tc.get('gridSpan', '1')), int(tc.get('rowSpan', '1'))
                if gs > 1 or rs > 1:
                    L.append(f'_merge(tbl, {ri}, {ci}, {ri + rs - 1}, {ci + gs - 1})')
        for ri, tr in enumerate(rows):
            for ci, tc in enumerate(children(tr, 'tc')):
                L.append(f'cell = tbl.cell({ri}, {ci})')
                tcpr = child(tc, 'tcPr')
                if tcpr is not None:
                    kw = []
                    for k, val in (_attr_items(tcpr) or []):
                        kw.append(f'{k}={fmt_len(val)}' if k.startswith('mar') and val.isdigit() else f'{k}={val!r}')
                    borders = []
                    for c in tcpr:
                        if local(c) in FILL_TAGS:
                            e = fill_expr(c)
                            if e:
                                kw.append(f'fill={e}')
                        elif local(c) in ('lnL', 'lnR', 'lnT', 'lnB', 'lnTlToBr', 'lnBlToTr'):
                            borders.append(f"{local(c)[2:]!r}: dict({', '.join(line_kwargs(c))})")
                    if borders:
                        kw.append('borders={' + ', '.join(borders) + '}')
                    L += call('_cell', 'cell', kw=kw)
                body = child(tc, 'txBody')
                if body is not None:
                    L += emit_text('cell', body, rels)
        return L

    # ── code rendering ───────────────────────────────────────────────────────
    def ops_lines(self, se):
        L = []
        for (kind, path), op in se.ops.items():
            if kind == 'attrs':
                attrs = {self.prefixed(k): v for k, v in op[2].items()}
                L.append(f'_attrs({se.var}, {path!r}, {attrs!r})')
            else:
                el = op[2]
                if el is None:
                    L.append(f'_sync({se.var}, {path!r}, None)')
                else:
                    xml = snippet(el, self.ns)
                    L.append(f'_sync({se.var}, {path!r}, {py_str(xml, IND)})')
        if L:
            L.insert(0, f'# exact patch: {self.patch_reason(se)}')
        return L

    def patch_reason(self, se):
        tags = set()
        for (kind, path), op in se.ops.items():
            if kind == 'sync' and op[2] is not None:
                for n in op[2].iter():
                    if isinstance(n.tag, str):
                        tags.add(local(n))
        known = {'effectLst': 'effects/shadow', 'outerShdw': 'shadow', 'glow': 'glow', 'softEdge': 'soft edges',
                 'scene3d': '3-D', 'sp3d': '3-D', 'custGeom': 'freeform geometry', 'style': 'theme style refs',
                 'blipFill': 'picture fill', 'pattFill': 'pattern fill', 'creationId': 'Office ids',
                 'lnL': 'cell borders', 'lnR': 'cell borders', 'lnT': 'cell borders', 'lnB': 'cell borders',
                 'hlinkClick': 'click action', 'extLst': 'Office extensions', 'buBlip': 'picture bullets',
                 'tabLst': 'tab stops', 'defRPr': 'default run props', 'lumMod': 'theme colour tints',
                 'prstTxWarp': 'WordArt warp', 'grpSpPr': 'group frame', 'xfrm': 'position', 'chOff': 'group frame'}
        hits = sorted({known[t] for t in tags if t in known})
        return ', '.join(hits) if hits else 'details python-pptx does not expose'

    def prefixed(self, k):
        if k.startswith('{'):
            uri, name = k[1:].split('}')
            for pfx, u in self.ns.map.items():
                if u == uri:
                    return f'{pfx}:{name}'
        return k

    def shape_block(self, se, container, rels, out, owners, slide_no, depth=0):
        start = len(out)
        out.append(f'# ── {D.shape_summary(se.el)}' + (f'  [xml: {se.reason}]' if se.mode == 'xml' and self.mode != 'exact' else ''))
        if se.mode == 'xml':
            xml = snippet(se.el, self.ns)
            out.append(f'_add({container}, {py_str(xml, IND)})')
        else:
            out.extend(self.api_lines(se, container, rels))
            for ch in se.children:
                self.shape_block(ch, se.var, rels, out, owners, slide_no, depth + 1)
            out.extend(self.ops_lines(se))
        for i in range(start, len(out)):
            owners.setdefault(i, (slide_no, se))

    def slide_code(self, sl, owners_base):
        s = sl.src
        sld = s._element
        out = []
        owners = {}
        layout_part = s.part.part_related_by('http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout')
        m, l = self.layout_index[layout_part]
        lname = layout_part.slide_layout.name
        title = self.slide_title(s)
        anim = D.animation_list(sld, self.names_of(sld))
        tr = D.transition_info(sld)
        doc = [f'Slide {sl.index} · {title}' if title else f'Slide {sl.index}',
               f'Layout: {lname} · {len(sl.shapes)} shapes' + (' · hidden' if sld.get('show') == '0' else '')]
        if tr:
            doc.append('Transition: ' + D.describe_transition(tr))
        if anim:
            doc.append(f'Animations: {len(anim)}')
        rels = self.rels_of(s)
        rel_lines = ['{'] + [f'{IND}{k!r}: {self.spec_repr(v)},' for k, v in rels.items()] + ['}'] if rels else ['{}']
        cSld = child(sld, 'cSld')
        args = f'master={m}, layout={l}'
        if cSld.get('name'):
            args += f", name={cSld.get('name')!r}"
        if sld.get('show') == '0':
            args += ', hidden=True'
        if self.mode != 'exact':
            args += ', keep_placeholders=True'
        out.append(f'def slide_{sl.index:02d}(prs):')
        out.append(f'{IND}"""{doc[0]}')
        out.extend(f'{IND}{d}' for d in doc[1:])
        out.append(f'{IND}"""')
        body = []
        if len(rel_lines) > 1:
            body.append(f'slide = _new_slide(prs, {args}, rels=' + rel_lines[0])
            body += rel_lines[1:-1]
            body.append('})')
        else:
            body.append(f'slide = _new_slide(prs, {args})')
        sattrs = {self.prefixed(k): val for k, val in sld.attrib.items()}
        if sattrs and sattrs != {'show': '0'}:
            body.append(f'_attrs(slide, None, {sattrs!r})  # slide options (master graphics, animations …)')
        if child(sld, 'clrMapOvr') is None:
            body.append("_drop(slide, 'clrMapOvr')")
        bg = child(cSld, 'bg')
        if bg is not None:
            body.append(f'_background(slide, {py_str(snippet(bg, self.ns), IND)})  # {self.bg_desc(bg)}')
        if sl.tree_props:
            tree = child(cSld, 'spTree')
            xml = snippet(child(tree, 'nvGrpSpPr'), self.ns) + snippet(child(tree, 'grpSpPr'), self.ns)
            body.append(f'_tree_props(slide, {py_str(xml, IND)})')
        shapes_start = len(body)
        shape_lines = []
        for se in sl.shapes:
            self.shape_block(se, 'slide', rels, shape_lines, owners, sl.index)
            shape_lines.append('')
        body += shape_lines
        implicit = self.implicit_rels(s)
        body.append('_end_slide(slide)' if not implicit else
                    f'_end_slide(slide)\nfor rid in {implicit!r}:  # relationships not referenced from XML\n'
                    f'{IND}_rel(slide.part, _CTX.rels[slide.part][rid])')
        for c in sld:
            n = local(c)
            if n in ('cSld',):
                continue
            if n == 'clrMapOvr' and canon(c) == canon(etree.fromstring(
                    f'<p:clrMapOvr xmlns:p="{P_NS}" xmlns:a="{A_NS}"><a:masterClrMapping/></p:clrMapOvr>')):
                continue
            xml = snippet(c, self.ns)
            rank = D.local(c)
            label = ''
            if n == 'transition' or (n == 'AlternateContent' and c.find('.//{%s}transition' % P_NS) is not None):
                fn, label = '_transition', D.describe_transition(tr)
            elif n == 'timing':
                fn = '_timing'
                label = '; '.join(f"{a['trigger']}: {a['effect']} → {a['target']}" for a in anim[:6])
                if len(anim) > 6:
                    label += f'; … {len(anim) - 6} more'
            else:
                fn = '_slide_xml'
            body.append(f'{fn}(slide, {py_str(xml, IND)})' + (f'  # {label}' if label else ''))
        for c in cSld:
            if local(c) in ('custDataLst', 'controls', 'extLst'):
                body.append(f'_cSld_extra(slide, {py_str(snippet(c, self.ns), IND)})')
        if self.notes and s.has_notes_slide:
            ntf = s.notes_slide.notes_text_frame
            if ntf is not None:
                if sl.notes_xml:
                    txb = s.notes_slide.notes_placeholder._element.find('{%s}txBody' % P_NS)
                    body.append(f'_notes_xml(slide, {py_str(snippet(txb, self.ns), IND)})  # speaker notes')
                elif ntf.text:
                    body.append(f'_notes(slide, {ntf.text!r})')
        body.append('return slide')
        # indent + line ownership
        base = len(out)
        for i, line in enumerate(body):
            for sub in line.split('\n'):
                out.append((IND + sub) if sub else '')
        # map body line index (after split) → owners; recompute by walking
        mapped = {}
        cursor = base
        for i, line in enumerate(body):
            n = line.count('\n') + 1
            if shapes_start <= i < shapes_start + len(shape_lines):
                own = owners.get(i - shapes_start)
                if own:
                    for k in range(n):
                        mapped[owners_base + cursor + k] = own
            cursor += n
        return out, mapped

    def bg_desc(self, bg):
        bgpr = child(bg, 'bgPr')
        if bgpr is None:
            ref = child(bg, 'bgRef')
            return f"theme background #{ref.get('idx')}" if ref is not None else 'background'
        f = next((c for c in bgpr if local(c) in FILL_TAGS), None)
        if f is None:
            return 'background'
        return {'solidFill': 'solid', 'gradFill': 'gradient', 'blipFill': 'picture', 'pattFill': 'pattern',
                'noFill': 'none'}.get(local(f), local(f)) + ' background'

    def slide_title(self, s):
        for sh in s.shapes:
            if sh.is_placeholder and sh.placeholder_format.type is not None and \
                    'TITLE' in str(sh.placeholder_format.type) and sh.has_text_frame:
                return sh.text_frame.text.replace('\n', ' ')[:60]
        return ''

    def names_of(self, sld):
        out = {}
        for c in sld.iter():
            if local(c) == 'cNvPr':
                out[c.get('id')] = c.get('name', '')
        return out

    def spec_repr(self, spec):
        rt = RT_NAMES.get(spec[1], repr(spec[1]))
        rest = ', '.join(repr(x) for x in spec[2:])
        return f'({spec[0]!r}, {rt}, {rest})'

    def rels_of(self, slide):
        out = {}
        for rid, rel in sorted(slide.part.rels.items(), key=lambda kv: _rid_num(kv[0])):
            if rel.reltype in SKIP_RELS:
                continue
            out[rid] = self.rel_spec(rel)
        return out

    def implicit_rels(self, slide):
        used = {v for n in slide._element.iter() if isinstance(n.tag, str) for k, v in n.attrib.items() if k.startswith('{' + R_NS)}
        return [rid for rid, rel in sorted(slide.part.rels.items(), key=lambda kv: _rid_num(kv[0]))
                if rel.reltype not in SKIP_RELS and rid not in used]

    # ── module ───────────────────────────────────────────────────────────────
    def render(self):
        rt = RUNTIME_PATH.read_text()
        out = []
        stats = self.stats
        out.append('"""' + f"{self.title} — rebuilt from {self.source_name}")
        out.append('')
        out.append(f'Generated by PPTX→Code Studio on {_dt.date.today().isoformat()}.')
        out.append(f"Mode: {self.mode} · {stats['slides']} slides · {stats['shapes']} shapes · "
                   f"{stats['charts']} charts · {stats['pictures']} pictures · {stats['tables']} tables · "
                   f"{stats['transitions']} transitions · {stats['animations']} animations")
        out.append('')
        out.append('Run:   python ' + f'{self.module_name}.py [output.pptx]')
        out.append('Needs: pip install python-pptx lxml' + ('' if self.asset_mode == 'inline' else
                                                           '   (keep the assets/ folder next to this file)'))
        out.append('"""')
        out.append('from pptx.chart.data import BubbleChartData, CategoryChartData, XyChartData  # noqa: F401')
        out.append('from pptx.enum.chart import XL_CHART_TYPE  # noqa: F401')
        out.append('from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE  # noqa: F401')
        out.append('from pptx.opc.constants import RELATIONSHIP_TYPE as RT  # noqa: F401')
        out.append('')
        nsmap = '{\n' + ''.join(f'    {k!r}: {v!r},\n' for k, v in sorted(self.ns.map.items())) + '}'
        rt = re.sub(r"NSMAP = \{  # @@NSMAP@@\n.*?\n\}\n", lambda m: f'NSMAP = {nsmap}\n', rt, count=1, flags=re.S)
        out.extend(rt.rstrip('\n').split('\n'))
        out.append('')
        out.append('')
        out.append('# ═══ package parts copied from the source deck ═══════════════════════════════')
        out.append('PARTS.update({')
        for key in sorted(self.parts_used):
            info = self.parts[key]
            rels = '{' + ', '.join(f'{r!r}: {self.spec_repr(s)}' for r, s in info['rels'].items()) + '}'
            out.append(f"    {key!r}: {{'ct': {info['ct']!r}, 'file': {info['file']!r}, 'rels': {rels}}},")
        out.append('})')
        if self.asset_mode == 'inline':
            import base64
            out.append('')
            out.append('ASSETS_INLINE.update({  # base64 – single-file build')
            for name in sorted(self.assets_used):
                b = base64.b64encode(self.assets[name]).decode()
                out.append(f'    {name!r}: (')
                for i in range(0, len(b), 96):
                    out.append(f"        '{b[i:i + 96]}'")
                out.append('    ),')
            out.append('})')
        out.append('')
        out.append('')
        out.append('# ═══ slides ══════════════════════════════════════════════════════════════════')
        owners = {}
        for sl in self.slides:
            out.append('')
            code, mapped = self.slide_code(sl, len(out))
            owners.update({k: v for k, v in mapped.items()})
            out.extend(code)
            out.append('')
        out.append('')
        out.append('SLIDES = [' + ', '.join(f'slide_{sl.index:02d}' for sl in self.slides) + ']')
        out.append(f'SLIDE_IDS = {self.slide_ids!r}')
        out.append(f'CUSTOM_SHOWS = {self.custom_shows!r}')
        out.append('')
        out.append('')
        out.append('def build_presentation():')
        out.append(f'{IND}prs = _open_template()')
        out.append(f'{IND}for make in SLIDES:')
        out.append(f'{IND}{IND}make(prs)')
        out.append(f'{IND}return _finish(prs, slide_ids=SLIDE_IDS, custom_shows=CUSTOM_SHOWS)')
        out.append('')
        out.append('')
        out.append(f"def build(path='{self.module_name}_rebuilt.pptx'):")
        out.append(f'{IND}prs = build_presentation()')
        out.append(f'{IND}prs.save(path)')
        out.append(f'{IND}return path')
        out.append('')
        out.append('')
        out.append("if __name__ == '__main__':")
        out.append(f'{IND}import sys')
        out.append(f"{IND}print('saved', build(*sys.argv[1:2]))")
        return '\n'.join(out) + '\n', owners

    # ── execute + diff ───────────────────────────────────────────────────────
    def execute(self, code):
        g = {'__name__': 'p2c_check', '__file__': str(Path.cwd() / f'{self.module_name}.py')}
        exec(compile(code, '<p2c-gen>', 'exec'), g)
        g['ASSETS_OVERRIDE'].update(self.assets)
        prs = g['_open_template']()
        errors = []
        for i, make in enumerate(g['SLIDES']):
            try:
                make(prs)
            except Exception as exc:  # noqa: BLE001
                tb = traceback.extract_tb(exc.__traceback__)
                lines = [fr.lineno for fr in tb if fr.filename == '<p2c-gen>']
                errors.append((i + 1, lines, f'{type(exc).__name__}: {exc}'))
                return prs, errors, g
        g['_finish'](prs, slide_ids=g['SLIDE_IDS'], custom_shows=g['CUSTOM_SHOWS'])
        return prs, errors, g

    def compare(self, built):
        """Diff every API-built shape; returns (n_changes, problems)."""
        changes = 0
        problems = []
        built_slides = [built.part.related_part(s.rId) for s in built.slides._sldIdLst]
        new_index = {p: i + 1 for i, p in enumerate(built_slides)}
        for sl, bpart in zip(self.slides, built_slides):
            ro = make_resolver(sl.src.part, self.slide_index)
            rn = make_resolver(bpart, new_index)
            bmap = _id_map(bpart._element)
            for se in _walk(sl.shapes):
                if se.mode != 'api':
                    continue
                n = bmap.get(se.sid)
                if n is None:
                    problems.append((sl, se, 'missing after rebuild'))
                    continue
                ops = diff(se.el, n, ro, rn, skip_graphic=(se.kind == 'chart'))
                if any(op[1] == '' and op[0] == 'sync' for op in ops):
                    problems.append((sl, se, 'element type changed'))
                    continue
                if ops:
                    changes += len(ops)
                    se.ops = merge_ops(se.ops, ops)
                if se.kind == 'chart':
                    gref = n.find('.//{%s}chart' % C_NS)
                    cpart = bpart.related_part(gref.get(f'{{{R_NS}}}id'))
                    opart = self.part_obj[se.chart['part']]
                    if _chart_canon(cpart) != _chart_canon(opart):
                        problems.append((sl, se, 'chart data rewrite changed formatting'))
            # slide-level header
            o_tree = child(child(sl.src._element, 'cSld'), 'spTree')
            n_tree = child(child(bpart._element, 'cSld'), 'spTree')
            for nm in ('nvGrpSpPr', 'grpSpPr'):
                if canon(child(o_tree, nm), ro) != canon(child(n_tree, nm), rn) and not sl.tree_props:
                    sl.tree_props = True
                    changes += 1
            # notes
            if self.notes and sl.src.has_notes_slide and not sl.notes_xml:
                o_np = sl.src.notes_slide.notes_placeholder
                bslide = bpart.slide
                if o_np is not None and bslide.has_notes_slide:
                    o_tx = o_np._element.find('{%s}txBody' % P_NS)
                    n_np = bslide.notes_slide.notes_placeholder
                    n_tx = n_np._element.find('{%s}txBody' % P_NS) if n_np is not None else None
                    if n_tx is None or canon(o_tx) != canon(n_tx):
                        sl.notes_xml = True
                        changes += 1
        return changes, problems

    def full_check(self, built):
        """Whole-slide comparison used for the final report."""
        report = []
        built_slides = [built.part.related_part(s.rId) for s in built.slides._sldIdLst]
        new_index = {p: i + 1 for i, p in enumerate(built_slides)}
        for sl, bpart in zip(self.slides, built_slides):
            ro = make_resolver(sl.src.part, self.slide_index)
            rn = make_resolver(bpart, new_index)
            o, n = sl.src._element, bpart._element
            ok_items, bad = 0, []
            o_items = _slide_items(o)
            n_items = _slide_items(n)
            for key, oel in o_items.items():
                nel = n_items.get(key)
                skip = None
                se = sl_find(sl, key)
                if se is not None and se.kind == 'chart' and se.mode == 'api':
                    skip = (lambda c: local(c) == 'graphic')
                if nel is not None and canon(oel, ro, skip) == canon(nel, rn, skip):
                    ok_items += 1
                else:
                    bad.append(key)
            for key in n_items:
                if key not in o_items:
                    bad.append(f'extra {key}')
            report.append({'slide': sl.index, 'items': len(o_items), 'identical': ok_items, 'differences': bad})
        return report

    # ── main ─────────────────────────────────────────────────────────────────
    def run(self, source_name='deck.pptx', title=None):
        self.source_name = source_name
        self.title = title or Path(source_name).stem
        self.build_template()
        src = Presentation(io.BytesIO(self.data))
        self.src = src
        self.slide_index = {s.part: i + 1 for i, s in enumerate(src.slides)}
        self.layout_index = {}
        for m, master in enumerate(src.slide_masters):
            for l, lay in enumerate(master.slide_layouts):
                self.layout_index[lay.part] = (m, l)
        self.part_obj = {}
        for s in src.slides:
            for rel in s.part.rels.values():
                if not rel.is_external:
                    self._index_parts(rel.target_part)
        self.slides = []
        for i, s in enumerate(src.slides):
            sl = SlideEmit(index=i + 1, src=s)
            rels = self.rels_of(s)
            lay = s.slide_layout
            layout_ph = {ph.placeholder_format.idx: ph._element.ph_type and
                         ph._element.find('.//{%s}ph' % P_NS).get('type', 'body')
                         for ph in lay.iter_cloneable_placeholders()}
            used = set()
            tree = s.shapes._spTree
            ids = [c.get('id') for c in tree.iter() if local(c) == 'cNvPr']
            mode_backup = self.mode
            if len(ids) != len(set(ids)):
                self.mode = 'exact'
                self.warnings.append(f'slide {i + 1}: duplicate shape ids – kept as exact XML')
            for c in tree:
                if local(c) in ('nvGrpSpPr', 'grpSpPr', 'extLst'):
                    continue
                sl.shapes.append(self.make_shape(c, used, rels, layout_ph))
            self.mode = mode_backup
            self.slides.append(sl)
        self.stats = self.collect_stats()

        rounds = 0
        while True:
            rounds += 1
            self.mark_used()
            code, owners = self.render()
            try:
                built, errors, _ = self.execute(code)
            except Exception as exc:  # noqa: BLE001 – module level failure
                raise RuntimeError(f'generated module failed to load: {exc}') from exc
            if errors:
                slide_no, lines, msg = errors[0]
                target = None
                for ln in reversed(lines):
                    if ln - 1 in owners:
                        target = owners[ln - 1]
                        break
                if target and target[1].mode == 'api':
                    target[1].mode, target[1].reason = 'xml', f'API build failed ({msg[:60]})'
                    target[1].ops = {}
                    self.warnings.append(f'slide {slide_no} [{target[1].sid}] {target[1].name}: {msg}')
                else:
                    sl = self.slides[slide_no - 1]
                    for se in _walk(sl.shapes):
                        se.mode, se.reason, se.ops = 'xml', 'slide fallback', {}
                    self.warnings.append(f'slide {slide_no}: {msg} – slide kept as exact XML')
                    if not lines:
                        raise
                if rounds > 40:
                    raise RuntimeError(msg)
                continue
            changes, problems = self.compare(built)
            snapshot = [(se.sid, tuple(se.ops)) for sl in self.slides for se in _walk(sl.shapes)]
            if snapshot == getattr(self, '_last_snapshot', None) and not problems:
                break  # nothing new to learn (e.g. dangling references in the source)
            self._last_snapshot = snapshot
            for sl, se, why in problems:
                se.mode, se.reason, se.ops = 'xml', why, {}
                se.children = []
            if not changes and not problems:
                break
            if rounds >= self.max_rounds + 10:
                break
        self.mark_used()
        code, owners = self.render()
        built, errors, _ = self.execute(code)
        check = self.full_check(built)
        report = self.make_report(check, rounds)
        assets = {k: self.assets[k] for k in self.assets_used} if self.asset_mode != 'inline' else {}
        return Result(code=code, assets=assets, report=report, module_name=self.module_name)

    def _index_parts(self, part, seen=None):
        key = str(part.partname)
        if key in self.part_obj:
            return
        self.part_obj[key] = part
        for rel in part.rels.values():
            if not rel.is_external and rel.target_part not in self.slide_index:
                self._index_parts(rel.target_part)

    def mark_used(self):
        """Parts/assets referenced by the code as it will be rendered."""
        used = set()

        def need(key):
            if key in used:
                return
            used.add(key)
            for s in self.parts[key]['rels'].values():
                if s[0] == 'part':
                    need(s[2])

        for sl in self.slides:
            for spec in self.rels_of(sl.src).values():
                if spec[0] == 'part':
                    need(spec[2])
        self.parts_used = used
        assets = {'template.pptx'} | {self.parts[k]['file'] for k in used}
        self.assets_used = assets

    def collect_stats(self):
        st = dict(slides=len(self.slides), shapes=0, charts=0, pictures=0, tables=0, transitions=0, animations=0,
                  groups=0, connectors=0, smartart=0, media=0, notes=0, hidden=0)
        for sl in self.slides:
            sld = sl.src._element
            for se in _walk(sl.shapes):
                st['shapes'] += 1
                k = se.kind
                st['charts'] += k.startswith('chart')
                st['pictures'] += k == 'picture'
                st['tables'] += k == 'table'
                st['groups'] += k == 'group'
                st['connectors'] += k == 'connector'
                st['smartart'] += k == 'smartart'
                st['media'] += k in ('video', 'audio')
            st['transitions'] += D.transition_info(sld) is not None
            st['animations'] += len(D.animation_list(sld, {}))
            st['notes'] += bool(sl.src.has_notes_slide and sl.src.notes_slide.notes_text_frame is not None
                                and sl.src.notes_slide.notes_text_frame.text)
            st['hidden'] += sld.get('show') == '0'
        return st

    def make_report(self, check, rounds):
        api = xml = patches = 0
        reasons = {}
        per_slide = []
        for sl, chk in zip(self.slides, check):
            sa = sx = sp = 0
            for se in _walk(sl.shapes):
                if se.mode == 'api':
                    sa += 1
                    sp += len(se.ops)
                else:
                    sx += 1
                    reasons[se.reason] = reasons.get(se.reason, 0) + 1
            api, xml, patches = api + sa, xml + sx, patches + sp
            per_slide.append({**chk, 'api_shapes': sa, 'xml_shapes': sx, 'patches': sp,
                              'title': self.slide_title(sl.src),
                              'transition': D.describe_transition(D.transition_info(sl.src._element)),
                              'animations': D.animation_list(sl.src._element, self.names_of(sl.src._element)),
                              'shapes': [{'id': se.sid, 'summary': D.shape_summary(se.el), 'mode': se.mode,
                                          'reason': se.reason, 'patches': len(se.ops)} for se in _walk(sl.shapes)]})
        items = sum(c['items'] for c in check)
        same = sum(c['identical'] for c in check)
        return {'mode': self.mode, 'stats': self.stats, 'api_shapes': api, 'xml_shapes': xml, 'patches': patches,
                'xml_reasons': reasons, 'rounds': rounds, 'fidelity': (same / items) if items else 1.0,
                'items': items, 'identical': same, 'slides': per_slide, 'warnings': self.warnings}


# ═══ module-level helpers ════════════════════════════════════════════════════
def _rid_num(rid):
    m = re.search(r'(\d+)$', rid)
    return (int(m.group(1)) if m else 0, rid)


def _walk(shapes):
    for se in shapes:
        yield se
        yield from _walk(se.children)


def _id_map(sld):
    out = {}
    tree = sld.find('.//{%s}spTree' % P_NS)
    for el in tree.iter():
        if local(el) in ('sp', 'pic', 'cxnSp', 'grpSp', 'graphicFrame', 'contentPart'):
            for c in el.iter():
                if local(c) == 'cNvPr':
                    out.setdefault(c.get('id'), el)
                    break
    return out


def _chart_canon(part):
    """Chart XML canonical form; numbers compared by value (Excel writes 17 significant digits)."""
    import copy
    el = copy.deepcopy(part._element)
    for v in el.iter('{%s}v' % C_NS):
        try:
            v.text = repr(float(v.text))
        except (TypeError, ValueError):
            pass
    return canon(el, make_resolver(part), lambda c: local(c) == 'externalData')


def _slide_items(sld):
    """Comparable top-level items of a slide: slide attrs, background, header, shapes, timing …"""
    items = {}
    items['slide attributes'] = etree.Element('attrs', {k: v for k, v in sld.attrib.items()})
    cSld = child(sld, 'cSld')
    items['cSld attributes'] = etree.Element('attrs', {k: v for k, v in cSld.attrib.items()})
    for c in cSld:
        if local(c) == 'spTree':
            for sc in c:
                n = local(sc)
                if n in ('nvGrpSpPr', 'grpSpPr'):
                    items[f'tree {n}'] = sc
                else:
                    name, sid = D.shape_name(sc)
                    items[f'shape {sid} {name}'] = sc
        else:
            items[f'cSld {local(c)}'] = c
    for c in sld:
        if local(c) != 'cSld':
            n = local(c)
            if n == 'AlternateContent' and c.find('.//{%s}transition' % P_NS) is not None:
                n = 'transition'
            items[n] = c
    return items


def sl_find(sl, key):
    if not key.startswith('shape '):
        return None
    sid = key.split()[1]
    for se in sl.shapes:
        if se.sid == sid:
            return se
    return None


def generate(data, mode='editable', asset_mode='folder', module_name='deck', source_name='deck.pptx',
             notes=True, log=None):
    g = Generator(data, mode=mode, asset_mode=asset_mode, module_name=module_name, notes=notes, log=log)
    return g.run(source_name=source_name)


if __name__ == '__main__':
    src = Path(sys.argv[1])
    res = generate(src.read_bytes(), mode=sys.argv[2] if len(sys.argv) > 2 else 'editable', source_name=src.name)
    print(res.code[:3000])
    print(res.report['fidelity'], res.report['warnings'])
