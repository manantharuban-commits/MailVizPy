"""Independent round-trip verification.

1. runs the generated script in a fresh Python process (as a user would),
2. compares every slide of the rebuilt file with the source, element by element,
3. compares media and chart parts, and
4. renders both decks with LibreOffice and measures per-slide pixel similarity.
"""
import copy
import hashlib
import io
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from pptx import Presentation

from . import describe as D
from .ooxml import C_NS, canon, child, local, make_resolver


def run_generated(code, assets, workdir, module_name='deck', timeout=180):
    """Write the generated module + assets to workdir and execute it. -> (pptx bytes, log)."""
    wd = Path(workdir)
    wd.mkdir(parents=True, exist_ok=True)
    (wd / f'{module_name}.py').write_text(code, encoding='utf-8')
    for name, blob in assets.items():
        p = wd / 'assets' / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(blob)
    out = wd / 'rebuilt.pptx'
    proc = subprocess.run([sys.executable, '-I', f'{module_name}.py', str(out)], cwd=wd, capture_output=True,
                          text=True, timeout=timeout)
    if proc.returncode != 0:
        raise RuntimeError('generated script failed:\n' + proc.stderr[-3000:])
    return out.read_bytes(), proc.stdout + proc.stderr


def _items(sld):
    items = {'slide attributes': ('attrs', tuple(sorted(sld.attrib.items())))}
    cSld = child(sld, 'cSld')
    items['cSld attributes'] = ('attrs', tuple(sorted(cSld.attrib.items())))
    for c in cSld:
        if local(c) == 'spTree':
            for sc in c:
                if local(sc) in ('nvGrpSpPr', 'grpSpPr'):
                    items[f'shape tree {local(sc)}'] = sc
                else:
                    name, sid = D.shape_name(sc)
                    items[f'shape {sid} · {name}'] = sc
        else:
            items[local(c)] = c
    for c in sld:
        n = local(c)
        if n == 'cSld':
            continue
        if n == 'AlternateContent' and c.find('.//{http://schemas.openxmlformats.org/presentationml/2006/main}transition') is not None:
            n = 'transition'
        items[n] = c
    return items


def _num_canon(part):
    el = copy.deepcopy(part._element)
    for v in el.iter('{%s}v' % C_NS):
        try:
            v.text = repr(float(v.text))
        except (TypeError, ValueError):
            pass
    return canon(el, make_resolver(part), lambda c: local(c) == 'externalData')


def structural(src_bytes, out_bytes):
    a = Presentation(io.BytesIO(src_bytes))
    b = Presentation(io.BytesIO(out_bytes))
    a_parts = [a.part.related_part(s.rId) for s in a.slides._sldIdLst]
    b_parts = [b.part.related_part(s.rId) for s in b.slides._sldIdLst]
    ai = {p: i + 1 for i, p in enumerate(a_parts)}
    bi = {p: i + 1 for i, p in enumerate(b_parts)}
    slides = []
    for n, (pa, pb) in enumerate(zip(a_parts, b_parts), 1):
        ra, rb = make_resolver(pa, ai), make_resolver(pb, bi)
        ia, ib = _items(pa._element), _items(pb._element)
        same, diffs = 0, []
        for key, ea in ia.items():
            eb = ib.get(key)
            if isinstance(ea, tuple):
                ok = eb == ea
            else:
                ok = eb is not None and not isinstance(eb, tuple) and canon(ea, ra) == canon(eb, rb)
                if not ok and eb is not None and not isinstance(eb, tuple):
                    # charts built through the chart-data API: compare the chart parts instead
                    ok = _same_chart(ea, eb, pa, pb, ra, rb)
            same += ok
            if not ok:
                diffs.append(key)
        diffs += [f'extra: {k}' for k in ib if k not in ia]
        notes_ok = True
        if a.slides[n - 1].has_notes_slide:
            na = a.slides[n - 1].notes_slide.notes_text_frame
            nb = b.slides[n - 1].notes_slide.notes_text_frame if b.slides[n - 1].has_notes_slide else None
            notes_ok = nb is not None and (na is None or na.text == nb.text)
        slides.append({'slide': n, 'items': len(ia), 'identical': same, 'differences': diffs, 'notes_ok': notes_ok})
    media = _media_check(a, b)
    total = sum(s['items'] for s in slides)
    ident = sum(s['identical'] for s in slides)
    return {'slides': slides, 'slide_count': (len(a_parts), len(b_parts)), 'items': total, 'identical': ident,
            'score': ident / total if total else 1.0, 'media': media}


def _same_chart(ea, eb, pa, pb, ra, rb):
    ga = ea.find('.//{%s}chart' % C_NS)
    gb = eb.find('.//{%s}chart' % C_NS)
    if ga is None or gb is None:
        return False
    rid = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
    skip = (lambda c: local(c) == 'graphic')
    if canon(ea, ra, skip) != canon(eb, rb, skip):
        return False
    return _num_canon(pa.related_part(ga.get(rid))) == _num_canon(pb.related_part(gb.get(rid)))


def _media_check(a, b):
    def hashes(prs):
        out = set()
        for part in prs.part.package.iter_parts():
            ct = part.content_type or ''
            if ct.startswith(('image/', 'video/', 'audio/')) or 'oleObject' in ct or ct.endswith('.package'):
                out.add(hashlib.sha1(part.blob).hexdigest())
        return out
    ha, hb = hashes(a), hashes(b)
    return {'source': len(ha), 'rebuilt': len(hb), 'missing': len(ha - hb)}


# ── visual ───────────────────────────────────────────────────────────────────
def soffice():
    return shutil.which('soffice') or shutil.which('libreoffice')


def render(pptx_bytes, outdir, prefix, dpi=60, timeout=240):
    """Render every slide (hidden ones too) to PNG. -> list of paths (empty if LibreOffice is missing)."""
    exe = soffice()
    if not exe:
        return []
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / f'{prefix}.pptx'
        src.write_bytes(pptx_bytes)
        flt = 'pdf:impress_pdf_Export:{"ExportHiddenSlides":{"type":"boolean","value":"true"}}'
        subprocess.run([exe, f'-env:UserInstallation=file://{td}/lo', '--headless', '--convert-to', flt,
                        '--outdir', td, str(src)], capture_output=True, timeout=timeout)
        pdf = Path(td) / f'{prefix}.pdf'
        if not pdf.exists():
            return []
        for old in outdir.glob(f'{prefix}-*.png'):
            old.unlink()
        if shutil.which('pdftoppm'):
            subprocess.run(['pdftoppm', '-r', str(dpi), '-png', str(pdf), str(outdir / prefix)],
                           capture_output=True, timeout=timeout)
        else:
            try:
                import fitz  # PyMuPDF
                doc = fitz.open(str(pdf))
                for i, page in enumerate(doc, 1):
                    page.get_pixmap(dpi=dpi).save(str(outdir / f'{prefix}-{i}.png'))
            except ImportError:
                return []
    files = sorted(outdir.glob(f'{prefix}-*.png'), key=lambda p: int(p.stem.rsplit('-', 1)[1]))
    return files


def visual(src_pngs, out_pngs):
    from PIL import Image, ImageChops, ImageStat
    rows = []
    for i, (a, b) in enumerate(zip(src_pngs, out_pngs), 1):
        ia, ib = Image.open(a).convert('RGB'), Image.open(b).convert('RGB')
        if ia.size != ib.size:
            ib = ib.resize(ia.size)
        d = ImageChops.difference(ia, ib)
        mean = sum(ImageStat.Stat(d).mean) / 3
        gray = d.convert('L').point(lambda v: 255 if v > 24 else 0)
        changed = ImageStat.Stat(gray).mean[0] / 255
        rows.append({'slide': i, 'similarity': round(1 - mean / 255, 5), 'changed_pixels': round(changed, 5)})
    return rows


def verify(src_bytes, code, assets, workdir, module_name='deck', do_render=True):
    workdir = Path(workdir)
    out_bytes, log = run_generated(code, assets, workdir / 'run', module_name)
    report = {'structural': structural(src_bytes, out_bytes), 'log': log.strip()[-500:]}
    if do_render and soffice():
        a = render(src_bytes, workdir / 'render', 'source')
        b = render(out_bytes, workdir / 'render', 'rebuilt')
        report['visual'] = visual(a, b)
        report['render'] = {'source': [str(p) for p in a], 'rebuilt': [str(p) for p in b]}
    return report, out_bytes


def render_many(decks, outdir, dpi=60, timeout=300):
    """Render several small decks with one LibreOffice start-up. decks = [(prefix, bytes)] -> {prefix: [paths]}."""
    exe = soffice()
    if not exe or not decks:
        return {}
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    out = {}
    with tempfile.TemporaryDirectory() as td:
        srcs = []
        for prefix, data in decks:
            p = Path(td) / f'{prefix}.pptx'
            p.write_bytes(data)
            srcs.append(str(p))
        flt = 'pdf:impress_pdf_Export:{"ExportHiddenSlides":{"type":"boolean","value":"true"}}'
        subprocess.run([exe, f'-env:UserInstallation=file://{td}/lo', '--headless', '--convert-to', flt,
                        '--outdir', td, *srcs], capture_output=True, timeout=timeout)
        for prefix, _ in decks:
            pdf = Path(td) / f'{prefix}.pdf'
            if not pdf.exists():
                continue
            mine = re.compile(re.escape(prefix) + r'-(\d+)\.png$')  # exact: 'a-1.png' but never 'a-b-1.png'
            for old in outdir.iterdir():
                if mine.match(old.name):
                    old.unlink()
            subprocess.run(['pdftoppm', '-r', str(dpi), '-png', str(pdf), str(outdir / prefix)],
                           capture_output=True, timeout=timeout)
            out[prefix] = sorted((q for q in outdir.iterdir() if mine.match(q.name)),
                                 key=lambda q: int(mine.match(q.name).group(1)))
    return out
