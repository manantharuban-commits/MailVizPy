"""Theme conversion: swap a deck's colour + font scheme and, optionally, re-colour
hard-coded colours and fonts so the whole deck follows the new theme."""
import colorsys
import io
import re

from lxml import etree
from pptx import Presentation
from pptx.opc.constants import RELATIONSHIP_TYPE as RT

A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
P = 'http://schemas.openxmlformats.org/presentationml/2006/main'
SLOTS = ['dk1', 'lt1', 'dk2', 'lt2', 'accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6',
         'hlink', 'folHlink']

from .looks import presets as _look_presets  # noqa: E402

PRESETS = _look_presets()


# ── colour maths ─────────────────────────────────────────────────────────────
def _rgb(h):
    h = h.strip('#')
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def _hex(rgb):
    return ''.join(f'{max(0, min(255, round(c * 255))):02X}' for c in rgb)


def _lab(h):
    def lin(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(c) for c in _rgb(h))
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883

    def f(t):
        return t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116
    return 116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z))


def delta_e(a, b):
    la, lb = _lab(a), _lab(b)
    return sum((x - y) ** 2 for x, y in zip(la, lb)) ** 0.5


def luminance(h):
    r, g, b = _rgb(h)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


# ── reading ──────────────────────────────────────────────────────────────────
def _theme_parts(prs):
    seen, out = set(), []
    masters = list(prs.slide_masters)
    for m in masters:
        tp = m.part.part_related_by(RT.THEME)
        if tp not in seen:
            seen.add(tp)
            out.append(tp)
    return out


def _scheme(theme_el):
    cs = theme_el.find(f'.//{{{A}}}clrScheme')
    colors = {}
    for slot in SLOTS:
        el = cs.find(f'{{{A}}}{slot}') if cs is not None else None
        val = None
        if el is not None and len(el):
            c = el[0]
            val = c.get('lastClr') if c.tag.endswith('sysClr') else c.get('val')
        colors[slot] = (val or '000000').upper()
    fs = theme_el.find(f'.//{{{A}}}fontScheme')
    fonts = {}
    for k in ('major', 'minor'):
        lat = fs.find(f'{{{A}}}{k}Font/{{{A}}}latin') if fs is not None else None
        fonts[k] = lat.get('typeface') if lat is not None else ''
    name = cs.get('name') if cs is not None else ''
    return {'name': name, 'colors': colors, 'fonts': fonts}


def read_theme(data):
    prs = Presentation(io.BytesIO(data))
    tp = _theme_parts(prs)[0]
    info = _scheme(etree.fromstring(tp.blob))
    cm = prs.slide_masters[0]._element.find(f'{{{P}}}clrMap')
    info['dark'] = cm is not None and cm.get('bg1') == 'dk1'
    if not info['dark']:
        info['dark'] = luminance(info['colors']['lt1']) < 0.35
    return info


# ── conversion ───────────────────────────────────────────────────────────────
def _write_scheme(theme_el, colors, fonts, name):
    cs = theme_el.find(f'.//{{{A}}}clrScheme')
    if cs is not None:
        cs.set('name', name)
        for slot in SLOTS:
            el = cs.find(f'{{{A}}}{slot}')
            if el is None:
                continue
            for c in list(el):
                el.remove(c)
            etree.SubElement(el, f'{{{A}}}srgbClr').set('val', colors[slot].upper())
    if fonts:
        fs = theme_el.find(f'.//{{{A}}}fontScheme')
        if fs is not None:
            fs.set('name', name)
            for k in ('major', 'minor'):
                if not fonts.get(k):
                    continue
                lat = fs.find(f'{{{A}}}{k}Font/{{{A}}}latin')
                if lat is not None:
                    for attr in list(lat.attrib):
                        del lat.attrib[attr]
                    lat.set('typeface', fonts[k])


class _Recolor:
    """Maps hard-coded colours onto the new theme.

    Chromatic colours follow the nearest theme slot (keeping their tint/shade). When the deck
    changes between light and dark, neutral colours are flipped by role: light fills and dark
    text are inverted, while dark fills and light text (already-dark panels) are kept, so
    every text/fill pair keeps its contrast."""

    TEXT = {'rPr', 'endParaRPr', 'defRPr'}

    def __init__(self, old, new, mode, flip, threshold=14.0):
        self.mode, self.threshold = mode, threshold
        self.old, self.new = old, new
        self.flip = flip            # None | 'to_dark' | 'to_light'
        self.exact = {}
        for slot in SLOTS:
            self.exact.setdefault(old[slot].upper(), new[slot].upper())
        self.chroma_slots = [s for s in SLOTS if s not in ('dk1', 'lt1')]
        self.cache = {}
        self.changed = 0

    @staticmethod
    def neutral(v):
        r, g, b = _rgb(v)
        h, l, s = colorsys.rgb_to_hls(r, g, b)
        return (max(r, g, b) - min(r, g, b)) < 0.12 or l < 0.2 or l > 0.93

    def _shift(self, v, old_ref, new_ref):
        ho, lo, so = colorsys.rgb_to_hls(*_rgb(old_ref))
        hv, lv, sv = colorsys.rgb_to_hls(*_rgb(v))
        hn, ln, sn = colorsys.rgb_to_hls(*_rgb(new_ref))
        l2 = min(1, max(0, ln + (lv - lo)))
        s2 = min(1, max(0, sn + (sv - so) * 0.5))
        return _hex(colorsys.hls_to_rgb(hn, l2, s2))

    def _invert(self, v):
        h, l, s = colorsys.rgb_to_hls(*_rgb(v))
        anchor = self.new['lt1'] if l < 0.5 else self.new['dk1']
        ha, la, sa = colorsys.rgb_to_hls(*_rgb(anchor))
        l2 = la + (1 - l - la) * 0.15 if abs(l - 0.5) > 0.3 else 1 - l
        return _hex(colorsys.hls_to_rgb(ha, min(1, max(0, l2)), min(sa, 0.3)))

    def map(self, val, role):
        v = val.upper()
        key = (v, role)
        if key in self.cache:
            return self.cache[key]
        out = v
        h, l, s = colorsys.rgb_to_hls(*_rgb(v))
        if self.neutral(v):
            if self.flip == 'to_dark' and ((role == 'text' and l < 0.45) or (role == 'fill' and l > 0.6)):
                out = self._invert(v)
            elif self.flip == 'to_light' and ((role == 'text' and l > 0.55) or (role == 'fill' and l < 0.4)):
                out = self._invert(v)
            elif not self.flip and v in self.exact:
                out = self.exact[v]
        elif v in self.exact:
            out = self.exact[v]
        elif self.mode == 'smart':
            best = min(self.chroma_slots, key=lambda sl: delta_e(v, self.old[sl]))
            if delta_e(v, self.old[best]) <= self.threshold or best.startswith('accent'):
                out = self._shift(v, self.old[best], self.new[best]) \
                    if delta_e(v, self.old[best]) <= self.threshold * 2.5 else v
        self.cache[key] = out
        return out

    def apply(self, root):
        for el in root.iter(f'{{{A}}}srgbClr'):
            role = 'fill'
            node = el.getparent()
            while node is not None:
                if etree.QName(node).localname in self.TEXT:
                    role = 'text'
                    break
                node = node.getparent()
            new = self.map(el.get('val', '000000'), role)
            if new != el.get('val', '').upper():
                el.set('val', new)
                self.changed += 1


class _Refont:
    def __init__(self, old, new, mode):
        self.map = {}
        if old.get('major') and new.get('major'):
            self.map[old['major']] = new['major']
        if old.get('minor') and new.get('minor'):
            self.map[old['minor']] = new['minor']
        self.mode, self.new = mode, new
        self.changed = 0

    def apply(self, root):
        for tag in ('latin', 'ea', 'cs'):
            for el in root.iter(f'{{{A}}}{tag}'):
                face = el.get('typeface', '')
                if not face or face.startswith('+'):
                    continue
                target = self.map.get(face)
                if target is None and self.mode == 'all' and tag == 'latin':
                    target = self.new.get('minor')
                if target and target != face:
                    for attr in ('panose', 'pitchFamily', 'charset'):
                        el.attrib.pop(attr, None)
                    el.set('typeface', target)
                    self.changed += 1


def _bg_kind(el):
    bg = el.find(f'.//{{{P}}}cSld/{{{P}}}bg')
    if bg is None:
        return None
    pr = bg.find(f'{{{P}}}bgPr')
    if pr is None:
        return 'ref'
    for c in pr:
        n = etree.QName(c).localname
        if n in ('blipFill', 'pattFill'):
            return 'picture'
        if n in ('solidFill', 'gradFill', 'noFill'):
            return 'colour'
    return None


def _picture_backed(prs):
    """Slides/layouts/masters whose effective background is an image: their neutral colours must
    not be flipped, because the image itself can't change from light to dark."""
    fixed = set()
    for m in prs.slide_masters:
        mk = _bg_kind(m._element)
        if mk == 'picture':
            fixed.add(m.part)
        for lay in m.slide_layouts:
            lk = _bg_kind(lay._element) or mk
            if lk == 'picture':
                fixed.add(lay.part)
    for s in prs.slides:
        sk = _bg_kind(s._element)
        if sk is None:
            lay = s.slide_layout
            sk = _bg_kind(lay._element) or _bg_kind(lay.slide_master._element)
        if sk == 'picture':
            fixed.add(s.part)
    return fixed


def convert(data, colors, fonts=None, name='Custom', dark=None, recolor='smart', refont='theme'):
    """Return (new pptx bytes, summary).

    recolor: 'theme' (scheme only) | 'exact' (also hard-coded colours equal to old theme colours)
             | 'smart' (also near-theme colours, keeping their tint/shade)
    refont:  'theme' (font scheme only) | 'matching' (also explicit uses of the old theme fonts)
             | 'all' (every explicit latin font becomes the new body font)
    """
    colors = {k: v.strip('#').upper() for k, v in colors.items()}
    prs = Presentation(io.BytesIO(data))
    theme_parts = _theme_parts(prs)
    old = _scheme(etree.fromstring(theme_parts[0].blob))
    cm0 = prs.slide_masters[0]._element.find(f'{{{P}}}clrMap')
    old_dark = cm0 is not None and cm0.get('bg1') == 'dk1'
    want_dark = old_dark if dark is None else bool(dark)
    flip = None if want_dark == old_dark else ('to_dark' if want_dark else 'to_light')
    # 1. schemes (slide-master themes + notes/handout themes)
    all_themes = set(theme_parts)
    for part in prs.part.package.iter_parts():
        if part.content_type.endswith('theme+xml'):
            all_themes.add(part)
    for tp in all_themes:
        el = etree.fromstring(tp.blob)
        _write_scheme(el, colors, fonts, name)
        th = el if el.tag.endswith('theme') else None
        if th is not None:
            th.set('name', name)
        tp._blob = etree.tostring(el, xml_declaration=True, encoding='UTF-8', standalone=True)
    # 2. light/dark colour mapping on the slide masters
    if dark is not None:
        for m in prs.slide_masters:
            cm = m._element.find(f'{{{P}}}clrMap')
            if cm is not None:
                if want_dark:
                    cm.set('bg1', 'dk1'), cm.set('tx1', 'lt1'), cm.set('bg2', 'dk2'), cm.set('tx2', 'lt2')
                else:
                    cm.set('bg1', 'lt1'), cm.set('tx1', 'dk1'), cm.set('bg2', 'lt2'), cm.set('tx2', 'dk2')
    # picture-backed slides/layouts keep the original light/dark mapping (the picture can't flip)
    if dark is not None and flip:
        orig_map = {'bg1': 'lt1', 'tx1': 'dk1', 'bg2': 'lt2', 'tx2': 'dk2'} if flip == 'to_dark' else \
            {'bg1': 'dk1', 'tx1': 'lt1', 'bg2': 'dk2', 'tx2': 'lt2'}
        mapping = dict(orig_map, **{f'accent{i}': f'accent{i}' for i in range(1, 7)}, hlink='hlink', folHlink='folHlink')
        for part in _picture_backed(prs):
            el = part._element
            if etree.QName(el).localname == 'sldMaster':
                continue
            for old_ovr in el.findall(f'{{{P}}}clrMapOvr'):
                el.remove(old_ovr)
            ovr = etree.Element(f'{{{P}}}clrMapOvr')
            etree.SubElement(ovr, f'{{{A}}}overrideClrMapping', mapping)
            el.find(f'{{{P}}}cSld').addnext(ovr)
    # 3. table styles follow the light/dark direction (built-in styles use fixed light/dark slots)
    if flip and recolor != 'theme':
        style = '{E8034E78-7F5D-4C2E-B375-FC64B27BC917}' if flip == 'to_dark' else '{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}'
        for s in prs.slides:
            for el in s._element.iter(f'{{{A}}}tableStyleId'):
                el.text = style
    # 4. hard-coded colours / fonts in slides, layouts, masters, charts, diagrams
    rc = _Recolor(old['colors'], colors, recolor, flip) if recolor in ('exact', 'smart') else None
    rc_fixed = _Recolor(old['colors'], colors, recolor, None) if rc and flip else None
    fixed = _picture_backed(prs) if flip else set()
    rf = _Refont(old['fonts'], fonts or {}, refont) if fonts and refont in ('matching', 'all') else None
    if rc or rf:
        for part in prs.part.package.iter_parts():
            ct = part.content_type or ''
            if not ct.endswith('xml') or 'theme' in ct:
                continue
            if not any(k in ct for k in ('slide', 'chart', 'diagram', 'drawing', 'notes')):
                continue
            if hasattr(part, '_element'):
                root = part._element
                if rc:
                    (rc_fixed if part in fixed else rc).apply(root)
                if rf:
                    rf.apply(root)
            else:
                try:
                    root = etree.fromstring(part.blob)
                except etree.XMLSyntaxError:
                    continue
                if rc:
                    rc.apply(root)
                if rf:
                    rf.apply(root)
                part._blob = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
    out = io.BytesIO()
    prs.save(out)
    return out.getvalue(), {
        'from': old, 'to': {'name': name, 'colors': colors, 'fonts': fonts or old['fonts']},
        'recoloured': (rc.changed + (rc_fixed.changed if rc_fixed else 0)) if rc else 0,
        'picture_backgrounds': len(fixed), 'refonted': rf.changed if rf else 0,
        'dark': want_dark, 'light_dark_flip': flip}


def preset_list():
    return [{'id': k, **v} for k, v in PRESETS.items()]


FRESH_HUES = ['4F46E5', '8B5CF6', 'D946EF', 'EC4899', 'F43F5E', 'F97316', 'F59E0B', 'EAB308', '84CC16',
              '22C55E', '10B981', '14B8A6', '06B6D4', '0EA5E9', '3B82F6']
FRESH_DARK = dict(zip(FRESH_HUES, ['818CF8', 'A78BFA', 'E879F9', 'F472B6', 'FB7185', 'FB923C', 'FBBF24', 'FACC15',
                                   'A3E635', '4ADE80', '34D399', '2DD4BF', '22D3EE', '38BDF8', '60A5FA']))


def harmonize(base_hex, dark=False):
    """Build a fresh 12-slot scheme from one brand colour.

    The brand colour is accent 1; accents 2-6 are picked from a curated set of vivid, evenly
    bright modern hues so that they sit as far apart from each other (and the brand) as possible.
    Neutrals are tinted very slightly towards the brand hue."""
    base_hex = base_hex.strip('#').upper()
    h, l, s = colorsys.rgb_to_hls(*_rgb(base_hex))

    def hdist(a, b):
        d = abs(a - b) % 1
        return min(d, 1 - d)

    chosen = [h]
    pool = [(c, colorsys.rgb_to_hls(*_rgb(c))[0]) for c in FRESH_HUES]
    accents = [base_hex]
    while len(accents) < 6:
        c, hh = max(((c, hh) for c, hh in pool if c not in accents),
                    key=lambda x: min(hdist(x[1], o) for o in chosen))
        accents.append(c)
        chosen.append(hh)
    # order: brand, then the most distant colour, then alternate warm/cool for good neighbouring contrast
    if dark:  # the 400-weight of each hue glows on a dark page without turning neon
        lifted = [FRESH_DARK.get(c, c) for c in accents[1:]]
        hh, ll, ss = colorsys.rgb_to_hls(*_rgb(accents[0]))
        brand = accents[0] if ll >= 0.55 else _hex(colorsys.hls_to_rgb(hh, 0.64, min(ss, 0.9)))
        accents = [brand] + lifted
        base = dict(dk1=_hex(colorsys.hls_to_rgb(h, 0.065, 0.35)), lt1='F8FAFC',
                    dk2=_hex(colorsys.hls_to_rgb(h, 0.13, 0.28)), lt2=_hex(colorsys.hls_to_rgb(h, 0.76, 0.18)))
    else:
        base = dict(dk1=_hex(colorsys.hls_to_rgb(h, 0.1, 0.35)), lt1='FFFFFF',
                    dk2=_hex(colorsys.hls_to_rgb(h, 0.36, 0.14)), lt2=_hex(colorsys.hls_to_rgb(h, 0.965, 0.45)))
    cols = dict(base, **{f'accent{i + 1}': a for i, a in enumerate(accents)})
    cols['hlink'] = accents[0]
    cols['folHlink'] = accents[4]
    return cols


if __name__ == '__main__':
    import sys
    src = sys.argv[1]
    data = open(src, 'rb').read()
    print(read_theme(data))
    p = PRESETS[sys.argv[2] if len(sys.argv) > 2 else 'aurora']
    out, summary = convert(data, p['colors'], p['fonts'], p['name'], p['dark'], 'smart', 'matching')
    open(re.sub(r'\.pptx$', '', src) + '_themed.pptx', 'wb').write(out)
    print(summary)
