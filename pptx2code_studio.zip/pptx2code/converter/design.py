"""One design spec drives everything: palette, fonts, light/dark and component styles.

    design = {'look': 'fresh',                    # one-click look (palette + font pair + component styles)
              'palette': {...12 slots...},        # optional: overrides the look's palette
              'font': 'segoe',                    # optional: font pair id (looks.FONT_PAIRS)
              'dark': True,                       # optional: force light/dark
              'kinds': {'chart': {'style': 'bold', 'chart_type': 'bar'}},
              'items': {'3:4': {'style': 'keep'}},
              'title_accent': 'DB0011',
              'custom': {'brand-heat': {...}}}        # optional: your own designs, used as style 'my:<id>'
    data, theme_summary, restyle_summary = prepare(pptx_bytes, design)
"""
from . import looks, restyle, themes


def design_args(design, src=None):
    """UI design spec -> (theme args or None, restyle plan or None).

    design = {look, palette, font, fonts, dark, kinds, items, colour, title_accent, recolor, refont}
    A look supplies palette, font pair, light/dark and a style for every component kind; anything
    else in the spec overrides it."""
    if not design or design.get('enabled') is False:
        return None, None
    lk = looks.LOOK_BY_ID.get(design.get('look') or '')
    colors = design.get('palette') or (lk['colors'] if lk else None)
    fid = design.get('font') or (lk['font'] if lk else None)
    fonts = design.get('fonts') or ({k: looks.FONT_BY_ID[fid][k] for k in ('major', 'minor')}
                                    if fid in looks.FONT_BY_ID else None)
    dark = False  # light designs only: dark decks are converted to light
    targs = None
    if colors or fonts:
        if not colors:
            colors = themes.read_theme(src)['colors'] if src else None
        if colors:
            name = (lk['name'] if lk and not design.get('palette') else design.get('palette_name') or 'Custom')
            targs = (colors, fonts, name, dark, design.get('recolor', 'smart'),
                     design.get('refont') or ('all' if fonts else 'theme'))
    kinds = {k: ({'style': v} if isinstance(v, str) else dict(v)) for k, v in (lk['kinds'] if lk else {}).items()}
    for k, v in (design.get('kinds') or {}).items():
        mine = {a: b for a, b in v.items() if b not in (None, '', 'inherit')}
        if str(mine.get('style', '')).startswith('my:'):  # a custom design brings its own icons and legend
            kinds[k] = {a: b for a, b in kinds.get(k, {}).items() if a not in ('icons', 'legend')}
        kinds[k] = {**kinds.get(k, {}), **mine}
    plan = {'look': lk['id'] if lk else None, 'kinds': kinds, 'items': design.get('items') or {},
            'colour': design.get('colour') or 'auto', 'dark': bool(dark) if dark is not None else
            (themes.read_theme(src)['dark'] if src else False),
            'title_accent': design['title_accent'] if 'title_accent' in design else (lk or {}).get('title_accent'),
            'light_font': (looks.FONT_BY_ID.get(fid) or {}).get('light') if fid else None,
            'custom': design.get('custom') or {}}
    return targs, (plan if has_plan(plan) else None)


def has_plan(plan):
    if not plan:
        return False
    vals = [v for k in (plan.get('kinds') or {}).values() for v in k.values()]
    vals += [v for k in (plan.get('items') or {}).values() for v in k.values()]
    return any(v not in ('keep', 'inherit', None, '') for v in vals)


def prepare(src, design, slide=None):
    """source -> (one slide) -> palette/fonts -> component styles. Returns (bytes, theme summary, restyle summary)."""
    targs, plan = design_args(design, src)
    data = src
    if slide:
        data = restyle.single_slide(data, slide)
        if plan:
            pre = f'{slide}:'
            plan = dict(plan, items={'1:' + k[len(pre):]: v for k, v in plan['items'].items() if k.startswith(pre)})
    tsum = rsum = None
    if targs:
        data, tsum = themes.convert(data, *targs)
    if plan:
        data, rsum = restyle.apply(data, plan)
    return data, tsum, rsum


def custom_ids(design, kind):
    """'my:<id>' for the custom designs of `kind` (heatmap and table designs both style tables)."""
    return [f'my:{i}' for i, d in (design or {}).get('custom', {}).items()
            if isinstance(d, dict) and d.get('kind') == kind and not i.startswith('__')]


def gallery_designs(design, kind, chart_type=None, extra=()):
    """One design per style of `kind`: the current design with only that component kind switched."""
    out = []
    base = dict(design or {})
    base.pop('items', None)
    for sid in ['keep'] + [x[0] for x in restyle.STYLES[kind]] + custom_ids(design, kind) + list(extra):
        d = dict(base)
        kinds = {k: dict(v) for k, v in (base.get('kinds') or {}).items()}
        if kind == 'heatmap':
            kinds['heatmap'] = {**kinds.get('heatmap', {}), 'style': sid}
        else:
            kinds[kind] = {**kinds.get(kind, {}), 'style': sid}
            if kind == 'table':
                kinds['heatmap'] = {'style': 'keep'}
            if kind == 'chart' and chart_type:
                kinds['chart']['chart_type'] = chart_type
        d['kinds'] = kinds
        out.append((sid, d))
    return out
