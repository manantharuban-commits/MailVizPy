"""Structural diff between a source shape and its rebuilt counterpart.

Produces the minimal set of exact-patch operations (`_sync` / `_attrs`) that make
the rebuilt XML identical to the source, at readable granularity (whole spPr,
one paragraph's pPr, one run's rPr …)."""
from .ooxml import canon, local
from .runtime import _ORDER


CONTAINERS = {'sp', 'pic', 'cxnSp', 'grpSp', 'graphicFrame',
              'nvSpPr', 'nvPicPr', 'nvCxnSpPr', 'nvGrpSpPr', 'nvGraphicFramePr',
              'txBody', 'p', 'r', 'br', 'fld', 'graphic', 'graphicData', 'tbl', 'tr', 'tc',
              'spPr', 'grpSpPr', 'xfrm', 'ln', 'bodyPr', 'pPr', 'rPr', 'endParaRPr', 'tcPr', 'tblPr',
              'cNvPr', 'nvPr'}
SEQ = {'txBody': {'p'}, 'p': {'r', 'br', 'fld'}, 'tbl': {'tr'}, 'tr': {'tc'}}
SHAPE_TAGS = {'sp', 'pic', 'cxnSp', 'grpSp', 'graphicFrame', 'contentPart', 'AlternateContent'}


def _join(path, step):
    return f'{path}/{step}' if path else step


def _kids(el, group):
    out = []
    for c in el:
        if not isinstance(c.tag, str):
            continue
        if group and local(c) in SHAPE_TAGS:
            continue
        out.append(c)
    return out


def _attr_canon(el, resolve):
    items = []
    for k, v in el.attrib.items():
        if resolve and k.startswith('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'):
            v = resolve(v)
        items.append((k, v))
    return sorted(items)


def diff(o, n, ro, rn, path='', skip_graphic=False):
    """-> list of ('sync', path, element_or_None) | ('attrs', path, dict). path '' = whole shape."""
    name = local(o)
    group = name == 'grpSp'

    def skip(c):
        return (group and local(c) in SHAPE_TAGS) or (skip_graphic and local(c) == 'graphic' and path == '')

    if canon(o, ro, skip) == canon(n, rn, skip):
        return []
    if local(n) != name or name not in CONTAINERS:
        return [('sync', path, o)]
    ops = []
    if _attr_canon(o, ro) != _attr_canon(n, rn):
        ops.append(('attrs', path, dict(o.attrib)))
    seq_names = SEQ.get(name, set())
    ok = [c for c in _kids(o, group) if not skip(c)]
    nk = [c for c in _kids(n, group) if not skip(c)]
    o_seq = [c for c in ok if local(c) in seq_names]
    n_seq = [c for c in nk if local(c) in seq_names]
    if [local(c) for c in o_seq] != [local(c) for c in n_seq]:
        return [('sync', path, o)]

    def units(kids):
        seen, out = {}, {}
        for c in kids:
            if local(c) in seq_names:
                continue
            k = local(c)
            i = seen.get(k, 0)
            seen[k] = i + 1
            out[(k, i)] = c
        return out

    ou, nu = units(ok), units(nk)
    order = list(ou) + [k for k in nu if k not in ou]
    for key in order:
        nm, i = key
        step = f'{nm}[{i}]' if i else nm
        oc, nc = ou.get(key), nu.get(key)
        if oc is None:
            ops.append(('sync', _join(path, step), None))
        elif nc is None:
            if name not in _ORDER or not _ORDER[name]:  # no safe insertion point: replace the parent
                return [('sync', path, o)] if path else [('sync', path, o)]
            ops.append(('sync', _join(path, step), oc))
        else:
            ops += diff(oc, nc, ro, rn, _join(path, step))
    counters = {}
    for oc, nc in zip(o_seq, n_seq):
        nm = local(oc)
        i = counters.get(nm, 0)
        counters[nm] = i + 1
        ops += diff(oc, nc, ro, rn, _join(path, f'{nm}[{i}]'))
    return ops


def merge_ops(existing, new):
    """Combine patch lists; a patch on a container replaces patches below it."""
    merged = dict(existing)
    for op in new:
        kind, path, val = op
        key = (kind, path)
        if kind == 'sync':
            for k in [k for k in merged if k[1].startswith(path + '/') or (path == '' and k[1])]:
                del merged[k]
        merged[key] = op
    return merged
