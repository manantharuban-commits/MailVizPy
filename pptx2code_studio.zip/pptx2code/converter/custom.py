"""Your own component designs.

A custom design is a built-in design used as the starting point plus your own settings, for
example a heatmap with your colour ramp, cell gaps, header and total row:

    {'id': 'brand-heat', 'kind': 'heatmap', 'name': 'Brand heat', 'base': 'heat-tiles',
     'params': {'ramp': ['F1F5FF', '1F4FD8'], 'gap': 2, 'header': 'fill', ...}}

The settings can also be *captured* from a component on a sample slide (`capture`): colours,
gaps, borders, sizes and so on are read off that component and become the design's settings,
which can then be fine-tuned. A design spec refers to a custom design as style 'my:<id>'.

Designs are kept in designs/my_designs.json next to the app (PPTX_STUDIO_DESIGNS overrides the
path) and can be exported/imported as one JSON file to share them with a team.

Colour tokens used in settings:
    'accent1' … 'accent6', 'tx1', 'tx2', 'bg1', 'bg2'   theme colours (follow the palette)
    'accent1@15'   a tint: 15 % of the colour on white (lumMod 15 %, lumOff 85 %)
    'accent1@-30'  a shade: 30 % darker
    '1F4FD8'       a fixed hex colour (may also take @n)
    'auto'         let the design decide (only where a field allows it)
"""
import colorsys
import copy
import io
import json
import os
import re
import time
import uuid
from pathlib import Path

from lxml import etree
from pptx import Presentation

from . import restyle as R
from .restyle import A, C, P, EMU_IN, X, kid, kids, ln_, put, solid, clr

ROOT = Path(__file__).resolve().parent.parent
FORMAT = 'pptx-studio-designs'

# ── colour tokens ────────────────────────────────────────────────────────────
THEME_NAMES = ('accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6', 'tx1', 'tx2', 'bg1', 'bg2')
TOKEN_RX = re.compile(r'^(?:(accent[1-6]|tx[12]|bg[12])|([0-9A-Fa-f]{6}))(?:@(-?\d{1,2}))?$')
SCHEME_MAP = {'tx1': 'dk1', 'bg1': 'lt1', 'tx2': 'dk2', 'bg2': 'lt2'}


def valid_token(t, allow_auto=False):
    return isinstance(t, str) and (bool(TOKEN_RX.match(t)) or (allow_auto and t == 'auto'))


def _mod(n):
    n = int(n)
    if n > 0:
        return {'lumMod': str(n * 1000), 'lumOff': str((100 - n) * 1000)}
    if n < 0:
        return {'lumMod': str((100 + n) * 1000)}
    return {}


def tok(token):
    """Colour token -> (value, modifiers) for restyle.clr()/solid()."""
    m = TOKEN_RX.match(token or '')
    if not m:
        return 'accent1', {}
    name, hexv, n = m.groups()
    if hexv:
        hexv = hexv.upper()
        if n:
            n = int(n)
            hexv = R._lummod(hexv, n, 100 - n) if n > 0 else R._lummod(hexv, 100 + n, 0)
        return hexv, {}
    return name, (_mod(n) if n else {})


def fill_xml(token):
    v, m = tok(token)
    return solid(v, **m)


def clr_xml(token, **extra):
    v, m = tok(token)
    return clr(v, **{**m, **extra})


def hexof(token, ctx):
    """The hex value of a token in the deck's (new) theme."""
    m = TOKEN_RX.match(token or '')
    if not m:
        return '4F46E5'
    name, hexv, n = m.groups()
    if name:
        theme = getattr(ctx, 'theme', {}) or {}
        hexv = theme.get(SCHEME_MAP.get(name, name)) or theme.get(name) or \
            {'dk1': '0F172A', 'lt1': 'FFFFFF', 'dk2': '1E293B', 'lt2': 'F1F5F9'}.get(SCHEME_MAP.get(name, name), '4F46E5')
    hexv = hexv.upper()
    if n:
        n = int(n)
        hexv = R._lummod(hexv, n, 100 - n) if n > 0 else R._lummod(hexv, 100 + n, 0)
    return hexv


def is_dark(token, ctx, cut=0.36):
    return R._lum(R._hex2rgb(hexof(token, ctx))) < cut


def on(token, ctx):
    """Text colour that reads on a fill token."""
    return ('lt1', {}) if is_dark(token, ctx) else ('tx1', {})


# ── settings schema ──────────────────────────────────────────────────────────
def _opts(*pairs):
    return [{'id': a, 'name': b} for a, b in pairs]


def F(key, label, type_, default, group, **kw):
    return dict(key=key, label=label, type=type_, default=default, group=group, **kw)


PADDING = _opts(('compact', 'Compact'), ('normal', 'Normal'), ('airy', 'Airy'))
SHADOWS = _opts(('none', 'None'), ('soft', 'Soft'), ('float', 'Floating'))

FIELDS = {
    'heatmap': [
        F('ramp', 'Colour ramp', 'ramp', [], 'Colours', help='Light to deep. Empty = shades of the brand colour'),
        F('mode', 'Show values as', 'select', 'fill', 'Colours', options=_opts(
            ('fill', 'Coloured cells'), ('text', 'Coloured numbers'), ('top', 'Highlight top values'))),
        F('top_n', 'How many top values', 'range', 5, 'Colours', min=1, max=12, step=1, when={'mode': ['top']}),
        F('scale', 'Colour scale', 'select', 'auto', 'Colours', options=_opts(
            ('auto', 'Automatic (per column when units differ)'), ('table', 'Whole table'), ('rows', 'Each row'),
            ('columns', 'Each column'))),
        F('diverge', 'Diverging (centre on the median)', 'toggle', False, 'Colours'),
        F('gap', 'Gap between cells', 'range', 1, 'Cells', min=0, max=6, step=0.5, unit='pt'),
        F('gap_colour', 'Gap colour', 'colour', 'bg1', 'Cells', when={'gap': '>0'}),
        F('text', 'Number colour', 'select', 'auto', 'Cells', options=_opts(
            ('auto', 'Automatic contrast'), ('dark', 'Dark'), ('light', 'White')), when={'mode': ['fill']}),
        F('bold', 'Bold numbers', 'toggle', False, 'Cells'),
        F('align', 'Number alignment', 'select', 'ctr', 'Cells', options=_opts(('ctr', 'Centre'), ('r', 'Right'))),
        F('padding', 'Cell padding', 'select', 'normal', 'Cells', options=PADDING),
        F('font_size', 'Text size', 'range', 0, 'Cells', min=0, max=24, step=1, unit='pt', zero='Keep'),
        F('header', 'Header row', 'select', 'rule', 'Header, labels, total', options=_opts(
            ('rule', 'Bold with a rule'), ('plain', 'Bold, no rule'), ('fill', 'Filled'))),
        F('header_colour', 'Header fill', 'colour', 'tx1', 'Header, labels, total', when={'header': ['fill']}),
        F('first_col', 'First column', 'select', 'bold', 'Header, labels, total', options=_opts(
            ('bold', 'Bold'), ('plain', 'Regular'), ('fill', 'Filled'))),
        F('first_colour', 'First column fill', 'colour', 'bg2', 'Header, labels, total', when={'first_col': ['fill']}),
        F('total', 'Total row', 'select', 'rule', 'Header, labels, total', options=_opts(
            ('rule', 'Bold with a rule'), ('plain', 'Bold, no rule'), ('fill', 'Filled'))),
        F('total_colour', 'Total row fill', 'colour', 'bg2', 'Header, labels, total', when={'total': ['fill']}),
    ],
    'table': [
        F('header', 'Header row', 'select', 'rule', 'Header', options=_opts(
            ('rule', 'Bold with a rule'), ('fill', 'Filled'), ('plain', 'Bold, no rule'))),
        F('header_colour', 'Header colour', 'colour', 'accent1', 'Header',
          help='The fill of a filled header, or the colour of the rule'),
        F('header_text', 'Header text', 'colour', 'auto', 'Header', auto=True),
        F('banding', 'Row banding', 'select', 'none', 'Rows', options=_opts(
            ('none', 'None'), ('rows', 'Alternate rows'), ('all', 'Every row (card rows)'),
            ('columns', 'Alternate columns'))),
        F('band_colour', 'Band colour', 'colour', 'bg2', 'Rows', when={'banding': ['rows', 'all', 'columns']}),
        F('row_colour', 'Other rows', 'colour', 'auto', 'Rows', auto=True, when={'banding': ['rows', 'columns']},
          help='Fill of the rows between the bands. Automatic = no fill'),
        F('borders', 'Lines', 'select', 'rows', 'Rows', options=_opts(
            ('none', 'None'), ('rows', 'Between rows'), ('grid', 'Full grid'), ('gaps', 'Gaps between cells'))),
        F('border_colour', 'Line colour', 'colour', 'auto', 'Rows', auto=True, when={'borders': ['rows', 'grid']}),
        F('gap', 'Gap', 'range', 3, 'Rows', min=0.5, max=6, step=0.5, unit='pt', when={'borders': ['gaps']}),
        F('first_col', 'First column', 'select', 'plain', 'Rows', options=_opts(
            ('plain', 'Regular'), ('bold', 'Bold'), ('fill', 'Filled'))),
        F('first_colour', 'First column fill', 'colour', 'accent1@15', 'Rows', when={'first_col': ['fill']}),
        F('total', 'Total row', 'select', 'rule', 'Rows', options=_opts(
            ('rule', 'Bold with a rule'), ('plain', 'Bold, no rule'), ('fill', 'Filled'))),
        F('total_colour', 'Total row fill', 'colour', 'bg2', 'Rows', when={'total': ['fill']}),
        F('text_colour', 'Body text', 'colour', 'auto', 'Text', auto=True),
        F('font_size', 'Text size', 'range', 0, 'Text', min=0, max=24, step=1, unit='pt', zero='Keep'),
        F('padding', 'Cell padding', 'select', 'normal', 'Text', options=PADDING),
        F('numbers_right', 'Right-align numbers', 'toggle', True, 'Text'),
    ],
    'chart': [
        F('palette', 'Series colours', 'palette', [], 'Colours', help='Empty = the deck palette'),
        F('fill', 'Fill', 'select', 'solid', 'Colours', options=_opts(
            ('solid', 'Solid'), ('gradient', 'Gradient'), ('fade', 'Fade to transparent'), ('outline', 'Tint + outline'),
            ('pastel', 'Pastel'), ('highlight', 'Highlight first, rest grey'), ('mono', 'Shades of one colour'))),
        F('gap', 'Gap between bars', 'range', 60, 'Bars & lines', min=0, max=300, step=10, unit='%'),
        F('overlap', 'Bar overlap', 'range', -8, 'Bars & lines', min=-100, max=100, step=4, unit='%'),
        F('width', 'Line width', 'range', 2.5, 'Bars & lines', min=0.5, max=6, step=0.25, unit='pt'),
        F('smooth', 'Smooth lines', 'toggle', False, 'Bars & lines'),
        F('markers', 'Line markers', 'select', 'none', 'Bars & lines', options=_opts(
            ('none', 'None'), ('dot', 'Dots'), ('ring', 'Rings'))),
        F('grid', 'Gridlines', 'select', 'dash', 'Axes & labels', options=_opts(
            ('none', 'None'), ('dash', 'Dashed'), ('solid', 'Solid'))),
        F('axis', 'Show the value axis', 'toggle', True, 'Axes & labels'),
        F('labels', 'Data labels', 'select', 'none', 'Axes & labels', options=_opts(
            ('none', 'None'), ('out', 'Outside / above'), ('in', 'Inside'))),
        F('font_size', 'Axis & legend text', 'range', 10.5, 'Axes & labels', min=7, max=16, step=0.5, unit='pt'),
        F('legend', 'Legend', 'select', 'chips', 'Axes & labels', options=_opts(
            ('chips', 'Dot chips (in a container)'), ('top', 'Top'), ('bottom', 'Bottom'), ('right', 'Right'),
            ('none', 'None'))),
        F('ring', 'Pies become doughnuts', 'toggle', False, 'Pie & doughnut'),
        F('hole', 'Doughnut hole', 'range', 62, 'Pie & doughnut', min=30, max=90, step=2, unit='%'),
        F('centre', 'Lead share in the centre', 'toggle', True, 'Pie & doughnut'),
    ],
    'card': [
        F('surface', 'Card', 'select', 'card', 'Card', options=_opts(
            ('card', 'White card'), ('float', 'Floating white card'), ('outline', 'Outlined'), ('soft', 'Grey surface'),
            ('tint', 'Tinted'), ('solid', 'Solid colour'), ('gradient', 'Gradient'), ('tile', 'Gradient tile'),
            ('hero', 'Solid tile'), ('none', 'No card'))),
        F('surface_colour', 'Card colour', 'colour', 'auto', 'Card', auto=True,
          help='Automatic = from the card colours below'),
        F('gradient_to', 'Gradient to', 'colour', 'auto', 'Card', auto=True, when={'surface': ['gradient', 'tile']}),
        F('radius', 'Corner radius', 'range', 0.14, 'Card', min=0, max=0.5, step=0.02, unit='in'),
        F('shadow', 'Shadow', 'select', 'auto', 'Card', options=_opts(('auto', 'Design default'), *[
            (o['id'], o['name']) for o in SHADOWS])),
        F('border', 'Edge', 'select', 'auto', 'Card', options=_opts(
            ('auto', 'Design default'), ('none', 'None'), ('hairline', 'Hairline'), ('colour', 'Coloured'))),
        F('border_colour', 'Edge colour', 'colour', 'auto', 'Card', auto=True, when={'border': ['hairline', 'colour']}),
        F('strip', 'Cards in a row share one container', 'toggle', False, 'Card'),
        F('deco', 'Accent line', 'select', 'none', 'Card', options=_opts(
            ('none', 'None'), ('top', 'Along the top'), ('left', 'Down the left'))),
        F('layout', 'Layout', 'select', 'stack', 'Layout & icon', options=_opts(
            ('stack', 'Icon above the figure'), ('side', 'Icon on the left'), ('header', 'Icon + title header'),
            ('corner', 'Icon top-right'), ('center', 'Centred'), ('tile', 'Centred figure, no icon'),
            ('hero', 'Big figure, icon on the right'), ('plain', 'Figure only'))),
        F('chip', 'Icon style', 'select', 'solid', 'Layout & icon', options=_opts(
            ('solid', 'Solid chip'), ('circle', 'Round badge'), ('soft', 'Soft chip'), ('ring', 'Outlined chip'),
            ('white', 'White chip'), ('bare', 'Icon only'), ('none', 'No icon'))),
        F('colours', 'Card colours', 'palette', [], 'Colours',
          help='Used in turn by each card. Empty = the deck accents'),
        F('value', 'Figure colour', 'select', 'ink', 'Colours', options=_opts(('ink', 'Dark ink'),
                                                                                ('accent', 'Card colour'))),
        F('weight', 'Figure weight', 'select', 'bold', 'Type', options=_opts(('bold', 'Bold'), ('light', 'Light'))),
        F('value_size', 'Figure size', 'range', 0, 'Type', min=0, max=72, step=1, unit='pt', zero='Fit the card'),
        F('label_size', 'Label size', 'range', 0, 'Type', min=0, max=24, step=1, unit='pt', zero='Automatic'),
    ],
    'flow': [
        F('shape', 'Step shape', 'select', 'pill', 'Steps', options=_opts(
            ('pill', 'Pill'), ('rounded', 'Rounded box'), ('rect', 'Square box'), ('keep', 'Keep shapes'))),
        F('fill', 'Step fill', 'select', 'tint', 'Steps', options=_opts(
            ('tint', 'Tinted'), ('solid', 'Solid colour'), ('white', 'White'), ('grey', 'Grey'),
            ('gradient', 'Gradient'), ('outline', 'Outline only'))),
        F('colours', 'Step colours', 'palette', [], 'Steps', help='Empty = the brand colour'),
        F('rainbow', 'A different colour per step', 'toggle', False, 'Steps'),
        F('border', 'Edge', 'select', 'none', 'Steps', options=_opts(
            ('none', 'None'), ('hairline', 'Hairline'), ('colour', 'Step colour'))),
        F('shadow', 'Soft shadow', 'toggle', False, 'Steps'),
        F('text', 'Text colour', 'select', 'auto', 'Steps', options=_opts(
            ('auto', 'Automatic'), ('dark', 'Dark'), ('light', 'White'), ('accent', 'Step colour'))),
        F('decision', 'Decisions', 'select', 'next', 'Step types', options=_opts(
            ('next', 'Next accent, same fill'), ('same', 'Same as steps'), ('solid', 'Solid colour'))),
        F('decision_colour', 'Decision colour', 'colour', 'auto', 'Step types', auto=True),
        F('terminal', 'Start / end', 'select', 'same', 'Step types', options=_opts(
            ('same', 'Same as steps'), ('solid', 'Solid pills'))),
        F('terminal_colour', 'Start / end colour', 'colour', 'accent1', 'Step types', when={'terminal': ['solid']}),
        F('connector', 'Arrow colour', 'colour', 'auto', 'Arrows', auto=True),
        F('connector_width', 'Arrow width', 'range', 1.5, 'Arrows', min=0.5, max=4, step=0.25, unit='pt'),
        F('dash', 'Arrow line', 'select', 'solid', 'Arrows', options=_opts(
            ('solid', 'Solid'), ('dash', 'Dashed'), ('dot', 'Dotted'))),
        F('arrow', 'Arrow head', 'select', 'sm', 'Arrows', options=_opts(('sm', 'Small'), ('med', 'Medium'),
                                                                          ('lg', 'Large'))),
    ],
    'shape': [
        F('fill', 'Fill', 'select', 'tint', 'Shape', options=_opts(
            ('tint', 'Tinted'), ('solid', 'Solid colour'), ('gradient', 'Gradient'), ('white', 'White'),
            ('grey', 'Grey'), ('none', 'None'))),
        F('colours', 'Colours', 'palette', [], 'Shape', help='Used in turn by each shape. Empty = the deck accents'),
        F('border', 'Edge', 'select', 'none', 'Shape', options=_opts(
            ('none', 'None'), ('hairline', 'Hairline'), ('colour', 'Shape colour'))),
        F('border_width', 'Edge width', 'range', 1, 'Shape', min=0.25, max=6, step=0.25, unit='pt',
          when={'border': ['hairline', 'colour']}),
        F('radius', 'Corner radius', 'range', 0.12, 'Shape', min=0, max=0.6, step=0.02, unit='in'),
        F('shadow', 'Shadow', 'select', 'none', 'Shape', options=SHADOWS),
        F('text', 'Text colour', 'select', 'auto', 'Shape', options=_opts(
            ('auto', 'Automatic'), ('dark', 'Dark'), ('light', 'White'), ('accent', 'Shape colour'))),
    ],
    'picture': [
        F('shape', 'Shape', 'select', 'rounded', 'Picture', options=_opts(
            ('rounded', 'Rounded'), ('circle', 'Circle'), ('arch', 'Arch'), ('rect', 'Square'))),
        F('radius', 'Corner radius', 'range', 0.16, 'Picture', min=0, max=1, step=0.02, unit='in',
          when={'shape': ['rounded']}),
        F('border_width', 'Border', 'range', 0, 'Picture', min=0, max=8, step=0.5, unit='pt'),
        F('border_colour', 'Border colour', 'colour', 'bg1', 'Picture', when={'border_width': '>0'}),
        F('shadow', 'Shadow', 'select', 'none', 'Picture', options=_opts(
            ('none', 'None'), ('soft', 'Soft'), ('glow', 'Colour glow'))),
        F('effect', 'Photo effect', 'select', 'none', 'Picture', options=_opts(
            ('none', 'None'), ('grayscale', 'Black & white'), ('duotone', 'Duotone'))),
        F('colour', 'Glow / duotone colour', 'colour', 'accent1', 'Picture'),
    ],
    'title': [
        F('colour', 'Colour', 'colour', 'auto', 'Type', auto=True),
        F('size', 'Size', 'range', 0, 'Type', min=0, max=60, step=1, unit='pt', zero='Keep'),
        F('weight', 'Weight', 'select', 'bold', 'Type', options=_opts(('bold', 'Bold'), ('regular', 'Regular'))),
        F('caps', 'Capitals', 'toggle', False, 'Type'),
        F('tracking', 'Letter spacing', 'range', -30, 'Type', min=-100, max=200, step=10),
        F('font', 'Font', 'select', 'heading', 'Type', options=_opts(('heading', 'Heading font'), ('body', 'Body font'))),
        F('align', 'Alignment', 'select', 'left', 'Layout', options=_opts(
            ('left', 'Left'), ('center', 'Centre'), ('keep', 'Keep'))),
        F('decoration', 'Decoration', 'select', 'none', 'Layout', options=_opts(
            ('none', 'None'), ('bar', 'Short bar beneath'), ('side', 'Bar beside'), ('dot', 'Dot before'),
            ('underline', 'Full-width rule'))),
        F('deco_colour', 'Decoration colour', 'colour', 'accent1', 'Layout',
          when={'decoration': ['bar', 'side', 'dot', 'underline']}),
    ],
    'text': [
        F('bullet', 'Bullets', 'select', 'keep', 'Bullets', options=_opts(
            ('keep', 'Keep'), ('dot', 'Dots'), ('check', 'Check marks'), ('arrow', 'Arrows'), ('dash', 'Dashes'),
            ('number', 'Numbers'), ('none', 'No bullets'))),
        F('bullet_colour', 'Bullet colour', 'colour', 'accent1', 'Bullets'),
        F('colour', 'Text colour', 'colour', 'auto', 'Text', auto=True),
        F('size', 'Size', 'range', 0, 'Text', min=0, max=32, step=1, unit='pt', zero='Keep'),
        F('line_spacing', 'Line spacing', 'range', 100, 'Text', min=80, max=200, step=5, unit='%'),
        F('space_after', 'Space after paragraphs', 'range', 6, 'Text', min=0, max=24, step=1, unit='pt'),
        F('first_bold', 'Bold first line', 'toggle', False, 'Text'),
    ],
    'background': [
        F('type', 'Background', 'select', 'solid', 'Page', options=_opts(
            ('solid', 'Solid colour'), ('linear', 'Two-colour gradient'), ('glow', 'Glow from the top-right'),
            ('corner', 'Glow from the bottom-left'), ('spotlight', 'Glow from the centre'),
            ('band', 'Band along the top'))),
        F('colour', 'Page colour', 'colour', 'bg1', 'Page'),
        F('colour2', 'Second colour', 'colour', 'accent1@12', 'Page', when={'type': ['linear', 'glow', 'corner',
                                                                                    'spotlight', 'band']}),
        F('angle', 'Gradient angle', 'range', 90, 'Page', min=0, max=345, step=15, unit='°', when={'type': ['linear']}),
    ],
}

# built-in starting points: the settings that reproduce (or come close to) each built-in design
BASE_PARAMS = {
    'heatmap': {
        'heat-mono': {}, 'heat-tiles': dict(gap=3, bold=True),
        'heat-duo': dict(ramp=['accent2@18', 'accent2', 'accent1', 'accent1@-30']),
        'heat-ocean': dict(ramp=R.HEAT_FIXED['heat-ocean']), 'heat-sunset': dict(ramp=R.HEAT_FIXED['heat-sunset']),
        'heat-violet': dict(ramp=R.HEAT_FIXED['heat-violet']), 'heat-mint': dict(ramp=R.HEAT_FIXED['heat-mint']),
        'heat-viridis': dict(ramp=R.HEAT_FIXED['heat-viridis']),
        'heat-traffic': dict(ramp=R.HEAT_FIXED['heat-traffic'], text='dark'),
        'heat-diverge': dict(ramp=R.HEAT_FIXED['heat-diverge'], diverge=True, text='dark'),
        'heat-rows': dict(scale='rows'), 'heat-cols': dict(scale='columns'),
        'heat-text': dict(mode='text', gap=0), 'heat-top': dict(mode='top', gap=0),
    },
    'table': {
        'clean': dict(header_colour='tx1@75'), 'soft': dict(header='fill', header_colour='bg2'),
        'striped': dict(header_text='accent1@-40', banding='rows', borders='none'),
        'accent': dict(header='fill', total='fill', total_colour='accent1@15'),
        'ink': dict(header='fill', header_colour='tx1'), 'minimal': dict(borders='none', padding='airy',
                                                                        header_colour='tx1@75'),
        'grid': dict(header='fill', header_colour='bg2', borders='grid'),
        'rows': dict(header='plain', banding='all', borders='gaps', gap=3),
        'columns': dict(banding='columns', borders='none'),
        'ledger': dict(first_col='fill', header_text='accent1@-40'),
        'compact': dict(padding='compact', font_size=10, header_colour='tx1@75'),
        'blocks': dict(header='fill', header_colour='tx1@80', first_col='fill', first_colour='tx1@80',
                       banding='all', borders='gaps', gap=3, total='plain'),
    },
    'chart': {
        'clean': {}, 'highlight': dict(fill='highlight', gap=55),
        'bold': dict(grid='none', axis=False, labels='in', gap=35, width=3.5, markers='ring'),
        'labels': dict(grid='none', axis=False, labels='out', gap=55, markers='dot'),
        'smooth': dict(smooth=True, width=2.75, markers='ring'), 'mono': dict(fill='mono', gap=50),
        'duo': dict(fill='highlight', gap=50), 'pastel': dict(fill='pastel', gap=50, labels='out'),
        'gradient': dict(fill='gradient', gap=45), 'fade': dict(fill='fade', gap=70, grid='none', smooth=True),
        'outline': dict(fill='outline', gap=50, markers='ring'),
        'slim': dict(gap=200, width=1.5, markers='dot', ring=True, hole=80),
        'blueprint': dict(width=1.75, gap=80, markers='dot'), 'ring': dict(ring=True, hole=75),
    },
    'flow': {
        'pill': {}, 'chip': dict(shape='rounded', fill='white', border='hairline', shadow=True),
        'solid': dict(shape='rounded', fill='solid'), 'outline': dict(shape='rounded', fill='outline', border='colour'),
        'tint': dict(shape='rounded'), 'neutral': dict(shape='rounded', fill='grey'),
        'rainbow': dict(rainbow=True), 'gradient': dict(shape='rounded', fill='gradient'),
        'dashed': dict(shape='rounded', fill='white', border='hairline', shadow=True, dash='dash'),
        'bold-arrows': dict(connector='accent1', connector_width=2.5, arrow='med'),
        'typed': dict(shape='rect', colours=['accent3'], border='colour', text='dark', decision='solid',
                      decision_colour='accent5', terminal='solid', terminal_colour='accent1', connector='tx1@75',
                      connector_width=1.25),
    },
    'shape': {
        'soft': {}, 'solid': dict(fill='solid'), 'gradient': dict(fill='gradient'), 'soft-gradient': {},
        'outline': dict(fill='none', border='colour', border_width=1.25), 'tint-outline': dict(border='colour', border_width=0.75),
        'muted': dict(fill='grey', text='dark'), 'floating': dict(fill='white', shadow='float', text='dark'),
    },
    'picture': {
        'rounded': {}, 'soft-round': dict(radius=0.36), 'shadow': dict(shadow='soft'), 'glow': dict(shadow='glow'),
        'frame': dict(radius=0.05, border_width=6, border_colour='bg1', shadow='soft'),
        'outline': dict(border_width=2.25, border_colour='accent1'), 'arch': dict(shape='arch'),
        'circle': dict(shape='circle'), 'mono': dict(effect='grayscale'), 'duotone': dict(effect='duotone'),
        'plain': dict(shape='rect'),
    },
    'title': {
        'modern': {}, 'accent-bar': dict(decoration='bar'), 'side-bar': dict(decoration='side'),
        'dot': dict(decoration='dot'), 'underline': dict(decoration='underline', deco_colour='tx1@20'),
        'accent': dict(colour='accent1'), 'gradient': dict(colour='accent1'),
        'editorial': dict(weight='regular', tracking=-60), 'caps': dict(caps=True, tracking=60),
        'centered': dict(align='keep'),
    },
    'text': {
        'modern': {}, 'airy': dict(line_spacing=120, space_after=10), 'compact': dict(line_spacing=95, space_after=3),
        'check': dict(bullet='check'), 'arrow': dict(bullet='arrow'), 'dash': dict(bullet='dash'),
        'numbered': dict(bullet='number'), 'lead': dict(first_bold=True),
    },
    'background': {
        'canvas': dict(colour='bg2@60'), 'white': {}, 'glow': dict(type='glow'),
        'soft': dict(type='linear', colour2='bg2', angle=90), 'band': dict(type='band', colour2='accent1@14'),
        'mesh': dict(type='linear', colour='accent1@13', colour2='accent2@13', angle=45),
        'aurora': dict(type='linear', colour='accent1@16', colour2='accent3@13', angle=30),
        'spotlight': dict(type='spotlight', colour2='accent1@13'), 'corner': dict(type='corner', colour2='accent2@15'),
        'dots': dict(colour='bg1'), 'grid': dict(colour='bg1'),
    },
}


def _card_base(style):
    spec = R.KPI.get(style, R.KPI['kpi'])
    out = dict(surface=spec['surface'], layout=spec['layout'], chip=spec.get('chip') or 'none',
               value=spec.get('value') or 'ink', weight=spec.get('weight') or 'bold', deco=spec.get('deco') or 'none')
    if out['chip'] in ('glass', 'halo'):
        out['chip'] = 'solid'
    out['radius'] = 0.05 if spec['surface'] == 'hero' else 0.1 if spec['surface'] == 'tile' else 0.14
    out['strip'] = style == 'kpi-strip'
    return out


BASE_PARAMS['card'] = {sid: _card_base(sid) for sid, _, _ in R.STYLES['card']}
DEFAULT_BASE = {'heatmap': 'heat-mono', 'table': 'clean', 'chart': 'clean', 'card': 'kpi', 'flow': 'pill',
                'shape': 'soft', 'picture': 'rounded', 'title': 'modern', 'text': 'modern', 'background': 'white'}


def defaults(kind, base=None):
    """Every setting of `kind`, as the built-in design `base` has it."""
    out = {f['key']: copy.deepcopy(f['default']) for f in FIELDS[kind]}
    out.update(copy.deepcopy(BASE_PARAMS.get(kind, {}).get(base or DEFAULT_BASE[kind], {})))
    return out


def clean(kind, params, base=None):
    """Validated settings: unknown keys dropped, bad values replaced by the base design's."""
    out = defaults(kind, base)
    for f in FIELDS[kind]:
        k, t = f['key'], f['type']
        if k not in (params or {}):
            continue
        v = params[k]
        if t == 'select' and v in [o['id'] for o in f['options']]:
            out[k] = v
        elif t == 'toggle':
            out[k] = bool(v)
        elif t == 'range':
            try:
                out[k] = max(f['min'], min(f['max'], float(v)))
                if float(out[k]).is_integer():
                    out[k] = int(out[k])
            except (TypeError, ValueError):
                pass
        elif t == 'colour' and valid_token(v, f.get('auto', False)):
            out[k] = v if v == 'auto' else v.upper() if re.fullmatch(r'[0-9A-Fa-f]{6}(@-?\d+)?', v) else v
        elif t in ('palette', 'ramp') and isinstance(v, list):
            vals = [x.upper() if re.fullmatch(r'[0-9A-Fa-f]{6}(@-?\d+)?', str(x)) else x for x in v
                    if valid_token(str(x))][:8]
            out[k] = vals if t == 'palette' or len(vals) != 1 else vals + vals
    return out


def schema():
    """For the UI: settings per kind, built-in starting points, ramp presets."""
    return {'fields': FIELDS, 'bases': {k: list(v) for k, v in BASE_PARAMS.items()},
            'defaults': {k: {b: defaults(k, b) for b in BASE_PARAMS[k]} for k in FIELDS},
            'ramps': [{'id': 'brand', 'name': 'Brand', 'stops': []}] + [
                {'id': k[5:], 'name': n, 'stops': R.HEAT_FIXED[k]} for k, n, _ in R.STYLES['heatmap']
                if k in R.HEAT_FIXED],
            'theme_tokens': list(THEME_NAMES)}


# ── store ────────────────────────────────────────────────────────────────────
def store_path():
    return Path(os.environ.get('PPTX_STUDIO_DESIGNS') or ROOT / 'designs' / 'my_designs.json')


def load():
    p = store_path()
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}
    return {d['id']: d for d in data.get('designs', []) if isinstance(d, dict) and d.get('id')}


def _write(designs):
    p = store_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps({'format': FORMAT, 'version': 1, 'designs': list(designs.values())}, indent=1),
                   encoding='utf-8')
    tmp.replace(p)


def _slug(name):
    return re.sub(r'[^a-z0-9]+', '-', (name or 'design').lower()).strip('-')[:32] or 'design'


def normalise(d):
    """A design dict checked and completed (id, kind, base, name, params)."""
    kind = d.get('kind')
    if kind not in FIELDS:
        raise ValueError(f'unknown component kind {kind!r}')
    base = d.get('base') if d.get('base') in BASE_PARAMS[kind] else DEFAULT_BASE[kind]
    did = d.get('id') or ''
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,47}', did):
        did = f'{_slug(d.get("name"))}-{uuid.uuid4().hex[:4]}'
    return {'id': did, 'kind': kind, 'base': base, 'name': (d.get('name') or 'My design').strip()[:60],
            'desc': (d.get('desc') or '').strip()[:160], 'source': d.get('source') or 'builder',
            'sample': d.get('sample') if isinstance(d.get('sample'), dict) else None,
            'params': clean(kind, d.get('params') or {}, base), 'updated': int(time.time())}


def save(d):
    d = normalise(d)
    designs = load()
    designs[d['id']] = d
    _write(designs)
    return d


def delete(did):
    designs = load()
    if designs.pop(did, None) is None:
        return False
    _write(designs)
    return True


def export(ids=None):
    designs = load()
    return {'format': FORMAT, 'version': 1,
            'designs': [d for d in designs.values() if not ids or d['id'] in ids]}


def import_(obj, replace=False):
    """Add the designs of an exported file (same id = updated). Returns the saved designs."""
    items = obj.get('designs') if isinstance(obj, dict) else obj
    if not isinstance(items, list):
        raise ValueError('not a designs file')
    designs = {} if replace else load()
    saved = []
    for d in items:
        try:
            d = normalise(d)
        except (ValueError, TypeError, AttributeError):
            continue
        designs[d['id']] = d
        saved.append(d)
    _write(designs)
    return saved


def resolve(plan):
    """{id: design} for every 'my:<id>' a plan uses: the plan's own copies first, then the store."""
    own = {k: v for k, v in (plan.get('custom') or {}).items() if isinstance(v, dict)}
    wanted = set()
    for v in list((plan.get('kinds') or {}).values()) + list((plan.get('items') or {}).values()):
        s = (v or {}).get('style') or ''
        if s.startswith('my:'):
            wanted.add(s[3:])
    out = {}
    stored = None
    for did in wanted:
        d = own.get(did)
        if d is None:
            stored = load() if stored is None else stored
            d = stored.get(did)
        if d is not None:
            try:
                d = dict(d, id=did)
                d['params'] = clean(d['kind'], d.get('params') or {}, d.get('base'))
                out[did] = d
            except (KeyError, TypeError):
                continue
    return out


# ── rendering ────────────────────────────────────────────────────────────────
PAD = {'compact': (0.08, 0.08, 0.03, 0.03), 'normal': (0.12, 0.12, 0.07, 0.07), 'airy': (0.16, 0.16, 0.11, 0.11)}
NOFILL = '<a:noFill/>'
HEXRX = re.compile(r'[0-9A-Fa-f]{6}')


def colour_arg(token, ctx):
    """A token as a single clr() value: plain theme names stay theme colours, the rest become hex."""
    m = TOKEN_RX.match(token or '')
    if m and m.group(1) and not m.group(3):
        return m.group(1)
    return hexof(token, ctx)


def accent_for(colours, idx, ctx, default=None):
    if colours:
        return colour_arg(colours[idx % len(colours)], ctx)
    return default


def _tint(c, n=15):
    """(value, mods) of a pale version of a clr() value."""
    if HEXRX.fullmatch(c or ''):
        return R._lummod(c, n, 100 - n), {}
    return c, {'lumMod': str(n * 1000), 'lumOff': str((100 - n) * 1000)}


def _deep(c, n=60):
    if HEXRX.fullmatch(c or ''):
        return R._lummod(c, n, 0), {}
    return c, {'lumMod': str(n * 1000)}


def _dark_value(c, ctx):
    h = c if HEXRX.fullmatch(c or '') else hexof(c, ctx)
    return R._lum(R._hex2rgb(h)) < 0.36


def _none(*sides):
    return ''.join(R._border(s) for s in sides)


def _size_runs(tc, pt):
    if not pt:
        return
    for r in R._runs(tc):
        R._rpr(r).set('sz', str(int(pt * 100)))
    for e in tc.iter(f'{{{A}}}endParaRPr'):
        e.set('sz', str(int(pt * 100)))


def heat(el, tbl, P, accent, ctx):
    """A numeric table as a heatmap, entirely from settings."""
    R._reset_tblpr(tbl)
    rows, numeric_col, total_row = R._table_shape(tbl)
    body = [r for r in rows[1:] if r is not total_row]
    grid = [[(R._number(R._cell_text(tc)) if ci < len(numeric_col) and numeric_col[ci] else None)
             for ci, tc in enumerate(kids(r, 'tc'))] for r in body]
    flat = sorted(v for row in grid for v in row if v is not None)
    if not flat:
        return table(el, defaults('table'), accent, ctx)
    col_vals = {}
    for row in grid:
        for ci, v in enumerate(row):
            if v is not None:
                col_vals.setdefault(ci, []).append(v)
    scales = [max(abs(x) for x in vs) for vs in col_vals.values()]
    scales = [s for s in scales if s > 0]
    mixed = len(scales) > 1 and max(scales) / min(scales) > 8
    scale = P['scale'] if P['scale'] != 'auto' else ('columns' if mixed else 'table')

    def values(ri, ci):
        if scale == 'rows':
            return [x for x in grid[ri] if x is not None]
        if scale == 'columns':
            return col_vals.get(ci) or flat
        return flat

    def norm(v, ri, ci):
        vals = values(ri, ci)
        lo, hi = min(vals), max(vals)
        if P['diverge']:
            s = sorted(vals)
            m = s[len(s) // 2]
            span = max(abs(hi - m), abs(m - lo)) or 1
            return 0.5 + (v - m) / span / 2
        return (v - lo) / (hi - lo) if hi > lo else 0.5

    ramp = [hexof(t, ctx) for t in P['ramp']] if P['ramp'] else None
    acc_hex = accent if HEXRX.fullmatch(accent or '') else hexof(accent, ctx)

    def at(t):
        """(clr value, mods, hex) at position t of the ramp."""
        if ramp:
            h = R._mix(ramp, t)
            return h, {}, h
        mod, off = R._theme_ramp(t)
        mods = {'lumMod': str(mod * 1000)}
        if off:
            mods['lumOff'] = str(off * 1000)
        return accent, mods, R._lummod(acc_hex, mod, off)

    def cut(ci):
        vals = sorted(col_vals.get(ci) or flat) if scale == 'columns' else flat
        n = int(P['top_n'])
        return vals[-min(n, len(vals))]

    gap_w = int(float(P['gap']) * 12700)
    gv, gm = tok(P['gap_colour'])
    gaps = ''.join(R._border(s, gap_w, gv, **gm) for s in 'LRTB') if gap_w else _none('L', 'R', 'T', 'B')
    pad = PAD.get(P['padding'], PAD['normal'])
    rule = ('tx1', {'lumMod': '75000', 'lumOff': '25000'})
    hair = R._border('B', 6350, ctx.hair[0], **ctx.hair[1])
    mode = P['mode']
    for ri, tr in enumerate(rows):
        for ci, tc in enumerate(kids(tr, 'tc')):
            numeric = ci < len(numeric_col) and numeric_col[ci]
            align = P['align'] if numeric else None
            if ri == 0:
                if P['header'] == 'fill':
                    R._cell(tc, gaps, fill_xml(P['header_colour']), on(P['header_colour'], ctx), True, pad, align)
                else:
                    b = _none('L', 'R', 'T') + (R._border('B', 12700, rule[0], **rule[1]) if P['header'] == 'rule'
                                                else R._border('B'))
                    R._cell(tc, b, NOFILL, ctx.ink2, True, pad, align)
            elif tr is total_row:
                if P['total'] == 'fill':
                    R._cell(tc, gaps, fill_xml(P['total_colour']), on(P['total_colour'], ctx), True, pad, align)
                else:
                    b = _none('L', 'R') + (R._border('T', 12700, rule[0], **rule[1]) if P['total'] == 'rule'
                                           else R._border('T')) + _none('B')  # schema order: L R T B
                    R._cell(tc, b, NOFILL, ctx.ink, True, pad, align)
            else:
                bi = body.index(tr)
                v = grid[bi][ci] if ci < len(grid[bi]) else None
                if v is None:  # a label cell
                    if ci == 0 and P['first_col'] == 'fill':
                        R._cell(tc, gaps, fill_xml(P['first_colour']), on(P['first_colour'], ctx), True, pad, align)
                    else:
                        b = gaps if mode == 'fill' else _none('L', 'R', 'T') + hair
                        R._cell(tc, b, NOFILL, ctx.ink, (P['first_col'] == 'bold') if ci == 0 else None, pad, align)
                else:
                    t = norm(v, bi, ci)
                    if mode == 'fill':
                        cv, cm, h = at(t)
                        if P['text'] == 'auto':
                            txt = ('lt1', {}) if R._lum(R._hex2rgb(h)) < 0.33 else ('tx1', {})
                        else:
                            txt = ('lt1', {}) if P['text'] == 'light' else ('tx1', {})
                        R._cell(tc, gaps, solid(cv, **cm), txt, True if P['bold'] else None, pad, align)
                    elif mode == 'text':
                        cv, cm, _ = at(0.35 + 0.65 * t)  # the palest end of a ramp is unreadable as text
                        R._cell(tc, _none('L', 'R', 'T') + hair, NOFILL, (cv, cm), True if (P['bold'] or t >= 0.75)
                                else None, pad, align)
                    else:  # top values
                        hit = v >= cut(ci)
                        pv, pm, _ = at(0.0) if ramp else (accent, ctx.tint(accent), '')
                        dv, dm, _ = at(1.0) if ramp else (accent, ctx.on_tint(accent), '')
                        R._cell(tc, _none('L', 'R', 'T') + hair, solid(pv, **pm) if hit else NOFILL,
                                (dv, dm) if hit else ('tx1', {'lumMod': '85000', 'lumOff': '15000'}),
                                True if (hit or P['bold']) else None, pad, align)
            _size_runs(tc, P['font_size'])
    return True


def table(el, P, accent, ctx):
    """A table entirely from settings."""
    tbl = el.find(f'.//{{{A}}}tbl')
    if tbl is None:
        return False
    R._reset_tblpr(tbl)
    rows, numeric_col, total_row = R._table_shape(tbl)
    pad = PAD.get(P['padding'], PAD['normal'])
    on_grey = getattr(ctx, 'on_grey', False)
    line = ctx.hair if P['border_colour'] == 'auto' else tok(P['border_colour'])
    gline = ctx.line if P['border_colour'] == 'auto' else line
    gap_w = int(float(P['gap']) * 12700)
    gap_c = 'bg2' if on_grey else 'bg1'
    body_txt = ctx.body if P['text_colour'] == 'auto' else tok(P['text_colour'])
    hc = P['header_colour']
    head_txt = tok(P['header_text']) if P['header_text'] != 'auto' else \
        (on(hc, ctx) if P['header'] == 'fill' else ctx.ink2)
    rule = tok(hc)
    total_rule = ('tx1', {'lumMod': '75000', 'lumOff': '25000'})
    last = rows[-1] if rows else None
    for ri, tr in enumerate(rows):
        head, is_total = ri == 0, tr is total_row
        for ci, tc in enumerate(kids(tr, 'tc')):
            numeric = ci < len(numeric_col) and numeric_col[ci]
            fill, txt, bold = NOFILL, body_txt, None
            if P['borders'] == 'gaps':
                sides = {s: R._border(s, gap_w, gap_c) for s in 'LRTB'}
            elif P['borders'] == 'grid':
                sides = {s: R._border(s, 6350, gline[0], **gline[1]) for s in 'LRTB'}
            elif P['borders'] == 'rows':
                sides = {'L': R._border('L'), 'R': R._border('R'), 'T': R._border('T'),
                         'B': R._border('B', 6350, line[0], **line[1]) if tr is not last else R._border('B')}
            else:
                sides = {s: R._border(s) for s in 'LRTB'}
            if not head and not is_total:
                band = P['banding']
                if band == 'all' or (band == 'rows' and (ri - 1) % 2 == 1) or (band == 'columns' and ci % 2 == 1):
                    fill = fill_xml(P['band_colour'])
                elif band in ('rows', 'columns') and P['row_colour'] != 'auto':
                    fill = fill_xml(P['row_colour'])
                    if band == 'all' and P['borders'] != 'gaps':
                        sides['T'] = R._border('T', 38100, gap_c)
                        sides['B'] = R._border('B', 38100, gap_c)
                if ci == 0 and P['first_col'] == 'fill':
                    fill, bold = fill_xml(P['first_colour']), True
                    txt = on(P['first_colour'], ctx) if P['text_colour'] == 'auto' else txt
                elif ci == 0 and P['first_col'] == 'bold':
                    bold = True
                    txt = ctx.ink if P['text_colour'] == 'auto' else txt
            if head:
                bold, txt = True, head_txt
                if P['header'] == 'fill':
                    fill = fill_xml(hc)
                elif P['header'] == 'rule':
                    sides['B'] = R._border('B', 15875, rule[0], **rule[1])
                elif P['borders'] not in ('gaps', 'grid'):
                    sides['B'] = R._border('B')
            if is_total:
                bold = True
                if P['total'] == 'fill':
                    fill = fill_xml(P['total_colour'])
                    txt = on(P['total_colour'], ctx) if P['text_colour'] == 'auto' else txt
                elif P['total'] == 'rule':
                    sides['T'] = R._border('T', 12700, total_rule[0], **total_rule[1])
            R._cell(tc, sides['L'] + sides['R'] + sides['T'] + sides['B'], fill, txt, bold, pad,
                    'r' if numeric and P['numbers_right'] else None)
            _size_runs(tc, P['font_size'])
    return True


def chart_recipe(P, ctx):
    """Chart settings as overrides of the chart engine's recipe, plus the series palette."""
    over = dict(colors={'solid': 'accents'}.get(P['fill'], P['fill']), gap=int(P['gap']),
                width=int(float(P['width']) * 12700), smooth=bool(P['smooth']), markers=P['markers'],
                grid={'none': None, 'dash': 'soft-dash', 'solid': 'solid'}[P['grid']], axis=bool(P['axis']),
                labels=None if P['labels'] == 'none' else P['labels'], ring=bool(P['ring']), hole=int(P['hole']),
                overlap=int(P['overlap']), font=int(float(P['font_size']) * 100),
                legend_pos={'top': 't', 'bottom': 'b', 'right': 'r'}.get(P['legend']))
    palette = [colour_arg(t, ctx) for t in P['palette']] or None
    if palette and len(palette) < 6:  # more series than colours: lighter, then deeper versions of the same
        hexes = [hexof(t, ctx) for t in P['palette']]
        palette += [R._lummod(h, 55, 45) for h in hexes] + [R._lummod(h, 65, 0) for h in hexes]
    return over, palette


def _card_fill(sppr, P, accent, surface, box, ctx):
    """Card settings applied on top of the design's surface."""
    if surface != 'none':
        r = float(P['radius']) * EMU_IN
        if r <= 0:
            R._geom(sppr, 'rect')
        elif box:
            adj = max(0, min(50000, int(r / max(1, min(box[2], box[3])) * 100000)))
            put(sppr, X(f'<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val {adj}"/></a:avLst>'
                        f'</a:prstGeom>'), replace={'prstGeom', 'custGeom'})
    sc = P['surface_colour']
    if surface in ('gradient', 'tile') and (sc != 'auto' or P['gradient_to'] != 'auto' or HEXRX.fullmatch(accent)):
        a = colour_arg(sc, ctx) if sc != 'auto' else accent
        b = colour_arg(P['gradient_to'], ctx) if P['gradient_to'] != 'auto' else \
            (R._lummod(a, 72, 0) if HEXRX.fullmatch(a) else R._next_accent(a))
        put(sppr, X(R._grad(a, b)))
    elif sc != 'auto' and surface != 'none':
        put(sppr, X(fill_xml(sc)))
    if P['shadow'] != 'auto':
        if P['shadow'] == 'none':
            put(sppr, X('<a:effectLst/>'), replace={'effectLst', 'effectDag'})
        elif P['shadow'] == 'soft':
            put(sppr, X(R.shadow(**R.SOFT_SHADOW)), replace={'effectLst', 'effectDag'})
        else:
            put(sppr, X(R.shadow(alpha=12000, blur=508000, dist=101600)), replace={'effectLst', 'effectDag'})
    if P['border'] != 'auto':
        bc = P['border_colour']
        if P['border'] == 'none':
            put(sppr, R._no_line())
        elif P['border'] == 'hairline':
            v, m = tok(bc) if bc != 'auto' else ctx.line
            put(sppr, R._line(9525, v, **m))
        else:
            v, m = tok(bc) if bc != 'auto' else (accent, {})
            put(sppr, R._line(15875, v, **m))


def card_on_colour(P, surface, ctx):
    if P['surface_colour'] != 'auto' and surface not in ('none', 'gradient', 'tile'):
        return is_dark(P['surface_colour'], ctx)
    return None


def _connector(el, P, ctx):
    sppr = kid(el, 'spPr')
    col = tok(P['connector']) if P['connector'] != 'auto' else ('tx1', {'lumMod': '40000', 'lumOff': '60000'})
    w, size = int(float(P['connector_width']) * 12700), P['arrow']
    old = kid(sppr, 'ln')
    ends = ''
    for end in ('headEnd', 'tailEnd'):  # the arrow directions stay exactly as drawn
        e = kid(old, end) if old is not None else None
        if e is not None and e.get('type', 'none') != 'none':
            ends += f'<a:{end} type="triangle" w="{size}" len="{size}"/>'
    dash = {'dash': '<a:prstDash val="sysDash"/>', 'dot': '<a:prstDash val="sysDot"/>'}.get(P['dash'], '')
    put(sppr, X(f'<a:ln w="{w}" cap="rnd">{solid(col[0], **col[1])}{dash}<a:round/>{ends}</a:ln>'))
    return True


def _paint_node(el, sppr, P, colour, mode, ctx, shape_kind='box'):
    """Fill/edge/text of a flowchart step or a shape in one of the fill modes."""
    if mode == 'tint':
        tv, tm = _tint(colour)
        fill, txt = solid(tv, **tm), _deep(colour)
    elif mode == 'solid':
        fill, txt = solid(colour), ('lt1', {}) if _dark_value(colour, ctx) else ('tx1', {})
    elif mode == 'gradient':
        b = R._lummod(colour, 72, 0) if HEXRX.fullmatch(colour) else R._next_accent(colour)
        fill, txt = R._grad(colour, b), ('lt1', {})
    elif mode == 'white':
        fill, txt = solid('bg1'), R.T1
    elif mode == 'grey':
        fill, txt = solid('bg2'), R.T1
    else:  # outline / none
        fill, txt = NOFILL, (_deep(colour, 75) if mode == 'outline' else R.T1)
    put(sppr, X(fill))
    edge = P.get('border', 'none')
    width = int(float(P.get('border_width', 1)) * 12700) if 'border_width' in P else None
    if edge == 'hairline':
        put(sppr, R._line(width or 9525, ctx.line[0], **ctx.line[1]))
    elif edge == 'colour' or (mode == 'outline' and edge == 'none'):
        put(sppr, R._line(width or 15875, colour))
    else:
        put(sppr, R._no_line())
    sh = P.get('shadow')
    if sh is True or sh == 'soft':
        put(sppr, X(R.shadow(alpha=9000, blur=254000, dist=38100)), replace={'effectLst', 'effectDag'})
    elif sh == 'float':
        put(sppr, X(R.shadow(alpha=14000, blur=457200, dist=76200)), replace={'effectLst', 'effectDag'})
    t = P.get('text', 'auto')
    if t == 'dark':
        txt = R.T1
    elif t == 'light':
        txt = ('lt1', {})
    elif t == 'accent':
        txt = _deep(colour, 75) if mode in ('tint', 'white', 'grey', 'outline', 'none') else ('lt1', {})
    return txt


def flow(el, P, accent, ctx, idx=0):
    sppr = kid(el, 'spPr')
    if sppr is None:
        return False
    R._clean_sppr(sppr)
    if ln_(el) == 'cxnSp':
        return _connector(el, P, ctx)
    geom = kid(sppr, 'prstGeom')
    prst = geom.get('prst') if geom is not None else ''
    decision = prst in ('flowChartDecision', 'diamond')
    gd = kid(kid(geom, 'avLst'), 'gd') if geom is not None and kid(geom, 'avLst') is not None else None
    terminal = prst in ('flowChartTerminator', 'ellipse', 'flowChartConnector') or (
        prst == 'roundRect' and gd is not None and 'val 5' in (gd.get('fmla') or ''))
    if P['rainbow']:
        colour = accent_for(P['colours'], idx, ctx) or R.ACCENTS[idx % 6]
    else:
        colour = accent_for(P['colours'], 0, ctx) or accent
    mode = P['fill']
    if decision:
        if P['decision_colour'] != 'auto':
            colour = colour_arg(P['decision_colour'], ctx)
        elif P['decision'] == 'next' and not P['rainbow']:
            colour = R._next_accent(colour) if colour in R.ACCENTS else R._lummod(colour, 70, 0) \
                if HEXRX.fullmatch(colour) else colour
        if P['decision'] == 'solid':
            mode = 'solid'
    elif terminal and P['terminal'] == 'solid':
        mode, colour = 'solid', colour_arg(P['terminal_colour'], ctx)
        R._round(sppr, pill=True)
    if not decision and prst in R.PILL_FLOW and not (terminal and P['terminal'] == 'solid'):
        if P['shape'] == 'pill':
            R._round(sppr, pill=True)
        elif P['shape'] == 'rounded':
            R._round(sppr, radius=int(0.1 * EMU_IN))
        elif P['shape'] == 'rect':
            R._geom(sppr, 'rect')
    q = dict(P)
    if decision and P['decision'] == 'solid':
        q['border'] = 'none'
    txt = _paint_node(el, sppr, q, colour, mode, ctx)
    R._paint_text(el, txt, txt, headline_font=False, align='ctr')
    if decision:
        R._fit_diamond(el)
    return True


def shape(el, P, accent, ctx, idx=0):
    sppr = kid(el, 'spPr')
    if sppr is None:
        return False
    R._clean_sppr(sppr)
    colour = accent_for(P['colours'], idx, ctx) or accent
    geom = kid(sppr, 'prstGeom')
    if geom is not None and geom.get('prst') in R.RECTLIKE:
        r = float(P['radius']) * EMU_IN
        if r <= 0:
            R._geom(sppr, 'rect')
        else:
            R._round(sppr, radius=int(r))
    txt = _paint_node(el, sppr, P, colour, P['fill'], ctx)
    R._paint_text(el, txt, txt if P['text'] != 'auto' or P['fill'] in ('solid', 'gradient') else R.T2,
                  headline_font=False)
    return True


def picture(el, P, accent, ctx):
    sppr = kid(el, 'spPr')
    if sppr is None:
        return False
    if P['shape'] == 'circle':
        R._picture_style(el, 'circle', accent, ctx)
    elif P['shape'] == 'arch':
        R._picture_style(el, 'arch', accent, ctx)
    else:
        R._picture_style(el, 'plain', accent, ctx)
        if P['shape'] == 'rounded' and float(P['radius']) > 0:
            R._round(sppr, int(float(P['radius']) * EMU_IN))
    if float(P['border_width']) > 0:
        put(sppr, X(f'<a:ln w="{int(float(P["border_width"]) * 12700)}">{fill_xml(P["border_colour"])}</a:ln>'))
    if P['shadow'] == 'soft':
        put(sppr, X(R.shadow(alpha=16000, blur=304800, dist=63500)), replace={'effectLst', 'effectDag'})
    elif P['shadow'] == 'glow':
        put(sppr, X(f'<a:effectLst><a:outerShdw blurRad="508000" dist="88900" dir="5400000" algn="t" '
                    f'rotWithShape="0">{clr_xml(P["colour"], alpha="38000")}</a:outerShdw></a:effectLst>'),
            replace={'effectLst', 'effectDag'})
    c = colour_arg(P['colour'], ctx)
    if P['effect'] == 'grayscale':
        R._blip_effect(el, '<a:grayscl/>')
    elif P['effect'] == 'duotone':
        d1, m1 = _deep(c, 35)
        d2, m2 = _tint(c, 20)
        R._blip_effect(el, f'<a:duotone>{clr(d1, **m1)}{clr(d2, **m2)}</a:duotone>')
    return True


DECO = {'none': 'modern', 'bar': 'accent-bar', 'side': 'side-bar', 'dot': 'dot', 'underline': 'underline'}


def title(slide, el, P, accent, ctx):
    tctx = copy.copy(ctx)
    tctx.title_accent = None
    style = DECO[P['decoration']]
    if style == 'modern' and P['align'] in ('keep', 'center'):
        style = 'centered'
    deco = colour_arg(P['deco_colour'], ctx)
    nxt = el.getnext()
    R._title_style(slide, el, style, deco, tctx)
    if P['decoration'] == 'underline':  # the rule takes the decoration colour too
        bar = el.getnext()
        if bar is not None and bar is not nxt and ln_(bar) == 'sp':
            sp = kid(bar, 'spPr')
            put(sp, X(fill_xml(P['deco_colour'])), replace=R.FILLS)
    for r in R._runs(el):
        rpr = R._rpr(r)
        if P['colour'] != 'auto':
            put(rpr, X(fill_xml(P['colour'])), replace=R.FILLS)
        if P['size']:
            rpr.set('sz', str(int(float(P['size']) * 100)))
        rpr.set('b', '1' if P['weight'] == 'bold' else '0')
        if P['caps']:
            rpr.set('cap', 'all')
        else:
            rpr.attrib.pop('cap', None)
        rpr.set('spc', str(int(P['tracking'])))
        R._set_font(rpr, '+mj-lt' if P['font'] == 'heading' else '+mn-lt')
    if P['align'] == 'center':
        for p in el.iter(f'{{{A}}}p'):
            ppr = kid(p, 'pPr')
            if ppr is None:
                ppr = X('<a:pPr/>')
                p.insert(0, ppr)
            ppr.set('algn', 'ctr')
    return True


BULLET_CHARS = {'dot': '•', 'check': '✓', 'arrow': '→', 'dash': '–'}


def text(el, P, ctx):
    base = {'number': 'numbered', 'check': 'check', 'arrow': 'arrow', 'dash': 'dash'}.get(P['bullet'], 'modern')
    R._text_style(el, base, ctx)
    ph = el.find(f'.//{{{P_NS}}}ph')
    paras = [p for p in el.iter(f'{{{A}}}p') if any(ln_(c) in ('r', 'fld') for c in p)]
    for pi, p in enumerate(paras):
        ppr = kid(p, 'pPr')
        if ppr is None:
            ppr = X('<a:pPr/>')
            p.insert(0, ppr)
        bulleted = kid(ppr, 'buNone') is None and (
            kid(ppr, 'buChar') is not None or kid(ppr, 'buAutoNum') is not None or
            (ph is not None and ph.get('type') != 'subTitle'))
        if P['bullet'] == 'none':
            put(ppr, X('<a:buNone/>'), replace={'buNone', 'buChar', 'buAutoNum', 'buBlip'})
            ppr.set('marL', '0')
            ppr.set('indent', '0')
        elif P['bullet'] == 'dot' and bulleted:
            put(ppr, X('<a:buFont typeface="Arial"/>'), replace={'buFont', 'buFontTx'})
            put(ppr, X('<a:buChar char="•"/>'), replace={'buChar', 'buAutoNum', 'buBlip'})
        if kid(ppr, 'buNone') is None:
            put(ppr, X(f'<a:buClr>{clr_xml(P["bullet_colour"])}</a:buClr>'), replace={'buClr', 'buClrTx'})
        put(ppr, X(f'<a:lnSpc><a:spcPct val="{int(P["line_spacing"]) * 1000}"/></a:lnSpc>'))
        put(ppr, X(f'<a:spcAft><a:spcPts val="{int(P["space_after"]) * 100}"/></a:spcAft>'))
        for r in [c for c in p if ln_(c) in ('r', 'fld')]:
            rpr = R._rpr(r)
            if P['colour'] != 'auto':
                put(rpr, X(fill_xml(P['colour'])), replace=R.FILLS)
            if P['size']:
                rpr.set('sz', str(int(float(P['size']) * 100)))
            if P['first_bold']:
                rpr.set('b', '1' if pi == 0 else '0')
    return True


P_NS = P


def background(slide, P_, ctx):
    """Returns True when the new page is dark (its text then needs to be light)."""
    c1, c2 = clr_xml(P_['colour']), clr_xml(P_['colour2'])
    t = P_['type']
    if t == 'linear':
        fill = R._linear([(0, c1), (100000, c2)], int(float(P_['angle']) * 60000) % 21600000)
    elif t == 'glow':
        fill = R._radial([(0, c2), (50000, c1), (100000, c1)], 100000, 0, 0, 100000)
    elif t == 'corner':
        fill = R._radial([(0, c2), (55000, c1), (100000, c1)], 0, 100000, 100000, 0)
    elif t == 'spotlight':
        fill = R._radial([(0, c2), (70000, c1), (100000, c1)], 50000, 50000, 50000, 50000)
    elif t == 'band':
        fill = R._linear([(0, c2), (38000, c1), (100000, c1)], 5400000)
    else:
        fill = solid(*tok(P_['colour'])[:1], **tok(P_['colour'])[1])
    cSld = slide._element.find(f'{{{P}}}cSld')
    for old in cSld.findall(f'{{{P}}}bg'):
        cSld.remove(old)
    cSld.insert(0, X(f'<p:bg><p:bgPr>{fill}<a:effectLst/></p:bgPr></p:bg>'))
    return is_dark(P_['colour'], ctx, 0.3)


# ── capture: settings read off a component on a sample slide ─────────────────
PRESET_CLR = {'black': '000000', 'white': 'FFFFFF', 'red': 'FF0000', 'green': '008000', 'blue': '0000FF',
              'yellow': 'FFFF00', 'gray': '808080', 'grey': '808080', 'darkGray': 'A9A9A9', 'lightGray': 'D3D3D3',
              'orange': 'FFA500', 'navy': '000080', 'purple': '800080', 'teal': '008080'}
COLOUR_TAGS = {'srgbClr', 'schemeClr', 'sysClr', 'prstClr', 'scrgbClr', 'hslClr'}


class Reader:
    """Reads colours, fills and lines of a sample deck as hex values and (optionally) theme tokens."""

    def __init__(self, prs, follow_theme=False):
        self.prs = prs
        self.theme = R._theme_hex(prs)
        self.follow = follow_theme

    def hex(self, c):
        if c is None or ln_(c) not in COLOUR_TAGS:
            return None
        n = ln_(c)
        if n == 'srgbClr':
            base = c.get('val', '000000')
        elif n == 'schemeClr':
            v = c.get('val')
            if v == 'phClr':
                return None
            base = self.theme.get(SCHEME_MAP.get(v, v)) or self.theme.get(v) or \
                ('000000' if v in ('tx1', 'dk1', 'tx2', 'dk2') else 'FFFFFF')
        elif n == 'sysClr':
            base = c.get('lastClr') or ('000000' if c.get('val') == 'windowText' else 'FFFFFF')
        elif n == 'prstClr':
            base = PRESET_CLR.get(c.get('val'), '808080')
        elif n == 'scrgbClr':
            base = R._rgb2hex(tuple(int(c.get(k, '0')) / 100000 for k in 'rgb'))
        else:
            return None
        rgb = R._hex2rgb(base.upper()[:6].ljust(6, '0'))
        mods = {ln_(m): int(m.get('val', '0')) / 100000 for m in c}
        if 'lumMod' in mods or 'lumOff' in mods:
            h, l_, s = colorsys.rgb_to_hls(*rgb)
            l_ = max(0.0, min(1.0, l_ * mods.get('lumMod', 1) + mods.get('lumOff', 0)))
            rgb = colorsys.hls_to_rgb(h, l_, s)
        if 'tint' in mods:
            t = mods['tint']
            rgb = tuple(x * t + (1 - t) for x in rgb)
        if 'shade' in mods:
            rgb = tuple(x * mods['shade'] for x in rgb)
        if 'satMod' in mods:
            h, l_, s = colorsys.rgb_to_hls(*rgb)
            rgb = colorsys.hls_to_rgb(h, l_, max(0.0, min(1.0, s * mods['satMod'])))
        return R._rgb2hex(rgb)

    def token(self, c):
        """The colour as a settings token: a theme token when following the theme, else hex."""
        hx = self.hex(c)
        if hx is None:
            return None
        if self.follow and ln_(c) == 'schemeClr':
            v = SCHEME_MAP_REV.get(c.get('val'), c.get('val'))
            mods = {ln_(m): int(m.get('val', '0')) for m in c}
            if v in THEME_NAMES and set(mods) <= {'lumMod', 'lumOff'}:
                m, o = mods.get('lumMod', 100000) // 1000, mods.get('lumOff', 0) // 1000
                if not mods:
                    return v
                if o and abs(m + o - 100) <= 2 and 0 < m < 100:
                    return f'{v}@{m}'
                if not o and 0 < m < 100:
                    return f'{v}@-{100 - m}'
        return hx

    def fill(self, parent, style=None):
        """{'type': none|solid|grad|pattern|picture|None, 'tokens': [...], 'hex': [...], 'angle': deg}"""
        if parent is not None:
            for c in parent:
                n = ln_(c)
                if n == 'noFill':
                    return {'type': 'none', 'tokens': [], 'hex': []}
                if n == 'solidFill' and len(c):
                    return {'type': 'solid', 'tokens': [self.token(c[0])], 'hex': [self.hex(c[0])],
                            'alpha': [int(a.get('val')) for a in c[0] if ln_(a) == 'alpha']}
                if n == 'gradFill':
                    gs = sorted(((int(g.get('pos', 0)), g[0]) for g in c.iter(f'{{{A}}}gs') if len(g)),
                                key=lambda t: t[0])
                    lin = c.find(f'{{{A}}}lin')
                    return {'type': 'grad', 'tokens': [self.token(x) for _, x in gs], 'hex': [self.hex(x) for _, x in gs],
                            'alpha': [next((int(a.get('val')) for a in x if ln_(a) == 'alpha'), 100000) for _, x in gs],
                            'angle': int(lin.get('ang', 0)) / 60000 if lin is not None else None,
                            'path': c.find(f'{{{A}}}path') is not None}
                if n == 'pattFill':
                    bg = c.find(f'{{{A}}}bgClr')
                    return {'type': 'pattern', 'tokens': [self.token(bg[0])] if bg is not None and len(bg) else [],
                            'hex': [self.hex(bg[0])] if bg is not None and len(bg) else []}
                if n == 'blipFill':
                    return {'type': 'picture', 'tokens': [], 'hex': []}
        if style is not None:
            ref = kid(style, 'fillRef')
            if ref is not None and ref.get('idx', '0') != '0' and len(ref):
                return {'type': 'solid', 'tokens': [self.token(ref[0])], 'hex': [self.hex(ref[0])], 'alpha': []}
        return {'type': None, 'tokens': [], 'hex': []}

    def line(self, sppr, style=None):
        """(width pt, token, hex, dash) of a shape's outline, or None."""
        ln = kid(sppr, 'ln') if sppr is not None else None
        if ln is not None:
            if kid(ln, 'noFill') is not None:
                return None
            sf = kid(ln, 'solidFill')
            w = int(ln.get('w', '9525')) / 12700
            dash = kid(ln, 'prstDash')
            if sf is not None and len(sf):
                return w, self.token(sf[0]), self.hex(sf[0]), dash.get('val') if dash is not None else 'solid'
        if style is not None:
            ref = kid(style, 'lnRef')
            if ref is not None and ref.get('idx', '0') != '0' and len(ref) and (ln is None or kid(ln, 'solidFill') is None):
                w = int(ln.get('w', '12700')) / 12700 if ln is not None else 1.0
                return w, self.token(ref[0]), self.hex(ref[0]), 'solid'
        return None

    @staticmethod
    def shadow(sppr):
        eff = kid(sppr, 'effectLst') if sppr is not None else None
        sh = eff.find(f'{{{A}}}outerShdw') if eff is not None else None
        if sh is None:
            return None
        return int(sh.get('blurRad', '0')), sh


SCHEME_MAP_REV = {'dk1': 'tx1', 'lt1': 'bg1', 'dk2': 'tx2', 'lt2': 'bg2'}


def _lum_hex(h):
    return R._lum(R._hex2rgb(h)) if h else 1.0


def _sat_hex(h):
    if not h:
        return 0.0
    return colorsys.rgb_to_hls(*R._hex2rgb(h))[2]


def _greyish(h):
    return _sat_hex(h) < 0.12


def _near(a, b, tol=0.04):
    if not a or not b:
        return a == b
    return max(abs(x - y) for x, y in zip(R._hex2rgb(a), R._hex2rgb(b))) <= tol


def _runs_info(el, rd):
    """[(text, size pt, bold, colour token, colour hex, font)] for every text run in el."""
    out = []
    for r in el.iter(f'{{{A}}}r'):
        rpr = kid(r, 'rPr')
        t = r.find(f'{{{A}}}t')
        txt = t.text if t is not None and t.text else ''
        if not txt.strip():
            continue
        sz = int(rpr.get('sz')) / 100 if rpr is not None and rpr.get('sz') else None
        b = rpr is not None and rpr.get('b') in ('1', 'true')
        sf = kid(rpr, 'solidFill') if rpr is not None else None
        tokn = rd.token(sf[0]) if sf is not None and len(sf) else None
        hx = rd.hex(sf[0]) if sf is not None and len(sf) else None
        lat = kid(rpr, 'latin') if rpr is not None else None
        out.append((txt, sz, b, tokn, hx, lat.get('typeface') if lat is not None else None))
    return out


# tables ----------------------------------------------------------------------
# PowerPoint's default table style family (Medium Style 2 – Accent n), used when a deck does not
# carry the style's definition itself (python-pptx decks, for one)
MEDIUM2 = {'{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}': 'accent1', '{21E4AEA4-8DFA-4A89-87EB-49C32662AFE8}': 'accent2',
           '{F5AB1C69-6EDB-4FF4-983F-18BD219EF322}': 'accent3', '{00A15C55-8517-42AA-B614-E9B94910E393}': 'accent4',
           '{7DF18680-E054-41AD-8BC1-D1AEF772440D}': 'accent5', '{93296810-A885-4BE3-A3E7-6D5BEEA58F35}': 'accent6',
           '{073A0DAA-6AF3-43AB-8588-CEC1D06C72B9}': 'dk1'}


def _medium2(sid, acc):
    ln = '<a:ln w="12700" cmpd="sng"><a:solidFill><a:schemeClr val="lt1"/></a:solidFill></a:ln>'
    bdr = ''.join(f'<a:{k}>{ln}</a:{k}>' for k in ('left', 'right', 'top', 'bottom', 'insideH', 'insideV'))
    head = (f'<a:tcTxStyle b="on"><a:fontRef idx="minor"><a:prstClr val="black"/></a:fontRef>'
            f'<a:schemeClr val="lt1"/></a:tcTxStyle><a:tcStyle><a:tcBdr/><a:fill><a:solidFill>'
            f'<a:schemeClr val="{acc}"/></a:solidFill></a:fill></a:tcStyle>')
    return etree.fromstring(
        f'<a:tblStyle xmlns:a="{A}" styleId="{sid}"><a:wholeTbl><a:tcTxStyle><a:fontRef idx="minor">'
        f'<a:prstClr val="black"/></a:fontRef><a:schemeClr val="dk1"/></a:tcTxStyle><a:tcStyle><a:tcBdr>{bdr}'
        f'</a:tcBdr><a:fill><a:solidFill><a:schemeClr val="{acc}"><a:tint val="20000"/></a:schemeClr></a:solidFill>'
        f'</a:fill></a:tcStyle></a:wholeTbl><a:band1H><a:tcStyle><a:tcBdr/><a:fill><a:solidFill>'
        f'<a:schemeClr val="{acc}"><a:tint val="40000"/></a:schemeClr></a:solidFill></a:fill></a:tcStyle></a:band1H>'
        f'<a:band1V><a:tcStyle><a:tcBdr/><a:fill><a:solidFill><a:schemeClr val="{acc}"><a:tint val="40000"/>'
        f'</a:schemeClr></a:solidFill></a:fill></a:tcStyle></a:band1V><a:lastCol>{head}</a:lastCol>'
        f'<a:firstCol>{head}</a:firstCol><a:lastRow>{head}</a:lastRow><a:firstRow>{head}</a:firstRow></a:tblStyle>')


def _table_style_parts(prs, tbl, rd):
    """Fills/text of the table's built-in style (most PowerPoint tables are coloured by one)."""
    tp = kid(tbl, 'tblPr')
    sid = tp.find(f'{{{A}}}tableStyleId') if tp is not None else None
    flags = {k: tp.get(k) in ('1', 'true') for k in ('firstRow', 'firstCol', 'lastRow', 'bandRow', 'bandCol')} \
        if tp is not None else {}
    parts = {}
    if sid is None or not sid.text:
        return parts, flags
    styles = []
    for rel in prs.part.rels.values():
        if rel.reltype.endswith('/tableStyles'):
            styles = etree.fromstring(rel.target_part.blob).findall(f'{{{A}}}tblStyle')
    key = sid.text.strip()
    found = [st for st in styles if st.get('styleId') == key]
    if not found and key.upper() in MEDIUM2:
        found = [_medium2(key, MEDIUM2[key.upper()])]
    for st in found:
        for part in st:
            tc_style = kid(part, 'tcStyle')
            fill = None
            if tc_style is not None:
                f = kid(tc_style, 'fill')
                if f is not None:
                    fill = rd.fill(f)
            tx = kid(part, 'tcTxStyle')
            colour = None
            if tx is not None:
                for c in tx:
                    if ln_(c) in COLOUR_TAGS:
                        colour = (rd.token(c), rd.hex(c))
            borders = {}
            bdr = kid(tc_style, 'tcBdr') if tc_style is not None else None
            if bdr is not None:
                for side in bdr:
                    ln = kid(side, 'ln')
                    if ln is not None and kid(ln, 'noFill') is None:
                        sf = kid(ln, 'solidFill')
                        if sf is not None and len(sf):
                            borders[ln_(side)] = (int(ln.get('w', '12700')) / 12700, rd.token(sf[0]), rd.hex(sf[0]))
            parts[ln_(part)] = {'fill': fill, 'text': colour,
                                'bold': tx is not None and tx.get('b') == 'on', 'borders': borders}
    return parts, flags


def _cells(prs, el, rd):
    """Effective look of every cell: explicit cell formatting over the table style."""
    tbl = el.find(f'.//{{{A}}}tbl')
    rows, numeric_col, total_row = R._table_shape(tbl)
    parts, flags = _table_style_parts(prs, tbl, rd)
    grid = []
    nrows = len(rows)
    for ri, tr in enumerate(rows):
        row = []
        for ci, tc in enumerate(kids(tr, 'tc')):
            roles = ['wholeTbl']
            if flags.get('bandRow') and 0 < ri < nrows - (1 if flags.get('lastRow') else 0):
                roles.append('band1H' if (ri - (1 if flags.get('firstRow') else 0)) % 2 == 0 else 'band2H')
            if flags.get('bandCol'):
                roles.append('band1V' if (ci - (1 if flags.get('firstCol') else 0)) % 2 == 0 else 'band2V')
            if flags.get('firstCol') and ci == 0:
                roles.append('firstCol')
            if flags.get('lastRow') and ri == nrows - 1:
                roles.append('lastRow')
            if flags.get('firstRow') and ri == 0:
                roles.append('firstRow')
            fill, txt, bold, borders = None, None, False, {}
            for role in roles:
                prt = parts.get(role) or {}
                if prt.get('fill') and prt['fill']['type'] in ('solid', 'none'):
                    fill = prt['fill']
                if prt.get('text'):
                    txt = prt['text']
                bold = bold or prt.get('bold', False)
                for k, v in (prt.get('borders') or {}).items():
                    borders[k] = v
            tcpr = kid(tc, 'tcPr')
            own = rd.fill(tcpr) if tcpr is not None else {'type': None}
            if own['type'] is not None:
                fill = own
            sides = {}
            for s in 'LRTB':
                b = kid(tcpr, f'ln{s}') if tcpr is not None else None
                if b is not None:
                    sf = kid(b, 'solidFill')
                    if kid(b, 'noFill') is not None or int(b.get('w', '12700') or 0) == 0 or sf is None or not len(sf):
                        sides[s] = None
                    else:
                        sides[s] = (int(b.get('w', '12700')) / 12700, rd.token(sf[0]), rd.hex(sf[0]))
                else:
                    key = {'L': 'left', 'R': 'right', 'T': 'top', 'B': 'bottom'}[s]
                    inside = {'L': 'insideV', 'R': 'insideV', 'T': 'insideH', 'B': 'insideH'}[s]
                    sides[s] = borders.get(key) or borders.get(inside)
            info = _runs_info(tc, rd)
            colour = next(((t, h) for _, _, _, t, h, _ in info if h), None) or txt
            sizes = [s for _, s, _, _, _, _ in info if s]
            bolds = [b for _, _, b, _, _, _ in info]
            p = tc.find(f'.//{{{A}}}pPr')
            row.append({'fill': fill if fill and fill['type'] == 'solid' else None, 'colour': colour,
                        'bold': (sum(bolds) > len(bolds) / 2) if bolds else bold, 'size': sizes[0] if sizes else None,
                        'borders': sides, 'marL': int(tcpr.get('marL', '91440')) if tcpr is not None else 91440,
                        'align': p.get('algn') if p is not None else None, 'text': R._cell_text(tc)})
        grid.append(row)
    return rows, numeric_col, total_row, grid


def _fill_tok(cell):
    return cell['fill']['tokens'][0] if cell and cell.get('fill') and cell['fill']['tokens'] else None


def _fill_hex(cell):
    return cell['fill']['hex'][0] if cell and cell.get('fill') and cell['fill']['hex'] else None


def _common(values):
    vals = [v for v in values if v is not None]
    if not vals:
        return None
    return max(set(vals), key=vals.count)


def _padding(cells):
    m = _common([c['marL'] for c in cells])
    if m is None:
        return 'normal'
    return 'compact' if m < 0.1 * EMU_IN else 'airy' if m > 0.145 * EMU_IN else 'normal'


def _header_and_total(P, grid, total_idx, page_hex, notes):
    head = grid[0] if grid else []
    hf = _common([_fill_tok(c) for c in head[1:] or head])
    hfx = _common([_fill_hex(c) for c in head[1:] or head])
    if hf and not _near(hfx, page_hex, 0.02):
        P['header'], P['header_colour'] = 'fill', hf
        notes.append('filled header')
    else:
        rule = _common([(c['borders'].get('B') or (None,))[0] for c in head])
        P['header'] = 'rule' if rule else 'plain'
    if total_idx is not None:
        tr = grid[total_idx]
        tf, tfx = _common([_fill_tok(c) for c in tr]), _common([_fill_hex(c) for c in tr])
        if tf and not _near(tfx, page_hex, 0.02):
            P['total'], P['total_colour'] = 'fill', tf
        else:
            P['total'] = 'rule' if _common([(c['borders'].get('T') or (None,))[0] for c in tr]) else 'plain'


def _gap(cells, page_hex):
    """(gap pt, colour token) when the cells are separated by page-coloured borders."""
    ws, cols = [], []
    for c in cells:
        for s in 'LRTB':
            b = c['borders'].get(s)
            if b and b[0] >= 0.75 and _lum_hex(b[2]) > 0.85:
                ws.append(b[0])
                cols.append(b[1])
    if len(ws) >= len(cells):
        return round(_common([round(w * 2) / 2 for w in ws]) or 1, 1), _common(cols)
    return 0, None


def _scale_fit(body_vals, lums):
    """Which scale (table / rows / columns) explains the cell colours best."""
    def corr(ts):
        pairs = [(t, l) for t, l in zip(ts, lums) if t is not None]
        if len(pairs) < 3:
            return 0
        n = len(pairs)
        mt, ml = sum(p[0] for p in pairs) / n, sum(p[1] for p in pairs) / n
        cov = sum((a - mt) * (b - ml) for a, b in pairs)
        va = sum((a - mt) ** 2 for a, _ in pairs) ** 0.5
        vb = sum((b - ml) ** 2 for _, b in pairs) ** 0.5
        return abs(cov / (va * vb)) if va and vb else 0
    out = {}
    for scale in ('table', 'rows', 'columns'):
        ts = []
        for ri, ci, v in body_vals:
            if scale == 'rows':
                vals = [x for r, c, x in body_vals if r == ri]
            elif scale == 'columns':
                vals = [x for r, c, x in body_vals if c == ci]
            else:
                vals = [x for _, _, x in body_vals]
            lo, hi = min(vals), max(vals)
            ts.append((v - lo) / (hi - lo) if hi > lo else None)
        out[scale] = (corr(ts), ts)
    best = max(out, key=lambda k: out[k][0] + (0.02 if k == 'table' else 0))
    return best, out[best][1]


def _ramp_from(points):
    """2–5 colour stops (light → deep in value order) from (t, token, hex) samples."""
    pts = sorted((t, tk, hx) for t, tk, hx in points if t is not None and hx)
    if not pts:
        return []
    stops = []
    for q in (0.0, 0.25, 0.5, 0.75, 1.0):
        best = min(pts, key=lambda p: abs(p[0] - q))
        if not stops or not _near(stops[-1][2], best[2], 0.05):
            stops.append(best)
    if len(stops) == 1:
        stops.append(stops[0])
    # the fewest evenly spaced stops that still reproduce every sample
    hexes = [hx for _, _, hx in stops]
    qs = [p[0] for p in stops]
    for keep in ([0, len(stops) - 1], [0, len(stops) // 2, len(stops) - 1]):
        if len(keep) >= len(stops) or len(set(keep)) < len(keep):
            continue
        sub = [hexes[i] for i in keep]
        span = (qs[-1] - qs[0]) or 1
        if all(_near(R._mix(sub, (q - qs[0]) / span), h, 0.06) for q, h in zip(qs, hexes)):
            return [stops[i][1] for i in keep]
    return [tk for _, tk, _ in stops]


def _cap_heatmap(prs, el, rd, notes):
    rows, numeric_col, total_row, grid = _cells(prs, el, rd)
    P = {}
    total_idx = rows.index(total_row) if total_row is not None else None
    body_idx = [i for i in range(1, len(rows)) if i != total_idx]
    page_hex = 'FFFFFF'
    vals, cells = [], []
    for ri in body_idx:
        for ci, cell in enumerate(grid[ri]):
            if ci < len(numeric_col) and numeric_col[ci]:
                v = R._number(cell['text'])
                if v is not None:
                    vals.append((ri, ci, v))
                    cells.append(cell)
    fills = [_fill_hex(c) for c in cells]
    distinct = {f for f in fills if f}
    texts = [c['colour'][1] if c['colour'] else None for c in cells]
    if len(distinct) >= 3 and sum(1 for f in fills if f) >= 0.7 * len(fills):
        P['mode'] = 'fill'
        scale, ts = _scale_fit(vals, [1 - _lum_hex(f) if f else None for f in fills])
        P['scale'] = scale
        P['ramp'] = _ramp_from([(t, _fill_tok(c), _fill_hex(c)) for t, c in zip(ts, cells)])
        light_txt = [c for c in cells if c['colour'] and _lum_hex(c['colour'][1]) > 0.7]
        dark_txt = [c for c in cells if c['colour'] and _lum_hex(c['colour'][1]) <= 0.7]
        P['text'] = 'auto' if light_txt and dark_txt else 'light' if light_txt else 'dark' if dark_txt else 'auto'
        gap, gc = _gap(cells, page_hex)
        P['gap'] = gap
        if gc:
            P['gap_colour'] = gc
        notes.append(f'{len(P["ramp"])}-stop colour ramp, scaled per {"table" if scale == "table" else scale[:-1]}')
    elif len({t for t in texts if t and not _greyish(t)}) >= 3:
        P['mode'], P['gap'] = 'text', 0
        scale, ts = _scale_fit(vals, [1 - _lum_hex(t) if t else None for t in texts])
        P['scale'] = scale
        P['ramp'] = _ramp_from([(t, c['colour'][0], c['colour'][1]) for t, c in zip(ts, cells) if c['colour']])
        notes.append('coloured numbers')
    elif 0 < len([f for f in fills if f and not _near(f, page_hex, 0.02)]) <= max(1, len(fills) // 3):
        hits = [c for c in cells if _fill_hex(c) and not _near(_fill_hex(c), page_hex, 0.02)]
        P['mode'], P['gap'], P['top_n'] = 'top', 0, len(hits)
        deep = _common([c['colour'][0] for c in hits if c['colour']]) or _fill_tok(hits[0])
        P['ramp'] = [_fill_tok(hits[0]), deep]
        notes.append(f'top {len(hits)} values highlighted')
    else:
        notes.append('no value colours found: brand ramp kept')
    P['bold'] = sum(1 for c in cells if c['bold']) > len(cells) / 2 if cells else False
    P['align'] = 'r' if _common([c['align'] for c in cells]) == 'r' else 'ctr'
    P['padding'] = _padding(cells)
    size = _common([c['size'] for c in cells])
    if size:
        P['font_size'] = size
    _header_and_total(P, grid, total_idx, page_hex, notes)
    first = [grid[ri][0] for ri in body_idx if grid[ri]]
    ff = _common([_fill_tok(c) for c in first])
    if ff and not (numeric_col and numeric_col[0]) and not _near(_common([_fill_hex(c) for c in first]), page_hex, .02):
        P['first_col'], P['first_colour'] = 'fill', ff
    else:
        P['first_col'] = 'bold' if sum(1 for c in first if c['bold']) > len(first) / 2 else 'plain'
    return 'heat-mono', P


def _cap_table(prs, el, rd, notes):
    rows, numeric_col, total_row, grid = _cells(prs, el, rd)
    P = {}
    total_idx = rows.index(total_row) if total_row is not None else None
    body_idx = [i for i in range(1, len(rows)) if i != total_idx]
    page_hex = 'FFFFFF'
    _header_and_total(P, grid, total_idx, page_hex, notes)
    head = grid[0]
    ht = _common([c['colour'][0] for c in head if c['colour']])
    if ht:
        P['header_text'] = ht
    if P['header'] == 'rule':
        rc = _common([(c['borders'].get('B') or (0, None))[1] for c in head])
        if rc:
            P['header_colour'] = rc
    body = [grid[ri] for ri in body_idx]
    cells = [c for row in body for c in row]
    # banding
    row_fill = [_common([_fill_hex(c) for c in row[1:] or row]) for row in body]
    real = [f for f in row_fill if f and not _near(f, page_hex, 0.02)]
    gap, gc = _gap(cells, page_hex)
    tok_rows = [_common([_fill_tok(c) for c in row[1:] or row]) for row in body]
    if len(body) >= 2 and len(real) >= len(body) - 1 and len({r for r in real}) == 1:
        P['banding'], P['band_colour'] = 'all', _common([_fill_tok(c) for row in body for c in row[1:] or row])
    elif len(body) >= 3 and len(real) == len(body) and len(set(row_fill)) == 2 and \
            all(not _near(row_fill[i], row_fill[i + 1], .01) for i in range(len(body) - 1)):
        P['banding'], P['band_colour'], P['row_colour'] = 'rows', tok_rows[1], tok_rows[0]  # two-tone rows
    elif len(body) >= 3 and real and all((bool(f) and not _near(f, page_hex, .02)) == (i % 2 == 0)
                                         for i, f in enumerate(row_fill)):
        P['banding'], P['band_colour'], P['row_colour'] = 'rows', 'bg1', tok_rows[0]  # bands start on row one
    elif len(body) >= 3 and real and all((bool(f) and not _near(f, page_hex, .02)) == (i % 2 == 1)
                                         for i, f in enumerate(row_fill)):
        P['banding'] = 'rows'
        P['band_colour'] = _common([_fill_tok(c) for row in body for c in row if _fill_hex(c) and
                                    not _near(_fill_hex(c), page_hex, .02)])
    else:
        col_fill = [_common([_fill_hex(row[ci]) for row in body if ci < len(row)]) for ci in range(len(body[0]))] \
            if body else []
        if len(col_fill) >= 3 and all((bool(f) and not _near(f, page_hex, .02)) == (i % 2 == 1)
                                      for i, f in enumerate(col_fill)):
            P['banding'] = 'columns'
            P['band_colour'] = _common([_fill_tok(row[1]) for row in body if len(row) > 1])
        else:
            P['banding'] = 'none'
    # lines
    if gap:
        P['borders'], P['gap'] = 'gaps', gap
    else:
        vert = sum(1 for c in cells if c['borders'].get('L') or c['borders'].get('R'))
        horiz = [c['borders'].get('B') or c['borders'].get('T') for c in cells]
        hz = [h for h in horiz if h]
        if hz and vert >= len(cells) / 2:
            P['borders'] = 'grid'
        elif len(hz) >= len(cells) / 2:
            P['borders'] = 'rows'
        else:
            P['borders'] = 'none'
        if hz:
            P['border_colour'] = _common([h[1] for h in hz])
    first = [row[0] for row in body if row]
    ff, ffx = _common([_fill_tok(c) for c in first]), _common([_fill_hex(c) for c in first])
    others = _common([_fill_hex(c) for row in body for c in row[1:]])
    if ff and not _near(ffx, page_hex, .02) and not _near(ffx, others, .02):
        P['first_col'], P['first_colour'] = 'fill', ff
    else:
        P['first_col'] = 'bold' if first and sum(1 for c in first if c['bold']) > len(first) / 2 else 'plain'
    tc = _common([c['colour'][0] for c in cells if c['colour'] and not _fill_hex(c)])
    if tc:
        P['text_colour'] = tc
    size = _common([c['size'] for c in cells])
    if size:
        P['font_size'] = size
    P['padding'] = _padding(cells)
    nums = [c for row in body for ci, c in enumerate(row) if ci < len(numeric_col) and numeric_col[ci]]
    P['numbers_right'] = _common([c['align'] for c in nums]) == 'r' if nums else True
    notes.append(f'{P["banding"]} banding, {P["borders"]} lines'.replace('none banding, ', ''))
    return 'clean', P


# charts ----------------------------------------------------------------------
def _cap_chart(prs, slide, el, rd, notes):
    part = R._chart_part(slide, el)
    if part is None:
        raise ValueError('this chart has no data part')
    cs = part._element
    chart = kid(cs, 'chart')
    pa = chart.find(f'{{{C}}}plotArea')
    plots = [c for c in pa if ln_(c).endswith('Chart')]
    sers = [s for p in plots for s in kids(p, 'ser')]
    pie = any(ln_(p) in R.PIE_FAMILY for p in plots)
    P, palette, fills = {}, [], []
    for s in sers:
        sp = kid(s, 'spPr')
        if pie:
            for dpt in kids(s, 'dPt'):
                f = rd.fill(kid(dpt, 'spPr'))
                if f['tokens']:
                    palette.append(f['tokens'][0])
                    fills.append(f)
            continue
        f = rd.fill(sp)
        ln = kid(sp, 'ln') if sp is not None else None
        if f['type'] in (None, 'none') and ln is not None:
            lf = rd.fill(ln)
            if lf['tokens']:
                palette.append(lf['tokens'][0])
                fills.append({'type': 'line'})
                continue
        if f['tokens']:
            palette.append(f['tokens'][0])
            fills.append(f)
    if palette:
        P['palette'] = palette[:8]
        notes.append(f'{len(P["palette"])} series colours')
    grads = [f for f in fills if f.get('type') == 'grad']
    if grads and len(grads) >= len(fills) / 2:
        al = grads[0].get('alpha') or []
        P['fill'] = 'fade' if al and min(al) < 50000 else 'gradient'
        P['palette'] = [g['tokens'][0] for g in grads][:8]
    for p in plots:
        if ln_(p) in ('barChart', 'bar3DChart'):
            g, o = kid(p, 'gapWidth'), kid(p, 'overlap')
            P['gap'] = int(g.get('val', 150)) if g is not None else 150
            if o is not None:
                P['overlap'] = int(o.get('val', 0))
        if ln_(p) == 'doughnutChart':
            P['ring'] = True
            h = kid(p, 'holeSize')
            P['hole'] = int(h.get('val', 50)) if h is not None else 50
    lines = [s for p in plots if ln_(p) in ('lineChart', 'scatterChart', 'radarChart') for s in kids(p, 'ser')]
    if lines:
        s = lines[0]
        ln = kid(kid(s, 'spPr'), 'ln') if kid(s, 'spPr') is not None else None
        if ln is not None and ln.get('w'):
            P['width'] = round(int(ln.get('w')) / 12700 * 4) / 4
        sm = kid(s, 'smooth')
        P['smooth'] = sm is not None and sm.get('val', '1') in ('1', 'true')
        mk = kid(s, 'marker')
        sym = kid(mk, 'symbol') if mk is not None else None
        if sym is None or sym.get('val') == 'none':
            P['markers'] = 'none'
        else:
            mf = rd.fill(kid(mk, 'spPr')) if kid(mk, 'spPr') is not None else {'hex': []}
            P['markers'] = 'ring' if mf['hex'] and _lum_hex(mf['hex'][0]) > 0.9 else 'dot'
    val_axes = [c for c in pa if ln_(c) == 'valAx']
    if val_axes:
        ax = val_axes[0]
        gl = kid(ax, 'majorGridlines')
        if gl is None:
            P['grid'] = 'none'
        else:
            dash = gl.find(f'.//{{{A}}}prstDash')
            P['grid'] = 'dash' if dash is not None and dash.get('val') != 'solid' else 'solid'
        d = kid(ax, 'delete')
        P['axis'] = not (d is not None and d.get('val') in ('1', 'true'))
        sz = ax.find(f'.//{{{A}}}defRPr')
        if sz is not None and sz.get('sz'):
            P['font_size'] = int(sz.get('sz')) / 100
    dl = [d for s in sers for d in kids(s, 'dLbls')] + [d for p in plots for d in kids(p, 'dLbls')]
    shown = [d for d in dl if (kid(d, 'showVal') is not None and kid(d, 'showVal').get('val') in ('1', 'true'))]
    if shown and not pie:
        pos = kid(shown[0], 'dLblPos')
        P['labels'] = 'in' if pos is not None and pos.get('val') in ('inEnd', 'ctr', 'inBase') else 'out'
    elif not pie:
        P['labels'] = 'none'
    leg = kid(chart, 'legend')
    if leg is None:
        P['legend'] = 'none'
    else:
        pos = kid(leg, 'legendPos')
        P['legend'] = {'t': 'top', 'b': 'bottom', 'r': 'right', 'l': 'right'}.get(
            pos.get('val') if pos is not None else 'r', 'right')
    notes.append(f'gap {P.get("gap", "–")}%, grid {P.get("grid", "–")}, legend {P.get("legend")}')
    return 'clean', P


# KPI cards, shapes, flowcharts ------------------------------------------------
def _box(el):
    sppr = kid(el, 'spPr')
    return R._ext(sppr) if sppr is not None else None


def _inside(inner, outer, slack=0.05 * EMU_IN):
    return inner and outer and inner[0] >= outer[0] - slack and inner[1] >= outer[1] - slack and \
        inner[0] + inner[2] <= outer[0] + outer[2] + slack and inner[1] + inner[3] <= outer[1] + outer[3] + slack


def _radius(el):
    sppr = kid(el, 'spPr')
    geom = kid(sppr, 'prstGeom') if sppr is not None else None
    box = _box(el)
    if geom is None or box is None:
        return None
    prst = geom.get('prst')
    if prst in ('rect', 'flowChartProcess'):
        return 0.0
    if prst == 'roundRect':
        gd = geom.find(f'.//{{{A}}}gd')
        adj = int(re.sub(r'\D', '', gd.get('fmla', 'val 16667')) or 16667) if gd is not None else 16667
        return round(adj / 100000 * min(box[2], box[3]) / EMU_IN, 2)
    return None


def _surface(el, rd, notes):
    """(surface, surface colour token or 'auto', gradient end, shadow, border, border colour)."""
    sppr = kid(el, 'spPr')
    style = kid(el, 'style')
    f = rd.fill(sppr, style)
    ln = rd.line(sppr, style)
    sh = Reader.shadow(sppr)
    shadow = 'none' if sh is None else ('float' if sh[0] >= 300000 else 'soft')
    border = 'none' if ln is None else ('hairline' if _greyish(ln[2]) else 'colour')
    bcol = ln[1] if ln else 'auto'
    if f['type'] in (None, 'none'):
        return ('outline' if ln else 'none'), 'auto', 'auto', shadow, border, bcol
    if f['type'] == 'grad' and f['tokens']:
        return 'gradient', f['tokens'][0], f['tokens'][-1], shadow, border, bcol
    h = f['hex'][0] if f['hex'] else 'FFFFFF'
    tk = f['tokens'][0] if f['tokens'] else h
    if _lum_hex(h) > 0.93 and _greyish(h):
        surface = 'float' if shadow == 'float' else 'outline' if ln and shadow == 'none' else 'card'
        return surface, 'auto', 'auto', shadow, border, bcol
    if _greyish(h) and _lum_hex(h) > 0.6:
        return 'soft', tk, 'auto', shadow, border, bcol
    if _lum_hex(h) > 0.6:
        return 'tint', tk, 'auto', shadow, border, bcol
    return 'solid', tk, 'auto', shadow, border, bcol


def _cap_card(prs, slide, el, rd, notes):
    P = {}
    surface, sc, gto, shadow, border, bcol = _surface(el, rd, notes)
    P.update(surface=surface, surface_colour=sc, gradient_to=gto, shadow=shadow, border=border, border_colour=bcol)
    r = _radius(el)
    if r is not None:
        P['radius'] = r
    box = _box(el)
    tree = slide.shapes._spTree
    inner = [e for e in R._walk(tree) if e is not el and ln_(e) in ('sp', 'pic') and _inside(_box(e), box) and
             _box(e) and _box(e)[2] < box[2] * 0.5]
    runs = _runs_info(el, rd)
    for e in inner:
        runs += _runs_info(e, rd)
    chips = [e for e in inner if not _runs_info(e, rd) and _box(e)[2] < box[2] * 0.45 and _box(e)[3] < box[3] * 0.7
             and abs(_box(e)[2] - _box(e)[3]) < 0.25 * max(_box(e)[2], _box(e)[3])]
    bars = [e for e in inner if not _runs_info(e, rd) and (_box(e)[3] < 0.1 * EMU_IN or _box(e)[2] < 0.1 * EMU_IN)]
    if bars:
        b = _box(bars[0])
        P['deco'] = 'top' if b[3] < b[2] else 'left'
    colour = None
    if chips:
        c = chips[0]
        cb = _box(c)
        geom = kid(kid(c, 'spPr'), 'prstGeom') if kid(c, 'spPr') is not None else None
        cf = rd.fill(kid(c, 'spPr'), kid(c, 'style'))
        circle = geom is not None and geom.get('prst') == 'ellipse'
        translucent = bool(cf.get('alpha')) and min(cf['alpha']) < 60000
        if cf['type'] in (None, 'none') or kid(c, 'spPr') is None:
            P['chip'] = 'bare'
        elif translucent:  # a glass chip on a coloured card
            P['chip'] = 'circle' if circle else 'solid'
        elif cf['hex'] and _lum_hex(cf['hex'][0]) > 0.75:
            P['chip'] = 'soft' if not _greyish(cf['hex'][0]) else 'white'
        else:
            P['chip'] = 'circle' if circle else 'solid'
        if cf['tokens'] and not _greyish(cf['hex'][0]):
            colour = cf['tokens'][0]
        cx, cy = cb[0] + cb[2] / 2 - box[0], cb[1] + cb[3] / 2 - box[1]
        if cx > box[2] * 0.62:
            P['layout'] = 'hero' if cy > box[3] * 0.3 else 'corner'
        elif cy < box[3] * 0.42 and abs(cx - box[2] / 2) < box[2] * 0.12:
            P['layout'] = 'center'
        elif cy < box[3] * 0.42:
            P['layout'] = 'stack'
        else:
            P['layout'] = 'side'
        notes.append('icon chip found')
    else:
        P['chip'] = 'none'
        para = el.find(f'.//{{{A}}}pPr')
        P['layout'] = 'tile' if para is not None and para.get('algn') == 'ctr' else 'plain'
    if runs:
        big = max(runs, key=lambda r: r[1] or 0)
        small = [r for r in runs if r is not big and r[1]]
        if big[1]:
            P['value_size'] = big[1]
        if small:
            P['label_size'] = min(r[1] for r in small)
        P['weight'] = 'light' if (big[5] and 'light' in big[5].lower()) or not big[2] else 'bold'
        if big[4] and not _greyish(big[4]) and surface not in ('solid', 'gradient', 'tile', 'hero'):
            P['value'] = 'accent'
            colour = colour or big[3]
    if colour is None and surface in ('solid', 'gradient', 'tint') and sc != 'auto':
        colour = sc if surface != 'tint' else None
    if colour:
        P['colours'] = [colour]
    if surface in ('solid', 'tint') and colour and sc == colour:
        P['surface_colour'] = 'auto'
    notes.append(f'{dict(FIELDS_BY["card"]["surface"])[surface].lower()}, {P.get("layout")} layout')
    return 'kpi', P


def _cap_shape(prs, slide, el, rd, notes):
    P = {}
    sppr, style = kid(el, 'spPr'), kid(el, 'style')
    f = rd.fill(sppr, style)
    ln = rd.line(sppr, style)
    sh = Reader.shadow(sppr)
    P['shadow'] = 'none' if sh is None else ('float' if sh[0] >= 300000 else 'soft')
    colour = None
    if f['type'] == 'grad':
        P['fill'], colour = 'gradient', f['tokens'][0]
    elif f['type'] in (None, 'none'):
        P['fill'] = 'none'
    else:
        h = f['hex'][0]
        if _lum_hex(h) > 0.93 and _greyish(h):
            P['fill'] = 'white'
        elif _greyish(h) and _lum_hex(h) > 0.6:
            P['fill'] = 'grey'
        elif _lum_hex(h) > 0.6:
            P['fill'] = 'tint'
            colour = R._lummod(h, 45, 0)
        else:
            P['fill'], colour = 'solid', f['tokens'][0]
    if ln:
        P['border'] = 'hairline' if _greyish(ln[2]) else 'colour'
        P['border_width'] = max(0.25, round(ln[0] * 4) / 4)
        colour = colour or ln[1]
    else:
        P['border'] = 'none'
    if colour:
        P['colours'] = [colour]
    r = _radius(el)
    if r is not None:
        P['radius'] = r
    runs = _runs_info(el, rd)
    th = _common([r[4] for r in runs])
    if th:
        P['text'] = 'light' if _lum_hex(th) > 0.85 else 'dark' if _greyish(th) else 'accent'
    notes.append(f'{P["fill"]} fill')
    return 'soft', P


def _cap_flow(prs, slide, el, rd, notes):
    base, S = _cap_shape(prs, slide, el, rd, [])
    P = {k: v for k, v in S.items() if k in ('fill', 'colours', 'border', 'text')}
    P['shadow'] = S.get('shadow', 'none') != 'none'
    if P.get('fill') == 'none':
        P['fill'] = 'outline'
    sppr = kid(el, 'spPr')
    geom = kid(sppr, 'prstGeom') if sppr is not None else None
    prst = geom.get('prst') if geom is not None else ''
    r = _radius(el)
    box = _box(el)
    if prst in ('flowChartTerminator', 'ellipse') or (r is not None and box and r * EMU_IN >= min(box[2], box[3]) * 0.4):
        P['shape'] = 'pill'
    elif r:
        P['shape'] = 'rounded'
    elif r == 0:
        P['shape'] = 'rect'
    tree = slide.shapes._spTree
    connected = R.flow_nodes(tree)
    nodes = [e for e in R._walk(tree) if R.classify(e, connected) == 'flow']
    for e in nodes:
        g = kid(kid(e, 'spPr'), 'prstGeom') if kid(e, 'spPr') is not None else None
        if g is not None and g.get('prst') in ('flowChartDecision', 'diamond') and e is not el:
            df = rd.fill(kid(e, 'spPr'), kid(e, 'style'))
            if df['tokens']:
                P['decision_colour'] = df['tokens'][0]
                P['decision'] = 'solid' if df['hex'] and _lum_hex(df['hex'][0]) < 0.6 else 'same'
            break
    cx = next((e for e in nodes if ln_(e) == 'cxnSp'), None)
    if cx is not None:
        ln = rd.line(kid(cx, 'spPr'), kid(cx, 'style'))
        if ln:
            P['connector'], P['connector_width'] = ln[1], max(0.5, min(4, round(ln[0] * 4) / 4))
            P['dash'] = 'solid' if ln[3] in ('solid', None) else 'dot' if 'Dot' in ln[3] and 'Dash' not in ln[3] \
                else 'dash'
        end = next((e for e in (cx.find(f'.//{{{A}}}tailEnd'), cx.find(f'.//{{{A}}}headEnd'))
                    if e is not None and e.get('type', 'none') != 'none'), None)
        if end is not None and end.get('w'):
            P['arrow'] = end.get('w') if end.get('w') in ('sm', 'med', 'lg') else 'med'
        notes.append('arrows read from the connectors')
    return 'pill', P


def _cap_picture(prs, slide, el, rd, notes):
    P = {}
    sppr = kid(el, 'spPr')
    geom = kid(sppr, 'prstGeom') if sppr is not None else None
    prst = geom.get('prst') if geom is not None else 'rect'
    if prst == 'ellipse':
        P['shape'] = 'circle'
    elif prst == 'round2SameRect':
        P['shape'] = 'arch'
    elif prst == 'roundRect':
        P['shape'], P['radius'] = 'rounded', _radius(el) or 0.16
    else:
        P['shape'] = 'rect'
    ln = rd.line(sppr, kid(el, 'style'))
    if ln:
        P['border_width'], P['border_colour'] = round(ln[0] * 2) / 2, ln[1]
    sh = Reader.shadow(sppr)
    if sh is not None:
        c = next((x for x in sh[1] if ln_(x) in COLOUR_TAGS), None)
        hx = rd.hex(c) if c is not None else None
        if hx and not _greyish(hx):
            P['shadow'], P['colour'] = 'glow', rd.token(c)
        else:
            P['shadow'] = 'soft'
    blip = el.find(f'.//{{{A}}}blip')
    if blip is not None:
        if blip.find(f'{{{A}}}grayscl') is not None:
            P['effect'] = 'grayscale'
        duo = blip.find(f'{{{A}}}duotone')
        if duo is not None:
            P['effect'] = 'duotone'
            c = next((x for x in duo if ln_(x) in COLOUR_TAGS), None)
            if c is not None:
                P['colour'] = rd.token(c)
    notes.append(f'{P["shape"]} picture')
    return 'rounded', P


def _cap_title(prs, slide, el, rd, notes):
    P = {}
    runs = _runs_info(el, rd)
    rprs = [kid(r, 'rPr') for r in el.iter(f'{{{A}}}r') if kid(r, 'rPr') is not None]
    tk = _common([r[3] for r in runs])
    P['colour'] = tk or 'auto'
    size = _common([r[1] for r in runs])
    if size:
        P['size'] = size
    P['weight'] = 'bold' if sum(1 for r in runs if r[2]) >= len(runs) / 2 and runs else 'regular'
    P['caps'] = any(r.get('cap') == 'all' for r in rprs)
    spc = _common([int(r.get('spc')) for r in rprs if r.get('spc')])
    if spc is not None:
        P['tracking'] = max(-100, min(200, spc))
    face = _common([r[5] for r in runs])
    P['font'] = 'body' if face == '+mn-lt' else 'heading'
    algn = _common([p.get('algn') for p in el.iter(f'{{{A}}}pPr')])
    P['align'] = 'center' if algn == 'ctr' else 'left'
    box = _box(el)
    if box is None:  # a title placeholder usually inherits its position from the layout
        shp = next((x for x in slide.shapes if x._element is el), None)
        if shp is not None and shp.width:
            box = (shp.left, shp.top, shp.width, shp.height)
    if box:
        for e in R._walk(slide.shapes._spTree):
            b = _box(e)
            if e is el or not b or _runs_info(e, rd) or ln_(e) != 'sp':
                continue
            f = rd.fill(kid(e, 'spPr'), kid(e, 'style'))
            if not f['tokens']:
                continue
            below = 0 <= b[1] - (box[1] + box[3]) < 0.3 * EMU_IN and b[3] < 0.12 * EMU_IN
            left = 0 <= box[0] - (b[0] + b[2]) < 0.4 * EMU_IN or (b[0] <= box[0] + 0.05 * EMU_IN and b[2] < 0.12 * EMU_IN)
            if below and b[2] > box[2] * 0.6:
                P['decoration'], P['deco_colour'] = 'underline', f['tokens'][0]
            elif below:
                P['decoration'], P['deco_colour'] = 'bar', f['tokens'][0]
            elif left and abs(b[1] + b[3] / 2 - (box[1] + box[3] / 2)) < box[3] / 2 and b[3] > b[2] * 1.5:
                P['decoration'], P['deco_colour'] = 'side', f['tokens'][0]
            elif left and abs(b[2] - b[3]) < 0.03 * EMU_IN and b[2] < 0.3 * EMU_IN:
                P['decoration'], P['deco_colour'] = 'dot', f['tokens'][0]
            if 'decoration' in P:
                notes.append(f'{P["decoration"]} decoration')
                break
    return 'modern', P


def _cap_text(prs, slide, el, rd, notes):
    P = {}
    pprs = [p for p in el.iter(f'{{{A}}}pPr')]
    chars = [kid(p, 'buChar').get('char') for p in pprs if kid(p, 'buChar') is not None]
    if any(kid(p, 'buAutoNum') is not None for p in pprs):
        P['bullet'] = 'number'
    elif chars:
        c = _common(chars)
        P['bullet'] = {'✓': 'check', '✔': 'check', '→': 'arrow', '➜': 'arrow', '–': 'dash', '-': 'dash',
                       '—': 'dash'}.get(c, 'dot')
    elif pprs and all(kid(p, 'buNone') is not None for p in pprs):
        P['bullet'] = 'none'
    bc = next((kid(p, 'buClr') for p in pprs if kid(p, 'buClr') is not None), None)
    if bc is not None and len(bc):
        P['bullet_colour'] = rd.token(bc[0])
    runs = _runs_info(el, rd)
    tk = _common([r[3] for r in runs])
    if tk:
        P['colour'] = tk
    size = _common([r[1] for r in runs])
    if size:
        P['size'] = size
    ls = next((p.find(f'{{{A}}}lnSpc/{{{A}}}spcPct') for p in pprs if p.find(f'{{{A}}}lnSpc/{{{A}}}spcPct') is not None),
              None)
    if ls is not None:
        P['line_spacing'] = int(ls.get('val', '100000')) // 1000
    sa = next((p.find(f'{{{A}}}spcAft/{{{A}}}spcPts') for p in pprs if p.find(f'{{{A}}}spcAft/{{{A}}}spcPts') is not None),
              None)
    if sa is not None:
        P['space_after'] = int(sa.get('val', '600')) // 100
    if len(runs) > 1 and runs[0][2] and not any(r[2] for r in runs[1:]):
        P['first_bold'] = True
    notes.append(f'{P.get("bullet", "kept")} bullets')
    return 'modern', P


def _cap_background(prs, slide, rd, notes):
    bg = slide._element.find(f'{{{P}}}cSld/{{{P}}}bg')
    owners = [slide._element]
    try:
        owners += [slide.slide_layout._element, slide.slide_layout.slide_master._element]
    except Exception:  # noqa: BLE001
        pass
    for o in owners:
        bg = o.find(f'{{{P}}}cSld/{{{P}}}bg')
        if bg is not None:
            break
    Q = {'type': 'solid', 'colour': 'bg1'}
    if bg is None:
        return 'white', Q
    pr = kid(bg, 'bgPr')
    if pr is None:
        ref = kid(bg, 'bgRef')
        if ref is not None and len(ref):
            Q['colour'] = rd.token(ref[0]) or 'bg1'
        return 'white', Q
    f = rd.fill(pr)
    if f['type'] == 'solid' and f['tokens']:
        Q['colour'] = f['tokens'][0]
    elif f['type'] == 'grad' and f['tokens']:
        toks, hexes = f['tokens'], f['hex']
        light = max(range(len(hexes)), key=lambda i: _lum_hex(hexes[i]))
        other = min(range(len(hexes)), key=lambda i: _lum_hex(hexes[i]))
        if f.get('path'):
            Q.update(type='glow' if light != 0 else 'spotlight', colour=toks[light], colour2=toks[other])
        else:
            Q.update(type='linear', colour=toks[0], colour2=toks[-1], angle=int(round((f.get('angle') or 90) / 15) * 15))
    elif f['type'] == 'pattern' and f['tokens']:
        Q['colour'] = f['tokens'][0]
    notes.append(f'{Q["type"]} background')
    return 'white', Q


FIELDS_BY = {k: {f['key']: [(o['id'], o['name']) for o in f.get('options', [])] for f in v} for k, v in FIELDS.items()}
TARGETS = {'chart': ['chart'], 'table': ['heatmap', 'table'], 'card': ['card', 'shape'], 'shape': ['shape', 'card'],
           'flow': ['flow'], 'picture': ['picture'], 'title': ['title'], 'text': ['text'], 'background': ['background']}


def capture(data, slide_n, cid, kind=None, follow_theme=False):
    """Read a design off component `cid` (e.g. '3:7', or '3:bg') on slide `slide_n` of a sample deck.

    kind: the design kind to make (heatmap/table for tables …); default: what the component is.
    follow_theme: colours the sample takes from its theme stay theme colours (follow the deck palette);
    otherwise every colour is kept exactly as in the sample."""
    prs = Presentation(io.BytesIO(data))
    if not 1 <= slide_n <= len(prs.slides):
        raise ValueError('no such slide')
    slide = prs.slides[slide_n - 1]
    rd = Reader(prs, follow_theme)
    notes = []
    if cid.endswith(':bg'):
        found = 'background'
        el = None
    else:
        sid = cid.split(':', 1)[1]
        tree = slide.shapes._spTree
        connected = R.flow_nodes(tree)
        el = next((e for e in R._walk(tree) if R._cnv(e).get('id') == sid), None)
        if el is None:
            raise ValueError('component not found on that slide')
        found = R.classify(el, connected)
    if found not in TARGETS:
        raise ValueError('this component cannot be captured')
    if kind is None:
        kind = ('heatmap' if R.is_numeric_table(el) else 'table') if found == 'table' else TARGETS[found][0]
    if kind not in TARGETS[found]:
        raise ValueError(f'a {found} cannot become a {kind} design')
    if kind == 'background':
        base, params = _cap_background(prs, slide, rd, notes)
    elif kind == 'heatmap':
        base, params = _cap_heatmap(prs, el, rd, notes)
    elif kind == 'table':
        base, params = _cap_table(prs, el, rd, notes)
    elif kind == 'chart':
        base, params = _cap_chart(prs, slide, el, rd, notes)
    elif kind == 'card':
        base, params = _cap_card(prs, slide, el, rd, notes)
    elif kind == 'shape':
        base, params = _cap_shape(prs, slide, el, rd, notes)
    elif kind == 'flow':
        base, params = _cap_flow(prs, slide, el, rd, notes)
    elif kind == 'picture':
        base, params = _cap_picture(prs, slide, el, rd, notes)
    elif kind == 'title':
        base, params = _cap_title(prs, slide, el, rd, notes)
    else:
        base, params = _cap_text(prs, slide, el, rd, notes)
    params = {k: v for k, v in params.items() if v is not None}
    return {'kind': kind, 'base': base, 'params': clean(kind, params, base), 'notes': notes,
            'component': {'slide': slide_n, 'id': cid, 'name': R._cnv(el).get('name') if el is not None else 'Background'}}
