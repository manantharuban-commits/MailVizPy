"""Component restyler – fresh, modern design language for every deck component.

Design rules applied everywhere
  * surfaces, not borders: cards and panels sit on a soft surface colour (bg2)
  * one corner radius (0.12 in) whatever the shape size; pills are fully round
  * no bevels, gradients-for-decoration, 3-D or heavy outlines; at most one soft shadow
  * left-aligned, tightly tracked headings in the theme heading font; muted body ink
  * charts: no borders or axis lines, faint grid, larger labels, legend on top, vivid accents
  * colours are theme roles (bg1/bg2/tx1/accentN), so Looks and light/dark switches flow through

    plan = {'look': 'fresh', 'kinds': {'chart': {'style': 'clean', 'chart_type': 'keep'}, …},
            'items': {'4:3': {'style': 'highlight'}}, 'colour': 'auto', 'dark': False}
    data, summary = apply(pptx_bytes, plan)
"""
import colorsys
import copy
import io
import re

from lxml import etree
from pptx import Presentation

A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
P = 'http://schemas.openxmlformats.org/presentationml/2006/main'
C = 'http://schemas.openxmlformats.org/drawingml/2006/chart'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
NSDECL = f'xmlns:a="{A}" xmlns:p="{P}" xmlns:c="{C}" xmlns:r="{R}"'
EMU_IN = 914400

STYLES = {
    'chart': [
        ('clean', 'Clean', 'Dashed hairline grid, soft labels, legend on top'),
        ('highlight', 'Highlight', 'Greys out the rest so the key series or top bar pops'),
        ('bold', 'Bold numbers', 'Chunky bars with values inside; no axis or grid'),
        ('labels', 'Direct labels', 'No grid or value axis; values sit above each bar'),
        ('smooth', 'Smooth', 'Curved lines with ring markers, tinted areas'),
        ('gradient', 'Gradient', 'Bars fade from full colour to a light tint'),
        ('fade', 'Fade', 'Bars dissolve into the page; horizontal bars grow from transparent'),
        ('mono', 'Monochrome', 'Shades of the brand colour only'),
        ('duo', 'Duotone', 'Brand colour against one contrast colour, the rest grey'),
        ('pastel', 'Pastel', 'Soft pastel fills with dark labels'),
        ('outline', 'Outline', 'Tinted fills with crisp coloured outlines'),
        ('slim', 'Slim', 'Thin bars, wide gaps, thin lines and rings'),
        ('blueprint', 'Blueprint', 'Accent dashed grid and fine technical type'),
        ('ring', 'Thin ring', 'Pies become slim doughnuts; other charts go clean'),
    ],
    'heatmap': [
        ('heat-mono', 'Brand ramp', 'Light-to-deep shades of the brand colour'),
        ('heat-tiles', 'Tiles', 'Brand ramp as separate tiles with white gaps'),
        ('heat-duo', 'Two-tone', 'From the second accent to the brand colour'),
        ('heat-ocean', 'Ocean', 'Ice blue to deep navy'),
        ('heat-sunset', 'Sunset', 'Cream to burnt orange'),
        ('heat-violet', 'Violet', 'Lavender to deep violet'),
        ('heat-mint', 'Mint', 'Pale mint to forest green'),
        ('heat-viridis', 'Viridis', 'Perceptual purple → teal → yellow'),
        ('heat-traffic', 'Traffic', 'Soft red, amber and green'),
        ('heat-diverge', 'Diverging', 'Rose below the middle, teal above'),
        ('heat-rows', 'Per row', 'Brand ramp scaled within each row'),
        ('heat-cols', 'Per column', 'Brand ramp scaled within each column'),
        ('heat-text', 'Coloured numbers', 'No fills; the numbers carry the colour'),
        ('heat-top', 'Top values', 'Plain table with the top values highlighted'),
    ],
    'table': [
        ('clean', 'Clean', 'No grid; muted header, hairline rows, numbers right-aligned'),
        ('soft', 'Soft header', 'Light grey header row, hairline rows'),
        ('striped', 'Striped', 'Accent header text and rule, tinted alternate rows'),
        ('accent', 'Accent header', 'Solid accent header, tinted total row'),
        ('ink', 'Ink header', 'Near-black header with white text'),
        ('minimal', 'Minimal', 'Only a rule under the header; airy rows'),
        ('grid', 'Fine grid', 'Hairline grid on every cell'),
        ('rows', 'Card rows', 'Each row a soft strip with white gaps'),
        ('columns', 'Column bands', 'Alternate columns tinted'),
        ('ledger', 'Ledger', 'Tinted first column, accent header rule'),
        ('compact', 'Compact', 'Tight padding and smaller type for dense data'),
        ('blocks', 'Blocks', 'Decision-matrix look: dark header and first-column blocks, cells with gaps'),
    ],
    'card': [
        ('kpi', 'KPI card', 'White card, solid icon chip, label above a big figure with a small unit'),
        ('kpi-side', 'Side icon', 'Icon chip on the left, label and figure beside it'),
        ('kpi-header', 'Icon header', 'Round icon badge and bold title, a divider, then the figure in colour'),
        ('kpi-strip', 'KPI strip', 'Cards in a row share one container with thin dividers'),
        ('kpi-hero', 'By the numbers', 'Solid colour tile, huge figure, outline icon in a soft circle'),
        ('kpi-tile', 'Gradient tile', 'Gradient colour tile with the figure centred above its label'),
        ('kpi-spotlight', 'Spotlight', 'Thin big numbers; the middle card is highlighted in colour'),
        ('kpi-light', 'Light numbers', 'No card: grey label, large thin figure, muted note'),
        ('kpi-tint', 'Tinted', 'Pale accent card, figure in the accent colour'),
        ('kpi-corner', 'Corner icon', 'Icon chip in the top-right corner'),
        ('kpi-accent', 'Accent line', 'Accent line along the top, soft icon chip'),
        ('kpi-bar', 'Accent bar', 'Accent bar down the left edge'),
        ('kpi-circle', 'Centred badge', 'Round icon badge and centred text'),
        ('kpi-soft', 'Soft', 'Borderless surface card, solid icon chip'),
        ('kpi-float', 'Floating', 'White card on a wide, diffuse shadow'),
        ('kpi-outline', 'Outline', 'Hairline card, outlined icon chip, no shadow'),
        ('kpi-solid', 'Solid colour', 'Solid accent card, white text and icon'),
        ('kpi-gradient', 'Gradient', 'Diagonal two-colour gradient card'),
        ('kpi-minimal', 'Minimal', 'No card: icon, label and figure on the page'),
    ],
    'shape': [
        ('soft', 'Soft tint', 'Pale accent tint with accent-coloured text'),
        ('solid', 'Solid', 'Solid accent with white text'),
        ('gradient', 'Gradient', 'Accent-to-accent gradient, white text'),
        ('soft-gradient', 'Soft gradient', 'Pale two-accent gradient with accent text'),
        ('outline', 'Outline', 'Accent outline only'),
        ('tint-outline', 'Tint + edge', 'Pale tint with a fine accent edge'),
        ('muted', 'Muted', 'Neutral surface with ink text'),
        ('floating', 'Floating', 'White with a diffuse shadow'),
    ],
    'flow': [
        ('pill', 'Pills', 'Pill-shaped tinted steps, slim grey arrows'),
        ('chip', 'Chips', 'White chips with hairline edge and soft shadow'),
        ('solid', 'Solid', 'Solid accent steps with white text'),
        ('outline', 'Outline', 'Accent outlines, no fill'),
        ('tint', 'Tinted boxes', 'Tinted rounded boxes with accent text'),
        ('neutral', 'Neutral', 'Grey surface boxes, decisions in accent'),
        ('rainbow', 'Rainbow', 'Each step in its own tinted accent'),
        ('gradient', 'Gradient', 'Gradient steps with white text'),
        ('dashed', 'Dashed links', 'Chips joined by dashed connectors'),
        ('bold-arrows', 'Bold arrows', 'Pills joined by thick accent arrows'),
        ('typed', 'Typed', 'Pill start/end, tinted process boxes, solid decision diamonds'),
    ],
    'picture': [
        ('rounded', 'Rounded', 'Consistent rounded corners'),
        ('soft-round', 'Extra round', 'Large, friendly corner radius'),
        ('shadow', 'Soft shadow', 'Rounded corners and a soft shadow'),
        ('glow', 'Colour glow', 'Rounded with a soft accent-coloured shadow'),
        ('frame', 'Frame', 'White border and shadow, like a print'),
        ('outline', 'Accent edge', 'Rounded with an accent outline'),
        ('arch', 'Arch', 'Fully rounded top, square bottom'),
        ('circle', 'Circle', 'Circular crop for portraits and logos'),
        ('mono', 'Black & white', 'Greyscale photo, rounded'),
        ('duotone', 'Duotone', 'Photo tinted in the brand colour'),
        ('plain', 'Plain', 'Square corners, no border or effects'),
    ],
    'title': [
        ('modern', 'Modern', 'Left-aligned, bold heading font, tight tracking'),
        ('accent-bar', 'Accent bar', 'Modern title with a short accent bar beneath'),
        ('side-bar', 'Side bar', 'Vertical accent bar beside the title'),
        ('dot', 'Accent dot', 'A small accent dot before the title'),
        ('underline', 'Rule', 'Hairline rule across the full title width'),
        ('accent', 'Accent colour', 'Title set in the brand colour'),
        ('gradient', 'Gradient text', 'Brand-to-accent gradient lettering'),
        ('editorial', 'Editorial', 'Regular weight, very tight tracking, magazine feel'),
        ('caps', 'Caps', 'Capitals with open letter spacing'),
        ('centered', 'Centred', 'Modern type, alignment kept'),
    ],
    'text': [
        ('modern', 'Modern', 'Body font, softer ink, accent bullets, comfortable spacing'),
        ('airy', 'Airy', 'Modern plus extra line and paragraph spacing'),
        ('compact', 'Compact', 'Tighter spacing for dense slides'),
        ('check', 'Check marks', 'Bullets become accent check marks'),
        ('arrow', 'Arrows', 'Bullets become accent arrows'),
        ('dash', 'Dashes', 'Bullets become accent dashes'),
        ('numbered', 'Numbered', 'Bullets become numbers'),
        ('lead', 'Lead line', 'First line bold and dark, the rest muted'),
    ],
    'background': [
        ('canvas', 'Canvas', 'Light slate page so white cards and charts stand out'),
        ('white', 'White', 'Plain white page'),
        ('glow', 'Glow', 'Soft accent glow from the top-right corner'),
        ('soft', 'Soft fade', 'White fading into light grey'),
        ('band', 'Top band', 'A soft accent band fading down from the top'),
        ('mesh', 'Mesh', 'Two-accent diagonal wash'),
        ('aurora', 'Aurora', 'Three-accent diagonal wash'),
        ('spotlight', 'Spotlight', 'Accent glow from the centre'),
        ('corner', 'Corner glow', 'Second accent glowing from the bottom-left'),
        ('dots', 'Dot grid', 'Faint dot grid texture'),
        ('grid', 'Graph paper', 'Faint square grid texture'),
    ],
}
# containers: charts and tables each sit in their own card
CONTAINERS = [
    ('card', 'Card', 'White card, hairline edge, soft shadow, title in the header'),
    ('header', 'Header rule', 'Card with a divider under the title'),
    ('badge', 'Icon header', 'Round icon badge before the title, divider below'),
    ('grey', 'Grey panel', 'Light grey panel with a capitals title, no edge'),
    ('centered', 'Centred title', 'Large-radius white card, centred title and divider'),
    ('accent', 'Accent line', 'Card with an accent line along the top'),
    ('float', 'Floating', 'White card on a wide, diffuse shadow, no edge'),
    ('outline', 'Outline', 'Hairline card without shadow'),
    ('tint', 'Tinted', 'Very light accent card, no edge'),
    ('none', 'No container', 'Chart or table straight on the slide'),
]
ICON_MODES = [('auto', 'Design default'), ('solid', 'Solid chips'), ('circle', 'Round badges'),
              ('soft', 'Soft chips'), ('bare', 'Icon only'), ('none', 'No icons')]
LEGENDS = [('chips', 'Dot chips'), ('native', 'Standard legend')]
ALIASES = {
    'chart': {'minimal': 'clean', 'soft': 'smooth', 'dark': 'clean', 'neon': 'clean', 'panel': 'clean'},
    'table': {'zebra': 'striped', 'header': 'accent', 'cards': 'rows', 'dark': 'ink'},
    'heatmap': {'heat-dark': 'heat-mono'},
    'card': {'soft': 'kpi-soft', 'elevated': 'kpi', 'floating': 'kpi-float', 'accent-top': 'kpi-accent',
             'accent-left': 'kpi-bar', 'accent-bottom': 'kpi-accent', 'header-band': 'kpi-accent',
             'tint': 'kpi-tint', 'tinted': 'kpi-tint', 'solid': 'kpi-solid', 'gradient': 'kpi-gradient',
             'contrast': 'kpi-solid', 'outline': 'kpi-outline', 'dashed': 'kpi-outline', 'glass': 'kpi-soft',
             'pill': 'kpi-solid', 'flat': 'kpi-solid'},
    'shape': {'tinted': 'soft', 'elevated': 'floating', 'flat': 'solid', 'ghost': 'soft-gradient',
              'contrast': 'solid', 'glass': 'muted'},
    'flow': {'soft': 'pill', 'contrast': 'solid', 'glass': 'chip'},
    'picture': {'framed': 'frame'},
    'title': {'clean': 'modern', 'bold': 'modern', 'rule': 'accent-bar'},
    'text': {'clean': 'modern'},
    'background': {'clean': 'white', 'tint': 'canvas', 'hero': 'glow'},
}
CHART_TYPES = [('keep', 'Keep type'), ('column', 'Column'), ('bar', 'Bar'), ('stacked', 'Stacked column'),
               ('line', 'Line'), ('area', 'Area'), ('pie', 'Pie'), ('doughnut', 'Doughnut')]
KIND_LABEL = {'chart': 'Charts', 'heatmap': 'Heatmaps', 'table': 'Tables', 'card': 'KPI cards', 'shape': 'Shapes',
              'flow': 'Flowcharts', 'picture': 'Pictures', 'title': 'Titles', 'text': 'Body text',
              'background': 'Slide backgrounds'}


ACCENTS = [f'accent{i}' for i in range(1, 7)]
RECTLIKE = {'rect', 'roundRect', 'snip1Rect', 'snip2SameRect', 'snip2DiagRect', 'snipRoundRect', 'round1Rect',
            'round2SameRect', 'round2DiagRect', 'plaque', 'foldedCorner', 'bevel', 'frame'}
PILL_FLOW = {'flowChartProcess', 'flowChartAlternateProcess', 'flowChartPredefinedProcess', 'flowChartTerminator',
             'flowChartInternalStorage', 'rect', 'roundRect', 'flowChartPunchedCard', 'flowChartPreparation'}
RADIUS = int(0.12 * EMU_IN)
PIC_RADIUS = int(0.16 * EMU_IN)


# ── XML + colour helpers ─────────────────────────────────────────────────────
def X(xml):
    return etree.fromstring(f'<w {NSDECL}>{xml}</w>')[0]


def ln_(el):
    return etree.QName(el).localname if isinstance(el.tag, str) else ''


def kid(el, name):
    for c in el:
        if ln_(c) == name:
            return c
    return None


def kids(el, name):
    return [c for c in el if ln_(c) == name]


def clr(val, **mods):
    """Theme role ('accent1', 'tx1' …) or a hex colour, with optional modifiers."""
    inner = ''.join(f'<a:{k} val="{v}"/>' for k, v in mods.items())
    tag, attr = ('srgbClr', val.upper()) if re.fullmatch(r'[0-9A-Fa-f]{6}', str(val)) else ('schemeClr', val)
    return f'<a:{tag} val="{attr}">{inner}</a:{tag}>' if inner else f'<a:{tag} val="{attr}"/>'


sc = clr


def solid(val, **mods):
    return f'<a:solidFill>{clr(val, **mods)}</a:solidFill>'


class Ctx:
    """Per-run design context: light/dark and brand title colour."""

    def __init__(self, dark=False, title_accent=None):
        self.dark = bool(dark)
        self.title_accent = title_accent
        self.on_dark = False
        self.picture_bg = False  # slide sits on a picture: inherited text colours are kept as designed
        self.canvas = False      # slide uses the light canvas page: 'surface' cards become white
        self.flip_light = False  # a dark title slide redrawn light: light text becomes ink
        self.light_font = None   # light weight of the heading font, for thin KPI numbers
        self.theme = {}
        self.ink = ('tx1', {})
        self.ink2 = ('tx1', {'lumMod': '65000', 'lumOff': '35000'})
        self.body = ('tx1', {'lumMod': '85000', 'lumOff': '15000'})
        self.hair = ('tx1', {'lumMod': '10000', 'lumOff': '90000'})
        self.line = ('tx1', {'lumMod': '20000', 'lumOff': '80000'})
        if self.dark:  # light ink on a dark page: hairlines come from transparency, not tints
            self.hair = ('tx1', {'alpha': '14000'})
            self.line = ('tx1', {'alpha': '26000'})

    @property
    def greys(self):
        """Muted marks for 'highlight' charts, readable on the page colour."""
        if self.dark or self.on_dark:
            return [dict(lumMod='45000'), dict(lumMod='35000'), dict(lumMod='55000'), dict(lumMod='28000')]
        return GREYS

    @property
    def grey_role(self):
        return 'lt1' if self.on_dark and not self.dark else 'tx1'

    def dark_slide(self):
        """Roles for a slide that stays dark inside a light look (hero/title slides)."""
        c = copy.copy(self)
        c.on_dark = True
        c.ink = ('lt1', {})
        c.ink2 = ('lt1', {'lumMod': '75000'})
        c.body = ('lt1', {'lumMod': '90000'})
        c.hair = ('lt1', {'alpha': '15000'})
        c.line = ('lt1', {'alpha': '28000'})
        return c

    def flipped(self):
        c = copy.copy(self)
        c.flip_light = True
        return c

    def on_canvas(self):
        c = copy.copy(self)
        c.canvas = True
        return c

    def on_picture(self):
        c = copy.copy(self)
        c.picture_bg = True
        return c

    def tint(self, acc):
        """Pale fill of an accent that reads well on the page colour."""
        return dict(lumMod='30000') if self.dark else dict(lumMod='15000', lumOff='85000')

    def on_tint(self, acc):
        """Accent-coloured text that is legible on its tint."""
        return dict(lumMod='20000', lumOff='80000') if self.dark else dict(lumMod='60000')



def shadow(alpha=10000, blur=381000, dist=76200):
    return (f'<a:effectLst><a:outerShdw blurRad="{blur}" dist="{dist}" dir="5400000" algn="t" rotWithShape="0">'
            f'<a:srgbClr val="0F172A"><a:alpha val="{alpha}"/></a:srgbClr></a:outerShdw></a:effectLst>')


# ── schema order + insertion ─────────────────────────────────────────────────
ORDER = {
    'spPr': ['xfrm', 'custGeom', 'prstGeom', 'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill',
             'ln', 'effectLst', 'effectDag', 'scene3d', 'sp3d', 'extLst'],
    'chartSpace': ['date1904', 'lang', 'roundedCorners', 'AlternateContent', 'clrMapOvr', 'pivotSource',
                   'protection', 'chart', 'spPr', 'txPr', 'externalData', 'printSettings', 'userShapes', 'extLst'],
    'chart': ['title', 'autoTitleDeleted', 'pivotFmts', 'view3D', 'floor', 'sideWall', 'backWall', 'plotArea',
              'legend', 'plotVisOnly', 'dispBlanksAs', 'showDLblsOverMax', 'extLst'],
    'plotArea': ['layout', '*', 'dTable', 'spPr', 'extLst'],
    'catAx': ['axId', 'scaling', 'delete', 'axPos', 'majorGridlines', 'minorGridlines', 'title', 'numFmt',
              'majorTickMark', 'minorTickMark', 'tickLblPos', 'spPr', 'txPr', 'crossAx', 'crosses', 'crossesAt',
              'auto', 'lblAlgn', 'lblOffset', 'tickLblSkip', 'tickMarkSkip', 'noMultiLvlLbl', 'extLst'],
    'valAx': ['axId', 'scaling', 'delete', 'axPos', 'majorGridlines', 'minorGridlines', 'title', 'numFmt',
              'majorTickMark', 'minorTickMark', 'tickLblPos', 'spPr', 'txPr', 'crossAx', 'crosses', 'crossesAt',
              'crossBetween', 'majorUnit', 'minorUnit', 'dispUnits', 'extLst'],
    'legend': ['legendPos', 'legendEntry', 'layout', 'overlay', 'spPr', 'txPr', 'extLst'],
    'title': ['tx', 'layout', 'overlay', 'spPr', 'txPr', 'extLst'],
    'barSer': ['idx', 'order', 'tx', 'spPr', 'invertIfNegative', 'pictureOptions', 'dPt', 'dLbls', 'trendline',
               'errBars', 'cat', 'val', 'shape', 'extLst'],
    'lineSer': ['idx', 'order', 'tx', 'spPr', 'marker', 'dPt', 'dLbls', 'trendline', 'errBars', 'cat', 'val',
                'smooth', 'extLst'],
    'areaSer': ['idx', 'order', 'tx', 'spPr', 'pictureOptions', 'dPt', 'dLbls', 'trendline', 'errBars', 'cat',
                'val', 'extLst'],
    'pieSer': ['idx', 'order', 'tx', 'spPr', 'explosion', 'dPt', 'dLbls', 'cat', 'val', 'extLst'],
    'scatterSer': ['idx', 'order', 'tx', 'spPr', 'marker', 'dPt', 'dLbls', 'trendline', 'errBars', 'xVal', 'yVal',
                   'smooth', 'extLst'],
    'radarSer': ['idx', 'order', 'tx', 'spPr', 'marker', 'dPt', 'dLbls', 'cat', 'val', 'extLst'],
    'barChart': ['barDir', 'grouping', 'varyColors', 'ser', 'dLbls', 'gapWidth', 'overlap', 'serLines', 'axId',
                 'extLst'],
    'bar3DChart': ['barDir', 'grouping', 'varyColors', 'ser', 'dLbls', 'gapWidth', 'gapDepth', 'shape', 'axId',
                   'extLst'],
    'lineChart': ['grouping', 'varyColors', 'ser', 'dLbls', 'dropLines', 'hiLowLines', 'upDownBars', 'marker',
                  'smooth', 'axId', 'extLst'],
    'areaChart': ['grouping', 'varyColors', 'ser', 'dLbls', 'dropLines', 'axId', 'extLst'],
    'pieChart': ['varyColors', 'ser', 'dLbls', 'firstSliceAng', 'extLst'],
    'doughnutChart': ['varyColors', 'ser', 'dLbls', 'firstSliceAng', 'holeSize', 'extLst'],
    'dLbls': ['dLbl', 'delete', 'numFmt', 'spPr', 'txPr', 'dLblPos', 'showLegendKey', 'showVal', 'showCatName',
              'showSerName', 'showPercent', 'showBubbleSize', 'separator', 'showLeaderLines', 'leaderLines',
              'extLst'],
    'dPt': ['idx', 'invertIfNegative', 'marker', 'bubble3D', 'explosion', 'spPr', 'pictureOptions', 'extLst'],
    'marker': ['symbol', 'size', 'spPr'],
    'scaling': ['logBase', 'orientation', 'max', 'min', 'extLst'],
    'tcPr': ['lnL', 'lnR', 'lnT', 'lnB', 'lnTlToBr', 'lnBlToTr', 'cell3D', 'noFill', 'solidFill', 'gradFill',
             'blipFill', 'pattFill', 'grpFill', 'headers', 'extLst'],
    'rPr': ['ln', 'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill', 'effectLst', 'effectDag',
            'highlight', 'uLnTx', 'uLn', 'uFillTx', 'uFill', 'latin', 'ea', 'cs', 'sym', 'hlinkClick',
            'hlinkMouseOver', 'rtl', 'extLst'],
    'pPr': ['lnSpc', 'spcBef', 'spcAft', 'buClrTx', 'buClr', 'buSzTx', 'buSzPct', 'buSzPts', 'buFontTx', 'buFont',
            'buNone', 'buAutoNum', 'buChar', 'buBlip', 'tabLst', 'defRPr', 'extLst'],
    'bgPr': ['noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill', 'effectLst', 'effectDag',
             'extLst'],
}
ORDER['endParaRPr'] = ORDER['defRPr'] = ORDER['rPr']
FILLS = {'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill'}


def put(parent, el, order_key=None, replace=None):
    """Insert el into parent at its schema position, replacing existing elements named in `replace`."""
    order = ORDER.get(order_key or ln_(parent))
    name = ln_(el)
    group = replace if replace is not None else ({name} | (FILLS if name in FILLS else set()))
    for c in [c for c in parent if ln_(c) in group]:
        parent.remove(c)
    if not order:
        parent.append(el)
        return el
    star = order.index('*') if '*' in order else None

    def rank(n):
        return order.index(n) if n in order else (star if star is not None else len(order))

    r = rank(name)
    for c in parent:
        if isinstance(c.tag, str) and rank(ln_(c)) > r:
            c.addprevious(el)
            return el
    parent.append(el)
    return el


def drop(parent, *names):
    for c in [c for c in parent if ln_(c) in names]:
        parent.remove(c)


def cval(tag, v):
    return X(f'<c:{tag} val="{v}"/>')


# ── detection ────────────────────────────────────────────────────────────────
# ── detection ────────────────────────────────────────────────────────────────
def _cnv(el):
    for c in el.iter(f'{{{P}}}cNvPr'):
        return c
    return None


def _text(el, limit=48):
    s = ' / '.join(t for t in (''.join(x.text or '' for x in p.iter(f'{{{A}}}t'))
                              for p in el.iter(f'{{{A}}}p')) if t)
    return s if len(s) <= limit else s[:limit - 1] + '…'


def chart_kind(cs):
    pa = cs.find(f'.//{{{C}}}plotArea')
    names = [ln_(c) for c in pa if ln_(c).endswith('Chart')] if pa is not None else []
    if not names:
        return 'unknown'
    n = names[0]
    if n in ('barChart', 'bar3DChart'):
        bd = pa.find(f'{{{C}}}{n}/{{{C}}}barDir')
        gr = pa.find(f'{{{C}}}{n}/{{{C}}}grouping')
        base = 'bar' if bd is not None and bd.get('val') == 'bar' else 'column'
        if gr is not None and gr.get('val') in ('stacked', 'percentStacked'):
            return 'stacked' if base == 'column' else 'stacked bar'
        return base + (' + ' + names[1].replace('Chart', '') if len(names) > 1 else '')
    return n.replace('Chart', '').replace('3D', ' 3-D') + (' + more' if len(names) > 1 else '')


def classify(el, connected):
    tag = ln_(el)
    if tag == 'graphicFrame':
        gd = el.find(f'.//{{{A}}}graphicData')
        uri = gd.get('uri', '') if gd is not None else ''
        if uri.endswith('/chart'):
            return 'chart'
        if uri.endswith('/table'):
            return 'table'
        return None
    if tag == 'pic':
        if el.find(f'.//{{{A}}}videoFile') is not None or el.find(f'.//{{{A}}}audioFile') is not None:
            return None
        return 'picture'
    if tag == 'cxnSp':
        return 'flow'
    if tag != 'sp':
        return None
    ph = el.find(f'.//{{{P}}}ph')
    if ph is not None:
        t = ph.get('type', 'body')
        if t in ('title', 'ctrTitle'):
            return 'title'
        if t in ('body', 'obj') and _has_fill(el) and _geom_of(el):
            pass  # a filled content placeholder used as a box: treat it like any other shape
        elif t in ('body', 'subTitle', 'obj') and _text(el):
            return 'text'
        else:
            return None
    cnv = _cnv(el)
    sid = cnv.get('id') if cnv is not None else None
    sppr = kid(el, 'spPr')
    geom = kid(sppr, 'prstGeom') if sppr is not None else None
    prst = geom.get('prst') if geom is not None else None
    nv = kid(el, 'nvSpPr')
    if nv is not None and kid(nv, 'cNvSpPr') is not None and kid(nv, 'cNvSpPr').get('txBox') == '1':
        has_fill = sppr is not None and any(ln_(c) in ('solidFill', 'gradFill') for c in sppr)
        if not has_fill:
            return 'text' if _text(el) else None
    if prst is None:
        return None  # freeform: leave alone
    if prst.startswith('flowChart') or sid in connected:
        return 'flow'
    if prst in ('line', 'straightConnector1') or prst.startswith('actionButton'):
        return None
    xf = kid(sppr, 'xfrm')
    ext = kid(xf, 'ext') if xf is not None else None
    if ext is not None and (int(ext.get('cx', 0)) < 91440 or int(ext.get('cy', 0)) < 91440):
        return None  # hairlines / dividers
    if not _has_fill(el):
        return 'text' if _text(el) else None  # a transparent box is text, not a card
    return 'card' if prst in RECTLIKE else 'shape'


def _geom_of(el):
    sppr = kid(el, 'spPr')
    g = kid(sppr, 'prstGeom') if sppr is not None else None
    return g.get('prst') if g is not None else None


def _has_fill(el):
    sppr = kid(el, 'spPr')
    if sppr is not None:
        for c in sppr:
            n = ln_(c)
            if n == 'noFill':
                return False
            if n in ('solidFill', 'gradFill', 'pattFill', 'blipFill'):
                return True
    st = kid(el, 'style')
    ref = kid(st, 'fillRef') if st is not None else None
    return ref is not None and ref.get('idx', '0') not in ('0', '1000') and len(ref) > 0


def _box(el):
    xf = el.find(f'{{{P}}}spPr/{{{A}}}xfrm')
    if xf is None:
        return None
    off, ext = kid(xf, 'off'), kid(xf, 'ext')
    if off is None or ext is None:
        return None
    return (int(off.get('x', 0)), int(off.get('y', 0)), int(ext.get('cx', 0)), int(ext.get('cy', 0)),
            int(xf.get('rot', 0)) % 21600000, xf.get('flipH') == '1', xf.get('flipV') == '1')


def _ends(cxn):
    b = _box(cxn)
    if b is None:
        return []
    x, y, w, h, rot, fh, fv = b
    cx, cy = x + w / 2, y + h / 2
    pts = [(x + (w if fh else 0), y + (h if fv else 0)), (x + (0 if fh else w), y + (0 if fv else h))]
    if rot in (5400000, 16200000):  # quarter turns: rotate the end points round the centre
        sgn = 1 if rot == 5400000 else -1
        pts = [(cx - sgn * (py - cy), cy + sgn * (px - cx)) for px, py in pts]
    return pts


def flow_nodes(tree):
    """Shape ids that belong to a diagram: glued to a connector, or touching an arrow's end."""
    ids = {x.get('id') for x in tree.iter() if ln_(x) in ('stCxn', 'endCxn')}
    arrows = []
    for c in tree.iter(f'{{{P}}}cxnSp'):
        ln = c.find(f'{{{P}}}spPr/{{{A}}}ln')
        has_head = ln is not None and any(kid(ln, e) is not None and kid(ln, e).get('type', 'none') != 'none'
                                          for e in ('headEnd', 'tailEnd'))
        if has_head or c.find(f'.//{{{A}}}stCxn') is not None or c.find(f'.//{{{A}}}endCxn') is not None:
            arrows.append(c)
    if len(arrows) < 2:
        return ids
    pad = 0.25 * EMU_IN
    pts = [pt for c in arrows if c.getparent() is tree for pt in _ends(c)]
    for el in tree:
        if ln_(el) != 'sp' or not _has_fill(el):
            continue
        b = _box(el)
        if b is None or len(_text(el, 200)) > 70:
            continue
        x, y, w, h = b[:4]
        if any(x - pad <= px <= x + w + pad and y - pad <= py <= y + h + pad for px, py in pts):
            cnv = _cnv(el)
            if cnv is not None:
                ids.add(cnv.get('id'))
    return ids


def _walk(tree):
    for c in tree:
        if ln_(c) == 'grpSp':
            yield from _walk(c)
        elif ln_(c) in ('sp', 'pic', 'cxnSp', 'graphicFrame'):
            yield c


def detect(data_or_prs):
    prs = data_or_prs if hasattr(data_or_prs, 'slides') else Presentation(io.BytesIO(data_or_prs))
    out = []
    for n, s in enumerate(prs.slides, 1):
        tree = s.shapes._spTree
        connected = flow_nodes(tree)
        out.append({'id': f'{n}:bg', 'slide': n, 'kind': 'background', 'name': 'Slide background',
                    'detail': 'picture' if s._element.find(f'.//{{{A}}}blipFill') is not None and
                    s._element.find(f'.//{{{P}}}bg') is not None else ''})
        for el in _walk(tree):
            kind = classify(el, connected)
            if not kind:
                continue
            cnv = _cnv(el)
            item = {'id': f"{n}:{cnv.get('id')}", 'slide': n, 'kind': kind, 'name': cnv.get('name', ''),
                    'detail': _text(el)}
            if kind == 'chart':
                part = _chart_part(s, el)
                item['detail'] = chart_kind(part._element) if part is not None else ''
                item['chart_type'] = item['detail']
            elif kind == 'table':
                tbl = el.find(f'.//{{{A}}}tbl')
                item['detail'] = f"{len(kids(tbl, 'tr'))} × {len(kids(kid(tbl, 'tblGrid'), 'gridCol'))}"
                item['numeric'] = is_numeric_table(el)
            elif kind == 'flow' and ln_(el) == 'cxnSp':
                item['detail'] = 'connector'
            out.append(item)
    return out


def _chart_part(slide, gf):
    ref = gf.find(f'.//{{{C}}}chart')
    if ref is None:
        return None
    try:
        return slide.part.related_part(ref.get(f'{{{R}}}id'))
    except KeyError:
        return None



# ── run helpers ──────────────────────────────────────────────────────────────
def _runs(el):
    return [x for x in el.iter() if ln_(x) in ('r', 'fld')]


def _rpr(r):
    rpr = kid(r, 'rPr')
    if rpr is None:
        rpr = X('<a:rPr/>')
        r.insert(0, rpr)
    return rpr


def _set_font(rpr, face):
    put(rpr, X(f'<a:latin typeface="{face}"/>'))


def _is_light_run(rpr):
    f = kid(rpr, 'solidFill')
    if f is None or not len(f):
        return False
    c = f[0]
    if ln_(c) == 'schemeClr':
        return c.get('val') in ('bg1', 'lt1', 'bg2', 'lt2')
    if ln_(c) == 'srgbClr':
        v = c.get('val', '000000')
        r, g, b = (int(v[i:i + 2], 16) for i in (0, 2, 4))
        return 0.2126 * r + 0.7152 * g + 0.0722 * b > 160
    return False


def _title_align(slide, el):
    p = el.find(f'.//{{{A}}}p/{{{A}}}pPr')
    if p is not None and p.get('algn'):
        return p.get('algn')
    try:
        lay = slide.slide_layout
        for ph in lay.placeholders:
            if 'TITLE' in str(ph.placeholder_format.type):
                lv = ph._element.find(f'.//{{{A}}}lstStyle/{{{A}}}lvl1pPr')
                if lv is not None and lv.get('algn'):
                    return lv.get('algn')
        ts = lay.slide_master._element.find(f'.//{{{P}}}titleStyle/{{{A}}}lvl1pPr')
        if ts is not None:
            return ts.get('algn', 'l')
    except Exception:  # noqa: BLE001
        pass
    return 'l'


def _is_neutral_run(rpr):
    f = kid(rpr, 'solidFill')
    if f is None or not len(f):
        return True
    c = f[0]
    if ln_(c) == 'schemeClr':
        return c.get('val') in ('tx1', 'tx2', 'dk1', 'dk2', 'bg1', 'bg2', 'lt1', 'lt2')
    if ln_(c) == 'srgbClr':
        v = c.get('val', '000000')
        r, g, b = (int(v[i:i + 2], 16) for i in (0, 2, 4))
        return max(r, g, b) - min(r, g, b) < 40
    return True



# ── chart type switching ─────────────────────────────────────────────────────
SER_ORDER = {'barChart': 'barSer', 'bar3DChart': 'barSer', 'lineChart': 'lineSer', 'line3DChart': 'lineSer',
             'areaChart': 'areaSer', 'area3DChart': 'areaSer', 'pieChart': 'pieSer', 'pie3DChart': 'pieSer',
             'doughnutChart': 'pieSer', 'scatterChart': 'scatterSer', 'radarChart': 'radarSer',
             'bubbleChart': 'scatterSer'}
AXIS_FAMILY = {'barChart', 'lineChart', 'areaChart'}
PIE_FAMILY = {'pieChart', 'doughnutChart'}


def _switch_type(cs, target):
    """Change chart type within the axis family (column/bar/stacked/line/area) or pie family."""
    pa = cs.find(f'.//{{{C}}}plotArea')
    plots = [c for c in pa if ln_(c).endswith('Chart')]
    if len(plots) != 1:
        return False
    old = plots[0]
    oname = ln_(old)
    axis_target = target in ('column', 'bar', 'stacked', 'line', 'area')
    if axis_target and oname not in AXIS_FAMILY | PIE_FAMILY:
        return False
    if target in ('pie', 'doughnut') and oname not in PIE_FAMILY | AXIS_FAMILY:
        return False
    if target in ('pie', 'doughnut') and oname in AXIS_FAMILY and len(kids(old, 'ser')) > 1:
        # a pie can only show one series: keep the first
        for s in kids(old, 'ser')[1:]:
            old.remove(s)
    new_name = {'column': 'barChart', 'bar': 'barChart', 'stacked': 'barChart', 'line': 'lineChart',
                'area': 'areaChart', 'pie': 'pieChart', 'doughnut': 'doughnutChart'}[target]
    new = etree.SubElement(pa, f'{{{C}}}{new_name}')
    pa.remove(new)
    if new_name == 'barChart':
        new.append(cval('barDir', 'bar' if target == 'bar' else 'col'))
        new.append(cval('grouping', 'stacked' if target == 'stacked' else 'clustered'))
    elif new_name in ('lineChart', 'areaChart'):
        new.append(cval('grouping', 'standard'))
    new.append(cval('varyColors', '1' if new_name in PIE_FAMILY else '0'))
    keep = {'idx', 'order', 'tx', 'spPr', 'cat', 'val', 'dLbls', 'dPt'}
    for s in kids(old, 'ser'):
        ns = etree.SubElement(new, f'{{{C}}}ser')
        okey = SER_ORDER[new_name]
        for c in s:
            if ln_(c) in keep:
                put(ns, copy.deepcopy(c), okey, replace=set())
        if new_name == 'barChart':
            put(ns, cval('invertIfNegative', '0'), okey)
        if new_name == 'lineChart':
            put(ns, X('<c:marker><c:symbol val="circle"/><c:size val="6"/></c:marker>'), okey)
            put(ns, cval('smooth', '0'), okey)
        if new_name not in PIE_FAMILY:
            drop(ns, 'dPt')
    if new_name == 'barChart':
        new.append(cval('gapWidth', '80'))
        if target == 'stacked':
            new.append(cval('overlap', '100'))
    if new_name == 'lineChart':
        new.append(cval('marker', '1'))
    if new_name in PIE_FAMILY:
        new.append(cval('firstSliceAng', '0'))
        if new_name == 'doughnutChart':
            new.append(cval('holeSize', '62'))
        for ax in [c for c in pa if ln_(c) in ('catAx', 'valAx', 'dateAx', 'serAx')]:
            pa.remove(ax)
    else:
        axes = [c for c in pa if ln_(c) in ('catAx', 'valAx', 'dateAx')]
        if not axes:  # coming from a pie: add a category and a value axis
            axes = [X('<c:catAx><c:axId val="50010"/><c:scaling><c:orientation val="minMax"/></c:scaling>'
                      '<c:delete val="0"/><c:axPos val="b"/><c:numFmt formatCode="General" sourceLinked="1"/>'
                      '<c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/>'
                      '<c:crossAx val="50020"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/>'
                      '<c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx>'),
                    X('<c:valAx><c:axId val="50020"/><c:scaling><c:orientation val="minMax"/></c:scaling>'
                      '<c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:numFmt formatCode="General" '
                      'sourceLinked="1"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/>'
                      '<c:tickLblPos val="nextTo"/><c:crossAx val="50010"/><c:crosses val="autoZero"/>'
                      '<c:crossBetween val="between"/></c:valAx>')]
            last = old
            for ax in axes:
                last.addnext(ax)
                last = ax
        for ax in axes:
            new.append(cval('axId', kid(ax, 'axId').get('val')))
        cat = next((a for a in axes if ln_(a) in ('catAx', 'dateAx')), None)
        val = next((a for a in axes if ln_(a) == 'valAx'), None)
        if cat is not None and val is not None:
            horiz = target == 'bar'
            kid(cat, 'axPos').set('val', 'l' if horiz else 'b')
            kid(val, 'axPos').set('val', 'b' if horiz else 'l')
            cb = kid(val, 'crossBetween')
            if cb is not None:
                cb.set('val', 'midCat' if new_name == 'areaChart' else 'between')
    old.addprevious(new)
    pa.remove(old)
    return True


def _picture_background(slide):
    """True when the slide shows an image background, its own or inherited from layout/master."""
    for owner in (slide, slide.slide_layout, slide.slide_layout.slide_master):
        bg = owner._element.find(f'{{{P}}}cSld/{{{P}}}bg')
        if bg is not None:
            return bg.find(f'.//{{{A}}}blipFill') is not None
        if owner is not slide:
            # a full-slide picture placed on the layout/master works as a background too
            for pic in owner._element.iter(f'{{{P}}}pic'):
                ext = pic.find(f'.//{{{A}}}ext')
                if ext is not None and int(ext.get('cx', 0)) > 0.8 * slide.part.package.presentation_part.presentation.slide_width:
                    return True
    return False




def catalogue():
    return {'styles': {k: [{'id': i, 'name': n, 'desc': d} for i, n, d in v] for k, v in STYLES.items()},
            'chart_types': [{'id': i, 'name': n} for i, n in CHART_TYPES], 'kinds': KIND_LABEL,
            'containers': [{'id': i, 'name': n, 'desc': d} for i, n, d in CONTAINERS],
            'icon_modes': [{'id': i, 'name': n} for i, n in ICON_MODES], 'icons': _icon_picker(),
            'legends': [{'id': i, 'name': n} for i, n in LEGENDS]}


def _icon_picker():
    from .icons import PICKER
    return PICKER


# ── geometry helpers ─────────────────────────────────────────────────────────
def _ext(sppr):
    xf = kid(sppr, 'xfrm') if sppr is not None else None
    off = kid(xf, 'off') if xf is not None else None
    ext = kid(xf, 'ext') if xf is not None else None
    if off is None or ext is None:
        return None
    return int(off.get('x')), int(off.get('y')), int(ext.get('cx')), int(ext.get('cy'))


def _round(sppr, radius=RADIUS, pill=False):
    """Rounded rectangle with the same corner radius whatever the size."""
    box = _ext(sppr)
    adj = 50000 if pill or box is None else max(2500, min(50000, int(radius / max(1, min(box[2], box[3])) * 100000)))
    put(sppr, X(f'<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val {adj}"/></a:avLst></a:prstGeom>'),
        replace={'prstGeom', 'custGeom'})


def _geom(sppr, prst):
    put(sppr, X(f'<a:prstGeom prst="{prst}"><a:avLst/></a:prstGeom>'), replace={'prstGeom', 'custGeom'})


def _clean_sppr(sppr):
    """Strip dated effects: bevels, 3-D, glow, reflection, shadows, rotation.

    An explicit empty effect list also overrides shadows that come from the theme's shape style."""
    drop(sppr, 'effectLst', 'effectDag', 'scene3d', 'sp3d')
    put(sppr, X('<a:effectLst/>'))
    style = kid(sppr.getparent(), 'style')
    if style is not None:  # theme shape styles add Office-2007 shadows/bevels: switch those references off
        for ref in style:
            if ln_(ref) == 'effectRef':
                ref.set('idx', '0')
    xf = kid(sppr, 'xfrm')
    if xf is not None and ln_(sppr.getparent()) != 'cxnSp':
        rot = int(xf.get('rot', 0)) % 21600000
        if rot and (rot < 900000 or rot > 20700000):  # a dated jaunty tilt (<15°) is straightened;
            xf.attrib.pop('rot', None)                # real rotations (vertical labels…) are kept


def _no_line():
    return X('<a:ln><a:noFill/></a:ln>')


def _line(w, val, **mods):
    return X(f'<a:ln w="{w}">{solid(val, **mods)}</a:ln>')


def _new_id(tree):
    root = tree.getroottree().getroot()
    ids = [int(x.get('id')) for x in root.iter(f'{{{P}}}cNvPr') if x.get('id', '').isdigit()]
    return max(ids or [1]) + 1


def _add_bar(after_el, x, y, w, h, fill_xml, name):
    nid = _new_id(after_el)
    bar = X(f'<p:sp><p:nvSpPr><p:cNvPr id="{nid}" name="{name} {nid}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{int(x)}" y="{int(y)}"/><a:ext cx="{int(w)}" cy="{int(h)}"/></a:xfrm>'
            f'<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 50000"/></a:avLst></a:prstGeom>'
            f'{fill_xml}<a:ln><a:noFill/></a:ln></p:spPr></p:sp>')
    after_el.addnext(bar)
    return bar


# ── text helpers ─────────────────────────────────────────────────────────────
def _autofit(el):
    """New fonts can be wider than the old ones: let text shrink rather than spill."""
    bp = el.find(f'.//{{{A}}}bodyPr')
    if bp is not None and kid(bp, 'spAutoFit') is None and kid(bp, 'normAutofit') is None:
        drop(bp, 'noAutofit')
        bp.insert(0 if kid(bp, 'prstTxWarp') is None else 1, X('<a:normAutofit/>'))


def _paint_text(el, first, rest, headline_font=True, bold_first=True, align=None, insets=None):
    """Recolour/refont the text of a shape: first paragraph = headline, others = supporting text."""
    body = kid(el, 'txBody')
    if body is None:
        return
    bp = kid(body, 'bodyPr')
    if bp is not None and insets:
        for k, v in insets.items():
            bp.set(k, str(int(v)))
    _autofit(el)
    paras = [p for p in kids(body, 'p') if any(ln_(c) in ('r', 'fld') for c in p)]
    for i, p in enumerate(paras):
        if align:
            ppr = kid(p, 'pPr')
            if ppr is None:
                ppr = X('<a:pPr/>')
                p.insert(0, ppr)
            ppr.set('algn', align)
        role = first if i == 0 else rest
        for r in [c for c in p if ln_(c) in ('r', 'fld')]:
            rpr = _rpr(r)
            put(rpr, X(solid(role[0], **role[1])))
            drop(rpr, 'effectLst', 'ln', 'highlight')
            rpr.attrib.pop('cap', None)
            _set_font(rpr, '+mj-lt' if (i == 0 and headline_font) else '+mn-lt')
            if i == 0 and bold_first:
                rpr.set('b', '1')
        end = kid(p, 'endParaRPr')
        if end is not None:
            put(end, X(solid(role[0], **role[1])))
    for p in kids(body, 'p'):  # empty paragraphs keep the colour for typing later
        end = kid(p, 'endParaRPr')
        if end is not None and not any(ln_(c) in ('r', 'fld') for c in p):
            put(end, X(solid(rest[0], **rest[1])))


INSETS = {'lIns': 0.18 * EMU_IN, 'rIns': 0.18 * EMU_IN, 'tIns': 0.12 * EMU_IN, 'bIns': 0.12 * EMU_IN}


def _next_accent(accent, step=1):
    if re.fullmatch(r'[0-9A-Fa-f]{6}', str(accent)):  # a custom colour: its deeper shade
        return _lummod(accent.upper(), 72, 0)
    return ACCENTS[(ACCENTS.index(accent) + step) % 6] if accent in ACCENTS else 'accent2'


def _grad(a, b, ang=2700000):
    """Two-colour linear gradient between theme roles (45° by default)."""
    return (f'<a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0">{clr(a)}</a:gs><a:gs pos="100000">{clr(b)}</a:gs>'
            f'</a:gsLst><a:lin ang="{ang}" scaled="0"/></a:gradFill>')


def _wash(ctx, acc, strength):
    """A very light wash of an accent for backgrounds (a darker wash on dark pages)."""
    if ctx.dark or ctx.on_dark:
        return clr(acc, lumMod=str(int(strength * 1.8 * 1000)))
    return clr(acc, lumMod=str(strength * 1000), lumOff=str((100 - strength) * 1000))


def _is_darkish(ctx):
    return ctx.dark or ctx.on_dark


T1 = ('tx1', {})
T2 = ('tx1', {'lumMod': '65000', 'lumOff': '35000'})


# ── cards and shapes ─────────────────────────────────────────────────────────
# ── KPI cards ────────────────────────────────────────────────────────────────
CARD_R = int(0.14 * EMU_IN)
SOFT_SHADOW = dict(alpha=7000, blur=152400, dist=25400)
UP_RX = re.compile(r'^\s*(\+|▲|↑|up\b)', re.I)
DOWN_RX = re.compile(r'^\s*(-|−|–|▼|↓|down\b)', re.I)
VALUE_RX = re.compile(r'^(?P<pre>[^\d+\-−–.]*?)(?P<num>[+\-−–]?[\d][\d.,]*)(?P<unit>.*)$', re.S)

# surface · layout · default chip · value colour · value weight
KPI = {
    'kpi': dict(surface='card', layout='stack', chip='solid'),
    'kpi-side': dict(surface='card', layout='side', chip='solid'),
    'kpi-header': dict(surface='card', layout='header', chip='circle', value='accent'),
    'kpi-corner': dict(surface='card', layout='corner', chip='soft'),
    'kpi-accent': dict(surface='card', deco='top', layout='stack', chip='soft'),
    'kpi-bar': dict(surface='card', deco='left', layout='stack', chip='soft'),
    'kpi-circle': dict(surface='card', layout='center', chip='circle'),
    'kpi-tint': dict(surface='tint', layout='stack', chip='white', value='accent'),
    'kpi-soft': dict(surface='soft', layout='stack', chip='solid'),
    'kpi-float': dict(surface='float', layout='stack', chip='solid'),
    'kpi-outline': dict(surface='outline', layout='stack', chip='ring'),
    'kpi-solid': dict(surface='solid', layout='stack', chip='glass'),
    'kpi-gradient': dict(surface='gradient', layout='stack', chip='glass'),
    'kpi-tile': dict(surface='tile', layout='tile', chip=None),
    'kpi-hero': dict(surface='hero', layout='hero', chip='halo'),
    'kpi-light': dict(surface='none', layout='plain', chip=None, weight='light'),
    'kpi-spotlight': dict(surface='none', layout='plain', chip=None, weight='light'),
    'kpi-strip': dict(surface='none', layout='side', chip='solid'),
    'kpi-minimal': dict(surface='none', layout='stack', chip='bare'),
}
ON_COLOUR = ('solid', 'gradient', 'tile', 'hero')  # surfaces that take white text


def _para_text(p):
    return ''.join(t.text or '' for t in p.iter(f'{{{A}}}t')).strip()


def _is_value(t):
    """'$4.2M', '+24%', '98%', '1,204', '3 new' – a short figure, not a sentence."""
    t = (t or '').strip()
    return bool(t) and len(t) <= 18 and re.search(r'\d', t) is not None and len(t.split()) <= 3


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


def _new_sp(after_el, xml):
    el = X(xml)
    after_el.addnext(el)
    return el


def _chip(after_el, x, y, size, fill_xml, line_xml='<a:ln><a:noFill/></a:ln>', circle=False, name='Icon chip'):
    nid = _new_id(after_el)
    geom = '<a:prstGeom prst="ellipse"><a:avLst/></a:prstGeom>' if circle else \
        '<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 28000"/></a:avLst></a:prstGeom>'
    return _new_sp(after_el, f'<p:sp><p:nvSpPr><p:cNvPr id="{nid}" name="{name} {nid}"/><p:cNvSpPr/><p:nvPr/>'
                             f'</p:nvSpPr><p:spPr><a:xfrm><a:off x="{int(x)}" y="{int(y)}"/><a:ext cx="{int(size)}" '
                             f'cy="{int(size)}"/></a:xfrm>{geom}{fill_xml}{line_xml}</p:spPr></p:sp>')


def _icon(after_el, name, x, y, size, fill_xml, filled=False):
    from . import icons
    nid = _new_id(after_el)
    el = etree.fromstring(icons.shape_xml(nid, name, x, y, size, fill_xml, filled, NSDECL))
    after_el.addnext(el)
    return el


def _text_box(after_el, x, y, w, h, paras_xml, anchor='ctr', name='Text'):
    nid = _new_id(after_el)
    return _new_sp(after_el, f'<p:sp><p:nvSpPr><p:cNvPr id="{nid}" name="{name} {nid}"/><p:cNvSpPr txBox="1"/>'
                             f'<p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="{int(x)}" y="{int(y)}"/><a:ext '
                             f'cx="{int(w)}" cy="{int(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
                             f'<a:noFill/></p:spPr><p:txBody><a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" '
                             f'bIns="0" anchor="{anchor}"><a:normAutofit/></a:bodyPr><a:lstStyle/>{paras_xml}'
                             f'</p:txBody></p:sp>')


def _kpi_roles(el, value_first=False):
    body = kid(el, 'txBody')
    paras = [p for p in kids(body, 'p') if any(ln_(c) in ('r', 'fld') for c in p)] if body is not None else []
    texts = [_para_text(p) for p in paras]
    if len(paras) >= 2 and _is_value(texts[0]) and not _is_value(texts[1]):
        return paras, ['value', 'label'] + ['note'] * (len(paras) - 2), not value_first
    if len(paras) >= 2 and _is_value(texts[1]):
        return paras, ['label', 'value'] + ['note'] * (len(paras) - 2), value_first
    if paras and _is_value(texts[0]):
        return paras, ['value'] + ['note'] * (len(paras) - 1), False
    return paras, ['head'] + ['body'] * (len(paras) - 1), False


def _kpi_size(role, orig, value_max):
    big = value_max >= 3200  # roomy cards get a larger label too
    if role == 'value':  # the figure fills the card; _kpi_text narrows it to the width
        return value_max
    if role == 'head':
        return _clamp(orig or 1800, 1400, 2000)
    if role == 'note':
        return _clamp(orig or 1100, 1000, 1300 if big else 1200)
    return _clamp(orig or 1400, 1200 if big else 1100, 1600 if big else 1400)


def _kpi_value_max(card_h, hero=False):
    if hero:
        return _clamp(int((14 + card_h / EMU_IN * 14) * 100), 2400, 5400)
    return _clamp(int((12 + card_h / EMU_IN * 11) * 100), 2200, 4000)


def _kpi_text_height(el, card_h, width, hero=False):
    """Rough height of the label/value block, so icon and text can be centred together."""
    paras, roles, _ = _kpi_roles(el)
    vmax = _kpi_value_max(card_h, hero)
    total = 0
    for p, role in zip(paras, roles):
        runs = [c for c in p if ln_(c) in ('r', 'fld')]
        orig = max((int(_rpr(r).get('sz') or 0) for r in runs), default=0)
        size = _kpi_size(role, orig, vmax) / 100 * 12700  # EMU per line
        chars = len(_para_text(p))
        per_line = max(1, int(width / (size * 0.55))) if size else 40
        lines = max(1, -(-chars // per_line))
        total += size * 1.2 * lines + {'label': 3, 'head': 4}.get(role, 2) * 12700
    return total


WORDY = re.compile(r'[A-Za-z]{2,}')


def _value_parts(text, split_words=True):
    """(prefix, figure, unit, trailing words, prefix-is-words) of a KPI value, or None."""
    m = VALUE_RX.match(text.strip())
    if not m:
        return None
    lead = text[:len(text) - len(text.lstrip())]
    pre, num, unit, tail = lead + m.group('pre'), m.group('num'), m.group('unit'), ''
    if split_words:
        um = re.match(r'^(\S*?)(\s+.*)$', unit, re.S)
        if um and WORDY.search(um.group(2)) and not WORDY.fullmatch(um.group(1) or '-'):
            unit, tail = um.group(1), um.group(2)
    words_pre = bool(split_words and WORDY.search(pre) and len(pre.strip()) >= 3)
    return pre, num, unit, tail, words_pre


def _value_width(text):
    """Width of the big figure line in ems (small prefix/unit count for less)."""
    vp = _value_parts(text)
    if not vp:
        return max(1, len(text.strip())) * 0.6
    pre, num, unit, tail, words_pre = vp
    return 0.6 * (len(num) + 0.55 * len(unit) + (0 if words_pre else 0.6 * len(pre)))


def _split_value(p, size, label_size=None, muted=None):
    """'$817.5K' → small '$', big '817.5', small 'K' (the modern dashboard number).
    Words around the figure become their own muted line: 'Sales up 12%' → 'Sales up' over a big
    '12%', '3 new offices' → a big '3' over 'new offices' – the label/value pair of a KPI card."""
    runs = [c for c in p if ln_(c) == 'r']
    if not runs or any(ln_(c) == 'fld' for c in p):
        return
    text = ''.join((r.find(f'{{{A}}}t').text or '') if r.find(f'{{{A}}}t') is not None else '' for r in runs)
    vp = _value_parts(text, bool(label_size and muted))
    if not vp:
        return
    pre, num, unit, tail, words_pre = vp
    if not (pre.strip() or unit.strip() or tail.strip()):
        return
    parts = [(pre, 'label' if words_pre else 0.6), ('\n' if words_pre else '', 'br'), (num, 1.0),
             (unit, 0.55), ('\n' if tail else '', 'br'), (tail, 'label')]
    template = runs[0]
    for r in runs:
        p.remove(r)
    anchor = kid(p, 'pPr')
    for chunk, ratio in reversed([pt for pt in parts if pt[0]]):
        if ratio == 'br':
            r = X('<a:br/>')
            br_rpr = copy.deepcopy(_rpr(template))
            br_rpr.set('sz', str(int(label_size)))
            r.append(br_rpr)
        else:
            r = copy.deepcopy(template)
            r.find(f'{{{A}}}t').text = chunk.strip() if ratio == 'label' else chunk
            rpr = _rpr(r)
            if ratio == 'label':
                rpr.set('sz', str(int(label_size)))
                rpr.set('b', '0')
                rpr.attrib.pop('spc', None)
                put(rpr, X(solid(muted[0], **muted[1])))
                _set_font(rpr, '+mn-lt')
            else:
                rpr.set('sz', str(int(size * ratio)))
        if anchor is not None:
            anchor.addnext(r)
        else:
            p.insert(0, r)


def _kpi_text(el, palette, align, insets, anchor, card_h, value_col=None, light_font=None, hero=False,
              value_first=False, skip_label=False, sizes=None):
    """Label above a big value; extra lines become muted notes (green/red when they read as a change)."""
    body = kid(el, 'txBody')
    if body is None:
        return
    paras, roles, swap = _kpi_roles(el, value_first)
    if skip_label and paras:  # the label now lives in the card header: figure first, then notes
        vi = next((i for i, p in enumerate(paras) if _is_value(_para_text(p))), 0)
        if vi:
            paras[0].addprevious(paras[vi])
            paras = [paras[vi]] + paras[:vi] + paras[vi + 1:]
        roles, swap = ['value'] + ['note'] * (len(paras) - 1), False
    if swap:
        paras[0].addprevious(paras[1])
        paras = [paras[1], paras[0]] + paras[2:]
        roles = [roles[1], roles[0]] + roles[2:]
    bp = kid(body, 'bodyPr')
    for k, v in insets.items():
        bp.set(k, str(int(v)))
    bp.set('anchor', anchor)
    bp.set('wrap', 'square')
    _autofit(el)
    value_max = _kpi_value_max(card_h, hero)
    fixed_value, fixed_label = (int(sizes[0] * 100) if sizes and sizes[0] else 0,
                                int(sizes[1] * 100) if sizes and sizes[1] else 0)
    if fixed_value:
        value_max = fixed_value
    ext = el.find(f'.//{{{A}}}xfrm/{{{A}}}ext')
    room = (int(ext.get('cx')) - int(insets.get('lIns', 91440)) - int(insets.get('rIns', 91440))) \
        if ext is not None else 0
    ink, muted = palette
    for p, role in zip(paras, roles):
        ppr = kid(p, 'pPr')
        if ppr is None:
            ppr = X('<a:pPr/>')
            p.insert(0, ppr)
        ppr.set('algn', align)
        ppr.set('marL', '0')
        ppr.set('indent', '0')
        put(ppr, X('<a:lnSpc><a:spcPct val="100000"/></a:lnSpc>'))
        put(ppr, X('<a:spcBef><a:spcPts val="0"/></a:spcBef>'))
        put(ppr, X(f'<a:spcAft><a:spcPts val="{ {"label": 300, "head": 400}.get(role, 200) }"/></a:spcAft>'))
        put(ppr, X('<a:buNone/>'), replace={'buNone', 'buChar', 'buAutoNum', 'buBlip'})
        txt = _para_text(p)
        size = 0
        for r in [c for c in p if ln_(c) in ('r', 'fld')]:
            rpr = _rpr(r)
            orig = int(rpr.get('sz') or 0)
            drop(rpr, 'effectLst', 'ln', 'highlight', 'gradFill')
            rpr.attrib.pop('cap', None)
            rpr.attrib.pop('i', None)
            col = muted
            size = _kpi_size(role, orig, value_max)
            if role in ('label', 'head') and fixed_label:
                size = fixed_label
            if role == 'value' and room > 0 and not fixed_value:  # never wider than the card: shrink long figures
                fit = int(room / 12700 / max(_value_width(txt), 0.6) * 100) // 100 * 100
                size = max(1600, min(size, fit))
            if role == 'value':
                bold, font = ('0', '+mj-lt') if light_font else ('1', '+mj-lt')
                col = value_col or ink
                if light_font:
                    font = light_font
                rpr.set('spc', '-20' if not light_font else '-10')
            elif role == 'head':
                bold, col, font = '1', ink, '+mj-lt'
            elif role == 'note':
                bold, font = '0', '+mn-lt'
                if UP_RX.match(txt) and ink[0] != 'lt1':
                    col, bold = ('059669', {}), '1'
                elif DOWN_RX.match(txt) and ink[0] != 'lt1':
                    col, bold = ('E11D48', {}), '1'
            elif role == 'label':
                bold, font = ('1', '+mn-lt') if hero else ('0', '+mn-lt')
                if hero:
                    col = ink
            else:
                bold, font = '0', '+mn-lt'
            rpr.set('sz', str(size))
            rpr.set('b', bold)
            put(rpr, X(solid(col[0], **col[1])))
            _set_font(rpr, font)
        if role == 'value' and size:
            _split_value(p, size, fixed_label or _kpi_size('label', 0, value_max), muted)
        end = kid(p, 'endParaRPr')
        if end is not None:
            put(end, X(solid(muted[0], **muted[1])))


def _take_label(el):
    """Remove and return the label paragraph (for header layouts that show it beside the icon)."""
    paras, roles, _ = _kpi_roles(el)
    for p, role in zip(paras, roles):
        if role in ('label', 'head') and len(paras) > 1:
            p.getparent().remove(p)
            return p
    return None


def _card_surface(sppr, surface, accent, ctx, box):
    hair = _line(9525, *ctx.hair[:1], **ctx.hair[1])
    radius = int(0.05 * EMU_IN) if surface == 'hero' else int(CARD_R * 0.75) if surface == 'tile' else CARD_R
    if surface != 'none':
        adj = _clamp(int(radius / max(1, min(box[2], box[3])) * 100000), 2500, 50000) if box else 16667
        put(sppr, X(f'<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val {adj}"/></a:avLst>'
                    f'</a:prstGeom>'), replace={'prstGeom', 'custGeom'})
    if surface == 'card':
        put(sppr, X(solid('bg1')))
        put(sppr, hair)
        put(sppr, X(shadow(**SOFT_SHADOW)), replace={'effectLst', 'effectDag'})
    elif surface == 'tint':
        put(sppr, X(solid(accent, lumMod='9000', lumOff='91000')))
        put(sppr, _no_line())
    elif surface == 'soft':
        put(sppr, X(solid('bg1' if ctx.canvas else 'bg2')))
        put(sppr, _no_line())
    elif surface == 'float':
        put(sppr, X(solid('bg1')))
        put(sppr, _no_line())
        put(sppr, X(shadow(alpha=12000, blur=508000, dist=101600)), replace={'effectLst', 'effectDag'})
    elif surface == 'outline':
        put(sppr, X(solid('bg1')))
        put(sppr, _line(12700, *ctx.line[:1], **ctx.line[1]))
    elif surface == 'solid':
        put(sppr, X(solid(accent)))
        put(sppr, _no_line())
        put(sppr, X(shadow(alpha=9000, blur=203200, dist=50800)), replace={'effectLst', 'effectDag'})
    elif surface == 'gradient':
        put(sppr, X(_grad(accent, _next_accent(accent))))
        put(sppr, _no_line())
        put(sppr, X(shadow(alpha=9000, blur=203200, dist=50800)), replace={'effectLst', 'effectDag'})
    elif surface == 'tile':
        put(sppr, X(f'<a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0">{clr(accent, lumMod="90000", lumOff="10000")}'
                    f'</a:gs><a:gs pos="100000">{clr(accent, lumMod="80000")}</a:gs></a:gsLst>'
                    f'<a:lin ang="2700000" scaled="0"/></a:gradFill>'))
        put(sppr, _no_line())
        put(sppr, X(shadow(alpha=10000, blur=228600, dist=50800)), replace={'effectLst', 'effectDag'})
    elif surface == 'hero':
        put(sppr, X(solid(accent)))
        put(sppr, _no_line())
    else:  # none
        put(sppr, X('<a:noFill/>'))
        put(sppr, _no_line())


def _chip_paint(mode, accent, on_colour):
    """(chip fill, chip line, icon fill) for an icon mode."""
    none = '<a:ln><a:noFill/></a:ln>'
    if on_colour and mode not in ('bare', 'halo'):
        return solid('lt1', alpha='22000'), none, solid('lt1')
    if mode in ('solid', 'circle'):
        return solid(accent), none, solid('lt1')
    if mode == 'soft':
        return solid(accent, lumMod='12000', lumOff='88000'), none, solid(accent)
    if mode == 'ring':
        return '<a:noFill/>', f'<a:ln w="12700">{solid(accent)}</a:ln>', solid(accent)
    if mode == 'white':
        return solid('bg1'), none, solid(accent)
    if mode == 'halo':
        return solid('lt1', alpha='18000'), none, solid('lt1')
    return '<a:noFill/>', none, solid('lt1' if on_colour else accent)  # bare


def _card_style(el, style, accent, ctx, icon=None, icon_mode='auto', pos=(0, 1), custom=None):
    """custom: the settings of a custom design (see custom.FIELDS['card'])."""
    from . import icons as _icons
    sppr = kid(el, 'spPr')
    if sppr is None or style not in KPI:
        return False
    spec = dict(KPI[style])
    if custom:
        spec.update(surface=custom['surface'], layout=custom['layout'], chip=custom['chip'], value=custom['value'],
                    weight=custom['weight'], deco=None if custom['deco'] == 'none' else custom['deco'])
    elif style == 'kpi-spotlight':  # one highlighted card, the rest are light numbers on the page
        if pos[0] == pos[1] // 2 and pos[1] > 1:
            spec.update(surface='solid', layout='plain')
            accent = _next_accent('accent1')
    box = _ext(sppr)
    _clean_sppr(sppr)
    x, y, w, h = box if box else (0, 0, int(2.5 * EMU_IN), int(1.5 * EMU_IN))
    surface, layout = spec['surface'], spec['layout']
    _card_surface(sppr, surface, accent, ctx, box)
    on_colour = surface in ON_COLOUR
    sizes = None
    if custom:
        from . import custom as _custom
        _custom._card_fill(sppr, custom, accent, surface, box, ctx)
        oc = _custom.card_on_colour(custom, surface, ctx)
        on_colour = on_colour if oc is None else oc
        sizes = (custom['value_size'], custom['label_size'])
    pad = _clamp(min(w, h) * 0.12, 0.14 * EMU_IN, 0.26 * EMU_IN)
    ink, muted = T1, ('tx1', {'lumMod': '55000', 'lumOff': '45000'})
    if on_colour:
        ink, muted = ('lt1', {}), ('lt1', {'lumMod': '88000'})
    value_col = None
    if spec.get('value') == 'accent' and not on_colour:
        value_col = (accent, {'lumMod': '75000'}) if surface == 'tint' and not (custom and
                                                                                 custom['surface_colour'] != 'auto') \
            else (accent, {})
    light = (ctx.light_font or '+mj-lt') if spec.get('weight') == 'light' else None
    mode = spec.get('chip') if icon_mode in (None, '', 'auto', 'outline', 'filled') else icon_mode
    if surface in ('solid', 'gradient') and mode not in (None, 'none', 'bare'):
        mode = 'glass'
    if layout in ('tile', 'plain') and icon_mode in (None, '', 'auto', 'outline', 'filled'):
        mode = None
    show = mode not in (None, 'none') and icon != 'none' and h >= 0.5 * EMU_IN and w >= 0.9 * EMU_IN
    if layout == 'stack' and h < 1.3 * EMU_IN and w >= 2.0 * EMU_IN:
        layout = 'side'
    chip = _clamp(min(h * 0.32, w * 0.24), 0.36 * EMU_IN, 0.62 * EMU_IN)
    last = el
    shift = 0
    if spec.get('deco') == 'top':
        r = min(CARD_R, h / 2)
        last = _add_bar(el, x + r * 0.9, y + 0.03 * EMU_IN, w - 1.8 * r, 0.045 * EMU_IN, solid(accent), 'Card accent')
    elif spec.get('deco') == 'left':
        last = _add_bar(el, x + 0.12 * EMU_IN, y + pad, 0.055 * EMU_IN, h - 2 * pad, solid(accent), 'Card accent')
        shift = int(0.16 * EMU_IN)
    ins = {'lIns': pad + shift, 'rIns': pad, 'tIns': pad, 'bIns': pad}
    align, anchor = 'l', 't'
    hero = layout == 'hero'
    name = None
    if show:
        name = icon if icon and icon not in ('auto', '') else \
            _icons.pick(_text(el, 400), ACCENTS.index(accent) if accent in ACCENTS else 0)
    filled = icon_mode == 'filled'
    fill, line, ifill = _chip_paint(mode or 'solid', accent, on_colour)
    gap = 0.14 * EMU_IN
    if layout == 'header':
        label = _take_label(el)
        c = _clamp(min(h * 0.24, w * 0.16), 0.32 * EMU_IN, 0.46 * EMU_IN)
        cx_, cy_ = x + pad, y + pad
        if show:
            ch = _chip(last, cx_, cy_, c, fill, line, circle=mode == 'circle')
            g = c * 0.56
            last = _icon(ch, name, cx_ + (c - g) / 2, cy_ + (c - g) / 2, g, ifill, filled)
        lx = cx_ + (c + 0.12 * EMU_IN if show else 0)
        if label is not None:
            for r in [q for q in label if ln_(q) in ('r', 'fld')]:
                rpr = _rpr(r)
                rpr.set('sz', str(_clamp(int(rpr.get('sz') or 1500), 1300, 1600)))
                rpr.set('b', '1')
                put(rpr, X(solid(ink[0], **ink[1])))
                _set_font(rpr, '+mj-lt')
                drop(rpr, 'effectLst', 'ln', 'highlight', 'gradFill')
            ppr = kid(label, 'pPr')
            if ppr is None:
                ppr = X('<a:pPr/>')
                label.insert(0, ppr)
            ppr.set('algn', 'l')
            ppr.set('marL', '0')
            ppr.set('indent', '0')
            put(ppr, X('<a:buNone/>'), replace={'buNone', 'buChar', 'buAutoNum', 'buBlip'})
            tb = _text_box(last, lx, cy_, x + w - pad - lx, c, '', name='Card title')
            kid(tb, 'txBody').append(label)
            last = tb
        rule_y = cy_ + c + gap * 0.8
        _add_bar(last, x + 1, rule_y, w - 2, int(0.012 * EMU_IN), solid(ctx.hair[0], **ctx.hair[1]),
                 'Card rule').find(f'.//{{{A}}}prstGeom').set('prst', 'rect')
        ins['tIns'] = rule_y - y + gap
        anchor = 't'
    elif layout == 'hero':
        c = _clamp(min(h * 0.62, w * 0.34), 0.6 * EMU_IN, 1.4 * EMU_IN)
        cx_, cy_ = x + w - pad * 0.6 - c, y + (h - c) / 2
        if show:
            ch = _chip(last, cx_, cy_, c, *_chip_paint('halo', accent, True)[:2], circle=True)
            g = c * 0.55
            _icon(ch, name, cx_ + (c - g) / 2, cy_ + (c - g) / 2, g, solid('lt1'), filled)
            ins['rIns'] = pad + c * 0.75
        anchor = 'ctr'
    elif layout == 'tile':
        align, anchor = 'ctr', 'ctr'
    elif layout == 'plain':
        anchor = 'ctr'
    elif show:
        text_h = _kpi_text_height(el, h, w - 2 * pad - shift)
        top = max(pad, (h - (chip + gap + text_h)) / 2)  # centre icon + figures as one block
        if layout == 'stack':
            cx_, cy_ = x + pad + shift, y + top
            ins['tIns'] = top + chip + gap
            ins['bIns'] = min(pad, ins['bIns'])
        elif layout == 'corner':
            cx_, cy_ = x + w - pad - chip, y + pad
            ins['rIns'] = pad + chip + gap
            ins['tIns'] = max(pad, (h - text_h) / 2)
        elif layout == 'side':
            cx_, cy_ = x + pad + shift, y + (h - chip) / 2
            ins['lIns'] = pad + shift + chip + 0.16 * EMU_IN
            ins['tIns'] = ins['bIns'] = pad * 0.6
            anchor = 'ctr'
        else:  # centre
            cx_, cy_ = x + (w - chip) / 2, y + top
            ins['tIns'] = top + chip + gap
            align = 'ctr'
        if mode == 'bare':
            _icon(last, name, cx_, cy_, chip * 0.85, ifill, filled)
        else:
            ch = _chip(last, cx_, cy_, chip, fill, line, circle=mode == 'circle' or layout == 'center')
            g = chip * 0.58
            _icon(ch, name, cx_ + (chip - g) / 2, cy_ + (chip - g) / 2, g, ifill, filled)
    else:
        anchor = 'ctr'
        if layout == 'center':
            align = 'ctr'
    _kpi_text(el, (ink, muted), align, ins, anchor, h, value_col=value_col, light_font=light,
              hero=hero, value_first=layout == 'tile', skip_label=layout == 'header', sizes=sizes)
    return True


def _kpi_strip(slide_tree, cards, ctx):
    """Cards that share a row become one strip: a single container, thin dividers between them."""
    rows = []
    for el in cards:
        b = _ext(kid(el, 'spPr'))
        if b is None:
            continue
        for row in rows:
            rb = row[0][1]
            if abs(b[1] - rb[1]) < 0.25 * EMU_IN and abs(b[3] - rb[3]) < 0.4 * EMU_IN:
                row.append((el, b))
                break
        else:
            rows.append([(el, b)])
    for row in rows:
        row.sort(key=lambda t: t[1][0])
        first = min(row, key=lambda t: list(t[0].getparent()).index(t[0]))[0]
        x0 = min(b[0] for _, b in row)
        y0 = min(b[1] for _, b in row)
        x1 = max(b[0] + b[2] for _, b in row)
        y1 = max(b[1] + b[3] for _, b in row)
        nid = _new_id(first)
        adj = _clamp(int(CARD_R / max(1, min(x1 - x0, y1 - y0)) * 100000), 2500, 50000)
        fill = solid('bg1') if ctx.canvas else solid('bg2')
        cont = X(f'<p:sp><p:nvSpPr><p:cNvPr id="{nid}" name="KPI strip {nid}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
                 f'<p:spPr><a:xfrm><a:off x="{x0}" y="{y0}"/><a:ext cx="{x1 - x0}" cy="{y1 - y0}"/></a:xfrm>'
                 f'<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val {adj}"/></a:avLst></a:prstGeom>'
                 f'{fill}<a:ln><a:noFill/></a:ln>'
                 f'{shadow(**SOFT_SHADOW) if ctx.canvas else "<a:effectLst/>"}</p:spPr></p:sp>')
        first.addprevious(cont)
        for (a, ba), (_, bb) in zip(row, row[1:]):
            mx = (ba[0] + ba[2] + bb[0]) / 2
            hh = (y1 - y0) * 0.56
            _add_bar(cont, mx, y0 + (y1 - y0 - hh) / 2, int(0.012 * EMU_IN), hh,
                     solid(ctx.line[0], **ctx.line[1]), 'Strip divider').find(f'.//{{{A}}}prstGeom').set('prst', 'rect')
    return bool(rows)


# ── containers: every chart and table on its own card ────────────────────────
def _chart_title(cs, take=True):
    """The chart's own title text (or the single series' name when the title is automatic)."""
    chart = kid(cs, 'chart')
    if chart is None:
        return ''
    title = kid(chart, 'title')
    deleted = kid(chart, 'autoTitleDeleted')
    text = ''
    if title is not None:
        text = ''.join(t.text or '' for t in title.iter(f'{{{A}}}t')).strip()
    if not text and (title is not None or (deleted is None or deleted.get('val') in ('0', 'false'))):
        sers = list(chart.iter(f'{{{C}}}ser'))
        pa = kid(chart, 'plotArea')
        plots = [c for c in pa if ln_(c).endswith('Chart')] if pa is not None else []
        if len(sers) == 1 and len(plots) == 1:
            tx = kid(sers[0], 'tx')
            text = ''.join(v.text or '' for v in tx.iter(f'{{{C}}}v')).strip() if tx is not None else ''
    if take and text:
        if title is not None:
            chart.remove(title)
        put(chart, cval('autoTitleDeleted', '1'), 'chart')
    return text[:80]


def _fill_of(sppr):
    """The visible colour of a chart mark as fill XML (for legend dots)."""
    if sppr is None:
        return None
    for c in sppr:
        n = ln_(c)
        if n == 'solidFill' and len(c):
            return etree.tostring(c).decode()
        if n == 'gradFill':
            gs = c.find(f'.//{{{A}}}gs')
            if gs is not None and len(gs):
                col = copy.deepcopy(gs[0])
                for m in [m for m in col if ln_(m) == 'alpha']:
                    col.remove(m)
                return f'<a:solidFill {NSDECL}>{etree.tostring(col).decode()}</a:solidFill>'
    ln = kid(sppr, 'ln')
    if ln is not None:
        f = kid(ln, 'solidFill')
        if f is not None and len(f):
            return etree.tostring(f).decode()
    return None


def _strip_ns(xml):
    return re.sub(r'\sxmlns(:\w+)?="[^"]+"', '', xml)


def _legend_entries(cs):
    """[(label, fill xml)] for the chart's series, or its categories for pies/doughnuts."""
    chart = kid(cs, 'chart')
    pa = kid(chart, 'plotArea') if chart is not None else None
    if pa is None:
        return []
    plots = [c for c in pa if ln_(c).endswith('Chart')]
    out = []
    for plot in plots:
        sers = kids(plot, 'ser')
        if ln_(plot) in PIE_FAMILY and sers:
            ser = sers[0]
            cat = kid(ser, 'cat')
            names = [v.text or '' for v in cat.iter(f'{{{C}}}v')] if cat is not None else []
            fills = {}
            for dpt in kids(ser, 'dPt'):
                fills[int(kid(dpt, 'idx').get('val'))] = _fill_of(kid(dpt, 'spPr'))
            for k, name in enumerate(names):
                if fills.get(k):
                    out.append((name, fills[k]))
            continue
        for ser in sers:
            tx = kid(ser, 'tx')
            name = ''.join(v.text or '' for v in tx.iter(f'{{{C}}}v')).strip() if tx is not None else ''
            f = _fill_of(kid(ser, 'spPr'))
            if name and f:
                out.append((name, f))
    return out


def _donut_centre(cs):
    """(big figure, small label) for the middle of a doughnut: the first slice's share."""
    chart = kid(cs, 'chart')
    pa = kid(chart, 'plotArea') if chart is not None else None
    d = pa.find(f'{{{C}}}doughnutChart') if pa is not None else None
    if d is None:
        return None
    ser = d.find(f'{{{C}}}ser')
    vals = [v for _, v in _values(ser)] if ser is not None else []
    if not vals or sum(vals) <= 0:
        return None
    cat = kid(ser, 'cat')
    names = [v.text or '' for v in cat.iter(f'{{{C}}}v')] if cat is not None else []
    share = vals[0] / sum(vals)
    return f'{share:.0%}', (names[0] if names else '')


CONTAINER_LOOK = {  # fill, edge, shadow, radius (in), title treatment
    'card': ('bg1', 'hair', 'soft', 0.16, 'left'),
    'header': ('bg1', 'hair', 'soft', 0.16, 'rule'),
    'badge': ('bg1', 'hair', 'soft', 0.16, 'badge'),
    'grey': ('bg2', None, None, 0.16, 'caps'),
    'centered': ('bg1', None, 'soft', 0.24, 'centre'),
    'accent': ('bg1', 'hair', 'soft', 0.16, 'left'),
    'float': ('bg1', None, 'float', 0.16, 'left'),
    'outline': ('bg1', 'line', None, 0.16, 'left'),
    'tint': ('tint', None, None, 0.16, 'left'),
}


def _contain(el, style, accent, ctx, title=None, table=False, legend=None, centre=None):
    from . import icons as _icons
    if style in (None, '', 'none', 'keep') or style not in CONTAINER_LOOK:
        return False
    xf = kid(el, 'xfrm')
    off, ext = (kid(xf, 'off'), kid(xf, 'ext')) if xf is not None else (None, None)
    if off is None or ext is None:
        return False
    x, y, w, h = (int(off.get('x', 0)), int(off.get('y', 0)), int(ext.get('cx', 0)), int(ext.get('cy', 0)))
    if w < 0.8 * EMU_IN or h < 0.6 * EMU_IN:
        return False
    fill_role, edge, shade, rad_in, head_kind = CONTAINER_LOOK[style]
    pad = int(_clamp(min(w, h) * 0.05, 0.16 * EMU_IN, 0.26 * EMU_IN))
    head = int(0.46 * EMU_IN) if title else 0
    radius = int(rad_in * EMU_IN)
    adj = _clamp(int(radius / max(1, min(w, h)) * 100000), 1500, 50000)
    fill = solid(accent, lumMod='6000', lumOff='94000') if fill_role == 'tint' else \
        solid('bg1' if fill_role == 'bg2' and ctx.canvas else fill_role)
    line = {'hair': _line(9525, *ctx.hair[:1], **ctx.hair[1]), 'line': _line(9525, *ctx.line[:1], **ctx.line[1])}\
        .get(edge, _no_line())
    eff = {'soft': shadow(**SOFT_SHADOW), 'float': shadow(alpha=11000, blur=457200, dist=88900)}.get(shade,
                                                                                                    '<a:effectLst/>')
    nid = _new_id(el)
    card = X(f'<p:sp><p:nvSpPr><p:cNvPr id="{nid}" name="Container {nid}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
             f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>'
             f'<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val {adj}"/></a:avLst></a:prstGeom>'
             f'{fill}{_strip_ns(etree.tostring(line).decode())}{eff}</p:spPr></p:sp>')
    el.addprevious(card)
    last = card
    if style == 'accent':
        last = _add_bar(card, x + radius * 0.9, y + 0.03 * EMU_IN, w - 1.8 * radius, 0.045 * EMU_IN, solid(accent),
                        'Container accent')
    if title:
        ty = y + int(pad * 0.7)
        tx = x + pad
        if head_kind == 'badge':
            c = int(0.34 * EMU_IN)
            ch = _chip(last, tx, ty + (head - c) / 2, c, solid(accent), circle=True)
            g = c * 0.56
            last = _icon(ch, _icons.pick(title), tx + (c - g) / 2, ty + (head - c) / 2 + (c - g) / 2, g, solid('lt1'))
            tx += c + int(0.12 * EMU_IN)
        caps = head_kind == 'caps'
        algn = 'ctr' if head_kind == 'centre' else 'l'
        size = 1200 if caps else 1500 if head_kind == 'centre' else 1400
        spc = '60' if caps else '-10'
        cap_attr = ' cap="all"' if caps else ''
        tb = _text_box(last, tx, ty, x + w - pad - tx, head,
                       f'<a:p><a:pPr algn="{algn}"/><a:r><a:rPr lang="en-US" sz="{size}" b="1" spc="{spc}"'
                       f'{cap_attr}>{solid("tx1")}<a:latin typeface="+mj-lt"/></a:rPr><a:t/></a:r>'
                       f'</a:p>', name='Container title')
        tb.find(f'.//{{{A}}}t').text = title
        last = tb
        if head_kind in ('rule', 'badge', 'centre'):
            _add_bar(tb, x + 1, ty + head + int(0.05 * EMU_IN), w - 2, int(0.012 * EMU_IN),
                     solid(ctx.hair[0], **ctx.hair[1]), 'Container rule').find(f'.//{{{A}}}prstGeom').set('prst', 'rect')
            head += int(0.1 * EMU_IN)
    foot = 0
    if legend:
        foot = int(0.46 * EMU_IN)
    nx, ny = x + pad, y + pad + (head + int(0.04 * EMU_IN) if title else 0)
    nw, nh = w - 2 * pad, h - (ny - y) - pad - foot
    if legend:
        _legend_chips(last, x + pad, y + h - pad - int(0.36 * EMU_IN), w - 2 * pad, int(0.36 * EMU_IN), legend,
                      'bg1' if fill_role == 'bg2' and not ctx.canvas else 'bg2')
    if table:
        tbl = el.find(f'.//{{{A}}}tbl')
        if tbl is not None:
            grid = kid(tbl, 'tblGrid')
            cols = kids(grid, 'gridCol') if grid is not None else []
            total = sum(int(c.get('w', 0)) for c in cols) or w
            fx = nw / total
            for c in cols:
                c.set('w', str(int(int(c.get('w', 0)) * fx)))
            rows = kids(tbl, 'tr')
            total_h = sum(int(r.get('h', 0)) for r in rows) or h
            fy = min(1.0, nh / total_h)
            for r in rows:
                r.set('h', str(int(int(r.get('h', 0)) * fy)))
            nw = sum(int(c.get('w', 0)) for c in cols) or nw
    off.set('x', str(int(nx)))
    off.set('y', str(int(ny)))
    ext.set('cx', str(int(nw)))
    ext.set('cy', str(int(nh)))
    if centre:
        big, small = centre
        cw = int(min(nw, nh) * 0.5)
        ch_ = int(0.7 * EMU_IN)
        paras = (f'<a:p><a:pPr algn="ctr"/><a:r><a:rPr lang="en-US" sz="{_clamp(int(min(nw, nh) / EMU_IN * 1100), 1600, 3200)}" '
                 f'b="1" spc="-20">{solid("tx1")}<a:latin typeface="+mj-lt"/></a:rPr><a:t/></a:r></a:p>'
                 f'<a:p><a:pPr algn="ctr"/><a:r><a:rPr lang="en-US" sz="1000">'
                 f'{solid("tx1", lumMod="55000", lumOff="45000")}<a:latin typeface="+mn-lt"/></a:rPr><a:t/></a:r></a:p>')
        tb = _text_box(el, nx + (nw - cw) / 2, ny + (nh - ch_) / 2, cw, ch_, paras, name='Donut centre')
        ts = tb.findall(f'.//{{{A}}}t')
        ts[0].text, ts[1].text = big, small
    return True


def _legend_chips(after_el, x, y, w, h, entries, fill_role):
    """A soft pill holding round colour dots and series names (instead of square legend keys)."""
    size = 1050
    est = lambda s, sz: int(len(s) * sz / 100 * 12700 * 0.56)  # noqa: E731
    dot = int(0.13 * EMU_IN)
    gap = int(0.08 * EMU_IN)
    space = int(0.26 * EMU_IN)
    widths = [dot + gap + est(n, size) for n, _ in entries]
    inner = int(0.18 * EMU_IN)
    total = sum(widths) + space * (len(widths) - 1)
    if total > w - 2 * inner:
        size = 900
        widths = [dot + gap + est(n, size) for n, _ in entries]
        total = sum(widths) + space * (len(widths) - 1)
    pill_w = min(w, total + 2 * inner)
    nid = _new_id(after_el)
    pill = _new_sp(after_el, f'<p:sp><p:nvSpPr><p:cNvPr id="{nid}" name="Legend {nid}"/><p:cNvSpPr/><p:nvPr/>'
                             f'</p:nvSpPr><p:spPr><a:xfrm><a:off x="{int(x)}" y="{int(y)}"/><a:ext cx="{int(pill_w)}" '
                             f'cy="{int(h)}"/></a:xfrm><a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" '
                             f'fmla="val 50000"/></a:avLst></a:prstGeom>{solid(fill_role)}<a:ln><a:noFill/></a:ln>'
                             f'</p:spPr></p:sp>')
    last = pill
    cx_ = x + inner
    for (name, fill_xml), wd in zip(entries, widths):
        f = _strip_ns(fill_xml)
        last = _chip(last, cx_, y + (h - dot) / 2, dot, f, circle=True, name='Legend dot')
        tb = _text_box(last, cx_ + dot + gap, y, wd - dot - gap + int(0.1 * EMU_IN), h,
                       f'<a:p><a:pPr algn="l"/><a:r><a:rPr lang="en-US" sz="{size}">'
                       f'{solid("tx1", lumMod="65000", lumOff="35000")}<a:latin typeface="+mn-lt"/></a:rPr><a:t/>'
                       f'</a:r></a:p>', name='Legend label')
        tb.find(f'.//{{{A}}}t').text = name
        last = tb
        cx_ += wd + space
    return pill


def _shape_style(el, style, accent, ctx):
    sppr = kid(el, 'spPr')
    if sppr is None:
        return False
    if style == 'glass' and not _is_darkish(ctx):
        style = 'muted'
    _clean_sppr(sppr)
    on = (accent, ctx.on_tint(accent))
    if style == 'soft':
        put(sppr, X(solid(accent, **ctx.tint(accent))))
        put(sppr, _no_line())
        first = rest = on
    elif style == 'solid':
        put(sppr, X(solid(accent)))
        put(sppr, _no_line())
        first = rest = ('lt1', {})
    elif style == 'gradient':
        put(sppr, X(_grad(accent, _next_accent(accent))))
        put(sppr, _no_line())
        first = rest = ('lt1', {})
    elif style == 'outline':
        put(sppr, X('<a:noFill/>'))
        put(sppr, _line(15875, accent))
        first, rest = on, ctx.ink2
    elif style == 'tint-outline':
        put(sppr, X(solid(accent, **ctx.tint(accent))))
        put(sppr, _line(9525, accent))
        first = rest = on
    elif style == 'muted':
        put(sppr, X(solid('bg2')))
        put(sppr, _no_line())
        first, rest = T1, T2
    elif style == 'floating':
        put(sppr, X(solid('bg1')))
        put(sppr, _no_line())
        put(sppr, X(shadow(alpha=14000, blur=457200, dist=76200)), replace={'effectLst', 'effectDag'})
        first, rest = T1, T2
    elif style == 'contrast':
        put(sppr, X(solid('tx1')))
        put(sppr, _no_line())
        first = rest = ('bg1', {})
    elif style == 'soft-gradient':
        t = ctx.tint(accent)
        nxt = _next_accent(accent)
        put(sppr, X(f'<a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0">{clr(accent, **t)}</a:gs>'
                    f'<a:gs pos="100000">{clr(nxt, **ctx.tint(nxt))}</a:gs></a:gsLst><a:lin ang="0" scaled="0"/>'
                    f'</a:gradFill>'))
        put(sppr, _no_line())
        first = rest = on
    elif style == 'glass':
        put(sppr, X(solid('lt1', alpha='8000')))
        put(sppr, X(f'<a:ln w="9525">{solid("lt1", alpha="18000")}</a:ln>'))
        first = rest = ('lt1', {})
    else:
        return False
    _paint_text(el, first, rest, headline_font=False)
    return True


FLOW_CONNECTOR = {'dashed': 'sysDash'}


def _flow_style(el, style, accent, ctx):
    sppr = kid(el, 'spPr')
    if sppr is None:
        return False
    _clean_sppr(sppr)
    darkish = _is_darkish(ctx)
    if style == 'glass' and not darkish:
        style = 'chip'
    if ln_(el) == 'cxnSp':
        col = ctx.line if darkish else ('tx1', {'lumMod': '40000', 'lumOff': '60000'})
        if style in ('solid', 'contrast') and not darkish:
            col = ('tx1', {'lumMod': '50000', 'lumOff': '50000'})
        w, size = 19050, 'sm'
        if style == 'typed':
            col, w = ('tx1', {'lumMod': '75000', 'lumOff': '25000'}), 15875
        if style == 'bold-arrows':
            col, w, size = ('accent1', {}), 31750, 'med'
        old = kid(sppr, 'ln')
        ends = ''
        for end in ('headEnd', 'tailEnd'):  # keep the arrow direction exactly as drawn
            e = kid(old, end) if old is not None else None
            if e is not None and e.get('type', 'none') != 'none':
                ends += f'<a:{end} type="triangle" w="med" len="{size}"/>'
        dash = kid(old, 'prstDash') if old is not None else None
        dval = FLOW_CONNECTOR.get(style) or (dash.get('val') if dash is not None else None)
        dash_xml = f'<a:prstDash val="{dval}"/>' if dval and dval != 'solid' else ''
        put(sppr, X(f'<a:ln w="{w}" cap="rnd">{solid(col[0], **col[1])}{dash_xml}<a:round/>{ends}</a:ln>'))
        return True
    geom = kid(sppr, 'prstGeom')
    prst = geom.get('prst') if geom is not None else ''
    decision = prst in ('flowChartDecision', 'diamond')
    acc = _next_accent(accent) if decision and style != 'rainbow' else accent
    boxy = prst in PILL_FLOW
    on = (acc, ctx.on_tint(acc))
    if style in ('pill', 'rainbow', 'bold-arrows'):
        if boxy:
            _round(sppr, pill=True)
        fill, line, txt = solid(acc, **ctx.tint(acc)), _no_line(), on
    elif style in ('chip', 'dashed'):
        if boxy:
            _round(sppr, radius=int(0.1 * EMU_IN))
        fill = solid('bg1')
        line = _line(15875, acc) if decision else _line(9525, *ctx.line[:1], **ctx.line[1])
        put(sppr, X(shadow(alpha=9000, blur=254000, dist=38100)), replace={'effectLst', 'effectDag'})
        txt = T1
    elif style == 'solid':
        if boxy:
            _round(sppr, radius=int(0.1 * EMU_IN))
        fill, line, txt = solid(acc), _no_line(), ('lt1', {})
    elif style == 'outline':
        if boxy:
            _round(sppr, radius=int(0.1 * EMU_IN))
        fill, line, txt = '<a:noFill/>', _line(15875, acc), on if not darkish else ctx.ink
    elif style == 'tint':
        if boxy:
            _round(sppr, radius=int(0.07 * EMU_IN))
        fill, line, txt = solid(acc, **ctx.tint(acc)), _no_line(), on
    elif style == 'neutral':
        if boxy:
            _round(sppr, radius=int(0.1 * EMU_IN))
        if decision:
            fill, line, txt = solid(acc, **ctx.tint(acc)), _no_line(), on
        else:
            fill, line, txt = solid('bg2'), _no_line(), T1
    elif style == 'typed':  # start/end pills, tinted process boxes, solid decision diamonds
        terminal = prst in ('flowChartTerminator', 'ellipse', 'flowChartConnector') or \
            (prst == 'roundRect' and (kid(kid(geom, 'avLst'), 'gd') is not None and
                                      'val 5' in (kid(kid(geom, 'avLst'), 'gd').get('fmla') or '')))
        if decision:
            fill, line, txt = solid('accent5'), _no_line(), ('lt1', {})
        elif terminal:
            _round(sppr, pill=True)
            fill, line, txt = solid('accent1'), _no_line(), ('lt1', {})
        else:
            if boxy:
                _geom(sppr, 'rect')
            fill, line, txt = solid('accent3', lumMod='15000', lumOff='85000'), _line(9525, 'accent3'), T1
    elif style == 'gradient':
        if boxy:
            _round(sppr, radius=int(0.1 * EMU_IN))
        fill, line, txt = _grad(acc, _next_accent(acc)), _no_line(), ('lt1', {})
    elif style == 'contrast':
        if boxy:
            _round(sppr, radius=int(0.1 * EMU_IN))
        if decision:
            fill, line, txt = solid(acc), _no_line(), ('lt1', {})
        else:
            fill, line, txt = solid('tx1'), _no_line(), ('bg1', {})
    elif style == 'glass':
        if boxy:
            _round(sppr, radius=int(0.1 * EMU_IN))
        fill, line, txt = solid('lt1', alpha='8000'), X(f'<a:ln w="9525">{solid("lt1", alpha="18000")}</a:ln>'), \
            ('lt1', {})
    else:
        return False
    put(sppr, X(fill) if isinstance(fill, str) else fill)
    put(sppr, line)
    _paint_text(el, txt, txt, headline_font=False, align='ctr')
    if decision:
        _fit_diamond(el)
    return True


def _fit_diamond(el):
    """A diamond's text area is only half its width – drop the side insets and shrink the
    type so the longest word never breaks mid-word ('Approv / ed?')."""
    body, xfrm = kid(el, 'txBody'), el.find(f'.//{{{A}}}xfrm')
    ext = kid(xfrm, 'ext') if xfrm is not None else None
    if body is None or ext is None:
        return
    bp = kid(body, 'bodyPr')
    if bp is not None:
        for k in ('lIns', 'rIns', 'tIns', 'bIns'):
            bp.set(k, '0')
    words = [w for p in kids(body, 'p') for w in _para_text(p).split()]
    if not words:
        return
    longest = max(len(w) for w in words)
    room_pt = int(ext.get('cx', '0')) / 12700 * 0.56
    fit = int(room_pt / (0.6 * longest) * 100) // 50 * 50
    for r in body.iter(f'{{{A}}}rPr', f'{{{A}}}endParaRPr'):
        cur = int(r.get('sz') or 1800)
        if fit < cur:
            r.set('sz', str(max(700, fit)))


def _blip_effect(el, xml):
    blip = el.find(f'.//{{{A}}}blip')
    if blip is None:
        return
    for c in list(blip):
        if ln_(c) in ('grayscl', 'duotone', 'clrChange', 'biLevel', 'lum', 'hsl', 'tint', 'clrRepl'):
            blip.remove(c)
    if xml:
        e = X(xml)
        ext = kid(blip, 'extLst')
        (ext.addprevious(e) if ext is not None else blip.append(e))


def _picture_style(el, style, accent='accent1', ctx=None):
    sppr = kid(el, 'spPr')
    if sppr is None:
        return False
    _clean_sppr(sppr)
    drop(sppr, 'ln')
    _blip_effect(el, None)
    if style == 'rounded':
        _round(sppr, PIC_RADIUS)
    elif style == 'soft-round':
        _round(sppr, int(0.36 * EMU_IN))
    elif style == 'shadow':
        _round(sppr, PIC_RADIUS)
        put(sppr, X(shadow(alpha=16000, blur=304800, dist=63500)), replace={'effectLst', 'effectDag'})
    elif style == 'glow':
        _round(sppr, PIC_RADIUS)
        put(sppr, X(f'<a:effectLst><a:outerShdw blurRad="508000" dist="88900" dir="5400000" algn="t" '
                    f'rotWithShape="0">{clr(accent, alpha="38000")}</a:outerShdw></a:effectLst>'),
            replace={'effectLst', 'effectDag'})
    elif style == 'frame':
        _round(sppr, int(0.05 * EMU_IN))
        put(sppr, X(f'<a:ln w="76200">{solid("bg1")}</a:ln>'))
        put(sppr, X(shadow(alpha=18000, blur=254000, dist=50800)), replace={'effectLst', 'effectDag'})
    elif style == 'outline':
        _round(sppr, PIC_RADIUS)
        put(sppr, X(f'<a:ln w="28575">{solid(accent)}</a:ln>'))
    elif style == 'arch':
        put(sppr, X('<a:prstGeom prst="round2SameRect"><a:avLst><a:gd name="adj1" fmla="val 50000"/>'
                    '<a:gd name="adj2" fmla="val 0"/></a:avLst></a:prstGeom>'), replace={'prstGeom', 'custGeom'})
    elif style == 'mono':
        _round(sppr, PIC_RADIUS)
        _blip_effect(el, '<a:grayscl/>')
    elif style == 'duotone':
        _round(sppr, PIC_RADIUS)
        _blip_effect(el, f'<a:duotone>{clr(accent, lumMod="35000")}{clr(accent, lumMod="20000", lumOff="80000")}'
                         f'</a:duotone>')
    elif style == 'circle':
        _geom(sppr, 'ellipse')
        xf = kid(sppr, 'xfrm')
        ext = kid(xf, 'ext') if xf is not None else None
        bf = kid(el, 'blipFill')
        if ext is not None and bf is not None:
            cx, cy = int(ext.get('cx')), int(ext.get('cy'))
            if cx and cy and abs(cx - cy) > 1000:
                side = min(cx, cy)
                off = kid(xf, 'off')
                off.set('x', str(int(off.get('x')) + (cx - side) // 2))
                off.set('y', str(int(off.get('y')) + (cy - side) // 2))
                ext.set('cx', str(side))
                ext.set('cy', str(side))
                crop = (1 - side / max(cx, cy)) / 2 * 100000
                sr = kid(bf, 'srcRect')
                if sr is None:
                    sr = X('<a:srcRect/>')
                    blip = kid(bf, 'blip')
                    (blip.addnext(sr) if blip is not None else bf.insert(0, sr))
                for k in (('l', 'r') if cx > cy else ('t', 'b')):
                    sr.set(k, str(int(int(sr.get(k, 0)) + crop)))
    elif style == 'plain':
        _geom(sppr, 'rect')
    else:
        return False
    return True


# ── titles, body text, backgrounds ───────────────────────────────────────────
def _title_anchor(slide, el):
    bp = el.find(f'.//{{{A}}}bodyPr')
    if bp is not None and bp.get('anchor'):
        return bp.get('anchor')
    try:
        for owner in (slide.slide_layout, slide.slide_layout.slide_master):
            for ph in owner.placeholders:
                if 'TITLE' in str(ph.placeholder_format.type):
                    b = ph._element.find(f'.//{{{A}}}bodyPr')
                    if b is not None and b.get('anchor'):
                        return b.get('anchor')
    except Exception:  # noqa: BLE001
        pass
    return 'ctr'


def _title_size(el):
    sizes = [int(_rpr(r).get('sz')) for r in _runs(el) if _rpr(r).get('sz')]
    return (max(sizes) if sizes else 3600) / 100 * 12700  # EMU of one line of type


def _title_style(slide, el, style, accent, ctx):
    runs = _runs(el)
    light = any(_is_light_run(_rpr(r)) for r in runs) and not ctx.flip_light  # on a dark panel/picture: stay light
    inherited = all(kid(_rpr(r), 'solidFill') is None for r in runs)
    ink = 'lt1' if light or ctx.on_dark else ctx.ink[0]
    if ctx.picture_bg and inherited:
        ink = None  # the layout picks a colour that works on its picture
    ph = el.find(f'.//{{{P}}}ph')
    centre_title = ph is not None and ph.get('type') == 'ctrTitle'
    left = style not in ('centered',) and not centre_title
    _autofit(el)
    for p in el.iter(f'{{{A}}}p'):
        if left:
            ppr = kid(p, 'pPr')
            if ppr is None:
                ppr = X('<a:pPr/>')
                p.insert(0, ppr)
            ppr.set('algn', 'l')
    brand = ctx.title_accent or accent
    for r in runs:
        rpr = _rpr(r)
        _set_font(rpr, '+mj-lt')
        rpr.attrib.pop('i', None)
        rpr.attrib.pop('cap', None)
        rpr.set('b', '0' if style == 'editorial' else '1')
        rpr.set('spc', {'editorial': '-60', 'caps': '60'}.get(style, '-30'))
        if style == 'caps':
            rpr.set('cap', 'all')
        drop(rpr, 'effectLst', 'ln', 'gradFill', 'highlight')
        if style == 'gradient' and not (ctx.picture_bg and inherited):
            put(rpr, X(_grad(brand, _next_accent(accent) if not ctx.title_accent else accent, ang=0)))
        elif style == 'accent' and not light and not (ctx.picture_bg and inherited):
            put(rpr, X(solid(brand, **({'lumMod': '60000', 'lumOff': '40000'} if ctx.on_dark else {}))))
        elif ink:
            put(rpr, X(solid(ink)))
    shp = next((s for s in slide.shapes if s._element is el), None)
    if shp is None or not shp.width:
        return True
    body = el.find(f'.//{{{A}}}bodyPr')
    lins = int(body.get('lIns')) if body is not None and body.get('lIns') else 91440
    line_h = _title_size(el)
    anchor = _title_anchor(slide, el)
    top = shp.top + {'t': 45720, 'b': shp.height - 45720 - line_h * 1.1}.get(anchor, (shp.height - line_h * 1.1) / 2)
    fill = solid(brand)
    if style == 'accent-bar' and not centre_title:
        _add_bar(el, shp.left + lins, shp.top + shp.height + int(0.04 * EMU_IN), int(0.6 * EMU_IN),
                 int(0.06 * EMU_IN), fill, 'Title accent')
    elif style == 'side-bar' and not centre_title:
        h = line_h * 1.05
        _add_bar(el, shp.left, top + line_h * 0.05, int(0.06 * EMU_IN), h, fill, 'Title accent')
        if body is not None:
            body.set('lIns', str(lins + int(0.16 * EMU_IN)))
    elif style == 'dot' and not centre_title:
        d = int(min(0.16 * EMU_IN, line_h * 0.32))
        bar = _add_bar(el, shp.left + lins, top + line_h * 0.55 - d / 2, d, d, fill, 'Title accent')
        geom = bar.find(f'.//{{{A}}}prstGeom')
        geom.set('prst', 'ellipse')
        for g in list(kid(geom, 'avLst')):
            kid(geom, 'avLst').remove(g)
        if body is not None:
            body.set('lIns', str(lins + d + int(0.14 * EMU_IN)))
    elif style == 'underline' and not centre_title:
        _add_bar(el, shp.left + lins, shp.top + shp.height + int(0.03 * EMU_IN), shp.width - 2 * lins,
                 int(0.014 * EMU_IN), solid(ctx.line[0], **ctx.line[1]), 'Title rule')
    return True


BULLETS = {'check': '✓', 'arrow': '→', 'dash': '–'}


def _text_style(el, style, ctx):
    _autofit(el)
    ph = el.find(f'.//{{{P}}}ph')
    subtitle = ph is not None and ph.get('type') == 'subTitle'
    paras = [p for p in el.iter(f'{{{A}}}p') if any(ln_(c) in ('r', 'fld') for c in p)]
    for pi, p in enumerate(paras):
        ppr = kid(p, 'pPr')
        if ppr is None:
            ppr = X('<a:pPr/>')
            p.insert(0, ppr)
        if ppr.get('algn') in ('ctr', 'just') and not subtitle:
            ppr.set('algn', 'l')
        first = next((c for c in p if ln_(c) == 'r'), None)
        t = first.find(f'{{{A}}}t') if first is not None else None
        if t is not None and t.text and re.match(r'^(\t+ *|\t* {6,})', t.text):
            t.text = t.text.lstrip(' \t')  # tabs/spaces used to push text right: right-align it instead
            ppr.set('algn', 'r')
        bulleted = kid(ppr, 'buNone') is None and (
            kid(ppr, 'buChar') is not None or kid(ppr, 'buAutoNum') is not None or (ph is not None and not subtitle))
        if kid(ppr, 'buNone') is None:
            put(ppr, X(f'<a:buClr>{clr("accent1")}</a:buClr>'), replace={'buClr', 'buClrTx'})
        if bulleted and style in BULLETS:
            put(ppr, X('<a:buSzPct val="85000"/>'), replace={'buSzPct', 'buSzPts', 'buSzTx'})
            put(ppr, X('<a:buFont typeface="Segoe UI Symbol"/>'), replace={'buFont', 'buFontTx'})
            put(ppr, X(f'<a:buChar char="{BULLETS[style]}"/>'), replace={'buChar', 'buAutoNum', 'buBlip'})
        elif bulleted and style == 'numbered' and int(ppr.get('lvl', '0')) == 0:
            put(ppr, X('<a:buFontTx/>'), replace={'buFont', 'buFontTx'})
            put(ppr, X('<a:buAutoNum type="arabicPeriod"/>'), replace={'buChar', 'buAutoNum', 'buBlip'})
        if style == 'airy':
            put(ppr, X('<a:lnSpc><a:spcPct val="120000"/></a:lnSpc>'))
            put(ppr, X('<a:spcAft><a:spcPts val="1000"/></a:spcAft>'))
        elif style == 'compact':
            put(ppr, X('<a:lnSpc><a:spcPct val="95000"/></a:lnSpc>'))
            put(ppr, X('<a:spcBef><a:spcPts val="0"/></a:spcBef>'))
            put(ppr, X('<a:spcAft><a:spcPts val="300"/></a:spcAft>'))
        elif kid(ppr, 'spcAft') is None:
            put(ppr, X('<a:spcAft><a:spcPts val="600"/></a:spcAft>'))
        level = int(ppr.get('lvl', '0'))
        for r in [c for c in p if ln_(c) in ('r', 'fld')]:
            rpr = _rpr(r)
            _set_font(rpr, '+mn-lt')
            drop(rpr, 'effectLst', 'ln')
            if style == 'lead':
                rpr.set('b', '1' if pi == 0 else '0')
            f = kid(rpr, 'solidFill')
            if style == 'lead' and not ctx.picture_bg and (ctx.flip_light or not (_is_light_run(rpr) and not ctx.on_dark)):
                role = ctx.ink if pi == 0 else ctx.ink2
                put(rpr, X(solid(role[0], **role[1])))
                continue
            if f is None and (level == 0 or ctx.picture_bg):
                continue  # inherited colour: the layout/theme already decides it
            if _is_light_run(rpr) and not ctx.on_dark:
                if ctx.flip_light:  # the dark slide behind it is now light: light text becomes ink
                    role = ctx.ink2 if level else ctx.body
                    put(rpr, X(solid(role[0], **role[1])))
                elif ln_(kid(rpr, 'solidFill')[0]) == 'schemeClr':
                    put(rpr, X(solid('lt1')))  # light text placed on something dark: keep it light in every look
                continue
            if f is None or _is_neutral_run(rpr):
                role = ctx.ink2 if level else ctx.body
                put(rpr, X(solid(role[0], **role[1])))
            elif ctx.on_dark and not ctx.dark:
                c = kid(rpr, 'solidFill')[0]
                if ln_(c) == 'schemeClr' and c.get('val', '').startswith('accent'):
                    put(rpr, X(solid(c.get('val'), lumMod='60000', lumOff='40000')))
                elif ln_(c) == 'srgbClr':  # a dark hard-coded emphasis colour: lift it for the dark slide
                    v = c.get('val', '000000')
                    h, l_, s_ = colorsys.rgb_to_hls(*(int(v[i:i + 2], 16) / 255 for i in (0, 2, 4)))
                    if l_ < 0.62:
                        r_, g_, b_ = colorsys.hls_to_rgb(h, 0.68, max(s_, 0.6))
                        c.set('val', ''.join(f'{round(x * 255):02X}' for x in (r_, g_, b_)))
    return True


def _is_dark_bg(slide):
    """The slide paints its own dark colour background (a title or section slide, usually)."""
    bg = slide._element.find(f'{{{P}}}cSld/{{{P}}}bg')
    if bg is None or bg.find(f'.//{{{A}}}blipFill') is not None:
        return False
    lums = []
    for c in bg.iter():
        n = ln_(c)
        if n == 'srgbClr':
            v = c.get('val', 'FFFFFF')
            r, g, b = (int(v[i:i + 2], 16) / 255 for i in (0, 2, 4))
            lums.append(0.2126 * r + 0.7152 * g + 0.0722 * b)
        elif n == 'schemeClr':
            lums.append(0.1 if c.get('val') in ('tx1', 'dk1', 'tx2', 'dk2') else 0.9)
    return bool(lums) and sum(lums) / len(lums) < 0.4


def _radial(stops, l, t, r, b):
    gs = ''.join(f'<a:gs pos="{p}">{c}</a:gs>' for p, c in stops)
    return (f'<a:gradFill rotWithShape="1"><a:gsLst>{gs}</a:gsLst><a:path path="circle">'
            f'<a:fillToRect l="{l}" t="{t}" r="{r}" b="{b}"/></a:path></a:gradFill>')


def _linear(stops, ang):
    gs = ''.join(f'<a:gs pos="{p}">{c}</a:gs>' for p, c in stops)
    return f'<a:gradFill rotWithShape="1"><a:gsLst>{gs}</a:gsLst><a:lin ang="{ang}" scaled="0"/></a:gradFill>'


def _background_style(slide, style, ctx):
    cSld = slide._element.find(f'{{{P}}}cSld')
    page = clr('bg1')
    dk = ctx.dark
    if style == 'hero':
        # deep ink with an accent glow: keeps title/section slides bold, and their light text readable
        fill = _radial([(0, clr('accent1', lumMod='55000')), (55000, clr('dk1')), (100000, clr('dk1'))],
                       100000, 0, 0, 100000)
    elif style == 'white':
        fill = solid('bg1')
    elif style in ('canvas', 'tint'):
        fill = solid('bg2', lumMod='60000', lumOff='40000')
    elif style == 'title-glow':  # a dark title slide redrawn light, with a confident accent glow
        fill = _radial([(0, clr('accent1', lumMod='25000', lumOff='75000')), (45000, clr('accent2', lumMod='8000',
                       lumOff='92000')), (100000, page)], 100000, 0, 0, 100000)
    elif style == 'soft':
        fill = _linear([(0, page), (100000, clr('bg2'))], 5400000)
    elif style == 'glow':
        g = clr('accent1', lumMod='22000') if dk else clr('accent1', lumMod='12000', lumOff='88000')
        fill = _radial([(0, g), (50000, page), (100000, page)], 100000, 0, 0, 100000)
    elif style == 'band':
        fill = _linear([(0, _wash(ctx, 'accent1', 14)), (38000, page), (100000, page)], 5400000)
    elif style == 'mesh':
        fill = _linear([(0, _wash(ctx, 'accent1', 13)), (50000, page), (100000, _wash(ctx, 'accent2', 13))],
                       2700000)
    elif style == 'aurora':
        fill = _linear([(0, _wash(ctx, 'accent1', 16)), (45000, _wash(ctx, 'accent2', 9)),
                        (100000, _wash(ctx, 'accent3', 13))], 1800000)
    elif style == 'spotlight':
        fill = _radial([(0, _wash(ctx, 'accent1', 13)), (70000, page), (100000, page)], 50000, 50000, 50000, 50000)
    elif style == 'corner':
        fill = _radial([(0, _wash(ctx, 'accent2', 15)), (55000, page), (100000, page)], 0, 100000, 100000, 0)
    elif style in ('dots', 'grid'):
        fg = clr('bg1', lumMod='80000', lumOff='20000') if dk else clr('tx1', lumMod='8000', lumOff='92000')
        fill = f'<a:pattFill prst="{"dotGrid" if style == "dots" else "lgGrid"}"><a:fgClr>{fg}</a:fgClr>' \
               f'<a:bgClr>{page}</a:bgClr></a:pattFill>'
    else:
        return False
    for old in cSld.findall(f'{{{P}}}bg'):
        cSld.remove(old)
    cSld.insert(0, X(f'<p:bg><p:bgPr>{fill}<a:effectLst/></p:bgPr></p:bg>'))
    return True


# ── tables ───────────────────────────────────────────────────────────────────
NUMERIC = re.compile(r'^[\s$€£₹¥%+\-−–0-9.,()kKmMbBxX×/]*\d[\s$€£₹¥%+\-−–0-9.,()kKmMbBxX×/]*$')


def _cell_text(tc):
    return ''.join(t.text or '' for t in tc.iter(f'{{{A}}}t')).strip()


def _border(side, w=None, val=None, **mods):
    if w is None:
        return f'<a:ln{side} w="0"><a:noFill/></a:ln{side}>'
    return (f'<a:ln{side} w="{w}" cap="flat" cmpd="sng" algn="ctr">{solid(val, **mods)}'
            f'<a:prstDash val="solid"/></a:ln{side}>')


def _number(text):
    """'$1,234.5k' -> 1234500.0, '(12%)' -> -12.0, otherwise None."""
    t = (text or '').strip()
    if not t or not NUMERIC.match(t):
        return None
    neg = t.startswith('(') and t.endswith(')') or t.lstrip().startswith(('-', '−', '–'))
    mult = 1.0
    m = re.search(r'([kKmMbB])\s*\)?\s*$', t)
    if m:
        mult = {'k': 1e3, 'm': 1e6, 'b': 1e9}[m.group(1).lower()]
    digits = re.sub(r'[^0-9.]', '', t)
    if not digits or digits.count('.') > 1:
        return None
    try:
        v = float(digits) * mult
    except ValueError:
        return None
    return -v if neg else v


def _table_shape(tbl):
    rows = kids(tbl, 'tr')
    ncols = max((len(kids(r, 'tc')) for r in rows), default=0)
    numeric_col = []
    for ci in range(ncols):
        vals = [_cell_text(kids(r, 'tc')[ci]) for r in rows[1:] if ci < len(kids(r, 'tc'))]
        vals = [v for v in vals if v]
        numeric_col.append(bool(vals) and sum(bool(NUMERIC.match(v)) for v in vals) >= 0.6 * len(vals))
    last = rows[-1] if len(rows) > 2 else None
    total = last is not None and kids(last, 'tc') and re.search(
        r'\b(total|sum|overall|grand|average|avg)\b', _cell_text(kids(last, 'tc')[0]), re.I) is not None
    return rows, numeric_col, last if total else None


def is_numeric_table(el):
    """A table whose body is mostly numbers (a heatmap candidate)."""
    tbl = el.find(f'.//{{{A}}}tbl')
    if tbl is None:
        return False
    rows, numeric_col, _ = _table_shape(tbl)
    return len(rows) >= 3 and sum(numeric_col) >= 2


def _reset_tblpr(tbl):
    tp = kid(tbl, 'tblPr')
    if tp is None:
        tp = X('<a:tblPr/>')
        tbl.insert(0, tp)
    for c in list(tp):
        tp.remove(c)
    for k in list(tp.attrib):
        del tp.attrib[k]
    tp.set('firstRow', '1')
    tp.append(X('<a:tableStyleId>{2D5ABB26-0587-4C30-8999-92F81FD0307C}</a:tableStyleId>'))


def _cell(tc, borders, fill, txt, bold=None, margins=(0.12, 0.12, 0.07, 0.07), align=None, size=None):
    old = kid(tc, 'tcPr')
    attrs = {k: v for k, v in (old.attrib.items() if old is not None else []) if k in ('rowSpan', 'gridSpan')}
    attrs.update(marL=str(int(margins[0] * EMU_IN)), marR=str(int(margins[1] * EMU_IN)),
                 marT=str(int(margins[2] * EMU_IN)), marB=str(int(margins[3] * EMU_IN)), anchor='ctr')
    if old is not None:
        tc.remove(old)
    a = ''.join(f' {k}="{v}"' for k, v in attrs.items())
    tc.append(X(f'<a:tcPr{a}>{borders}{fill}</a:tcPr>'))
    if align:
        for p in tc.iter(f'{{{A}}}p'):
            ppr = kid(p, 'pPr')
            if ppr is None:
                ppr = X('<a:pPr/>')
                p.insert(0, ppr)
            ppr.set('algn', align)
    for r in _runs(tc):
        rpr = _rpr(r)
        _set_font(rpr, '+mn-lt')
        put(rpr, X(solid(txt[0], **txt[1])))
        drop(rpr, 'effectLst', 'ln', 'highlight')
        if bold is not None:
            rpr.set('b', '1' if bold else '0')
        if size:
            rpr.set('sz', str(int(int(rpr.get('sz') or 1800) * size)))  # size = scale factor
    for e in tc.iter(f'{{{A}}}endParaRPr'):
        put(e, X(solid(txt[0], **txt[1])))


def _table_style(el, style, accent, ctx):
    tbl = el.find(f'.//{{{A}}}tbl')
    if tbl is None:
        return False
    if style.startswith('heat-'):
        return _heat_style(el, tbl, style, accent, ctx)
    if style not in ('clean', 'soft', 'striped', 'accent', 'ink', 'minimal', 'grid', 'rows', 'columns', 'ledger',
                     'compact', 'dark', 'blocks'):
        return False
    _reset_tblpr(tbl)
    rows, numeric_col, total_row = _table_shape(tbl)
    hair = _border('B', 6350, ctx.hair[0], **ctx.hair[1])
    rule = ('tx1', {'lumMod': '75000', 'lumOff': '25000'})
    body_txt = ('tx1', {'lumMod': '85000', 'lumOff': '15000'})
    for ri, tr in enumerate(rows):
        head = ri == 0
        is_total = tr is total_row
        band = ri % 2 == 0
        for ci, tc in enumerate(kids(tr, 'tc')):
            side = _border('L') + _border('R')
            top = _border('T')
            bottom = _border('B') if tr is rows[-1] else hair
            fill, txt, bold = '<a:noFill/>', body_txt, None
            margins, size = (0.12, 0.12, 0.07, 0.07), None
            if style == 'clean':
                if head:
                    txt, bold = ctx.ink2, True
                    bottom = _border('B', 15875, rule[0], **rule[1])
            elif style == 'soft':
                if head:
                    fill, txt, bold, bottom = solid('bg2'), ctx.ink, True, _border('B')
            elif style == 'striped':
                bottom = _border('B')
                if head:
                    txt, bold, bottom = (accent, ctx.on_tint(accent)), True, _border('B', 19050, accent)
                elif not band:
                    fill = solid('bg2')
            elif style == 'accent':
                if head:
                    fill, txt, bold, bottom = solid(accent), ('lt1', {}), True, _border('B')
            elif style == 'ink':
                if head:
                    fill, txt, bold, bottom = solid('tx1'), ('bg1', {}), True, _border('B')
            elif style == 'minimal':
                bottom = _border('B')
                margins = (0.12, 0.12, 0.1, 0.1)
                if head:
                    txt, bold, bottom = ctx.ink2, True, _border('B', 12700, rule[0], **rule[1])
            elif style == 'grid':
                g = _border('L', 6350, ctx.line[0], **ctx.line[1]) + _border('R', 6350, ctx.line[0], **ctx.line[1])
                side, top = g, _border('T', 6350, ctx.line[0], **ctx.line[1])
                bottom = _border('B', 6350, ctx.line[0], **ctx.line[1])
                if head:
                    fill, txt, bold = solid('bg2'), ctx.ink, True
            elif style == 'rows':
                gap = _border('T', 38100, 'bg1') + _border('B', 38100, 'bg1')
                side, top, bottom = _border('L') + _border('R'), '', ''
                side += gap
                fill = solid('bg2') if not head else '<a:noFill/>'
                if head:
                    txt, bold = ctx.ink2, True
            elif style == 'columns':
                bottom = _border('B')
                if ci % 2 == 1:
                    fill = solid('bg2')
                if head:
                    txt, bold, bottom = ctx.ink, True, _border('B', 15875, accent)
            elif style == 'ledger':
                if ci == 0:
                    fill = solid(accent, **ctx.tint(accent))
                if head:
                    txt, bold, bottom = (accent, ctx.on_tint(accent)), True, _border('B', 19050, accent)
                elif ci == 0:
                    txt, bold = ctx.ink, True
            elif style == 'compact':
                margins, size = (0.08, 0.08, 0.03, 0.03), 0.8
                if head:
                    txt, bold = ctx.ink2, True
                    bottom = _border('B', 12700, rule[0], **rule[1])
            elif style == 'blocks':
                gapc = 'bg2' if getattr(ctx, 'on_grey', False) else 'bg1'
                g = ''.join(_border(sd, 38100, gapc) for sd in ('L', 'R'))
                side, top, bottom = g, _border('T', 38100, gapc), _border('B', 38100, gapc)
                if head and ci > 0 or (ci == 0 and not head):
                    fill, txt, bold = solid('tx1', lumMod='80000', lumOff='20000'), ('bg1', {}), True
                elif head:  # the corner cell carries the accent, like a matrix key
                    fill, txt, bold = solid(accent), ('lt1', {}), True
                else:
                    fill = solid('bg1') if getattr(ctx, 'on_grey', False) else solid('bg2')
                margins = (0.14, 0.14, 0.09, 0.09)
            elif style == 'dark':
                bottom = _border('B', 6350, 'dk1', lumMod='75000', lumOff='25000')
                fill = solid(accent) if head else solid('dk1', lumMod='85000', lumOff='15000') if band else \
                    solid('dk1', lumMod='75000', lumOff='25000')
                txt, bold = ('lt1', {}), (True if head else None)
            if is_total:
                bold = True
                if style not in ('dark', 'rows'):
                    top = _border('T', 12700, rule[0], **rule[1])
                if style == 'accent':
                    fill = solid(accent, **ctx.tint(accent))
            numeric = numeric_col[ci] if ci < len(numeric_col) else False
            _cell(tc, side + top + bottom, fill, txt, bold, margins, 'r' if numeric else None, size)
    return True


# heatmap colour ramps: light → deep. Theme ramps are written as theme colours (they follow the palette).
HEAT_FIXED = {
    'heat-ocean': ['F0F9FF', 'BAE6FD', '38BDF8', '0284C7', '075985', '0B3557'],
    'heat-sunset': ['FFF7ED', 'FED7AA', 'FB923C', 'EA580C', '9A3412', '5F1D0B'],
    'heat-violet': ['F5F3FF', 'DDD6FE', 'A78BFA', '7C3AED', '5B21B6', '36116F'],
    'heat-mint': ['F0FDF4', 'BBF7D0', '4ADE80', '16A34A', '166534', '0B3B20'],
    'heat-viridis': ['440154', '3B528B', '21918C', '5EC962', 'FDE725'],
    'heat-traffic': ['FCA5A5', 'FCD34D', '86EFAC'],
    'heat-diverge': ['E11D48', 'FDA4AF', 'F8FAFC', '5EEAD4', '0D9488'],
}
THEME_RAMP = [(0.0, 10, 90), (0.3, 30, 70), (0.6, 62, 38), (0.85, 100, 0), (1.0, 78, 0)]


def _hex2rgb(h):
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def _rgb2hex(c):
    return ''.join(f'{max(0, min(255, round(x * 255))):02X}' for x in c)


def _lum(rgb):
    def ch(c):
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _mix(stops, t):
    t = max(0.0, min(1.0, t))
    pos = t * (len(stops) - 1)
    i = min(int(pos), len(stops) - 2)
    f = pos - i
    a, b = _hex2rgb(stops[i]), _hex2rgb(stops[i + 1])
    return _rgb2hex(tuple(x + (y - x) * f for x, y in zip(a, b)))


def _lummod(hexv, mod, off):
    h, l_, s = colorsys.rgb_to_hls(*_hex2rgb(hexv))
    return _rgb2hex(colorsys.hls_to_rgb(h, min(1, l_ * mod / 100 + off / 100), s))


def _theme_ramp(t):
    t = max(0.0, min(1.0, t))
    for (t0, m0, o0), (t1, m1, o1) in zip(THEME_RAMP, THEME_RAMP[1:]):
        if t <= t1:
            f = (t - t0) / (t1 - t0) if t1 > t0 else 0
            return int(m0 + (m1 - m0) * f), int(o0 + (o1 - o0) * f)
    return THEME_RAMP[-1][1], THEME_RAMP[-1][2]


def _heat_style(el, tbl, style, accent, ctx):
    if style not in HEAT_FIXED and style not in ('heat-mono', 'heat-tiles', 'heat-duo', 'heat-rows', 'heat-cols',
                                                 'heat-dark', 'heat-text', 'heat-top'):
        return False
    _reset_tblpr(tbl)
    rows, numeric_col, total_row = _table_shape(tbl)
    theme = getattr(ctx, 'theme', {}) or {}
    acc_hex = theme.get(accent, '4F46E5')
    acc2_hex = theme.get(_next_accent(accent), '06B6D4')
    body = [r for r in rows[1:] if r is not total_row]
    grid = [[(_number(_cell_text(tc)) if (ci < len(numeric_col) and numeric_col[ci]) else None)
             for ci, tc in enumerate(kids(r, 'tc'))] for r in body]
    flat = sorted(v for row in grid for v in row if v is not None)
    if not flat:
        return _table_style(el, 'clean', accent, ctx)
    lo, hi = flat[0], flat[-1]
    mid = flat[len(flat) // 2]
    top_n = flat[-max(1, min(5, len(flat) // 8)):]
    top_cut = top_n[0]
    col_top = {}  # with mixed units, 'top values' means the best value of each column

    # columns on very different scales ($M next to %): colour each column on its own scale
    col_max = {}
    for row in grid:
        for ci, v in enumerate(row):
            if v is not None:
                col_max[ci] = max(col_max.get(ci, 0), abs(v))
    scales = [m for m in col_max.values() if m > 0]
    mixed = len(scales) > 1 and max(scales) / min(scales) > 8
    per_col = style == 'heat-cols' or (mixed and style not in ('heat-rows', 'heat-top'))
    if per_col and style == 'heat-diverge':
        style_div_cols = True
    else:
        style_div_cols = False

    def norm(v, ri, ci):
        if style == 'heat-diverge' and style_div_cols:
            vals = sorted(g[ci] for g in grid if ci < len(g) and g[ci] is not None)
            m = vals[len(vals) // 2]
            span = max(abs(vals[-1] - m), abs(m - vals[0])) or 1
            return 0.5 + (v - m) / span / 2
        if style == 'heat-rows':
            vals = [x for x in grid[ri] if x is not None]
        elif per_col:
            vals = [g[ci] for g in grid if ci < len(g) and g[ci] is not None]
        else:
            vals = None
        a, b = (min(vals), max(vals)) if vals else (lo, hi)
        if style == 'heat-diverge':
            span = max(abs(hi - mid), abs(mid - lo)) or 1
            return 0.5 + (v - mid) / span / 2
        return (v - a) / (b - a) if b > a else 0.5

    dark_table = style == 'heat-dark'
    gap_w = 38100 if style == 'heat-tiles' else 12700
    gap_col = 'dk1' if dark_table else 'bg1'
    rule = ('tx1', {'lumMod': '75000', 'lumOff': '25000'}) if not dark_table else ('lt1', {'alpha': '35000'})
    head_txt = ctx.ink2 if not dark_table else ('lt1', {'lumMod': '75000'})
    label_txt = ctx.ink if not dark_table else ('lt1', {})
    for ri, tr in enumerate(rows):
        for ci, tc in enumerate(kids(tr, 'tc')):
            numeric = ci < len(numeric_col) and numeric_col[ci]
            align = 'ctr' if numeric else None
            gaps = ''.join(_border(s, gap_w, gap_col) for s in ('L', 'R', 'T', 'B'))
            base_fill = solid('dk1') if dark_table else '<a:noFill/>'
            if ri == 0:
                _cell(tc, _border('L') + _border('R') + _border('T') + _border('B', 12700, rule[0], **rule[1]),
                      base_fill, head_txt, True, align=align)
                continue
            if tr is total_row:
                _cell(tc, _border('L') + _border('R') + _border('T', 12700, rule[0], **rule[1]) + _border('B'),
                      base_fill, label_txt, True, align=align)
                continue
            v = grid[body.index(tr)][ci] if ci < len(grid[body.index(tr)]) else None
            if v is None:
                _cell(tc, gaps if style == 'heat-tiles' or dark_table else
                      _border('L') + _border('R') + _border('T') + _border('B'),
                      base_fill, label_txt, not numeric, align=align)
                continue
            t = norm(v, body.index(tr), ci)
            bold = None
            if style in HEAT_FIXED:
                hexv = _mix(HEAT_FIXED[style], t)
                fill, rgb = solid(hexv), _hex2rgb(hexv)
            elif style == 'heat-duo':
                hexv = _mix([_lummod(acc2_hex, 18, 82), acc2_hex, acc_hex, _lummod(acc_hex, 70, 0)], t)
                fill, rgb = solid(hexv), _hex2rgb(hexv)
            elif style == 'heat-dark':
                mod = int(18 + 82 * t)
                fill, rgb = solid(accent, lumMod=str(mod * 1000)), _hex2rgb(_lummod(acc_hex, mod, 0))
            elif style == 'heat-text':
                ramp = [_lummod(acc_hex, 50, 0), acc_hex, _lummod(acc_hex, 35, 65)] if ctx.dark else \
                    [_lummod(acc_hex, 35, 65), acc_hex, _lummod(acc_hex, 60, 0)]
                hexv = _mix(ramp, t)
                _cell(tc, _border('L') + _border('R') + _border('T') + _border('B', 6350, ctx.hair[0], **ctx.hair[1]),
                      '<a:noFill/>', (hexv, {}), t >= 0.75, align=align)
                continue
            elif style == 'heat-top':
                if mixed:
                    if ci not in col_top:
                        col_top[ci] = max(g[ci] for g in grid if ci < len(g) and g[ci] is not None)
                    hit = v >= col_top[ci]
                else:
                    hit = v >= top_cut
                _cell(tc, _border('L') + _border('R') + _border('T') + _border('B', 6350, ctx.hair[0], **ctx.hair[1]),
                      solid(accent, **ctx.tint(accent)) if hit else '<a:noFill/>',
                      (accent, ctx.on_tint(accent)) if hit else ('tx1', {'lumMod': '85000', 'lumOff': '15000'}),
                      True if hit else None, align=align)
                continue
            else:  # brand ramp (mono / tiles / rows / cols)
                mod, off = _theme_ramp(t)
                mods = {'lumMod': str(mod * 1000)}
                if off:
                    mods['lumOff'] = str(off * 1000)
                fill, rgb = solid(accent, **mods), _hex2rgb(_lummod(acc_hex, mod, off))
            txt = ('lt1', {}) if _lum(rgb) < 0.33 else ('dk1', {})
            if style == 'heat-tiles':
                bold = True
            _cell(tc, gaps, fill, txt, bold, align=align)
    return True


# ── charts ───────────────────────────────────────────────────────────────────
def _txpr(size, val, bold=False, font='+mn-lt', **mods):
    b = ' b="1"' if bold else ' b="0"'
    return X(f'<c:txPr><a:bodyPr rot="0" spcFirstLastPara="1" vertOverflow="ellipsis" wrap="square" anchor="ctr" '
             f'anchorCtr="1"/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="{size}"{b}>{solid(val, **mods)}'
             f'<a:latin typeface="{font}"/></a:defRPr></a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr>')


def _sppr(inner):
    return X(f'<c:spPr>{inner}</c:spPr>')


def _dlbls(pos, size, val, bold=True, num=None, percent=False, **mods):
    lbl = X('<c:dLbls>' + (f'<c:numFmt formatCode="{num}" sourceLinked="0"/>' if num else '') +
            '<c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>' +
            (f'<c:dLblPos val="{pos}"/>' if pos else '') +
            f'<c:showLegendKey val="0"/><c:showVal val="{0 if percent else 1}"/><c:showCatName val="0"/>'
            f'<c:showSerName val="0"/><c:showPercent val="{1 if percent else 0}"/><c:showBubbleSize val="0"/>'
            + ('<c:showLeaderLines val="0"/>' if percent else '') + '</c:dLbls>')
    idx = 1 if num else 0
    lbl.insert(idx + 1, _txpr(size, val, bold=bold, **mods))
    return lbl


def _values(ser):
    out = []
    val = kid(ser, 'val')
    if val is None:
        return out
    for pt in val.iter(f'{{{C}}}pt'):
        v = kid(pt, 'v')
        try:
            out.append((int(pt.get('idx')), float(v.text)))
        except (TypeError, ValueError, AttributeError):
            pass
    return out


def _npts(ser):
    for tag in ('val', 'yVal'):
        v = kid(ser, tag)
        if v is not None:
            pc = v.find(f'.//{{{C}}}ptCount')
            if pc is not None:
                return int(pc.get('val', 0))
    return 0


GREYS = [dict(lumMod='25000', lumOff='75000'), dict(lumMod='18000', lumOff='82000'),
         dict(lumMod='35000', lumOff='65000'), dict(lumMod='12000', lumOff='88000')]
CHART_BASE = dict(grid='soft-dash', axis=True, colors='accents', gap=60, width=31750, markers='none', smooth=False,
                  labels=None, panel=None, ring=False, hole=62, area_alpha='28000', cat_bold=False)
CHART_RECIPES = {
    'clean': {},
    'highlight': dict(colors='highlight', gap=55),
    'bold': dict(grid=None, axis=False, labels='in', gap=35, width=44450, markers='ring', cat_bold=True),
    'labels': dict(grid=None, axis=False, labels='out', gap=55, markers='dot'),
    'smooth': dict(smooth=True, width=34925, markers='ring', area_alpha='34000'),
    'panel': dict(panel='surface'),
    'neon': dict(panel='ink', width=34925, markers='dot'),
    'mono': dict(colors='mono', gap=50),
    'duo': dict(colors='duo', gap=50),
    'pastel': dict(colors='pastel', gap=50, labels='out'),
    'gradient': dict(colors='gradient', gap=45),
    'fade': dict(colors='fade', gap=70, grid=None, smooth=True),
    'outline': dict(colors='outline', gap=50, markers='ring'),
    'slim': dict(gap=200, width=19050, markers='dot', ring=True, hole=80),
    'blueprint': dict(grid='dash', width=22225, gap=80, markers='dot'),
    'ring': dict(ring=True, hole=75),
}
MONO = [{}, {'lumMod': '60000', 'lumOff': '40000'}, {'lumMod': '75000'}, {'lumMod': '35000', 'lumOff': '65000'},
        {'lumMod': '50000'}, {'lumMod': '80000', 'lumOff': '20000'}]


def _chart_style(cs, style, accent, ctx, over=None, palette=None):
    """over: recipe overrides from a custom design; palette: its series colours (clr values)."""
    if style not in CHART_RECIPES:
        return False
    R = dict(CHART_BASE, **CHART_RECIPES[style])
    R.update(over or {})
    fsz = R.get('font', 1050)
    chart = kid(cs, 'chart')
    pa = chart.find(f'{{{C}}}plotArea')
    if R['ring'] and any(ln_(c) == 'pieChart' for c in pa):
        _switch_type(cs, 'doughnut')
    darkish = ctx.dark or ctx.on_dark
    ink_panel = R['panel'] == 'ink'
    if ink_panel:  # the chart sits on its own dark panel, whatever the slide
        panel_fill = 'dk2' if ctx.dark else 'dk1'
        ink, muted = ('lt1', {}), ('lt1', {'lumMod': '75000'})
        grid_c, axis_c, sep = ('lt1', {'alpha': '13000'}), ('lt1', {'alpha': '26000'}), panel_fill
        grey_role, greys = 'lt1', [dict(lumMod='45000'), dict(lumMod='35000'), dict(lumMod='55000'), dict(lumMod='28000')]
        dark_marks = True
    else:
        panel_fill = 'bg2' if R['panel'] == 'surface' else None
        ink, muted = (ctx.ink[0], {}), ctx.ink2
        grid_c, axis_c = ctx.hair, ctx.line
        sep = 'bg2' if panel_fill else 'bg1'
        grey_role, greys = ctx.grey_role, ctx.greys
        dark_marks = darkish
    put(cs, cval('roundedCorners', '1' if panel_fill else '0'))
    put(cs, _sppr(f'{solid(panel_fill)}<a:ln><a:noFill/></a:ln>' if panel_fill else
                  '<a:noFill/><a:ln><a:noFill/></a:ln>'))
    put(cs, _txpr(1200, muted[0], **muted[1]))
    put(pa, _sppr('<a:noFill/><a:ln><a:noFill/></a:ln>'), 'plotArea')
    title = kid(chart, 'title')
    if title is not None:
        put(title, X('<c:layout><c:manualLayout><c:xMode val="edge"/><c:yMode val="edge"/><c:x val="0.02"/>'
                     '<c:y val="0.03"/></c:manualLayout></c:layout>'), 'title')
        put(title, cval('overlay', '0'), 'title')
        drop(title, 'spPr')
        put(title, _txpr(1400, ink[0], bold=True, font='+mj-lt', **ink[1]), 'title')
        tx = kid(title, 'tx')
        if tx is not None:
            for r in tx.iter(f'{{{A}}}r'):
                rpr = _rpr(r)
                for k in ('sz', 'b'):
                    rpr.attrib.pop(k, None)
                drop(rpr, 'solidFill', 'latin', 'effectLst')
    plots = [c for c in pa if ln_(c).endswith('Chart')]
    sers = [s for p in plots for s in kids(p, 'ser')]
    n_series = len(sers)
    pie_like = any(ln_(p) in PIE_FAMILY for p in plots)
    horizontal = any(kid(p, 'barDir') is not None and kid(p, 'barDir').get('val') == 'bar'
                     for p in pa if ln_(p) in ('barChart', 'bar3DChart'))
    if horizontal:  # horizontal bars read top-down (first category on top), value axis stays at the bottom
        for ax in [c for c in pa if ln_(c) in ('catAx', 'dateAx')]:
            sc_ = kid(ax, 'scaling')
            if sc_ is not None:
                put(sc_, cval('orientation', 'maxMin'), 'scaling')
        for ax in [c for c in pa if ln_(c) == 'valAx']:
            drop(ax, 'crossesAt')
            put(ax, cval('crosses', 'max'), 'valAx')
    # bars and areas always start at zero (hidden axes otherwise auto-scale from the smallest value)
    if any(ln_(p) in ('barChart', 'bar3DChart', 'areaChart', 'area3DChart') for p in plots):
        vals = [v for ser in sers for _, v in _values(ser)]
        if vals and min(vals) >= 0:
            for ax in [c for c in pa if ln_(c) == 'valAx']:
                sc_ = kid(ax, 'scaling')
                if sc_ is not None and kid(sc_, 'min') is None:
                    put(sc_, cval('min', '0'), 'scaling')
    for ax in [c for c in pa if ln_(c) in ('catAx', 'valAx', 'dateAx')]:
        key = 'valAx' if ln_(ax) == 'valAx' else 'catAx'
        drop(ax, 'minorGridlines')
        put(ax, cval('majorTickMark', 'none'), key)
        put(ax, cval('minorTickMark', 'none'), key)
        put(ax, _txpr(fsz, muted[0], **muted[1]), key)
        if key == 'valAx':
            put(ax, cval('delete', '0' if R['axis'] else '1'), key)
            if R['grid']:
                dash = '<a:prstDash val="dash"/>' if R['grid'] in ('dash', 'soft-dash') else ''
                gcol = (accent, {'lumMod': '40000', 'lumOff': '60000'}) if R['grid'] == 'dash' and not ink_panel \
                    else grid_c
                put(ax, X(f'<c:majorGridlines><c:spPr><a:ln w="6350">{solid(gcol[0], **gcol[1])}{dash}</a:ln>'
                          f'</c:spPr></c:majorGridlines>'), key)
            else:
                drop(ax, 'majorGridlines')
            put(ax, _sppr('<a:noFill/><a:ln><a:noFill/></a:ln>'), key)
        else:
            drop(ax, 'majorGridlines')
            put(ax, _sppr(f'<a:noFill/><a:ln w="9525">{solid(axis_c[0], **axis_c[1])}</a:ln>'), key)
            if R['cat_bold']:
                put(ax, _txpr(max(fsz, 1200), ink[0], bold=True, **ink[1]), key)
    leg = kid(chart, 'legend')  # legend on top, or gone when there is nothing to tell apart
    if n_series <= 1 and not pie_like:
        if leg is not None:
            chart.remove(leg)
    else:
        if leg is None:
            leg = put(chart, X('<c:legend><c:legendPos val="t"/><c:overlay val="0"/></c:legend>'))
        put(leg, cval('legendPos', R.get('legend_pos') or ('b' if pie_like else 't')), 'legend')
        put(leg, cval('overlay', '0'), 'legend')
        drop(leg, 'layout', 'spPr')
        put(leg, _txpr(fsz, muted[0], **muted[1]), 'legend')
    start = ACCENTS.index(accent) if accent in ACCENTS else 0
    lead = palette[0] if palette else ACCENTS[start]

    def paint(i, horizontal_bar=False, pie=False):
        """(fill xml, outline xml, line colour) for series/point i."""
        acc = palette[i % len(palette)] if palette else ACCENTS[(start + i) % 6]
        mode = R['colors']
        if pie and mode in ('fade', 'gradient'):
            mode = 'accents'
        if mode == 'highlight' and i > 0 or mode == 'duo' and i > 1:
            g = greys[(i - 1) % 4]
            return solid(grey_role, **g), '<a:ln><a:noFill/></a:ln>', (grey_role, g)
        if mode == 'mono':
            m = MONO[i % 6]
            return solid(lead, **m), '<a:ln><a:noFill/></a:ln>', (lead, m)
        if mode == 'pastel':
            m = {'lumMod': '70000', 'lumOff': '30000'} if dark_marks else {'lumMod': '45000', 'lumOff': '55000'}
            return solid(acc, **m), '<a:ln><a:noFill/></a:ln>', (acc, {'lumMod': '75000'} if not dark_marks else m)
        if mode == 'gradient':
            light = clr(acc, lumMod='35000') if dark_marks else clr(acc, lumMod='30000', lumOff='70000')
            stops = f'<a:gs pos="0">{clr(acc)}</a:gs><a:gs pos="100000">{light}</a:gs>'
            ang = 10800000 if horizontal_bar else 5400000
            return (f'<a:gradFill rotWithShape="1"><a:gsLst>{stops}</a:gsLst><a:lin ang="{ang}" scaled="0"/>'
                    f'</a:gradFill>'), '<a:ln><a:noFill/></a:ln>', (acc, {})
        if mode == 'fade':
            stops = (f'<a:gs pos="0">{clr(acc)}</a:gs><a:gs pos="100000">{clr(acc, alpha="12000")}</a:gs>'
                     if not horizontal_bar else
                     f'<a:gs pos="0">{clr(acc, alpha="12000")}</a:gs><a:gs pos="100000">{clr(acc)}</a:gs>')
            ang = 0 if horizontal_bar else 5400000
            return (f'<a:gradFill rotWithShape="1"><a:gsLst>{stops}</a:gsLst><a:lin ang="{ang}" scaled="0"/>'
                    f'</a:gradFill>'), '<a:ln><a:noFill/></a:ln>', (acc, {})
        if mode == 'outline':
            t = {'lumMod': '30000'} if dark_marks else {'lumMod': '20000', 'lumOff': '80000'}
            return solid(acc, **t), f'<a:ln w="19050">{solid(acc)}</a:ln>', (acc, {})
        return solid(acc), '<a:ln><a:noFill/></a:ln>', (acc, {})

    label_ink = ('dk1', {}) if R['colors'] == 'pastel' and not dark_marks else ink
    i = 0
    for plot in plots:
        pname = ln_(plot)
        okey = SER_ORDER.get(pname, 'barSer')
        grp = kid(plot, 'grouping')
        clustered = grp is None or grp.get('val') in ('clustered', 'standard')
        if pname in ('barChart', 'bar3DChart'):
            put(plot, cval('gapWidth', R['gap']), pname)
            if clustered:
                put(plot, cval('overlap', R['overlap'] if R.get('overlap') is not None else
                               ('-8' if R['gap'] < 150 else '-20')), pname)
        if pname in PIE_FAMILY:
            put(plot, cval('varyColors', '1'), pname)
            if pname == 'doughnutChart':
                put(plot, cval('holeSize', str(R['hole'])), pname)
        for ser in kids(plot, 'ser'):
            fill, outline, linec = paint(i, horizontal)
            grey = R['colors'] in ('highlight', 'duo') and i > (0 if R['colors'] == 'highlight' else 1)
            i += 1
            drop(ser, 'dLbls')
            if pname in PIE_FAMILY:
                drop(ser, 'dPt')
                for k in range(_npts(ser)):
                    f2, o2, _ = paint(k, pie=True)
                    edge = f'<a:ln w="25400">{solid(sep)}</a:ln>' if R['colors'] != 'outline' else o2
                    put(ser, X(f'<c:dPt><c:idx val="{k}"/><c:bubble3D val="0"/><c:spPr>{f2}{edge}</c:spPr></c:dPt>'),
                        okey, replace=set())
                put(ser, _sppr(f'<a:ln w="25400">{solid(sep)}</a:ln>'), okey)
                if pname == 'pieChart':
                    lab = ('dk1', {}) if R['colors'] in ('pastel', 'outline', 'mono') and not dark_marks else ('lt1', {})
                    put(ser, _dlbls('ctr', 1100, lab[0], num='0%', percent=True, **lab[1]), okey)
                continue
            if pname.startswith('line') or pname in ('scatterChart', 'radarChart'):
                w = 19050 if grey else R['width']
                put(ser, _sppr(f'<a:ln w="{w}" cap="rnd">{solid(linec[0], **linec[1])}<a:round/></a:ln>'), okey)
                if okey in ('lineSer', 'scatterSer', 'radarSer'):
                    if R['markers'] == 'ring' and not grey:
                        mk = (f'<c:marker><c:symbol val="circle"/><c:size val="{8 if style == "bold" else 7}"/>'
                              f'<c:spPr>{solid(sep if panel_fill or not ink_panel else panel_fill)}'
                              f'<a:ln w="22225">{solid(linec[0], **linec[1])}</a:ln></c:spPr></c:marker>')
                    elif R['markers'] == 'dot' and not grey:
                        mk = (f'<c:marker><c:symbol val="circle"/><c:size val="5"/>'
                              f'<c:spPr>{solid(linec[0], **linec[1])}<a:ln><a:noFill/></a:ln></c:spPr></c:marker>')
                    else:
                        mk = '<c:marker><c:symbol val="none"/></c:marker>'
                    put(ser, X(mk), okey)
                if okey in ('lineSer', 'scatterSer'):
                    put(ser, cval('smooth', '1' if R['smooth'] else '0'), okey)
                if R['labels'] and not grey:
                    put(ser, _dlbls('t', 1100, label_ink[0], **label_ink[1]), okey)
                continue
            drop(ser, 'dPt')
            if pname.startswith('area'):
                put(ser, _sppr(f'{solid(linec[0], alpha=R["area_alpha"], **linec[1])}'
                               f'<a:ln w="25400">{solid(linec[0], **linec[1])}</a:ln>'), okey)
                continue
            if R['colors'] == 'highlight' and n_series == 1:
                # one series: grey bars, the largest one in the accent colour
                vals = _values(ser)
                top = max(vals, key=lambda kv: kv[1])[0] if vals else -1
                put(ser, _sppr(f'{solid(grey_role, **greys[0])}<a:ln><a:noFill/></a:ln>'), okey)
                if top >= 0:
                    put(ser, X(f'<c:dPt><c:idx val="{top}"/><c:invertIfNegative val="0"/><c:bubble3D val="0"/>'
                               f'<c:spPr>{solid(lead)}<a:ln><a:noFill/></a:ln></c:spPr></c:dPt>'), okey,
                        replace=set())
                put(ser, _dlbls('outEnd' if clustered else 'ctr', 1100, ink[0], bold=True, **ink[1]), okey)
                continue
            put(ser, _sppr(f'{fill}{outline}'), okey)
            if R['labels'] == 'in':
                put(ser, _dlbls('inEnd' if clustered else 'ctr', 1100, 'lt1'), okey)
            elif R['labels'] == 'out' and not grey:
                put(ser, _dlbls('outEnd' if clustered else 'ctr', 1050, label_ink[0], **label_ink[1]), okey)
    return True


# ── apply ────────────────────────────────────────────────────────────────────
def _norm(kind, style):
    return ALIASES.get(kind, {}).get(style, style)


def apply(data, plan):
    """Restyle a deck. Returns (pptx bytes, summary)."""
    from .looks import LOOK_BY_ID
    prs = Presentation(io.BytesIO(data))
    look = LOOK_BY_ID.get(plan.get('look') or '')
    kinds = dict(look['kinds']) if look and not plan.get('kinds') else {}
    kinds = {k: ({'style': v} if isinstance(v, str) else dict(v)) for k, v in kinds.items()}
    for k, v in (plan.get('kinds') or {}).items():
        kinds[k] = dict(v)
    items = plan.get('items') or {}
    colour = plan.get('colour', 'auto')
    dark = plan.get('dark')
    if dark is None:
        dark = look['dark'] if look else False
    ctx = Ctx(dark=dark, title_accent=plan.get('title_accent') or (look or {}).get('title_accent'))
    ctx.theme = _theme_hex(prs)
    ctx.light_font = plan.get('light_font')
    counts, skipped = {}, []
    from . import custom as _custom
    designs = _custom.resolve(plan)

    def mine(style, kind, el=None):
        """The custom design behind a 'my:<id>' style, when it suits this component."""
        if not style.startswith('my:'):
            return None
        d = designs.get(style[3:])
        if d is None:
            return None
        if d['kind'] == kind or (kind == 'table' and d['kind'] == 'heatmap'):
            return d
        if kind == 'table' and d['kind'] == 'table':
            return d
        return None

    def choice(cid, kind, el=None):
        o = items.get(cid) or {}
        k = kinds.get(kind) or {}
        if kind == 'table' and el is not None and (kinds.get('heatmap') or {}).get('style') not in (None, '', 'keep') \
                and is_numeric_table(el):
            k = kinds['heatmap']  # numeric tables follow the heatmap choice
        style = o.get('style') if o.get('style') not in (None, '', 'inherit') else k.get('style') or 'keep'
        ctype = o.get('chart_type') if o.get('chart_type') not in (None, '', 'inherit') else \
            k.get('chart_type') or 'keep'
        return _norm(kind, style), ctype

    def option(cid, kind, key, default, el=None):
        o = items.get(cid) or {}
        if o.get(key) not in (None, '', 'inherit'):
            return o[key]
        k = kinds.get(kind) or {}
        if kind == 'table' and el is not None and is_numeric_table(el) and \
                (kinds.get('heatmap') or {}).get('style') not in (None, '', 'keep'):
            k = kinds['heatmap']
        return k.get(key, default)

    for n, s in enumerate(prs.slides, 1):
        tree = s.shapes._spTree
        connected = flow_nodes(tree)
        style, _ = choice(f'{n}:bg', 'background')
        explicit = (items.get(f'{n}:bg') or {}).get('style') not in (None, '', 'inherit')
        flip = False
        bg_design = mine(style, 'background')
        if style.startswith('my:') and bg_design is None:
            style = 'keep'
        if bg_design is not None and (explicit or not _picture_background(s)):
            was_dark = _is_dark_bg(s)
            dark_page = _custom.background(s, bg_design['params'], ctx)
            counts['background'] = counts.get('background', 0) + 1
            sctx = ctx.dark_slide() if dark_page and not ctx.dark else ctx.flipped() if was_dark else ctx
            if not dark_page and _custom.hexof(bg_design['params']['colour'], ctx) != 'FFFFFF':
                sctx = sctx.on_canvas()
            style = 'custom'
        elif bg_design is not None:
            style = 'keep'
        if style == 'custom':
            pass
        elif _picture_background(s) and not explicit:
            style = 'keep'  # a branded picture background is only replaced when asked for that slide
        elif style != 'keep' and _is_dark_bg(s):
            style, flip = 'title-glow', True  # dark title/section slides are redrawn light, text becomes ink
        if style == 'custom':
            pass
        else:
            if style != 'keep' and _background_style(s, style, ctx):
                counts['background'] = counts.get('background', 0) + 1
            sctx = ctx.dark_slide() if style == 'keep' and _is_dark_bg(s) and not ctx.dark else ctx
            if flip:
                sctx = sctx.flipped()
            if style == 'canvas':
                sctx = sctx.on_canvas()
            if style == 'keep' and _picture_background(s):
                sctx = sctx.on_picture()
        order = {}
        elements = list(_walk(tree))
        card_total = sum(1 for e in elements if classify(e, connected) == 'card')
        strip_cards = []
        for el in elements:
            kind = classify(el, connected)
            if not kind:
                continue
            cid = f'{n}:{_cnv(el).get("id")}'
            style, ctype = choice(cid, kind, el)
            D = mine(style, kind, el)
            if style.startswith('my:') and D is None:
                style = 'keep'  # a custom design of another kind (or one that is gone): leave it be
            CP = D['params'] if D else None
            box = option(cid, kind, 'container', 'none', el) if kind in ('chart', 'table') else 'none'
            if style == 'keep' and ctype == 'keep' and box in ('none', 'keep', None, ''):
                continue
            idx = order.get(kind, 0)
            order[kind] = idx + 1
            if kind == 'flow' and ln_(el) != 'cxnSp':
                order['node'] = order.get('node', -1) + 1
            accent = colour if colour in ACCENTS else ACCENTS[idx % 6] if kind in ('card', 'shape') else 'accent1'
            if kind == 'card' and colour not in ACCENTS and style in ('kpi-minimal',):
                accent = 'accent1'
            if (items.get(cid) or {}).get('colour') in ACCENTS:
                accent = items[cid]['colour']
            ok = False
            if kind == 'chart':
                part = _chart_part(s, el)
                if part is None:
                    continue
                cs = part._element
                if ctype != 'keep':
                    if _switch_type(cs, ctype):
                        ok = True
                    else:
                        skipped.append(f'slide {n}: {_cnv(el).get("name")} can’t become {ctype}')
                if D:
                    over, palette = _custom.chart_recipe(CP, sctx)
                    ok = _chart_style(cs, D['base'], accent, sctx, over, palette) or ok
                    if CP['legend'] == 'none':
                        drop(kid(cs, 'chart'), 'legend')
                elif style != 'keep':
                    ok = _chart_style(cs, style, accent, sctx) or ok
                if box not in ('none', 'keep', None, ''):
                    legend = option(cid, 'chart', 'legend', None) or \
                        (('chips' if CP['legend'] == 'chips' else 'native') if D else 'native')
                    entries = _legend_entries(cs) if legend == 'chips' else []
                    pie = cs.find(f'.//{{{C}}}pieChart') is not None or cs.find(f'.//{{{C}}}doughnutChart') is not None
                    if entries and (len(entries) >= 2 or pie) and len(entries) <= 8:
                        leg = kid(kid(cs, 'chart'), 'legend')
                        if leg is not None:
                            leg.getparent().remove(leg)
                    else:
                        entries = []
                    centre = _donut_centre(cs) if (entries or kid(kid(cs, 'chart'), 'legend') is None) and \
                        not (D and not CP['centre']) else None
                    ok = _contain(el, box, accent, sctx, title=_chart_title(cs), legend=entries or None,
                                  centre=centre) or ok
            elif kind == 'table':
                tctx = copy.copy(sctx)
                tctx.on_grey = box == 'grey'
                if D and D['kind'] == 'heatmap':
                    ok = _custom.heat(el, el.find(f'.//{{{A}}}tbl'), CP, accent, tctx)
                elif D:
                    ok = _custom.table(el, CP, accent, tctx)
                else:
                    ok = _table_style(el, style, accent, tctx) if style != 'keep' else False
                if box not in ('none', 'keep', None, ''):
                    ok = _contain(el, box, accent, sctx, table=True) or ok
            elif kind == 'card':
                if D:
                    if (items.get(cid) or {}).get('colour') not in ACCENTS:
                        accent = _custom.accent_for(CP['colours'], idx, sctx, accent)
                    mode = option(cid, 'card', 'icons', None)
                    ok = _card_style(el, D['base'], accent, sctx, icon=(items.get(cid) or {}).get('icon'),
                                     icon_mode=CP['chip'] if mode in (None, '', 'auto') else mode,
                                     pos=(idx, card_total), custom=CP)
                    if ok and CP['strip']:
                        strip_cards.append(el)
                else:
                    ok = _card_style(el, style, accent, sctx, icon=(items.get(cid) or {}).get('icon'),
                                     icon_mode=option(cid, 'card', 'icons', 'auto'), pos=(idx, card_total))
                    if ok and style == 'kpi-strip':
                        strip_cards.append(el)
            elif kind == 'shape':
                ok = _custom.shape(el, CP, accent, sctx, idx) if D else _shape_style(el, style, accent, sctx)
            elif kind == 'flow':
                if D:
                    ok = _custom.flow(el, CP, 'accent1' if colour not in ACCENTS else colour, sctx,
                                      max(0, order.get('node', 0)))
                else:
                    node_acc = ACCENTS[order.get('node', 0) % 6] if style == 'rainbow' else 'accent1'
                    ok = _flow_style(el, style, accent if colour in ACCENTS else node_acc, sctx)
            elif kind == 'picture':
                ok = _custom.picture(el, CP, accent, sctx) if D else _picture_style(el, style, accent, sctx)
            elif kind == 'title':
                ok = _custom.title(s, el, CP, accent, sctx) if D else _title_style(s, el, style, accent, sctx)
            elif kind == 'text':
                ok = _custom.text(el, CP, sctx) if D else _text_style(el, style, sctx)
            if ok:
                counts[kind] = counts.get(kind, 0) + 1
        if strip_cards:
            _kpi_strip(tree, strip_cards, sctx)
    out = io.BytesIO()
    prs.save(out)
    return out.getvalue(), {'restyled': counts, 'skipped': skipped, 'total': sum(counts.values())}


def _theme_hex(prs):
    """{'accent1': '4F46E5', …} from the first master's theme (for contrast decisions)."""
    try:
        for rel in prs.slide_masters[0].part.rels.values():
            if rel.reltype.endswith('/theme'):
                cs = etree.fromstring(rel.target_part.blob).find(f'.//{{{A}}}clrScheme')
                out = {}
                for c in cs:
                    v = c[0] if len(c) else None
                    if v is not None:
                        out[ln_(c)] = (v.get('lastClr') if ln_(v) == 'sysClr' else v.get('val') or '').upper()
                return out
    except Exception:  # noqa: BLE001
        pass
    return {}


def single_slide(data, n):
    """A copy of the deck that contains only slide n (for fast previews)."""
    from pptx.opc.packuri import PackURI
    prs = Presentation(io.BytesIO(data))
    lst = prs.slides._sldIdLst
    keep = None
    for i, sid in enumerate(list(lst), 1):
        if i != n:
            prs.part.drop_rel(sid.rId)
            lst.remove(sid)
        else:
            keep = prs.part.related_part(sid.rId)
    # slides still linked from the kept one (a hyperlink to slide 1, say) stay in the package: move them
    # out of the way, or saving renames the kept slide onto one of their names
    for k, part in enumerate(list(prs.part.package.iter_parts())):
        if part is not keep and str(part.partname).startswith('/ppt/slides/slide'):
            part.partname = PackURI(f'/ppt/slides/linked{k}.xml')
    out = io.BytesIO()
    prs.save(out)
    return out.getvalue()


def parse_cli(spec):
    """'look=fresh,chart=clean,table=striped,chart_type=line' -> plan."""
    plan = {'kinds': {}, 'items': {}}
    for part in (spec or '').split(','):
        if '=' not in part:
            continue
        k, v = (x.strip() for x in part.split('=', 1))
        if k == 'chart_type':
            plan['kinds'].setdefault('chart', {})['chart_type'] = v
        elif k in ('colour', 'color'):
            plan['colour'] = v
        elif k == 'look':
            plan['look'] = v
        else:
            plan['kinds'].setdefault(k, {})['style'] = v
    if plan.get('look') and plan['kinds']:
        from .looks import LOOK_BY_ID
        base = {k: dict(v) if isinstance(v, dict) else {'style': v}
                for k, v in LOOK_BY_ID[plan['look']]['kinds'].items()}
        for k, v in plan['kinds'].items():  # keep the look's container/icons, change only what was asked
            base.setdefault(k, {}).update(v)
        plan['kinds'] = base
    return plan
