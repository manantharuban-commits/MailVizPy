"""Human-readable descriptions of slides, shapes, transitions and animations."""
from .ooxml import A_NS, C_NS, NS, P_NS, child, children, local

TRANSITIONS = {
    'fade': 'Fade', 'push': 'Push', 'wipe': 'Wipe', 'cover': 'Cover', 'pull': 'Uncover', 'split': 'Split',
    'randomBar': 'Random Bars', 'blinds': 'Blinds', 'checker': 'Checkerboard', 'circle': 'Circle',
    'comb': 'Comb', 'cut': 'Cut', 'diamond': 'Diamond', 'dissolve': 'Dissolve', 'newsflash': 'Newsflash',
    'plus': 'Plus', 'random': 'Random', 'strips': 'Strips', 'wedge': 'Wedge', 'wheel': 'Wheel', 'zoom': 'Zoom',
    'vortex': 'Vortex', 'switch': 'Switch', 'flip': 'Flip', 'ripple': 'Ripple', 'honeycomb': 'Honeycomb',
    'prism': 'Prism', 'doors': 'Doors', 'window': 'Window', 'ferris': 'Ferris Wheel', 'gallery': 'Gallery',
    'conveyor': 'Conveyor', 'pan': 'Pan', 'glitter': 'Glitter', 'warp': 'Warp', 'flythrough': 'Fly Through',
    'flash': 'Flash', 'shred': 'Shred', 'reveal': 'Reveal', 'wheelReverse': 'Wheel Reverse', 'morph': 'Morph',
    'prstTrans': 'Preset',
}
PRESET_TRANS = {'curtains': 'Curtains', 'wind': 'Wind', 'fallOver': 'Fall Over', 'drape': 'Drape',
                'airplane': 'Airplane', 'origami': 'Origami', 'fracture': 'Fracture', 'crush': 'Crush',
                'peelOff': 'Peel Off', 'pageCurlDouble': 'Page Curl', 'pageCurlSingle': 'Page Curl',
                'prestige': 'Prestige'}

ENTR = {1: 'Appear', 2: 'Fly In', 3: 'Blinds', 4: 'Box', 5: 'Checkerboard', 6: 'Circle', 7: 'Crawl In',
        8: 'Diamond', 9: 'Dissolve In', 10: 'Fade', 11: 'Flash Once', 12: 'Peek In', 13: 'Plus',
        14: 'Random Bars', 15: 'Spiral In', 16: 'Split', 17: 'Stretch', 18: 'Strips', 19: 'Swivel',
        20: 'Wedge', 21: 'Wheel', 22: 'Wipe', 23: 'Zoom', 24: 'Random Effects', 25: 'Boomerang',
        26: 'Bounce', 27: 'Colour Typewriter', 28: 'Credits', 29: 'Ease In', 30: 'Float', 31: 'Grow & Turn',
        34: 'Light Speed', 35: 'Pinwheel', 37: 'Rise Up', 38: 'Swish', 39: 'Thin Line', 40: 'Unfold',
        41: 'Whip', 42: 'Ascend', 43: 'Center Revolve', 45: 'Fold', 47: 'Descend', 48: 'Sling',
        49: 'Spinner', 50: 'Spiral', 52: 'Curve Up', 53: 'Grow / Zoom', 54: 'Float In', 55: 'Expand'}
EMPH = {1: 'Fill Colour', 2: 'Font Colour', 3: 'Change Font', 4: 'Font Size', 5: 'Font Style',
        6: 'Grow / Shrink', 7: 'Line Colour', 8: 'Spin', 9: 'Transparency', 10: 'Bold Flash', 14: 'Blast',
        15: 'Bold Reveal', 16: 'Brush On Colour', 18: 'Brush On Underline', 19: 'Colour Blend',
        20: 'Colour Wave', 21: 'Complementary Colour', 24: 'Contrasting Colour', 25: 'Darken',
        26: 'Desaturate', 27: 'Flash Bulb', 28: 'Flicker', 30: 'Grow With Colour', 31: 'Lighten',
        32: 'Teeter', 34: 'Shimmer', 35: 'Blink', 36: 'Underline', 37: 'Wave'}
CLASS = {'entr': 'Entrance', 'exit': 'Exit', 'emph': 'Emphasis', 'path': 'Motion path',
         'verb': 'Media', 'mediacall': 'Media'}

TABLE_STYLES = {
    '{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}': 'Medium Style 2 – Accent 1',
    '{2D5ABB26-0587-4C30-8999-92F81FD0307C}': 'No Style, No Grid',
    '{5940675A-B579-460E-94D1-54222C63F5DA}': 'No Style, Table Grid',
    '{073A0DAA-6AF3-43AB-8588-CEC1D06C72B9}': 'Medium Style 2',
    '{21E4AEA4-8DFA-4A89-87EB-49C32662AFE8}': 'Medium Style 2 – Accent 2',
    '{F5AB1C69-6EDB-4FF4-983F-18BD219EF322}': 'Medium Style 2 – Accent 3',
    '{00A15C55-8517-42AA-B614-E9B94910E393}': 'Medium Style 2 – Accent 4',
    '{7DF18680-E054-41AD-8BC1-D1AEF772440D}': 'Medium Style 2 – Accent 5',
    '{93296810-A885-4BE3-A3E7-6D5BEEA58F35}': 'Medium Style 2 – Accent 6',
    '{9D7B26C5-4107-4FEC-AEDC-1716B250EE53}': 'Light Style 1 – Accent 1',
    '{3B4B98B0-60AC-42C2-AFA5-B58CD77FA1E5}': 'Light Style 1 – Accent 1',
    '{69012ECD-51FC-41F1-AA8D-1B2483CD663E}': 'Light Style 2 – Accent 1',
    '{D7AC3CCA-C797-4891-BE02-D94E43425B78}': 'Medium Style 4',
    '{E8034E78-7F5D-4C2E-B375-FC64B27BC917}': 'Dark Style 1',
}


def transition_info(sld):
    """-> dict(name, speed, duration_ms, advance) or None."""
    tr = None
    for el in sld.iter():
        if local(el) == 'transition':
            tr = el
            break  # mc:Choice comes before mc:Fallback, so this is the richest variant
    if tr is None:
        return None
    effect = next((c for c in tr if local(c) not in ('sndAc', 'extLst')), None)
    name = 'None'
    detail = ''
    if effect is not None:
        name = TRANSITIONS.get(local(effect), local(effect))
        if local(effect) == 'prstTrans':
            name = PRESET_TRANS.get(effect.get('prst'), effect.get('prst', 'Preset'))
        detail = effect.get('dir') or effect.get('orient') or effect.get('option') or ''
    dur = None
    for k, v in tr.attrib.items():
        if k.endswith('}dur') or k == 'dur':
            dur = int(v)
    if dur is None:
        dur = {'slow': 1000, 'med': 750, 'fast': 500}.get(tr.get('spd', 'fast'), 500)
    adv = 'on click' if tr.get('advClick', '1') != '0' else ''
    if tr.get('advTm'):
        adv = (adv + ' or ' if adv else '') + f"after {int(tr.get('advTm')) / 1000:g}s"
    return {'name': name, 'detail': detail, 'duration_ms': dur, 'advance': adv or 'manual',
            'sound': child(tr, 'sndAc') is not None}


def animation_list(sld, names):
    """-> list of dict(trigger, cls, effect, target) in play order."""
    out = []
    timing = next((c for c in sld if local(c) == 'timing'), None)
    if timing is None:
        return out
    for ctn in timing.iter('{%s}cTn' % P_NS):
        pclass = ctn.get('presetClass')
        if not pclass:
            continue
        pid = int(ctn.get('presetID', '0'))
        table = ENTR if pclass in ('entr', 'exit') else EMPH if pclass == 'emph' else {}
        effect = table.get(pid, f'Effect #{pid}')
        if pclass == 'exit':
            effect = effect.replace(' In', ' Out').replace('Appear', 'Disappear')
        if pclass == 'path':
            effect = 'Custom path' if pid == 0 else f'Motion path #{pid}'
        tgt = ctn.find('.//{%s}spTgt' % P_NS)
        spid = tgt.get('spid') if tgt is not None else None
        node = ctn.get('nodeType', '')
        trigger = {'clickEffect': 'On click', 'withEffect': 'With previous',
                   'afterEffect': 'After previous'}.get(node, node or 'Auto')
        dur = None
        for sub in ctn.iter('{%s}cTn' % P_NS):
            if sub is not ctn and sub.get('dur') and sub.get('dur') != 'indefinite' and sub.get('dur') != '1':
                dur = int(sub.get('dur'))
                break
        out.append({'trigger': trigger, 'cls': CLASS.get(pclass, pclass), 'effect': effect,
                    'target': names.get(spid, f'shape {spid}'), 'spid': spid, 'duration_ms': dur})
    return out


def shape_kind(el):
    tag = local(el)
    if tag == 'sp':
        nv = child(el, 'nvSpPr')
        ph = nv.find('.//{%s}ph' % P_NS) if nv is not None else None
        if ph is not None:
            return f"placeholder:{ph.get('type', 'body')}"
        c = child(nv, 'cNvSpPr') if nv is not None else None
        if c is not None and c.get('txBox') == '1':
            return 'textbox'
        sp = child(el, 'spPr')
        if sp is not None and child(sp, 'custGeom') is not None:
            return 'freeform'
        g = child(sp, 'prstGeom') if sp is not None else None
        return f"autoshape:{g.get('prst')}" if g is not None else 'shape'
    if tag == 'pic':
        if el.find('.//{%s}videoFile' % A_NS) is not None:
            return 'video'
        if el.find('.//{%s}audioFile' % A_NS) is not None:
            return 'audio'
        return 'picture'
    if tag == 'cxnSp':
        return 'connector'
    if tag == 'grpSp':
        return 'group'
    if tag == 'graphicFrame':
        gd = el.find('.//{%s}graphicData' % A_NS)
        uri = gd.get('uri', '') if gd is not None else ''
        if uri.endswith('/table'):
            return 'table'
        if uri.endswith('/chart'):
            return 'chart'
        if uri.endswith('/diagram'):
            return 'smartart'
        if 'ole' in uri:
            return 'ole-object'
        if 'chartex' in uri or 'chartEx' in uri:
            return 'chart (2016+)'
        return 'graphic-frame'
    if tag == 'AlternateContent':
        inner = el.find('.//{%s}Choice' % NS['mc'])
        for c in (inner if inner is not None else []):
            k = shape_kind(c)
            return f'{k} (Office 2010+)'
        return 'alternate-content'
    if tag == 'contentPart':
        return 'ink'
    return tag


def shape_name(el):
    for c in el.iter():
        if local(c) == 'cNvPr':
            return c.get('name', ''), c.get('id')
    return '', None


def text_of(el, limit=None):
    paras = []
    for p in el.iter('{%s}p' % A_NS):
        paras.append(''.join(t.text or '' for t in p.iter('{%s}t' % A_NS)))
    s = ' / '.join(x for x in paras if x)
    if limit and len(s) > limit:
        s = s[:limit - 1] + '…'
    return s


def fonts_of(el):
    """Explicit fonts and sizes used by text in el -> (set(typefaces), set(sizes))."""
    faces, sizes = set(), set()
    for node in el.iter():
        n = local(node)
        if n in ('rPr', 'endParaRPr', 'defRPr'):
            if node.get('sz'):
                sizes.add(int(node.get('sz')) / 100)
            lat = child(node, 'latin')
            if lat is not None and lat.get('typeface'):
                faces.add(lat.get('typeface'))
    return faces, sizes


def shape_summary(el):
    kind = shape_kind(el)
    name, sid = shape_name(el)
    faces, sizes = fonts_of(el)
    txt = text_of(el, 48)
    bits = [kind]
    if txt:
        bits.append(f'"{txt}"')
    if faces:
        bits.append(', '.join(sorted(faces)))
    if sizes:
        bits.append('/'.join(f'{s:g}' for s in sorted(sizes)) + 'pt')
    return f"[{sid}] {name} · " + ' · '.join(bits)


DIRS = {'u': 'up', 'd': 'down', 'l': 'left', 'r': 'right', 'lu': 'up-left', 'ru': 'up-right', 'ld': 'down-left',
        'rd': 'down-right', 'horz': 'horizontal', 'vert': 'vertical', 'in': 'in', 'out': 'out'}


def describe_transition(t):
    if not t:
        return ''
    d = f" ({DIRS.get(t['detail'], t['detail'])})" if t['detail'] else ''
    return f"{t['name']}{d}, {t['duration_ms'] / 1000:g} s, advances {t['advance']}"


def chart_kind(chart_part_element):
    plot = chart_part_element.find('.//{%s}plotArea' % C_NS)
    kinds = [local(c).replace('Chart', '') for c in plot if local(c).endswith('Chart')] if plot is not None else []
    return '+'.join(kinds)
