# ── PPTX→Code runtime ────────────────────────────────────────────────────────
# Small helpers used by generated deck code. Pure python-pptx + lxml.
# They write exact OOXML so a rebuilt deck matches the source deck.
import base64
import io
import re
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.oxml import parse_xml
from pptx.opc.package import PartFactory
from pptx.opc.packuri import PackURI
from pptx.util import Cm, Emu, Inches, Length, Pt  # noqa: F401  (used by generated code)

NSMAP = {  # @@NSMAP@@
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart',
    'mc': 'http://schemas.openxmlformats.org/markup-compatibility/2006',
}
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
A_NS = NSMAP['a']
P_NS = NSMAP['p']

ASSET_DIR = Path(globals().get('__file__', 'deck.py')).resolve().with_name('assets')
ASSETS_INLINE = {}   # name -> base64 text (single-file builds)
ASSETS_OVERRIDE = {}  # name -> bytes (used by the converter while it checks its own output)
PARTS = {}  # original part name -> {'ct', 'file', 'rels'}; filled in below the runtime


# ── assets ───────────────────────────────────────────────────────────────────
def _asset(name):
    if name in ASSETS_OVERRIDE:
        return ASSETS_OVERRIDE[name]
    if name in ASSETS_INLINE:
        return base64.b64decode(ASSETS_INLINE[name])
    return (ASSET_DIR / name).read_bytes()


def _stream(name):
    return io.BytesIO(_asset(name))


# ── build context ────────────────────────────────────────────────────────────
class _Ctx:
    def __init__(self, prs):
        self.prs = prs
        self.package = prs.part.package
        self.parts = {}        # original part name -> new Part
        self.reserved = set()  # part names handed out but maybe not yet reachable
        self.slides = []       # built slides, in order
        self.rels = {}         # slide part -> {original rId: spec}
        self.pending = []      # (part, slide number, reltype, token)
        self.unclaimed = {}    # slide part -> set of auto placeholder elements
        self.current = None


_CTX = None


def _open_template():
    global _CTX
    prs = Presentation(_stream('template.pptx'))
    _CTX = _Ctx(prs)
    return prs


# ── XML snippets ─────────────────────────────────────────────────────────────
def _decl():
    return ' '.join(f'xmlns:{k}="{v}"' for k, v in NSMAP.items())


def _x(xml):
    """Parse an OOXML snippet written with the prefixes in NSMAP."""
    wrapper = parse_xml(f'<_w {_decl()}>{xml}</_w>')
    el = wrapper[0]
    wrapper.remove(el)
    return el


def _q(tag):
    """'a:srgbClr' -> Clark name."""
    if ':' in tag:
        pfx, local = tag.split(':', 1)
        return f'{{{NSMAP[pfx]}}}{local}'
    return tag


def _local(el):
    return etree.QName(el).localname if isinstance(el.tag, str) else ''


def _part_of(obj):
    if hasattr(obj, 'part'):
        return obj.part
    return _CTX.current.part


def _el_of(obj):
    if hasattr(obj, '_tc'):
        return obj._tc
    return obj._element if hasattr(obj, '_element') else obj


# ── relationships & parts ────────────────────────────────────────────────────
def _reserve(original):
    m = re.match(r'^(.*?)(\d*)(\.[^./]+)$', original)
    stem, ext = (m.group(1), m.group(3)) if m else (original, '')
    taken = {str(p.partname) for p in _CTX.package.iter_parts()} | _CTX.reserved
    if original not in taken:
        name = original
    else:
        n = 1
        while f'{stem}{n}{ext}' in taken:
            n += 1
        name = f'{stem}{n}{ext}'
    _CTX.reserved.add(name)
    return name


def _remap_tree(root, mapping):
    for el in root.iter():
        if not isinstance(el.tag, str):
            continue
        for k, v in list(el.attrib.items()):
            if k.startswith('{' + R_NS) and v in mapping:
                el.set(k, mapping[v])


def _part(key):
    """Create (once) a copy of an original package part and its own relationships."""
    if key in _CTX.parts:
        return _CTX.parts[key]
    info = PARTS[key]
    part = PartFactory(PackURI(_reserve(key)), info['ct'], _CTX.package, _asset(info['file']))
    part._p2c_origin = key
    _CTX.parts[key] = part
    mapping = {old: _rel(part, spec) for old, spec in info.get('rels', {}).items()}
    if mapping:
        if hasattr(part, '_element'):
            _remap_tree(part._element, mapping)
        else:  # blob parts (VML, ActiveX …) may not even be well-formed XML: swap quoted ids in place
            part._blob = re.sub(rb'(["\'])(rId\d+)\1',
                                lambda m: m.group(1) + mapping.get(m.group(2).decode(), m.group(2).decode()).encode()
                                + m.group(1), part.blob)
    return part


def _rel(src_part, spec):
    """Relate src_part to a target described by spec; returns the new rId."""
    kind = spec[0]
    if kind == 'part':
        return src_part.relate_to(_part(spec[2]), spec[1])
    if kind == 'ext':
        return src_part.relate_to(spec[2], spec[1], is_external=True)
    if kind == 'slide':
        n = spec[2]
        if n <= len(_CTX.slides):
            return src_part.relate_to(_CTX.slides[n - 1].part, spec[1])
        token = f'__p2c_slide_{n}_{len(_CTX.pending)}__'
        _CTX.pending.append((src_part, n, spec[1], token))
        return token
    if kind == 'layout':
        m, l = spec[2], spec[3]
        return src_part.relate_to(_CTX.prs.slide_masters[m].slide_layouts[l].part, spec[1])
    raise ValueError(spec)


def _remap(owner, el):
    """Point r:id style attributes in a snippet at relationships of the owning part."""
    part = _part_of(owner)
    rels = _CTX.rels.get(part, {})
    cache = {}
    for node in el.iter():
        if not isinstance(node.tag, str):
            continue
        for k, v in list(node.attrib.items()):
            if k.startswith('{' + R_NS) and v:
                if v not in rels:  # dangling reference in the source deck
                    node.set(k, '')
                    continue
                if v not in cache:
                    cache[v] = _rel(part, rels[v])
                node.set(k, cache[v])
    return el


# ── slides ───────────────────────────────────────────────────────────────────
def _new_slide(prs, master=0, layout=0, rels=None, name=None, hidden=False, keep_placeholders=False):
    lay = prs.slide_masters[master].slide_layouts[layout]
    slide = prs.slides.add_slide(lay)
    _CTX.slides.append(slide)
    _CTX.rels[slide.part] = rels or {}
    _CTX.current = slide
    tree = slide.shapes._spTree
    autos = [el for el in tree if _local(el) not in ('nvGrpSpPr', 'grpSpPr', 'extLst')]
    if keep_placeholders:
        _CTX.unclaimed[slide.part] = set(autos)
    else:
        for el in autos:
            tree.remove(el)
    cSld = slide._element.cSld
    if name:
        cSld.set('name', name)
    if hidden:
        slide._element.set('show', '0')
    return slide


def _ph(slide, idx):
    """Claim the placeholder this slide inherited from its layout."""
    for el in list(_CTX.unclaimed.get(slide.part, ())):
        ph = el.find('.//' + _q('p:ph'))
        if ph is not None and int(ph.get('idx', '0')) == idx:
            _CTX.unclaimed[slide.part].discard(el)
            return slide.shapes._shape_factory(el)
    raise KeyError(f'layout has no placeholder idx={idx}')


def _new_ph(container, kind=None, idx=None, **attrs):
    """A placeholder the layout doesn't supply: _new_ph(slide, 'sldNum', 12)."""
    a = ''.join(f' {k}="{v}"' for k, v in (('type', kind), ('idx', idx)) if v is not None)
    a += ''.join(f' {k}="{v}"' for k, v in attrs.items())
    el = _x('<p:sp><p:nvSpPr><p:cNvPr id="0" name=""/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>'
            f'<p:nvPr><p:ph{a}/></p:nvPr></p:nvSpPr><p:spPr/>'
            '<p:txBody><a:bodyPr/><a:lstStyle/><a:p/></p:txBody></p:sp>')
    _append_shape(_tree(container), el)
    return _CTX.current.shapes._shape_factory(el)


def _drop(slide, name):
    """Remove a slide-level element the source deck doesn't have (e.g. 'clrMapOvr')."""
    for c in [c for c in slide._element if _local(c) == name]:
        slide._element.remove(c)


def _end_slide(slide):
    tree = slide.shapes._spTree
    for el in _CTX.unclaimed.pop(slide.part, ()):
        if el.getparent() is tree:
            tree.remove(el)


def _place(container, shape, id, name, descr=None, title=None, hidden=None, cid=None):
    """Set id/name (ids keep animations pointing at the right shape) and move to the top of z-order."""
    el = _el_of(shape)
    cNvPr = next(c for c in el[0] if _local(c) == 'cNvPr')
    cNvPr.set('id', str(id))
    cNvPr.set('name', name)
    for k, v in (('descr', descr), ('title', title), ('hidden', hidden)):
        if v is not None:
            cNvPr.set(k, str(v))
    if cid:
        cNvPr.append(_x('<a:extLst><a:ext uri="{FF2B5EF4-FFF2-40B4-BE49-F238E27FC236}">'
                        '<a16:creationId xmlns:a16="http://schemas.microsoft.com/office/drawing/2014/main" '
                        f'id="{cid}"/></a:ext></a:extLst>'))
    tree = _tree(container)
    tree.remove(el)
    _append_shape(tree, el)
    return shape


def _tree(container):
    if hasattr(container, 'shapes'):
        return container.shapes._spTree
    return _el_of(container)


def _append_shape(tree, el):
    tail = tree.find(_q('p:extLst'))
    if tail is not None:
        tail.addprevious(el)
    else:
        tree.append(el)


def _add(container, xml):
    """Insert a shape exactly as authored (used for features python-pptx has no API for)."""
    el = _remap(_CTX.current, _x(xml))
    _append_shape(_tree(container), el)
    return el


_SLD_ORDER = ['cSld', 'clrMapOvr', 'transition', 'timing', 'extLst']


def _rank(el):
    name = _local(el)
    if name == 'AlternateContent':
        for d in el.iter():
            if _local(d) in _SLD_ORDER[2:4]:
                name = _local(d)
                break
    return _SLD_ORDER.index(name) if name in _SLD_ORDER else len(_SLD_ORDER)


def _slide_xml(slide, xml):
    """Add a slide-level element (transition, timing, colour-map override, extensions)."""
    sld = slide._element
    el = _remap(slide, _x(xml))
    r = _rank(el)
    for old in [c for c in sld if _rank(c) == r]:
        sld.remove(old)
    after = [c for c in sld if _rank(c) <= r]
    if after:
        after[-1].addnext(el)
    else:
        sld.insert(0, el)
    return el


_transition = _slide_xml
_timing = _slide_xml


def _background(slide, xml):
    cSld = slide._element.cSld
    for old in cSld.findall(_q('p:bg')):
        cSld.remove(old)
    cSld.insert(0, _remap(slide, _x(xml)))


def _cSld_extra(slide, xml):
    """Custom data / ActiveX controls / extensions that follow the shape tree."""
    cSld = slide._element.cSld
    el = _remap(slide, _x(xml))
    for old in [c for c in cSld if _local(c) == _local(el)]:
        cSld.remove(old)
    cSld.append(el)


def _tree_props(slide, xml):
    """Replace the slide's root group properties (nvGrpSpPr + grpSpPr)."""
    tree = slide.shapes._spTree
    for el in _x(f'<_t>{xml}</_t>'):
        for old in [c for c in tree if _local(c) == _local(el)]:
            tree.replace(old, el)


# ── exact-patch layer ────────────────────────────────────────────────────────
# Child order for elements that patches may insert into.
_ORDER = {
    'sp': ['nvSpPr', 'spPr', 'style', 'txBody', 'extLst'],
    'pic': ['nvPicPr', 'blipFill', 'spPr', 'style', 'extLst'],
    'cxnSp': ['nvCxnSpPr', 'spPr', 'style', 'extLst'],
    'grpSp': ['nvGrpSpPr', 'grpSpPr', '*', 'extLst'],
    'graphicFrame': ['nvGraphicFramePr', 'xfrm', 'graphic', 'extLst'],
    'nvSpPr': ['cNvPr', 'cNvSpPr', 'nvPr'],
    'nvPicPr': ['cNvPr', 'cNvPicPr', 'nvPr'],
    'nvCxnSpPr': ['cNvPr', 'cNvCxnSpPr', 'nvPr'],
    'nvGrpSpPr': ['cNvPr', 'cNvGrpSpPr', 'nvPr'],
    'nvGraphicFramePr': ['cNvPr', 'cNvGraphicFramePr', 'nvPr'],
    'txBody': ['bodyPr', 'lstStyle', '*'],
    'p': ['pPr', '*', 'endParaRPr'],
    'r': ['rPr', 't'],
    'br': ['rPr'],
    'fld': ['rPr', 'pPr', 't'],
    'tbl': ['tblPr', 'tblGrid', '*'],
    'tc': ['txBody', 'tcPr', 'extLst'],
    'tr': ['tc', 'extLst'],
    'endParaRPr': None,
    'defRPr': None,
    'spPr': ['xfrm', 'custGeom', 'prstGeom', 'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill',
             'grpFill', 'ln', 'effectLst', 'effectDag', 'scene3d', 'sp3d', 'extLst'],
    'grpSpPr': ['xfrm', 'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill', 'effectLst',
                'effectDag', 'scene3d', 'extLst'],
    'xfrm': ['off', 'ext', 'chOff', 'chExt'],
    'ln': ['noFill', 'solidFill', 'gradFill', 'pattFill', 'prstDash', 'custDash', 'round', 'bevel', 'miter',
           'headEnd', 'tailEnd', 'extLst'],
    'rPr': ['ln', 'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill', 'effectLst', 'effectDag',
            'highlight', 'uLnTx', 'uLn', 'uFillTx', 'uFill', 'latin', 'ea', 'cs', 'sym', 'hlinkClick',
            'hlinkMouseOver', 'rtl', 'extLst'],
    'pPr': ['lnSpc', 'spcBef', 'spcAft', 'buClrTx', 'buClr', 'buSzTx', 'buSzPct', 'buSzPts', 'buFontTx', 'buFont',
            'buNone', 'buAutoNum', 'buChar', 'buBlip', 'tabLst', 'defRPr', 'extLst'],
    'bodyPr': ['prstTxWarp', 'noAutofit', 'normAutofit', 'spAutoFit', 'scene3d', 'sp3d', 'flatTx', 'extLst'],
    'tcPr': ['lnL', 'lnR', 'lnT', 'lnB', 'lnTlToBr', 'lnBlToTr', 'cell3D', 'noFill', 'solidFill', 'gradFill',
             'blipFill', 'pattFill', 'grpFill', 'headers', 'extLst'],
    'tblPr': ['noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill', 'effectLst', 'effectDag',
              'tableStyleId', 'extLst'],
    'cNvPr': ['hlinkClick', 'hlinkHover', 'extLst'],
    'nvPr': ['ph', 'audioCd', 'wavAudioFile', 'audioFile', 'videoFile', 'quickTimeFile', 'custDataLst', 'extLst'],
}


_ORDER['endParaRPr'] = _ORDER['defRPr'] = _ORDER['rPr']


def _resolve(root, path):
    node = root
    for step in path.split('/'):
        m = re.match(r'^([\w:]+?)(?:\[(\d+)\])?$', step)
        name, idx = m.group(1).split(':')[-1], int(m.group(2) or 0)
        kids = [c for c in node if _local(c) == name]
        node = kids[idx] if idx < len(kids) else None
        if node is None:
            return None
    return node


def _insert_ordered(parent, el):
    order = _ORDER.get(_local(parent))
    name = _local(el)
    if not order or name not in order:
        parent.append(el)
        return
    rank = order.index(name)
    star = order.index('*') if '*' in order else None

    def rank_of(c):
        n = _local(c)
        return order.index(n) if n in order else (star if star is not None else len(order))

    before = [c for c in parent if rank_of(c) > rank]
    if before:
        before[0].addprevious(el)
    else:
        parent.append(el)


def _sync(shape, path, xml):
    """Make one part of a shape identical to the source deck.

    Used only where python-pptx has no API for a feature (effects, bullets with custom
    glyphs, 3-D, theme colour modifiers ...). `xml=None` removes the element.
    """
    root = _el_of(shape)
    *parents, last = path.split('/')
    parent = _resolve(root, '/'.join(parents)) if parents else root
    if parent is None:
        raise ValueError(f'_sync: missing parent for {path}')
    m = re.match(r'^([\w:]+?)(?:\[(\d+)\])?$', last)
    name, idx = m.group(1).split(':')[-1], int(m.group(2) or 0)
    kids = [c for c in parent if _local(c) == name]
    old = kids[idx] if idx < len(kids) else None
    if xml is None:
        if old is not None:
            parent.remove(old)
        return None
    new = _remap(shape if hasattr(shape, 'part') else _CTX.current, _x(xml))
    if old is not None:
        parent.replace(old, new)
    elif kids:
        kids[-1].addnext(new)
    else:
        _insert_ordered(parent, new)
    return new


def _attrs(shape, path, attrs):
    el = _resolve(_el_of(shape), path) if path else _el_of(shape)
    for k in list(el.attrib):
        del el.attrib[k]
    for k, v in attrs.items():
        el.set(_q(k), str(v))


# ── colours ──────────────────────────────────────────────────────────────────
class C:
    """Colour with modifiers, e.g. C('accent1', lumMod=75000) or C('1F4E79', alpha=50000)."""

    def __init__(self, value, **mods):
        self.value, self.mods = value, mods

    def __repr__(self):
        extra = ''.join(f', {k}={v!r}' for k, v in self.mods.items())
        return f'C({self.value!r}{extra})'


def _clr(spec):
    """Colour spec -> DrawingML colour element XML."""
    value, mods = (spec.value, dict(spec.mods)) if isinstance(spec, C) else (spec, {})
    lastClr = mods.pop('lastClr', None)
    inner = ''.join(f'<a:{k} val="{v}"/>' for k, v in mods.items())
    v = str(value)
    if v.startswith('sys:'):
        tag, attrs = 'sysClr', f'val="{v[4:]}"' + (f' lastClr="{lastClr}"' if lastClr else '')
    elif v.startswith('prst:'):
        tag, attrs = 'prstClr', f'val="{v[5:]}"'
    elif re.fullmatch(r'[0-9A-Fa-f]{6}', v):
        tag, attrs = 'srgbClr', f'val="{v.upper()}"'
    else:
        tag, attrs = 'schemeClr', f'val="{v}"'
    return f'<a:{tag} {attrs}>{inner}</a:{tag}>' if inner else f'<a:{tag} {attrs}/>'


class G:
    """Gradient fill: G(stops=[(0, '0EA59B'), (100000, '4FD1C5')], angle=90)."""

    def __init__(self, stops, angle=None, scaled=None, path=None, rotWithShape=None, flip=None, tile=None):
        self.stops, self.angle, self.scaled, self.path = stops, angle, scaled, path
        self.rotWithShape, self.flip, self.tile = rotWithShape, flip, tile

    def xml(self):
        attrs = ''.join(f' {k}="{v}"' for k, v in (('flip', self.flip), ('rotWithShape', self.rotWithShape)) if v is not None)
        gs = ''.join(f'<a:gs pos="{pos}">{_clr(c)}</a:gs>' for pos, c in self.stops)
        body = f'<a:gsLst>{gs}</a:gsLst>'
        if self.path:
            body += f'<a:path path="{self.path[0]}"><a:fillToRect {self.path[1]}/></a:path>' if isinstance(self.path, tuple) \
                else f'<a:path path="{self.path}"/>'
        elif self.angle is not None:
            sc = f' scaled="{self.scaled}"' if self.scaled is not None else ''
            body += f'<a:lin ang="{int(round(self.angle * 60000))}"{sc}/>'
        if self.tile:
            body += f'<a:tileRect {self.tile}/>'
        return f'<a:gradFill{attrs}>{body}</a:gradFill>'


def _fill_xml(value):
    if value == 'none':
        return '<a:noFill/>'
    if isinstance(value, G):
        return value.xml()
    return f'<a:solidFill>{_clr(value)}</a:solidFill>'


_FILLS = ('noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill')


def _spPr(shape):
    el = _el_of(shape)
    for c in el:
        if _local(c) in ('spPr', 'grpSpPr'):
            return c
    raise ValueError('shape has no spPr')


def _fill(shape, value):
    """value: hex 'F5A623' | theme name 'accent1' | C(...) | G(...) | 'none' | None (inherit)."""
    spPr = _spPr(shape)
    for c in [c for c in spPr if _local(c) in _FILLS]:
        spPr.remove(c)
    if value is None:
        return
    _insert_ordered(spPr, _x(_fill_xml(value)))


def _ln_xml(tag='ln', color=None, width=None, dash=None, none=False, cap=None, cmpd=None, algn=None,
            join=None, head=None, tail=None):
    attrs = ''
    if width is not None:
        attrs += f' w="{int(round(width * 12700))}"'
    for k, v in (('cap', cap), ('cmpd', cmpd), ('algn', algn)):
        if v is not None:
            attrs += f' {k}="{v}"'
    body = '<a:noFill/>' if none else (_fill_xml(color) if color is not None else '')
    if dash:
        body += f'<a:prstDash val="{dash}"/>'
    if join:
        body += f'<a:{join}/>' if join != 'miter' else '<a:miter lim="800000"/>'
    for t, end in (('headEnd', head), ('tailEnd', tail)):
        if end is not None:
            end = {'type': end} if isinstance(end, str) else end
            body += f'<a:{t}' + ''.join(f' {k}="{v}"' for k, v in end.items()) + '/>'
    return f'<a:{tag}{attrs}>{body}</a:{tag}>' if body else f'<a:{tag}{attrs}/>'


def _line(shape, **kw):
    """Outline: color, width (pt), dash, none=True, cap, cmpd, join, head/tail='triangle' or dict(...)."""
    spPr = _spPr(shape)
    for c in [c for c in spPr if _local(c) == 'ln']:
        spPr.remove(c)
    _insert_ordered(spPr, _x(_ln_xml('ln', **kw)))


class Shadow:
    """Outer shadow: Shadow(C('000000', alpha=40000), blurRad=38100, dist=38100, dir=5400000, algn='t')."""

    def __init__(self, color, **attrs):
        self.color, self.attrs = color, attrs

    def __repr__(self):
        extra = ''.join(f', {k}={v!r}' for k, v in self.attrs.items())
        return f'Shadow({self.color!r}{extra})'

    def xml(self):
        a = ''.join(f' {k}="{v}"' for k, v in self.attrs.items())
        return f'<a:effectLst><a:outerShdw{a}>{_clr(self.color)}</a:outerShdw></a:effectLst>'


def _effects(shape, value):
    """Shape effects: Shadow(...) or 'none' (an explicit empty effect list)."""
    spPr = _spPr(shape)
    for c in [c for c in spPr if _local(c) in ('effectLst', 'effectDag')]:
        spPr.remove(c)
    _insert_ordered(spPr, _x('<a:effectLst/>' if value == 'none' else value.xml()))


def _style(shape, line=None, fill=None, effect=None, font=None):
    """Theme style references (p:style): line/fill/effect=(idx, colour), font=('minor'|'major'|'none', colour)."""
    el = _el_of(shape)
    for c in [c for c in el if _local(c) == 'style']:
        el.remove(c)
    if line is None and fill is None and effect is None and font is None:
        return

    def ref(tag, spec):
        idx, col = spec if isinstance(spec, tuple) else (spec, None)
        inner = _clr(col) if col is not None else ''
        return f'<a:{tag} idx="{idx}">{inner}</a:{tag}>' if inner else f'<a:{tag} idx="{idx}"/>'

    xml = '<p:style>' + ref('lnRef', line) + ref('fillRef', fill) + ref('effectRef', effect) + \
        ref('fontRef', font) + '</p:style>'
    _insert_ordered(el, _x(xml))


def _locks(shape, **attrs):
    """Shape locks (a:spLocks / picLocks / …) exactly as stored."""
    nv = _el_of(shape)[0]
    cnv = nv[1]
    tag = {'cNvSpPr': 'spLocks', 'cNvPicPr': 'picLocks', 'cNvCxnSpPr': 'cxnSpLocks', 'cNvGrpSpPr': 'grpSpLocks',
           'cNvGraphicFramePr': 'graphicFrameLocks'}[_local(cnv)]
    for c in [c for c in cnv if _local(c) == tag]:
        cnv.remove(c)
    a = ''.join(f' {k}="{v}"' for k, v in attrs.items())
    cnv.insert(0, _x(f'<a:{tag}{a}/>'))


def _geom(shape, prst):
    geom = _spPr(shape).find(_q('a:prstGeom'))
    geom.set('prst', prst)


def _adj(shape, **guides):
    """Shape adjustments exactly as stored: _adj(shp, adj=18000)."""
    av = _spPr(shape).find(_q('a:prstGeom')).find(_q('a:avLst'))
    for c in list(av):
        av.remove(c)
    for k, v in guides.items():
        av.append(_x(f'<a:gd name="{k}" fmla="val {v}"/>'))


def _flip(shape, h=False, v=False):
    xfrm = _spPr(shape).find(_q('a:xfrm'))
    if h:
        xfrm.set('flipH', '1')
    if v:
        xfrm.set('flipV', '1')


def _connect(cxn, begin=None, end=None):
    """Glue a connector to shapes: begin=(shape_id, site), end=(shape_id, site)."""
    nv = _el_of(cxn)[0]
    c = next(x for x in nv if _local(x) == 'cNvCxnSpPr')
    for x in list(c):
        if _local(x) in ('stCxn', 'endCxn'):
            c.remove(x)
    if begin:
        c.append(_x(f'<a:stCxn id="{begin[0]}" idx="{begin[1]}"/>'))
    if end:
        c.append(_x(f'<a:endCxn id="{end[0]}" idx="{end[1]}"/>'))


# ── text ─────────────────────────────────────────────────────────────────────
def _txBody(obj):
    el = _el_of(obj)
    if _local(el) == 'txBody':
        return el
    for c in el:
        if _local(c) == 'txBody':
            return c
    if hasattr(obj, 'text_frame'):
        return obj.text_frame._txBody
    raise ValueError('no text body')


def _v(x):
    return str(int(x)) if isinstance(x, (Length, int)) and not isinstance(x, bool) else str(x)


def _frame(obj, autofit=None, font_scale=None, line_reduction=None, **attrs):
    """Text frame (a:bodyPr). attrs are stored verbatim: wrap='square', anchor='ctr', lIns=Inches(0.1)…"""
    body = _txBody(obj)
    bp = body.find(_q('a:bodyPr'))
    new = _x('<a:bodyPr/>')
    for k, v in attrs.items():
        new.set(k, _v(v))
    if autofit == 'shape':
        etree.SubElement(new, _q('a:spAutoFit'))
    elif autofit == 'none':
        etree.SubElement(new, _q('a:noAutofit'))
    elif autofit == 'normal':
        na = etree.SubElement(new, _q('a:normAutofit'))
        if font_scale is not None:
            na.set('fontScale', str(font_scale))
        if line_reduction is not None:
            na.set('lnSpcReduction', str(line_reduction))
    if bp is not None:
        body.replace(bp, new)
    else:
        body.insert(0, new)
    return body


class Pct:
    """Percentage spacing: Pct(115) -> 115 %."""

    def __init__(self, value):
        self.value = value

    def __repr__(self):
        return f'Pct({self.value!r})'


def _spacing(tag, value):
    if isinstance(value, Pct):
        return f'<a:{tag}><a:spcPct val="{int(round(value.value * 1000))}"/></a:{tag}>'
    return f'<a:{tag}><a:spcPts val="{int(round(Length(value).pt * 100))}"/></a:{tag}>'


def _ppr_xml(tag, align=None, level=None, line_spacing=None, space_before=None, space_after=None,
             bullet=None, bullet_font=None, bullet_color=None, bullet_size=None, autonum=None,
             start_at=None, no_bullet=False, tabs=None, default_run=None, **attrs):
    """bullet_color/size/font may be 'text' (follow the text); tabs=[(Inches(1), 'l'), …];
    default_run=dict(size=18, …) sets the paragraph's default character format."""
    a = {}
    if align is not None:
        a['algn'] = align
    if level is not None:
        a['lvl'] = level
    a.update(attrs)
    attr = ''.join(f' {k}="{_v(v)}"' for k, v in a.items())
    body = ''
    if line_spacing is not None:
        body += _spacing('lnSpc', line_spacing)
    if space_before is not None:
        body += _spacing('spcBef', space_before)
    if space_after is not None:
        body += _spacing('spcAft', space_after)
    if bullet_color == 'text':
        body += '<a:buClrTx/>'
    elif bullet_color is not None:
        body += f'<a:buClr>{_clr(bullet_color)}</a:buClr>'
    if bullet_size == 'text':
        body += '<a:buSzTx/>'
    elif isinstance(bullet_size, Length):
        body += f'<a:buSzPts val="{int(round(bullet_size.pt * 100))}"/>'
    elif bullet_size is not None:
        body += f'<a:buSzPct val="{int(round(bullet_size * 1000))}"/>'
    if bullet_font == 'text':
        body += '<a:buFontTx/>'
    elif bullet_font is not None:
        body += _font_xml('buFont', bullet_font)
    if no_bullet:
        body += '<a:buNone/>'
    elif autonum is not None:
        body += f'<a:buAutoNum type="{autonum}"' + (f' startAt="{start_at}"' if start_at else '') + '/>'
    elif bullet is not None:
        ch = bullet.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;')
        body += f'<a:buChar char="{ch}"/>'
    if tabs is not None:
        body += '<a:tabLst>' + ''.join(f'<a:tab pos="{_v(pos)}" algn="{al}"/>' for pos, al in tabs) + '</a:tabLst>'
    if default_run is not None:
        body += _rpr_xml('defRPr', **default_run)[0] or '<a:defRPr/>'
    if not attr and not body:
        return None
    return f'<a:{tag}{attr}>{body}</a:{tag}>' if body else f'<a:{tag}{attr}/>'


def _para(tf, i, **ppr):
    """Paragraph i of a text frame, rebuilt from scratch with the given paragraph properties."""
    body = _txBody(tf)
    paras = body.findall(_q('a:p'))
    if i < len(paras):
        p = paras[i]
        for c in list(p):
            p.remove(c)
        for k in list(p.attrib):
            del p.attrib[k]
    else:
        p = etree.SubElement(body, _q('a:p'))
    xml = _ppr_xml('pPr', **ppr)
    if xml:
        p.append(_x(xml))
    return p


class F:
    """Font face with extra attributes: F('Segoe UI', panose='020B0502040204020203', pitchFamily=34, charset=0)."""

    def __init__(self, typeface, **attrs):
        self.typeface, self.attrs = typeface, attrs

    def __repr__(self):
        extra = ''.join(f', {k}={v!r}' for k, v in self.attrs.items())
        return f'F({self.typeface!r}{extra})'


def _font_xml(tag, face):
    face = face if isinstance(face, F) else F(face)
    tf = face.typeface.replace('&', '&amp;').replace('"', '&quot;')
    extra = ''.join(f' {k}="{v}"' for k, v in face.attrs.items())
    return f'<a:{tag} typeface="{tf}"{extra}/>'


def _rpr_xml(tag, size=None, bold=None, italic=None, underline=None, strike=None, color=None, font=None,
             ea=None, cs=None, sym=None, highlight=None, link=None, outline=None, effects=None, **attrs):
    """outline='none' | colour | (colour, width_pt); effects='none' writes an empty effect list."""
    a = {}
    if size is not None:
        a['sz'] = int(round(size * 100))
    if bold is not None:
        a['b'] = int(bool(bold))
    if italic is not None:
        a['i'] = int(bool(italic))
    if underline is not None:
        a['u'] = underline
    if strike is not None:
        a['strike'] = strike
    a.update(attrs)
    attr = ''.join(f' {k}="{_v(v)}"' for k, v in a.items())
    body = ''
    if outline is not None:
        if outline == 'none':
            body += '<a:ln><a:noFill/></a:ln>'
        else:
            col, w = outline if isinstance(outline, tuple) else (outline, None)
            wa = f' w="{int(round(w * 12700))}"' if w is not None else ''
            body += f'<a:ln{wa}>{_fill_xml(col)}</a:ln>'
    if color is not None:
        body += _fill_xml(color)
    if effects == 'none':
        body += '<a:effectLst/>'
    elif isinstance(effects, Shadow):
        body += effects.xml()
    if highlight is not None:
        body += f'<a:highlight>{_clr(highlight)}</a:highlight>'
    for t, face in (('latin', font), ('ea', ea), ('cs', cs), ('sym', sym)):
        if face is not None:
            body += _font_xml(t, face)
    if link is not None:
        body += '<a:hlinkClick r:id="__link__"/>'
    if not attr and not body:
        return None, link
    xml = f'<a:{tag}{attr}>{body}</a:{tag}>' if body else f'<a:{tag}{attr}/>'
    return xml, link


def _apply_rpr(parent, xml, link):
    if not xml:
        return
    el = _x(xml)
    if link is not None:  # external hyperlink on the text
        rid = _CTX.current.part.relate_to(
            link, 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink', is_external=True)
        el.find(_q('a:hlinkClick')).set(_q('r:id'), rid)
    parent.insert(0, el)


def _run(p, text, **font):
    """Text run with character formatting: size (pt), bold, italic, color, font='Calibri', link=url, …"""
    r = etree.SubElement(p, _q('a:r'))
    end = p.find(_q('a:endParaRPr'))
    if end is not None:
        end.addprevious(r)
    t = etree.SubElement(r, _q('a:t'))
    t.text = text
    _apply_rpr(r, *_rpr_xml('rPr', **font))
    return r


def _br(p, **font):
    br = etree.SubElement(p, _q('a:br'))
    _apply_rpr(br, *_rpr_xml('rPr', **font))
    return br


def _field(p, kind, fid, text, para=None, **font):
    """Auto-updating field such as slide number: _field(p, 'slidenum', '{...}', '‹#›')."""
    f = etree.SubElement(p, _q('a:fld'))
    end = p.find(_q('a:endParaRPr'))
    if end is not None:
        end.addprevious(f)
    f.set('id', fid)
    if kind:
        f.set('type', kind)
    t = etree.SubElement(f, _q('a:t'))
    t.text = text
    if para is not None:
        t.addprevious(_x(_ppr_xml('pPr', **para) or '<a:pPr/>'))
    _apply_rpr(f, *_rpr_xml('rPr', **font))
    return f


def _end(p, **font):
    xml, link = _rpr_xml('endParaRPr', **font)
    el = _x(xml or '<a:endParaRPr/>')
    p.append(el)
    return el


def _no_text(shape):
    body = _el_of(shape).find(_q('p:txBody'))
    if body is not None:
        body.getparent().remove(body)


# ── tables ───────────────────────────────────────────────────────────────────
def _cell(cell, fill=None, borders=None, **attrs):
    """Cell properties: fill colour, borders={'L': dict(width=1, color='000000'), …}, margins, anchor='ctr'."""
    tc = cell._tc
    old = tc.find(_q('a:tcPr'))
    if old is not None:
        tc.remove(old)
    attr = ''.join(f' {k}="{_v(v)}"' for k, v in attrs.items())
    body = ''
    for side in ('L', 'R', 'T', 'B', 'TlToBr', 'BlToTr'):
        if borders and side in borders:
            body += _ln_xml(f'ln{side}', **borders[side])
    body += _fill_xml(fill) if fill is not None else ''
    tc.append(_x(f'<a:tcPr{attr}>{body}</a:tcPr>' if body else f'<a:tcPr{attr}/>'))


def _merge(table, r1, c1, r2, c2):
    """Merge a cell range without moving any text (python-pptx's merge() moves it)."""
    rows, cols = r2 - r1 + 1, c2 - c1 + 1
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            tc = table.cell(r, c)._tc
            if r == r1 and rows > 1:
                tc.set('rowSpan', str(rows))
            if c == c1 and cols > 1:
                tc.set('gridSpan', str(cols))
            if c > c1:
                tc.set('hMerge', '1')
            if r > r1:
                tc.set('vMerge', '1')


def _table_style(table, style_id=None, **flags):
    """Table style + banding flags, e.g. _table_style(tbl, '{5C22544A-…}', firstRow=1, bandRow=1)."""
    tbl = table._tbl
    old = tbl.find(_q('a:tblPr'))
    attr = ''.join(f' {k}="{v}"' for k, v in flags.items())
    body = f'<a:tableStyleId>{style_id}</a:tableStyleId>' if style_id else ''
    new = _x(f'<a:tblPr{attr}>{body}</a:tblPr>')
    if old is not None:
        tbl.replace(old, new)
    else:
        tbl.insert(0, new)


# ── charts ───────────────────────────────────────────────────────────────────
def _chart_style(graphic_frame, xml_asset, data=None, rels=None):
    """Restore the source chart's exact formatting, then (re)apply the editable data."""
    from pptx.chart.chart import Chart
    part = graphic_frame.chart_part
    wb_rid = part._element.xlsx_part_rId
    new = parse_xml(_asset(xml_asset))
    ext = new.find(_q('c:externalData'))
    if ext is not None:
        if wb_rid:
            ext.set(_q('r:id'), wb_rid)
        else:
            new.remove(ext)
    if rels:
        mapping = {old: _rel(part, spec) for old, spec in rels.items()}
        for node in new.iter():
            if isinstance(node.tag, str) and node is not ext:
                for k, v in list(node.attrib.items()):
                    if k.startswith('{' + R_NS) and v in mapping:
                        node.set(k, mapping[v])
    part._element = new
    for cached in ('chart', 'chart_workbook'):
        part.__dict__.pop(cached, None)
    if data is not None:
        Chart(new, part).replace_data(data)
    return Chart(part._element, part)


# ── notes ────────────────────────────────────────────────────────────────────
def _notes(slide, text):
    slide.notes_slide.notes_text_frame.text = text


def _notes_xml(slide, xml):
    """Speaker notes with their exact formatting."""
    body = slide.notes_slide.notes_placeholder._element.find(_q('p:txBody'))
    new = _x(xml)
    body.getparent().replace(body, new)


# ── finish ───────────────────────────────────────────────────────────────────
def _fix_namespaces(part):
    el = part._element
    s = etree.tostring(el).decode('utf-8')
    wanted = set()
    for m in re.finditer(r'(?:Ignorable|Requires)="([^"]*)"', s):
        wanted.update(m.group(1).split())
    missing = [p for p in sorted(wanted) if p not in (el.nsmap or {}) and p in NSMAP]
    if not missing:
        return
    decl = ''.join(f' xmlns:{p}="{NSMAP[p]}"' for p in missing)
    s = re.sub(r'^(<[\w:]+)', lambda m: m.group(1) + decl, s, count=1)
    part._element = parse_xml(s.encode('utf-8'))


def _finish(prs, slide_ids=None, custom_shows=None):
    """Resolve forward slide links, restore slide ids (used by sections) and custom shows."""
    for part, n, reltype, token in _CTX.pending:
        rid = part.relate_to(_CTX.slides[n - 1].part, reltype)
        _remap_tree(part._element, {token: rid})
    _CTX.pending.clear()
    lst = prs.slides._sldIdLst
    if slide_ids:
        for sldId, new_id in zip(lst, slide_ids):
            sldId.set('id', str(new_id))
    if custom_shows:
        pres = prs.part._element
        for old in pres.findall(_q('p:custShowLst')):
            pres.remove(old)
        shows = ''
        for i, (name, sid, nums) in enumerate(custom_shows):
            refs = ''.join(
                f'<p:sld r:id="{prs.part.relate_to(_CTX.slides[n - 1].part, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide")}"/>'
                for n in nums)
            shows += f'<p:custShow name="{name}" id="{sid}"><p:sldLst>{refs}</p:sldLst></p:custShow>'
        el = _x(f'<p:custShowLst>{shows}</p:custShowLst>')
        anchor = pres.find(_q('p:notesSz'))
        for tag in ('p:smartTags', 'p:embeddedFontLst'):
            nxt = pres.find(_q(tag))
            if nxt is not None:
                anchor = nxt
        anchor.addnext(el)
    for part in [p for p in _CTX.package.iter_parts() if hasattr(p, '_element')]:
        _fix_namespaces(part)
    return prs
# ── end runtime ──────────────────────────────────────────────────────────────
