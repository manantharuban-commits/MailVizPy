"""Deck inventory for the UI: slides, shapes, fonts, colours, transitions, animations."""
import collections
import io

from pptx import Presentation

from . import describe as D
from .ooxml import A_NS, local
from .themes import read_theme


def inventory(data):
    prs = Presentation(io.BytesIO(data))
    fonts = collections.Counter()
    sizes = collections.Counter()
    colors = collections.Counter()
    slides = []
    totals = collections.Counter()
    for i, s in enumerate(prs.slides, 1):
        sld = s._element
        names = {c.get('id'): c.get('name', '') for c in sld.iter() if local(c) == 'cNvPr'}
        shapes = []
        tree = s.shapes._spTree

        def walk(el, depth):
            for c in el:
                if local(c) in ('nvGrpSpPr', 'grpSpPr', 'extLst'):
                    continue
                kind = D.shape_kind(c)
                name, sid = D.shape_name(c)
                f, z = D.fonts_of(c)
                shapes.append({'id': sid, 'name': name, 'kind': kind, 'depth': depth,
                               'text': D.text_of(c, 80), 'fonts': sorted(f), 'sizes': sorted(z)})
                totals[kind.split(':')[0].split(' ')[0]] += 1
                if local(c) == 'grpSp':
                    walk(c, depth + 1)

        walk(tree, 0)
        for node in sld.iter():
            n = local(node)
            if n == 'latin' and node.get('typeface') and not node.get('typeface').startswith('+'):
                fonts[node.get('typeface')] += 1
            elif n in ('rPr', 'endParaRPr') and node.get('sz'):
                sizes[int(node.get('sz')) / 100] += 1
            elif n == 'srgbClr':
                colors[node.get('val', '').upper()] += 1
        tr = D.transition_info(sld)
        anims = D.animation_list(sld, names)
        notes = ''
        if s.has_notes_slide and s.notes_slide.notes_text_frame is not None:
            notes = s.notes_slide.notes_text_frame.text
        title = ''
        for sh in s.shapes:
            if sh.is_placeholder and 'TITLE' in str(sh.placeholder_format.type) and sh.has_text_frame:
                title = sh.text_frame.text.replace('\n', ' ')
                break
        slides.append({'index': i, 'title': title, 'layout': s.slide_layout.name, 'hidden': sld.get('show') == '0',
                       'transition': tr, 'transition_text': D.describe_transition(tr), 'animations': anims,
                       'notes': notes, 'shapes': shapes})
    theme = read_theme(data)
    return {
        'slide_count': len(slides),
        'size': {'width_in': round(prs.slide_width / 914400, 3), 'height_in': round(prs.slide_height / 914400, 3)},
        'slides': slides,
        'fonts': fonts.most_common(20),
        'sizes': sorted(sizes),
        'colors': colors.most_common(24),
        'theme': theme,
        'totals': dict(totals),
        'transitions': sum(1 for s in slides if s['transition']),
        'animations': sum(len(s['animations']) for s in slides),
        'masters': len(prs.slide_masters),
        'layouts': sum(len(m.slide_layouts) for m in prs.slide_masters),
    }
