"""OOXML helpers shared by the converter: namespaces, snippet serialisation, canonical
comparison and readable value formatting."""
import hashlib
import re

from lxml import etree
from pptx.opc.constants import RELATIONSHIP_TYPE as RT

NS = {
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart',
    'mc': 'http://schemas.openxmlformats.org/markup-compatibility/2006',
    'dgm': 'http://schemas.openxmlformats.org/drawingml/2006/diagram',
    'pic': 'http://schemas.openxmlformats.org/drawingml/2006/picture',
    'p14': 'http://schemas.microsoft.com/office/powerpoint/2010/main',
    'p15': 'http://schemas.microsoft.com/office/powerpoint/2012/main',
    'a14': 'http://schemas.microsoft.com/office/drawing/2010/main',
    'a16': 'http://schemas.microsoft.com/office/drawing/2014/main',
    'v': 'urn:schemas-microsoft-com:vml',
    'o': 'urn:schemas-microsoft-com:office:office',
}
R_NS = NS['r']
A_NS, P_NS, C_NS = NS['a'], NS['p'], NS['c']

# reltype URI -> 'RT.NAME' for readable generated code
RT_NAMES = {}
for _name in dir(RT):
    if _name.isupper():
        RT_NAMES.setdefault(getattr(RT, _name), f'RT.{_name}')


def local(el):
    return etree.QName(el).localname if isinstance(el.tag, str) else ''


def q(tag):
    pfx, name = tag.split(':')
    return f'{{{NS[pfx]}}}{name}'


def child(el, name):
    for c in el:
        if local(c) == name:
            return c
    return None


def children(el, name):
    return [c for c in el if local(c) == name]


class NsRegistry:
    """Collects every prefix->URI used by emitted snippets so the generated code can declare them once."""

    def __init__(self):
        self.map = dict(NS)
        self.conflicts = set()

    def collect(self, el):
        for node in el.iter():
            if not isinstance(node.tag, str):
                continue
            for pfx, uri in (node.nsmap or {}).items():
                if pfx is None:
                    continue
                if pfx not in self.map:
                    self.map[pfx] = uri
                elif self.map[pfx] != uri:
                    self.conflicts.add(pfx)
        # prefixes named only inside attribute values (mc:Ignorable / Requires)
        s = etree.tostring(el).decode('utf-8')
        for m in re.finditer(r'(?:Ignorable|Requires)="([^"]*)"', s):
            for pfx in m.group(1).split():
                uri = (el.nsmap or {}).get(pfx)
                if uri and pfx not in self.map:
                    self.map[pfx] = uri


def snippet(el, ns: NsRegistry, pretty=True):
    """Serialise an element without namespace declarations that NSMAP already provides."""
    ns.collect(el)
    s = etree.tostring(el, pretty_print=pretty, encoding='unicode').strip()

    def drop(m):
        pfx, uri = m.group(1), m.group(2)
        return '' if ns.map.get(pfx) == uri and pfx not in ns.conflicts else m.group(0)

    s = re.sub(r'\s+xmlns:([\w.-]+)="([^"]*)"', drop, s)
    return s


def py_str(s, indent=''):
    """Python literal for an XML snippet; triple-quoted raw string when multi-line."""
    if '\n' not in s and len(s) <= 100:
        return repr(s)
    if "'''" not in s and not s.endswith('\\'):
        body = s.replace('\n', '\n' + indent)
        return f"r'''\n{indent}{body}\n{indent}'''"
    return repr(s)


def fmt_len(emu):
    """Exact, readable length expression: Inches(1.25) / Pt(18) / Emu(123457)."""
    emu = int(emu)
    if emu == 0:
        return '0'
    if emu < 0:
        return '-' + fmt_len(-emu)
    for unit, per, nd in (('Inches', 914400, 3), ('Pt', 12700, 2), ('Cm', 360000, 3)):
        v = round(emu / per, nd)
        if int(v * per) == emu:
            return f'{unit}({v:g})'
    return f'Emu({emu})'


def fmt_num(v):
    f = float(v)
    return str(int(f)) if f.is_integer() else repr(f)


# ── canonical form ───────────────────────────────────────────────────────────
def canon(el, resolve=None, skip=None):
    """Hashable canonical form. r:* attribute values are resolved to what they point at."""
    if not isinstance(el.tag, str):
        return None
    attrs = []
    for k, v in el.attrib.items():
        if resolve is not None and k.startswith('{' + R_NS):
            v = resolve(v)
        attrs.append((k, v))
    kids = []
    for c in el:
        if not isinstance(c.tag, str):
            continue
        if skip and skip(c):
            continue
        kids.append(canon(c, resolve, skip))
    text = (el.text or '')
    if len(el):
        text = text.strip()
    return (el.tag, tuple(sorted(attrs)), text, tuple(kids))


def part_key(part):
    """Identity of a relationship target that survives a rebuild."""
    origin = getattr(part, '_p2c_origin', None)
    ct = getattr(part, 'content_type', '') or ''
    if not ct.endswith('xml'):
        return ('blob', hashlib.sha1(part.blob).hexdigest())
    if origin:
        return ('part', origin)
    return ('part', str(part.partname))


class _Any:
    """Stands in for a dangling relationship id; equal to anything."""

    def __eq__(self, other):
        return True

    def __lt__(self, other):
        return False

    def __hash__(self):
        return 0

    def __repr__(self):
        return 'ANY'


ANY = _Any()


def make_resolver(part, slide_index=None):
    """rId -> stable key for the relationships of `part`."""
    cache = {}
    slide_index = slide_index or {}

    def resolve(rid):
        if rid in cache:
            return cache[rid]
        rels = part.rels
        if rid not in rels:
            key = ANY
        else:
            rel = rels[rid]
            if rel.is_external:
                key = ('ext', rel.target_ref)
            elif rel.target_part in slide_index:
                key = ('slide', slide_index[rel.target_part])
            else:
                key = part_key(rel.target_part)
        cache[rid] = key
        return key

    return resolve
