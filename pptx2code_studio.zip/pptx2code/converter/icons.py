"""Bootstrap Icons as native PowerPoint shapes.

Icons are stored as DrawingML custom geometry (see tools/build_icons.py), so in the deck they are
crisp vector shapes whose colour is a theme colour: change the palette and the icons follow.
Bootstrap Icons: MIT licence, https://icons.getbootstrap.com
"""
import json
import re
from functools import lru_cache
from pathlib import Path

DATA = Path(__file__).with_name('icons_data.json')

# keyword → icon, checked in order (first match wins)
KEYWORDS = [
    (r'₹|\binr\b|rupee|lakh|crore', 'currency-rupee'),
    (r'€|\beur\b|euro', 'currency-euro'),
    (r'£|\bgbp\b|pound', 'currency-pound'),
    (r'¥|\byen\b|\bjpy\b', 'currency-yen'),
    (r'retention|renewal|repeat|recurr|churn', 'arrow-repeat'),
    (r'cost|spend|expense|budget|saving', 'wallet2'),
    (r'profit|margin|ebitda', 'cash-coin'),
    (r'\$|revenue|sales|income|earning|\barr\b|\bmrr\b|turnover|bookings|gmv|price|value', 'currency-dollar'),
    (r'decline|decrease|drop|down\b|loss', 'graph-down-arrow'),
    (r'growth|increase|grew|\byoy\b|\bqoq\b|\bup\b|gain|rise', 'graph-up-arrow'),
    (r'satisf|\bnps\b|\bcsat\b|rating|review|score|feedback|happy', 'star'),
    (r'customer|client|user|people|member|subscriber|audience|visitor', 'people'),
    (r'employee|headcount|staff|team|hire|hiring|talent|people', 'person-badge'),
    (r'order|cart|purchase|checkout|transaction|basket', 'cart3'),
    (r'ship|deliver|logistic|fleet|freight', 'truck'),
    (r'product|inventory|stock|unit|sku|item|package', 'box-seam'),
    (r'store|shop|retail|outlet', 'shop'),
    (r'office|branch|site|building|facility|campus', 'building'),
    (r'region|country|global|market|international|world|countries', 'globe2'),
    (r'location|city|address|footprint', 'geo-alt'),
    (r'hour|day|week|month|time|latency|duration|response|speed|faster', 'clock'),
    (r'deadline|schedule|calendar|date|quarter\b', 'calendar3'),
    (r'conversion|target|goal|objective|accuracy|aim', 'bullseye'),
    (r'uptime|reliab|secur|complian|risk|safe|protect', 'shield-check'),
    (r'award|rank|winner|best|top\b|leader', 'trophy'),
    (r'launch|release|new\b|start|ship', 'rocket-takeoff'),
    (r'email|mail|inbox|newsletter', 'envelope'),
    (r'traffic|visit|view|session|engagement|activity|usage', 'activity'),
    (r'performance|efficien|throughput|capacity', 'speedometer2'),
    (r'idea|innovat|insight', 'lightbulb'),
    (r'cloud|saas|platform', 'cloud'),
    (r'data|record|database|storage', 'database'),
    (r'energy|power|electric|fast', 'lightning-charge'),
    (r'health|patient|care|clinic|hospital', 'heart-pulse'),
    (r'learn|train|course|student|education|school|universit|college', 'mortarboard'),
    (r'task|complete|done|delivered|resolved|approved|success', 'check2-circle'),
    (r'funnel|pipeline|lead', 'funnel'),
    (r'%|percent|rate|share', 'percent'),
]
FALLBACK = ['bar-chart-line', 'lightning-charge', 'stars', 'layers', 'bullseye', 'gem']
PICKER = ['auto', 'currency-dollar', 'currency-rupee', 'currency-euro', 'cash-stack', 'wallet2', 'piggy-bank',
          'graph-up-arrow', 'graph-down-arrow', 'bar-chart-line', 'pie-chart', 'activity', 'speedometer2',
          'people', 'person-badge', 'emoji-smile', 'star', 'heart', 'trophy', 'award', 'cart3', 'bag', 'box-seam',
          'truck', 'shop', 'building', 'globe2', 'geo-alt', 'clock', 'calendar3', 'arrow-repeat', 'check2-circle',
          'shield-check', 'bullseye', 'rocket-takeoff', 'lightning-charge', 'lightbulb', 'gear', 'cloud',
          'database', 'envelope', 'megaphone', 'layers', 'stars', 'heart-pulse', 'mortarboard', 'funnel', 'percent']


@lru_cache(maxsize=1)
def _icons():
    try:
        return json.loads(DATA.read_text())['icons']
    except (OSError, ValueError):
        return {}


def names():
    return sorted(n for n in _icons() if not n.endswith('-fill'))


def pick(text, index=0):
    """Choose an icon from the card's own words (falls back to a neutral set)."""
    t = (text or '').lower()
    for rx, name in KEYWORDS:
        if re.search(rx, t):
            return name
    return FALLBACK[index % len(FALLBACK)]


def geometry(name, filled=False):
    icons = _icons()
    if filled and name + '-fill' in icons:
        return icons[name + '-fill']
    return icons.get(name) or icons.get(name.replace('-fill', '')) or icons.get('stars', '')


def shape_xml(nid, name, x, y, size, fill_xml, filled=False, nsdecl=''):
    """A p:sp element string: the icon as a custom-geometry shape, size x size EMU at (x, y)."""
    geo = geometry(name, filled)
    return (f'<p:sp {nsdecl}><p:nvSpPr><p:cNvPr id="{nid}" name="Icon {name} {nid}" descr="{name} icon"/>'
            f'<p:cNvSpPr><a:spLocks noChangeAspect="1"/></p:cNvSpPr><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{int(x)}" y="{int(y)}"/><a:ext cx="{int(size)}" cy="{int(size)}"/></a:xfrm>'
            f'<a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="0" t="0" r="r" b="b"/>'
            f'<a:pathLst>{geo}</a:pathLst></a:custGeom>{fill_xml}<a:ln><a:noFill/></a:ln></p:spPr>'
            f'<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp>')
