# PPTX Studio

Give an old deck a **fresh, modern look in one click**, then convert it into Python. Convert a PowerPoint deck into **Python (python-pptx) code that rebuilds it** — text with
font family, size, colour and bullets; autoshapes, freeforms, flowchart connectors and groups;
pictures with crops; tables with merges and borders; charts with editable data; backgrounds,
**transitions, animations**, hidden slides, speaker notes, links between slides, sections and
custom shows. A local web app (and a CLI) drives it, with looks, palettes and component restyling built in.

The generator **runs the code it writes, rebuilds the deck and diffs it against the source**
before handing it over, then patches anything that didn't match. A separate *Verify* step runs
the downloaded script in a fresh Python process and compares slides element by element and
pixel by pixel (via LibreOffice).

## Install & run

```bash
pip install -r requirements.txt
python app.py                 # open http://127.0.0.1:8765
```

Optional for slide previews / pixel verification: LibreOffice (`soffice` on PATH) plus
poppler (`pdftoppm`) or `pip install pymupdf`. Conversion itself needs neither.

## CLI

```bash
python cli.py deck.pptx                                  # editable code in ./deck_code/
python cli.py deck.pptx --mode exact --single            # one self-contained .py (assets base64-embedded)
python cli.py deck.pptx --look fresh                     # modernise with a look, then generate code
python cli.py deck.pptx --look finance --deck-only       # just write deck_code/deck_modern.pptx
python cli.py deck.pptx --look cobalt --restyle chart=bold,table=striped --chart-type bar
python cli.py deck.pptx --brand DB0011 --font segoe          # fresh palette from one brand colour
python cli.py deck.pptx --look house-red --title-accent DB0011
python cli.py deck.pptx --verify                         # run the output and compare with the source
python cli.py --capture sample.pptx 3:7 --name "Brand heat"   # save a design copied from slide 3, shape 7
python cli.py deck.pptx --restyle heatmap=my:brand-heat-1a2b    # use one of your own designs
python cli.py deck.pptx --designs team_designs.json --restyle chart=my:team-bars-9f00
python cli.py --looks                                    # list looks and font pairs
python cli.py --styles                                   # list component style ids
```

## What the generated code looks like

```python
def slide_02(prs):
    """Slide 2 · What changed this quarter
    Layout: Title Only · 3 shapes
    Transition: Push (up), 0.75 s, advances on click
    Animations: 3
    """
    slide = _new_slide(prs, master=0, layout=5, keep_placeholders=True, rels={...})
    # ── [3] TextBox 2 · textbox · "Revenue grew 18% year over year / …" · Calibri · 22/26pt
    textbox_2 = slide.shapes.add_textbox(Inches(0.8), Inches(1.7), Inches(7.2), Inches(4.8))
    _place(slide, textbox_2, 3, 'TextBox 2')
    _frame(textbox_2, wrap='square', autofit='shape')
    p = _para(textbox_2, 0, marL=Inches(0.375), indent=-Inches(0.375), line_spacing=Pct(115),
              space_after=Pt(14), bullet_color='0EA59B', bullet_font='Arial', bullet='•')
    _run(p, 'Revenue grew ', size=22, color='5B677A', font='Calibri')
    _run(p, '18%', size=26, bold=True, color='0EA59B', font='Calibri')
    ...
    _transition(slide, '<p:transition spd="med"><p:push dir="u"/></p:transition>')
    _timing(slide, r'''<p:timing> … </p:timing>''')   # On click: Fly In → TextBox 2; …
```

* **Editable mode** (default): python-pptx calls plus small helpers that live at the top of
  the file (`_run`, `_para`, `_frame`, `_fill`, `_line`, `_style`, `_cell`, `_merge`, `_connect`,
  `_chart_style` …). Anything python-pptx can't express (shadows on text, 3-D, freeform paths,
  exact theme tints, Office extension data) is restored by a targeted `_sync(shape, 'spPr/effectLst', …)`.
* **Exact mode**: every shape is written as its original OOXML — the most compact way to get a
  lossless rebuild.
* Charts are built from `CategoryChartData` / `XyChartData` / `BubbleChartData`; `_chart_style`
  re-applies the original chart formatting and then your (editable) data. Chart types the data
  API can't express (stock, surface, text-x scatter, 2016 chartex) are copied exactly.
* SmartArt, OLE objects, media and ink are copied with all their parts.
* Masters, layouts, theme and embedded fonts travel in `assets/template.pptx`.

## Design studio: looks, palettes, components

The **Design** view shows the current slide large, with a draggable **before / after** divider.
Every change re-renders that slide (about 1.5 s with LibreOffice), and a filmstrip shows
**the same slide in every look**, rendered for real, so you can pick by result rather than by
swatch. *All slides* renders the whole deck; hover a slide to see the original.

### Looks (one click: palette + fonts + every component), light designs only

Each look follows a pattern from modern dashboard and infographic design.

| Look | Fonts | Page | KPI cards | Charts & tables |
|---|---|---|---|---|
| Fresh Indigo | Aptos | canvas | KPI card | clean, header-rule cards |
| Finance Teal | Segoe UI | mint-grey canvas | icon header, coloured figures | icon-badge cards |
| Analytics | Segoe UI (Light figures) | white | spotlight: thin numbers, one card in orange | smooth lines, grey panels |
| Navy Sky | Segoe UI | canvas | side icon, icon only | centred titles |
| Electric | Segoe UI | canvas | lavender tinted cards, soft chips | smooth, white cards |
| Vivid Tiles | Segoe UI | canvas | gradient tiles | clean, header-rule cards |
| Cobalt | Segoe UI | white | KPI strip with solid icon chips and dividers | grey panels, CAPS titles, brand heatmap |
| Royal Numbers | Segoe UI | white | "by the numbers" solid tiles, huge figures | bold numbers, decision-matrix tables, typed flowcharts |
| Mint | Aptos | glow | accent line | smooth, accent-line cards |
| Sunset | Poppins + Inter | canvas | gradient | fading bars, white cards |
| Graphite | Inter | white | outline | highlight, outline cards |
| House Red | Segoe UI | canvas | accent bar | highlight; #DB0011 only on title bars |

On top of a look you can edit any palette swatch, **build a palette from one brand colour**
(the brand colour plus five curated, evenly bright hues), swap the font pair, and put a brand
colour on the title bars only. Every design is light: decks that start dark are converted to
light, and dark title slides are redrawn light with an accent glow (their text turns to ink).

### Component designs, picked from a gallery

Every component kind in the Design panel opens a **style gallery**: each design rendered for
real, on a sample slide or on **your own slide**, in your current look and colours. Click one
to apply it to every component of that kind; *On this slide* overrides single items (style,
chart type, container, icon).

| Component | Designs |
|---|---|
| KPI cards (19) | KPI card, Side icon, Icon header, KPI strip, By the numbers, Gradient tile, Spotlight, Light numbers, Tinted, Corner icon, Accent line, Accent bar, Centred badge, Soft, Floating, Outline, Solid colour, Gradient, Minimal. **Bootstrap icons** chosen from the card's words (revenue → $, ₹ → rupee, customers → people, retention → repeat, growth → trend…) as solid chips, round badges, soft chips, icon only, or none. Figures are split dashboard-style (small "$", big "4.2", small "M"); a card that says "Sales up 12%" becomes a muted "Sales up" over a big "12%"; up/down notes turn green/red |
| Charts (14) | Clean, Highlight, Bold numbers, Direct labels, Smooth, Gradient, Fade, Monochrome, Duotone, Pastel, Outline, Slim, Blueprint, Thin ring — plus a **chart type switch** (column, bar, stacked, line, area, pie, doughnut). Legends become **dot chips in a grey pill** (or keep the standard legend); doughnuts get their lead share in the centre |
| Containers (10) | Every chart and table sits on **its own card**: Card, Header rule, Icon header (round icon badge before the title), Grey panel (CAPS title), Centred title, Accent line, Floating, Outline, Tinted, or none. The chart's title moves into the card header |
| Heatmaps (14) | For numeric tables: Brand ramp, Tiles, Two-tone, Ocean, Sunset, Violet, Mint, Viridis, Traffic, Diverging, Per row, Per column, Coloured numbers, Top values. Mixed units ($M beside %) are scaled per column |
| Tables (12) | Clean, Soft header, Striped, Accent header, Ink header, Minimal, Fine grid, Card rows, Column bands, Ledger, Compact, Blocks (decision-matrix: dark header and first-column blocks, cells with gaps) |
| Shapes (8) | Soft tint, Solid, Gradient, Soft gradient, Outline, Tint + edge, Muted, Floating |
| Flowcharts (11) | Pills, Chips, Solid, Outline, Tinted boxes, Neutral, Rainbow, Gradient, Dashed links, Bold arrows, Typed (pill start/end, tinted process boxes, solid decision diamonds); arrow directions kept, diamond text sized so words never break |
| Pictures (11) | Rounded, Extra round, Soft shadow, Colour glow, Frame, Accent edge, Arch, Circle, Black & white, Duotone, Plain |
| Titles (10) | Modern, Accent bar, Side bar, Accent dot, Rule, Accent colour, Gradient text, Editorial, Caps, Centred |
| Body text (8) | Modern, Airy, Compact, Check marks, Arrows, Dashes, Numbered, Lead line |
| Backgrounds (11) | Canvas, White, Glow, Soft fade, Top band, Mesh, Aurora, Spotlight, Corner glow, Dot grid, Graph paper |

Icons are [Bootstrap Icons](https://icons.getbootstrap.com) (MIT licence) converted to native
DrawingML shapes by `tools/build_icons.py`: crisp at any size, coloured by the theme, editable in
PowerPoint. 169 glyphs ship in `converter/icons_data.json`.

`python samples/make_specimen.py` rebuilds the sample deck the gallery uses. Previews come from
LibreOffice, which draws gradient text as a solid colour; PowerPoint shows the gradient.

The design rules behind every style: surfaces instead of borders; one corner radius (0.12 in)
whatever the size; no bevels, 3-D, glow or decorative gradients (theme shadows are switched
off too); left-aligned, tightly tracked bold titles; muted body ink with accent bullets;
charts without borders or axis lines, a faint grid, legend on top, bars starting at zero and
horizontal bars reading top-down; numbers right-aligned in tables with the total row
detected. Light text placed on pictures or dark panels stays light; picture backgrounds are
kept; text pushed right with tabs becomes right-aligned.

Everything is written as theme references (accent 1–6, text, background), so palette and
light/dark changes flow through. The pipeline is **source → palette & fonts → components →
code**, and the generated code rebuilds the redesigned deck element for element (self-checked
for every look, component design, container and icon mode across the test decks).

### Your own designs

Every gallery ends with **My designs** and a **Create your own** card. The builder opens beside a
live preview (on the sample slide, on your own slide, or next to the sample you copied from):

* **Start from** any built-in design, then change its settings. For a heatmap: the colour ramp
  (2–8 stops, theme colours or exact hex, with presets), coloured cells / coloured numbers / top
  values, scale per table, row or column, diverging around the median, gap between cells and its
  colour, number colour and weight, alignment, padding, text size, and the header row, first
  column and total row (bold, ruled or filled in any colour). Tables, charts, KPI cards,
  flowcharts, shapes, pictures, titles, body text and backgrounds each have their own settings
  (series colours, bar gap and overlap, gridlines, labels, legend; card surface, colour, radius,
  shadow, edge, layout and icon style; step shape and fill, decision and start/end colours, arrow
  colour, width and dash; and so on).
* **Copy from my sample**: pick a slide in this deck or upload another deck, then click a
  component. Its colours, gaps, borders, sizes and layout are read and become the settings; for
  tables this includes PowerPoint's own table styles (banding, filled header). Tick *Theme colours
  follow the deck palette* to keep theme colours as theme references, so the design recolours with
  each look; otherwise every colour is kept exactly.

Saved designs live in `designs/my_designs.json` (or the file named by `PPTX_STUDIO_DESIGNS`), appear
in the gallery and in *On this slide*, and can be exported and imported as one JSON file to share
with a team. In a design spec they are styles named `my:<id>`; the generated code rebuilds them
like any other design.

### Palette conversion details

| Setting | Choices |
|---|---|
| Hard-coded colours | follow the palette (nearest slot, tint kept) / only exact theme colours / unchanged |
| Fonts | every text run / only the old theme fonts / theme slots only |

Light↔dark conversions flip neutral colours by role (light fills and dark text invert; dark
panels and light text stay), switch built-in table styles, and leave slides with picture
backgrounds on their original mapping so text stays readable.

**Fonts:** Aptos is the Microsoft 365 default and Segoe UI ships with Windows (thin figures
use Segoe UI Light / Aptos Light); Inter, Poppins and Manrope are free Google fonts — install
them on the machines that will show the deck. The previews substitute Inter for Aptos and
Segoe UI, so PowerPoint will look slightly different in letter shapes, not in layout.

## Project layout

```
app.py                 Flask server: live slide previews, every-look renders, export
cli.py                 command line
converter/
  codegen.py           generator (editable / exact), self-check loop
  runtime.py           helpers embedded into every generated script
  diff.py              structural diff → exact patches
  looks.py             looks, palettes and font pairs (the design system)
  icons.py             Bootstrap icons as native shapes + keyword auto-pick
  custom.py            your own designs: settings schema, renderers, capture from a sample, storage
  design.py            one design spec -> palette/fonts conversion + component restyle
  themes.py            palette conversion, light/dark flip, brand-colour palette builder
  restyle.py           component detection + modern component styles
  verify.py            run generated code, structural + pixel comparison
  inspect_deck.py      inventory for the UI
  describe.py          names for transitions, animations, shapes
  ooxml.py             namespaces, canonical XML, formatting
static/                UI (no build step)
samples/make_sample.py builds a feature-rich test deck
samples/make_specimen.py builds the gallery's sample deck (one old-style example per component)
tools/build_icons.py   converts Bootstrap Icons to DrawingML (converter/icons_data.json)
```

## Limits worth knowing

* The rebuilt file is compared structurally; PowerPoint itself is not available to the tool, so
  pixel checks use LibreOffice's renderer.
* Chart numbers are compared by value (Excel stores 17 significant digits; the rebuild writes the
  shortest equivalent).
* Raster images can't be recoloured by theme conversion.
